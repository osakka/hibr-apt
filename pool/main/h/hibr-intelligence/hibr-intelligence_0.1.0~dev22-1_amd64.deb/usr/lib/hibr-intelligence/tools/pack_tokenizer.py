#!/usr/bin/env python3
"""Compile a supported Hugging Face tokenizer recipe into a bounded HIBTOK3 index."""
import argparse
import hashlib
import json
import struct
from pathlib import Path
from unicode_categories import RANGES

MAGIC = b'HIBTOK3\0'
ALPHABET = list(range(33, 127)) + list(range(161, 173)) + list(range(174, 256))
RECIPES = {'gpt2-byte-bpe-digit-split-v1': 1, 'byte-bpe-unicode-nfc-v1': 2,
           'gpt2-byte-bpe-v1': 3, 'sentencepiece-bpe-byte-fallback-v1': 4,
           'gpt2-byte-bpe-nfc-v1': 5}
CHARS = ALPHABET[:]
counter = 0
for byte in range(256):
    if byte not in ALPHABET:
        ALPHABET.append(byte)
        CHARS.append(256 + counter)
        counter += 1
BYTE_FOR_CHAR = {chr(codepoint): byte for byte, codepoint in zip(ALPHABET, CHARS)}


def token_bytes(text, special):
    if special:
        return text.encode('utf-8')
    try:
        return bytes(BYTE_FOR_CHAR[char] for char in text)
    except KeyError as error:
        raise ValueError(f'token is outside the GPT-2 byte alphabet: {text!r}') from error


def merge_pieces(merges, vocab):
    result = []
    for rank, merge in enumerate(merges):
        if isinstance(merge, str):
            if merge.count(' ') != 1:
                raise ValueError(f'unsupported merge record at rank {rank}')
            left, right = merge.split(' ')
        elif isinstance(merge, list) and len(merge) == 2 and all(isinstance(piece,str) for piece in merge):
            left, right = merge
        else:
            raise ValueError(f'unsupported merge record at rank {rank}')
        try:
            left_id, right_id = vocab[left], vocab[right]
            result_id = vocab[left + right]
        except KeyError as error:
            raise ValueError(f'merge references missing vocabulary token at rank {rank}') from error
        result.append((left_id,right_id,result_id))
    return result


def compile_tokenizer(source, destination, recipe):
    if recipe not in RECIPES:
        raise ValueError(f'no native tokenizer compiler is registered for {recipe!r}')
    raw = source.read_bytes()
    if not 0 < len(raw) <= 16 * 1024 * 1024:
        raise ValueError('tokenizer JSON exceeds the 16 MiB input bound')
    data = json.loads(raw)
    model = data.get('model', {})
    if model.get('type') != 'BPE' and not (recipe in ('gpt2-byte-bpe-v1','gpt2-byte-bpe-nfc-v1') and
            'vocab' in model and 'merges' in model and 'type' not in model):
        raise ValueError('only BPE tokenizers are supported')
    pretokenizer = data.get('pre_tokenizer')
    steps = pretokenizer.get('pretokenizers', []) if isinstance(pretokenizer, dict) else []
    if recipe in ('gpt2-byte-bpe-v1','gpt2-byte-bpe-nfc-v1'):
        supported = None
        expected_normalizer={'type':'NFC'} if recipe=='gpt2-byte-bpe-nfc-v1' else None
        if data.get('normalizer') != expected_normalizer:
            raise ValueError(f'{recipe} requires normalizer {expected_normalizer!r}')
        bytelevel={'type':'ByteLevel','add_prefix_space':False,'trim_offsets':True}
        if data.get('pre_tokenizer') not in (bytelevel,{**bytelevel,'use_regex':True}):
            raise ValueError('gpt2-byte-bpe-v1 requires canonical ByteLevel(use_regex=true)')
        if data.get('decoder') not in ({'type':'ByteLevel','add_prefix_space':True,'trim_offsets':True},
                                       {**bytelevel,'use_regex':True}):
            raise ValueError('gpt2-byte-bpe-v1 requires the declared ByteLevel decoder')
        if data.get('post_processor') not in ({'type':'ByteLevel','add_prefix_space':True,'trim_offsets':False},
                                             {**bytelevel,'use_regex':True}):
            raise ValueError('gpt2-byte-bpe-v1 requires the offset-only ByteLevel post-processor')
    elif recipe == 'gpt2-byte-bpe-digit-split-v1':
        if data.get('normalizer') is not None:
            raise ValueError('gpt2-byte-bpe-digit-split-v1 requires no normalizer')
        supported = [{'type': 'Digits', 'individual_digits': True},
                     {'type': 'ByteLevel', 'add_prefix_space': False, 'trim_offsets': True,
                      'use_regex': True}]
    elif recipe == 'sentencepiece-bpe-byte-fallback-v1':
        normalizer = {'type':'Sequence','normalizers':[
            {'type':'Prepend','prepend':'▁'},
            {'type':'Replace','pattern':{'String':' '},'content':'▁'}]}
        decoder = {'type':'Sequence','decoders':[
            {'type':'Replace','pattern':{'String':'▁'},'content':' '},
            {'type':'ByteFallback'},{'type':'Fuse'},
            {'type':'Strip','content':' ','start':1,'stop':0}]}
        if (data.get('normalizer') != normalizer or data.get('pre_tokenizer') is not None or
                data.get('decoder') != decoder or not isinstance(data.get('post_processor'),dict) or
                data['post_processor'].get('type') != 'TemplateProcessing' or
                model.get('byte_fallback') is not True or model.get('fuse_unk') is not True or
                model.get('unk_token') not in model.get('vocab',{})):
            raise ValueError('sentencepiece-bpe-byte-fallback-v1 requires canonical metaspace normalization, byte fallback, and decoder')
        supported = None
    else:
        pattern = "(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?\\p{L}+|\\p{N}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+"
        if data.get('normalizer') != {'type': 'NFC'}:
            raise ValueError('byte-bpe-unicode-nfc-v1 requires NFC normalization')
        supported = [{'type': 'Split', 'pattern': {'Regex': pattern},
                      'behavior': 'Isolated', 'invert': False},
                     {'type': 'ByteLevel', 'add_prefix_space': False, 'trim_offsets': False,
                      'use_regex': False}]
    if supported is not None and steps != supported:
        raise ValueError(f'unsupported pre-tokenizer for {recipe}')
    vocab = data['model']['vocab']
    ids = sorted(vocab.values())
    if ids != list(range(len(ids))) or len(ids) > 262144:
        raise ValueError('model vocabulary IDs must be dense and bounded')
    added = data.get('added_tokens', [])
    if not isinstance(added, list) or any(not isinstance(token, dict) for token in added):
        raise ValueError('added_tokens must be an array')
    if any(type(token.get('id')) is not int or token['id'] < 0 or token['id'] >= 262144
           for token in added):
        raise ValueError('added token ID is outside the bounded vocabulary')
    seen_added_ids, seen_added_text = set(), set()
    for token in added:
        if not isinstance(token, dict) or not isinstance(token.get('content'), str) or not token['content']:
            raise ValueError('added token content must be nonempty text')
        if any(token.get(flag, False) is not False for flag in ('single_word', 'lstrip', 'rstrip')) or (
                token.get('normalized', False) is not False and
        not (recipe in ('gpt2-byte-bpe-v1','gpt2-byte-bpe-nfc-v1') and token.get('normalized') is True)):
            raise ValueError('added-token matching flags are unsupported')
        if type(token.get('special', False)) is not bool:
            raise ValueError('added-token special flag must be boolean')
        if token['id'] in seen_added_ids or token['content'] in seen_added_text:
            raise ValueError('added token IDs and contents must be unique')
        seen_added_ids.add(token['id']); seen_added_text.add(token['content'])
    limit = max([len(ids)-1, *(token['id'] for token in added)], default=-1)+1
    if not 0 < limit <= 262144:
        raise ValueError('tokenizer ID space is empty or exceeds its bound')
    added_ids = {token['id'] for token in added}
    specials = {token['id'] for token in added if token.get('special')}
    by_id = [None] * limit
    for token, token_id in vocab.items():
        by_id[token_id] = token
    for token in added:
        token_id, content = token['id'], token.get('content')
        if not isinstance(content, str) or not content:
            raise ValueError('added token content must be nonempty text')
        if by_id[token_id] is not None and by_id[token_id] != content:
            raise ValueError('added token conflicts with the model vocabulary')
        by_id[token_id] = content
    if any(token is None for token in by_id):
        raise ValueError('sparse tokenizer ID spaces are not supported')
    # Include every valid Unicode-category run. Unknown/unassigned code points
    # have category zero and are refused by the runtime.
    codepoint_ranges = RANGES
    merges = data['model']['merges']
    if len(merges) > 262144:
        raise ValueError('merge table exceeds the runtime bound')
    output = bytearray(MAGIC)
    output.extend(hashlib.sha256(raw).digest())
    output.extend(struct.pack('<I', RECIPES[recipe]))
    output.extend(struct.pack('<IIIII', limit, len(merges), len(added_ids), len(specials), len(codepoint_ranges)))
    for first, last, kind in codepoint_ranges:
        output.extend(struct.pack('<IIB', first, last, kind))
    for token_id, text in enumerate(by_id):
        if token_id in added_ids:
            encoded = text.encode('utf-8')
        elif recipe == 'sentencepiece-bpe-byte-fallback-v1':
            encoded = text.encode('utf-8')
        else:
            encoded = token_bytes(text, False)
        if len(encoded) > 4096:
            raise ValueError('vocabulary token exceeds the 4 KiB bound')
        flags = int(token_id in added_ids) | (int(token_id in specials) << 1)
        output.extend(struct.pack('<IB', len(encoded), flags))
        output.extend(encoded)
    for left_id, right_id, result_id in merge_pieces(merges,vocab):
        output.extend(struct.pack('<III', left_id, right_id, result_id))
    destination.write_bytes(output)
    return hashlib.sha256(raw).hexdigest(), hashlib.sha256(output).hexdigest(), len(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--recipe', required=True, choices=tuple(RECIPES))
    args = parser.parse_args()
    source_sha, output_sha, size = compile_tokenizer(args.source, args.destination, args.recipe)
    print(json.dumps({'format': 'HIBTOK3', 'recipe': args.recipe, 'source_sha256': source_sha,
                      'compiled_sha256': output_sha, 'bytes': size}, sort_keys=True))


if __name__ == '__main__':
    main()
