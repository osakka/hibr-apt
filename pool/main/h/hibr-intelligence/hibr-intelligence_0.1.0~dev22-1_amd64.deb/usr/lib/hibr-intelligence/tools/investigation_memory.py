"""Save, reopen and refresh one source-bound Hibr investigation locally."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile

from export_briefs import ROOT, collect, source_bytes
from hibr_runtime import as_layout, hibr_layout

FORMAT = 'HIBR-INVESTIGATION-MEMORY-1'
MAX_MEMORY_BYTES = 8 * 1024 * 1024
SHA256 = re.compile(r'^[0-9a-f]{64}$')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def digest_file(path, maximum=256 * 1024 * 1024):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) |
                 getattr(os, 'O_NONBLOCK', 0))
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > maximum:
            raise ValueError('Producer file is not a bounded regular file')
        hasher = hashlib.sha256()
        with os.fdopen(fd, 'rb') as stream:
            fd = -1
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                hasher.update(chunk)
        return hasher.hexdigest()
    finally:
        if fd >= 0:
            os.close(fd)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':')).encode('utf-8')


def read_private(path, maximum):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) |
                  getattr(os, 'O_NONBLOCK', 0))
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or
                info.st_mode & 0o077 or info.st_size > maximum):
            raise ValueError('Investigation memory file is not a bounded private regular file')
        with os.fdopen(fd, 'rb') as stream:
            fd = -1
            raw = stream.read(maximum + 1)
    finally:
        if fd >= 0:
            os.close(fd)
    if len(raw) > maximum:
        raise ValueError('Investigation memory file exceeds its byte limit')
    return raw


def write_private(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def load(folder):
    folder = Path(folder)
    if folder.is_symlink() or not folder.is_dir():
        raise ValueError('Refuse redirected or missing investigation memory')
    folder = folder.resolve(strict=True)
    info = folder.stat(follow_symlinks=False)
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or
            info.st_mode & 0o077):
        raise ValueError('Investigation memory directory must be owned by this user and private')
    if sorted(item.name for item in folder.iterdir()) != ['manifest.json', 'packet.json']:
        raise ValueError('Investigation memory must contain exactly manifest.json and packet.json')
    manifest_raw = read_private(folder / 'manifest.json', 64 * 1024)
    packet_raw = read_private(folder / 'packet.json', MAX_MEMORY_BYTES)
    manifest = json.loads(manifest_raw)
    packet = json.loads(packet_raw)
    manifest_fields = {'format', 'version', 'source_path', 'source_sha256',
                       'source_identity', 'function', 'question', 'note',
                       'hibr_version', 'hibr_binary_sha256', 'renderer_sha256',
                       'hibr_path', 'packet_sha256', 'supersedes', 'memory_id'}
    if not isinstance(manifest, dict) or set(manifest) != manifest_fields:
        raise ValueError('Investigation memory manifest has an unsupported shape')
    if (manifest['format'] != FORMAT or type(manifest['version']) is not int or
            manifest['version'] != 1 or
            any(not isinstance(manifest[key], str) for key in
                ('source_path', 'source_identity', 'function', 'question', 'note',
                 'hibr_version', 'hibr_path', 'supersedes')) or
            not 1 <= len(manifest['source_path']) <= 4096 or
            not 1 <= len(manifest['source_identity']) <= 256 or
            not 1 <= len(manifest['hibr_path']) <= 4096 or
            not 1 <= len(manifest['function']) <= 256 or
            not 1 <= len(manifest['question'].encode('utf-8')) <= 2048 or
            len(manifest['note'].encode('utf-8')) > 8192 or
            len(manifest['hibr_version']) > 256 or
            any(not SHA256.fullmatch(manifest[key]) for key in
                ('source_sha256', 'hibr_binary_sha256', 'renderer_sha256',
                 'packet_sha256', 'memory_id')) or
            (manifest['supersedes'] and not SHA256.fullmatch(manifest['supersedes']))):
        raise ValueError('Investigation memory manifest fields are invalid')
    if not isinstance(packet, dict):
        raise ValueError('Stored native investigation packet must be an object')
    if (manifest['format'] != FORMAT or
            manifest.get('packet_sha256') != digest(packet_raw) or
            manifest.get('memory_id') != digest(canonical({k: v for k, v in manifest.items()
                                                           if k != 'memory_id'}))):
        raise ValueError('Investigation memory identity or packet hash is invalid')
    if (packet.get('state') != 'ready' or packet.get('name') != manifest.get('function') or
            packet.get('identity') != manifest.get('source_identity')):
        raise ValueError('Stored native packet does not match investigation metadata')
    return folder, manifest, packet


def source_status(manifest):
    try:
        raw = source_bytes(Path(manifest['source_path']))
    except (OSError, ValueError):
        return 'unavailable'
    return 'current' if digest(raw) == manifest['source_sha256'] else 'stale'


def recall(folder):
    folder, manifest, packet = load(folder)
    try:
        producer_status = ('current' if digest_file(manifest['hibr_path']) ==
                           manifest['hibr_binary_sha256'] else 'changed-or-unavailable')
    except (OSError, ValueError):
        producer_status = 'changed-or-unavailable'
    try:
        renderer_status = ('current' if digest_file(ROOT / 'apps/Development/coding.hibr') ==
                           manifest['renderer_sha256'] else 'changed-or-unavailable')
    except (OSError, ValueError):
        renderer_status = 'changed-or-unavailable'
    source_state = source_status(manifest)
    evidence_current = (source_state == 'current' and
                        producer_status == 'current' and
                        renderer_status == 'current')
    return {'format': FORMAT, 'memory_id': manifest['memory_id'],
            'question': manifest['question'], 'note': manifest['note'],
            'source_path': manifest['source_path'], 'function': manifest['function'],
            'source_identity': manifest['source_identity'],
            'source_status': source_state,
            'producer_status': producer_status,
            'renderer_status': renderer_status,
            'evidence_status': 'current' if evidence_current else 'historical',
            'usable_as_current_evidence': evidence_current,
            'source_sha256': manifest['source_sha256'],
            'producer_hibr_version': manifest['hibr_version'],
            'producer_binary_sha256': manifest['hibr_binary_sha256'],
            'packet_sha256': manifest['packet_sha256'],
            'packet': packet,
            'authority': 'historical evidence only; no execution or action permission'}


def save(provider, source, function, question, note, output, supersedes='',
         expected_source_identity='', expected_source_sha256=''):
    provider = as_layout(provider)
    source = Path(source).resolve(strict=True)
    output = Path(output).absolute()
    if not function or len(function) > 256:
        raise ValueError('Function name must contain 1..256 characters')
    if not question.strip() or len(question.encode('utf-8')) > 2048:
        raise ValueError('Question must contain 1..2048 UTF-8 bytes')
    if len(note.encode('utf-8')) > 8192:
        raise ValueError('User note exceeds 8 KiB')
    before = source_bytes(source)
    origin, packets = collect(provider, source, function)
    after = source_bytes(source)
    if before != after:
        raise ValueError('Source changed during investigation capture')
    if (not isinstance(origin.get('identity'), str) or
            not 1 <= len(origin['identity']) <= 256):
        raise ValueError('Native source identity is missing or exceeds its bound')
    if expected_source_identity and origin['identity'] != expected_source_identity:
        raise ValueError('Current Hibr source identity differs from the attached investigation')
    if expected_source_sha256 and digest(before) != expected_source_sha256:
        raise ValueError('Current source SHA-256 differs from the attached investigation')
    matching = [packet for packet in packets if packet.get('name') == function]
    if len(matching) != 1 or matching[0].get('state') != 'ready':
        raise ValueError('Native Hibr did not produce one unambiguous ready function packet')
    packet_raw = (json.dumps(matching[0], ensure_ascii=False, sort_keys=True,
                             separators=(',', ':')) + '\n').encode('utf-8')
    if len(packet_raw) > MAX_MEMORY_BYTES:
        raise ValueError('Native investigation packet exceeds 8 MiB')
    manifest = {'format': FORMAT, 'version': 1,
                'source_path': str(source), 'source_sha256': digest(before),
                'source_identity': origin['identity'], 'function': function,
                'question': question, 'note': note,
                'hibr_version': subprocess.check_output(
                    [str(provider.executable), '--version'], text=True).strip(),
                'hibr_binary_sha256': digest_file(provider.executable),
                'renderer_sha256': digest_file(ROOT / 'apps/Development/coding.hibr'),
                'hibr_path': str(provider.executable),
                'packet_sha256': digest(packet_raw), 'supersedes': supersedes}
    manifest['memory_id'] = digest(canonical(manifest))
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    if output.exists() or output.is_symlink():
        raise FileExistsError(f'Investigation memory output already exists: {output}')
    output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.investigation-memory-', dir=output.parent))
    os.chmod(stage, 0o700)
    claimed = None
    try:
        write_private(stage / 'packet.json', packet_raw)
        write_private(stage / 'manifest.json', manifest_raw)
        os.mkdir(output, 0o700)
        claimed = output.stat(follow_symlinks=False)
        for name in ('packet.json', 'manifest.json'):
            os.rename(stage / name, output / name)
        stage.rmdir()
        output_fd = os.open(output, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(output_fd)
        finally:
            os.close(output_fd)
        parent_fd = os.open(output.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        try:
            info = output.stat(follow_symlinks=False)
            if claimed and (info.st_dev, info.st_ino) == (claimed.st_dev, claimed.st_ino):
                entries = list(output.iterdir())
                if all(entry.name in {'manifest.json', 'packet.json'} and
                       not entry.is_symlink() and entry.is_file() and
                       entry.stat(follow_symlinks=False).st_uid == os.geteuid()
                       for entry in entries):
                    for entry in entries:
                        entry.unlink()
                    output.rmdir()
        except FileNotFoundError:
            pass
        raise
    return recall(output)


def refresh(provider, folder, output):
    _, manifest, _ = load(folder)
    return save(provider, manifest['source_path'], manifest['function'],
                manifest['question'], manifest['note'], output,
                supersedes=manifest['memory_id'])


def list_memories(root, after='', limit=8):
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('Refuse redirected or missing investigation directory')
    root = root.resolve(strict=True)
    root_info = root.stat(follow_symlinks=False)
    if (not stat.S_ISDIR(root_info.st_mode) or root_info.st_uid != os.geteuid() or
            root_info.st_mode & 0o077):
        raise ValueError('Investigation directory must be owned by this user and private')
    if (type(limit) is not int or not 1 <= limit <= 8 or
            not isinstance(after, str) or len(after) > 255 or
            '/' in after or after in ('.', '..')):
        raise ValueError('Investigation list page must be 1..8 with a simple directory cursor')
    children = sorted(root.iterdir(), key=lambda path: path.name)
    if len(children) > 1024:
        raise ValueError('Investigation directory exceeds the 1024-entry scan bound')
    candidates = []
    for child in children:
        info = child.stat(follow_symlinks=False)
        if stat.S_ISLNK(info.st_mode):
            candidates.append((child.name, 'redirected'))
        elif stat.S_ISDIR(info.st_mode):
            names = {item.name for item in child.iterdir()}
            if {'manifest.json', 'packet.json'} & names:
                candidates.append((child.name, 'memory'))
    candidates = [(name, kind) for name, kind in candidates if name > after]
    page = candidates[:limit]
    memories = []
    for name, kind in page:
        if kind == 'redirected':
            memories.append({'directory': name, 'status': 'refused',
                             'reason': 'symbolic links are not followed'})
            continue
        try:
            record = recall(root / name)
            memories.append({
                'directory': name,
                'status': 'valid',
                'memory_id': record['memory_id'],
                'question': record['question'][:256],
                'question_truncated': len(record['question']) > 256,
                'note': record['note'][:256],
                'note_truncated': len(record['note']) > 256,
                'source_path': record['source_path'][:512],
                'source_path_truncated': len(record['source_path']) > 512,
                'function': record['function'],
                'source_status': record['source_status'],
                'producer_status': record['producer_status'],
                'renderer_status': record['renderer_status'],
                'evidence_status': record['evidence_status'],
                'usable_as_current_evidence': record['usable_as_current_evidence']})
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
            memories.append({'directory': name, 'status': 'invalid',
                             'reason': str(error)[:256]})
    has_more = len(candidates) > len(page)
    return {'format': FORMAT, 'root': str(root), 'count_returned': len(page),
            'more_available': has_more,
            'next_after': page[-1][0] if has_more and page else '',
            'memories': memories}


def forget(folder):
    folder, manifest, _ = load(folder)
    root_info = folder.stat(follow_symlinks=False)
    total = 0
    for name in ('manifest.json', 'packet.json'):
        info = (folder / name).stat(follow_symlinks=False)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise ValueError('Investigation memory contains a redirected or non-private file')
        total += info.st_size
    if total > MAX_MEMORY_BYTES + 64 * 1024:
        raise ValueError('Investigation memory exceeds its deletion bound')
    if root_info.st_uid != os.geteuid() or root_info.st_mode & 0o077:
        raise ValueError('Investigation memory directory is not private')
    if load(folder)[1]['memory_id'] != manifest['memory_id']:
        raise ValueError('Investigation memory changed before deletion')
    shutil.rmtree(folder)
    return {'forgotten': True, 'memory_id': manifest['memory_id'], 'bytes_removed': total}


def summarize(result):
    packet = result.get('packet', {})
    return {key: value for key, value in result.items() if key != 'packet'} | {
        'brief': packet.get('text', '')[:12000],
        'evidence_ids': [item.get('id', '') for item in packet.get('evidence', [])],
        'runtime': packet.get('runtime', 'not-observed')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    create = sub.add_parser('save')
    create.add_argument('--hibr', required=True, type=Path)
    create.add_argument('--desktop', type=Path)
    create.add_argument('--source', required=True, type=Path)
    create.add_argument('--function', required=True)
    create.add_argument('--question', required=True)
    create.add_argument('--note', default='')
    create.add_argument('--expected-source-identity', default='')
    create.add_argument('--expected-source-sha256', default='')
    create.add_argument('--output', required=True, type=Path)
    create.add_argument('--summary', action='store_true')
    open_parser = sub.add_parser('recall')
    open_parser.add_argument('folder', type=Path)
    open_parser.add_argument('--summary', action='store_true')
    update = sub.add_parser('refresh')
    update.add_argument('--hibr', required=True, type=Path)
    update.add_argument('--desktop', type=Path)
    update.add_argument('folder', type=Path)
    update.add_argument('--output', required=True, type=Path)
    update.add_argument('--summary', action='store_true')
    listing = sub.add_parser('list')
    listing.add_argument('root', type=Path)
    listing.add_argument('--after', default='')
    listing.add_argument('--limit', type=int, default=8)
    delete = sub.add_parser('forget')
    delete.add_argument('folder', type=Path)
    delete.add_argument('--confirm-delete', action='store_true', required=True)
    args = parser.parse_args()
    try:
        if args.command == 'save':
            result = save(hibr_layout(args.hibr, args.desktop), args.source, args.function, args.question,
                          args.note, args.output,
                          expected_source_identity=args.expected_source_identity,
                          expected_source_sha256=args.expected_source_sha256)
        elif args.command == 'recall':
            result = recall(args.folder)
        elif args.command == 'refresh':
            result = refresh(hibr_layout(args.hibr, args.desktop), args.folder, args.output)
        elif args.command == 'list':
            result = list_memories(args.root, args.after, args.limit)
        else:
            result = forget(args.folder)
        if getattr(args, 'summary', False):
            result = summarize(result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, subprocess.SubprocessError, json.JSONDecodeError) as error:
        print(f'investigation memory refused: {error}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
