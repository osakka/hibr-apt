#!/usr/bin/env python3
"""Trace bounded same-file Hibr calls using only the native inspect producer."""
import argparse
from collections import deque
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from hibr_runtime import as_layout, hibr_layout
from export_briefs import source_bytes

MAX_SOURCE_BYTES = 4 * 1024 * 1024
MAX_RESULT_BYTES = 120_000


def identity(raw):
    value = 14695981039346656037
    for byte in raw:
        value = ((value ^ byte) * 1099511628211) & 0xffffffffffffffff
    return f'fnv1a64:{value:016x}'


def inspect(hibr, helper, source, name, max_source_bytes):
    run = subprocess.run([
        sys.executable, str(helper), '--hibr', str(hibr.executable),
        '--desktop', str(hibr.desktop.parent), '--source', str(source),
        '--function', name, '--max-source-bytes', str(max_source_bytes)],
        capture_output=True, text=True, timeout=120, env=hibr.environment())
    if run.returncode or run.stderr:
        return None, run.stderr.strip() or 'Hibr refused the function inspection.'
    try:
        packet = json.loads(run.stdout)
    except json.JSONDecodeError:
        return None, 'Hibr source inspection returned malformed JSON.'
    if (packet.get('status') != 'ready' or packet.get('path') != str(source) or
            packet.get('function') != name or not packet.get('identity') or
            packet.get('brief_identity') != packet.get('identity') or
            not isinstance(packet.get('source_call_sites'), list) or
            not isinstance(packet.get('context'), str)):
        return None, 'Hibr source inspection returned incomplete or mismatched evidence.'
    return packet, ''


def trace(hibr, source, root, max_source_bytes, max_depth, max_functions,
          max_context_bytes):
    source = source.resolve(strict=True)
    hibr = as_layout(hibr)
    helper = Path(__file__).with_name('source_context.py').resolve(strict=True)
    if source.stat().st_size > MAX_SOURCE_BYTES:
        raise ValueError('Hibr source exceeds the 4 MiB inspection limit.')
    if not source.is_file() or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', root):
        raise ValueError('Expected a regular Hibr source file and a simple function name.')
    if not 64 <= max_source_bytes <= 4096 or not 0 <= max_depth <= 4:
        raise ValueError('Source-byte limit or trace depth is outside its supported range.')
    if not 1 <= max_functions <= 16 or not 1024 <= max_context_bytes <= 24000:
        raise ValueError('Function or context limit is outside its supported range.')

    original = source_bytes(source)
    original_identity = identity(original)
    original_sha = hashlib.sha256(original).hexdigest()
    nodes = []
    edges = []
    by_name = {}
    queue = deque([(root, 0, None)])
    complete = True
    context_bytes = 0

    while queue:
        name, depth, incoming = queue.popleft()
        if name in by_name:
            if incoming is not None:
                edges[incoming]['state'] = 'already-inspected'
            continue
        if len(nodes) >= max_functions:
            complete = False
            if incoming is not None:
                edges[incoming]['state'] = 'function-limit'
            continue
        packet, reason = inspect(hibr, helper, source, name, max_source_bytes)
        if packet is None:
            complete = False
            if incoming is not None:
                edges[incoming]['state'] = 'inspection-refused'
                edges[incoming]['reason'] = reason
            elif name == root:
                raise ValueError(f'Could not inspect the selected function: {reason}')
            continue
        if packet['identity'] != original_identity:
            raise ValueError('The source changed while the call trace was being inspected.')
        node_index = len(nodes)
        by_name[name] = node_index
        node = {
            'function': name, 'depth': depth, 'identity': packet['identity'],
            'line': packet['definition_line'], 'endline': packet['definition_endline'],
            'brief': packet['brief'], 'context': packet['context'], 'packet': packet,
        }
        nodes.append(node)
        context_bytes += len(packet['context'].encode('utf-8'))
        if context_bytes > max_context_bytes:
            raise ValueError('The complete bounded call trace exceeds its context budget.')
        if incoming is not None:
            edges[incoming]['state'] = 'inspected'
        for site in packet['source_call_sites']:
            resolution = site['resolution']
            edge = {
                'caller': name, 'callee': site['name'], 'resolution': resolution,
                'line': site['line'], 'endline': site['endline'], 'state': 'not-followed',
            }
            edge_index = len(edges)
            edges.append(edge)
            if resolution != 'function':
                edge['state'] = 'builtin' if resolution == 'builtin' else 'unresolved'
            elif site['name'] in by_name:
                edge['state'] = 'already-inspected'
            elif depth >= max_depth:
                complete = False
                edge['state'] = 'depth-limit'
            elif len(nodes) + len(queue) >= max_functions:
                complete = False
                edge['state'] = 'function-limit'
            else:
                queue.append((site['name'], depth + 1, edge_index))

    final = source_bytes(source)
    if final != original or identity(final) != original_identity:
        raise ValueError('The source changed before the call trace completed.')
    total = sum(len(node['context'].encode('utf-8')) for node in nodes[1:])
    context = '\n\n'.join(node['context'] for node in nodes[1:])
    lines = [f'Static same-file Hibr call trace from {root} at {source} ({original_identity}).']
    for edge in edges:
        lines.append(f"{edge['caller']} -> {edge['callee']} at {source}:{edge['line']} "
                     f"({edge['resolution']}; {edge['state']}).")
    lines.append(f'Inspected {len(nodes)} function(s), maximum depth {max_depth}; '
                 f"{'all bounded resolved calls inspected' if complete else 'some edges stopped at an explicit limit or refusal'}.")
    lines.append('These are static call records, not an execution trace. Dynamic calls, other files, '
                 'runtime values, branch choices and effects remain unknown.')
    result = {
        'status': 'ready', 'path': str(source), 'identity': original_identity,
        'sha256': original_sha, 'root': root, 'depth': max_depth,
        'complete': complete, 'nodes': nodes, 'edges': edges,
        'context': context, 'context_bytes': total, 'report': '\n'.join(lines),
    }
    if len(json.dumps(result, ensure_ascii=False).encode('utf-8')) > MAX_RESULT_BYTES:
        raise ValueError('The bounded trace result exceeds its 120,000-byte protocol limit.')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hibr', required=True, type=Path,
                        help='Hibr source checkout or executable (in a desktop: $HIBR)')
    parser.add_argument('--desktop', type=Path,
                        help='folder holding desktop.hibr (in a desktop: $DT_HERE)')
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--function', required=True)
    parser.add_argument('--max-source-bytes', required=True, type=int)
    parser.add_argument('--max-depth', type=int, default=2)
    parser.add_argument('--max-functions', type=int, default=8)
    parser.add_argument('--max-context-bytes', type=int, default=20000)
    args = parser.parse_args()
    result = trace(hibr_layout(args.hibr, args.desktop), args.source, args.function, args.max_source_bytes,
                   args.max_depth, args.max_functions, args.max_context_bytes)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (OSError, TimeoutError, ValueError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
