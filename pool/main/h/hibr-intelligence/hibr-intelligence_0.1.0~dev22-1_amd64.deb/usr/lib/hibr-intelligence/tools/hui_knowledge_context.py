#!/usr/bin/env python3
"""Prepare bounded, token-budgeted local snapshot evidence for HUI chat."""
import argparse
import json
from pathlib import Path
import sys

from byte_bpe import Tokenizer, chat_text
from knowledge_retrieve import clip_evidence, render_context, retrieve


def render_completion(system, user):
    if '<|' in system or '<|' in user:
        raise ValueError('Control-token-like content cannot be rendered as literal text')
    return system+'\n\n'+user+'\n\n'


def token_count(tokenizer, renderer, system, user, history_tokens=0):
    if history_tokens and renderer == 'chatml-v1':
        rendered = '<|im_start|>user\n'+user+'<|im_end|>\n<|im_start|>assistant\n'
    elif history_tokens and renderer == 'llama3-instruct-v1':
        rendered = '<|start_header_id|>user<|end_header_id|>\n\n'+user+'<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n'
    elif history_tokens and renderer == 'mistral-v0.1-instruct-v1':
        rendered = ' [INST] '+user+' [/INST]'
    elif history_tokens and renderer == 'gpt2-completion-v1':
        rendered = '\n\n'+user+'\n\n'
    elif renderer == 'chatml-v1':
        rendered = chat_text([{'role': 'system', 'content': system},
                              {'role': 'user', 'content': user}])
    elif renderer == 'llama3-instruct-v1':
        rendered = chat_text([{'role': 'system', 'content': system},
                              {'role': 'user', 'content': user}],renderer=renderer)
    elif renderer == 'mistral-v0.1-instruct-v1':
        rendered = chat_text([{'role': 'system', 'content': system},
                              {'role': 'user', 'content': user}],renderer=renderer)
    elif renderer == 'gpt2-completion-v1':
        rendered = render_completion(system, user)
    else:
        raise ValueError('Unsupported chat renderer: '+renderer)
    count=history_tokens+len(tokenizer.encode(rendered))
    if tokenizer.bos_token_id is not None and not history_tokens:
        count+=1
    return count


def turn_end_tokens(tokenizer, renderer):
    ending = ('<|im_end|>\n' if renderer == 'chatml-v1' else
              '<|eot_id|>' if renderer == 'llama3-instruct-v1' else
              '</s>' if renderer == 'mistral-v0.1-instruct-v1' else '\n\n')
    return len(tokenizer.encode(ending))


def render_transcript(packet, maximum=2400):
    """Show compact citations and readable excerpts in the desktop transcript."""
    if not packet['evidence']:
        return 'Snapshot '+packet['snapshot_id'][:12]+': no local evidence matched.'
    lines = ['Snapshot '+packet['snapshot_id'][:12]]
    for item in packet['evidence']:
        citation=(f"[{item['id']}] {item['source']}/{item['path']}:{item['lines'][0]}-"
                  f"{item['lines'][1]} sha256:{item['sha256'][:12]}")
        excerpt=''.join(character if character.isprintable() else ' ' for character in item['text'])
        excerpt=' '.join(excerpt.split())
        remaining=maximum-sum(len(line)+1 for line in lines)-len(citation)-1
        if remaining <= 0:
            break
        excerpt=excerpt[:min(240,remaining)]
        lines.extend((citation,excerpt+('…' if len(excerpt)<len(item['text']) else '')))
        if sum(len(line)+1 for line in lines) >= maximum:
            break
    return '\n'.join(lines)[:maximum]


def prepare(snapshot, query, base_message, system, tokenizer_path, tokenizer_sha256,
            renderer, context_limit, max_new_tokens=64, history_tokens=0):
    if not isinstance(query, str) or not query.strip() or len(query) > 2048:
        raise ValueError('Query must contain 1..2048 characters')
    if not isinstance(base_message, str) or len(base_message.encode('utf-8')) > 32768:
        raise ValueError('Base message exceeds the 32 KiB local request limit')
    if not isinstance(system, str) or len(system.encode('utf-8')) > 8192:
        raise ValueError('System message exceeds the 8 KiB local request limit')
    if type(context_limit) is not int or context_limit < 1:
        raise ValueError('Model context limit must be a positive integer')
    if type(max_new_tokens) is not int or not 1 <= max_new_tokens < context_limit:
        raise ValueError('Output limit must leave room in the model context')
    if type(history_tokens) is not int or not 0 <= history_tokens < context_limit:
        raise ValueError('Committed conversation history is outside the model context')

    tokenizer = Tokenizer(tokenizer_path, tokenizer_sha256)
    ending_tokens = turn_end_tokens(tokenizer, renderer)
    packet = (retrieve(snapshot, query, limit=8, max_chars=16000, excerpt_chars=4000)
              if snapshot else {'snapshot_id':'','evidence':[]})
    while True:
        context = render_context(packet) if snapshot else ''
        user = base_message+('\n\n'+context if context else '')
        count = token_count(tokenizer, renderer, system, user, history_tokens)
        if count + max_new_tokens + ending_tokens <= context_limit:
            return {
                'status': 'ready',
                'query': query,
                'snapshot_id': packet['snapshot_id'],
                'context': context,
                'display': render_transcript(packet) if snapshot else '',
                'input_tokens': count,
                'history_tokens': history_tokens,
                'output_tokens': max_new_tokens,
                'evidence': packet['evidence'],
                'training_performed': False,
                'active_model_changed': False,
            }
        if len(packet['evidence']) > 1:
            packet['evidence'].pop()
        elif packet['evidence'] and len(packet['evidence'][0]['text']) > 48:
            excerpt = packet['evidence'][0]['text']
            clip_evidence(packet['evidence'][0],max(48,len(excerpt)//2))
        else:
            raise ValueError('Question and local evidence do not fit this model context; shorten the question or use a larger-context model')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot', default='')
    parser.add_argument('--query', required=True)
    parser.add_argument('--base-message', required=True)
    parser.add_argument('--system', required=True)
    parser.add_argument('--tokenizer', required=True, type=Path)
    parser.add_argument('--tokenizer-sha256', required=True)
    parser.add_argument('--renderer', required=True)
    parser.add_argument('--context-limit', required=True, type=int)
    parser.add_argument('--history-tokens', type=int, default=0)
    parser.add_argument('--max-new-tokens', type=int, default=64)
    args = parser.parse_args()
    try:
        packet = prepare(Path(args.snapshot) if args.snapshot else None,
                         args.query, args.base_message, args.system,
                         args.tokenizer, args.tokenizer_sha256, args.renderer,
                         args.context_limit, args.max_new_tokens, args.history_tokens)
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        print(f'local HUI evidence refused: {error}', file=sys.stderr)
        return 2
    print(json.dumps(packet, ensure_ascii=False, separators=(',', ':')))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
