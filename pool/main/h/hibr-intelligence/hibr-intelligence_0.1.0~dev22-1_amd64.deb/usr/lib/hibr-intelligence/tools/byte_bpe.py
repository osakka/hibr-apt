"""Bounded local byte-BPE tokenizer adapter; not a Hibr ABI.

Uses Python's Unicode categories (rejects unassigned code points). No regex,
Jinja, upstream tokenizer or inference runtime is used during encoding. The
implemented recipes cover pinned GPT-2/SmolLM2, Qwen2.5 NFC, and SentencePiece
byte-fallback tokenizer JSON profiles.
"""
import hashlib
import json
from pathlib import Path
import unicodedata

TOKENIZER_SHA256 = '9ca9acddb6525a194ec8ac7a87f24fbba7232a9a15ffa1af0c1224fcd888e47c'
SPACE = frozenset('\t\n\v\f\r \x85\xa0\u1680\u2028\u2029\u202f\u205f\u3000'+''.join(chr(n) for n in range(0x2000,0x200b)))
CONTRACTIONS = ("'s", "'t", "'re", "'ve", "'m", "'ll", "'d")
DEFAULT_SYSTEM = 'You are a helpful AI assistant named SmolLM, trained by Hugging Face'


def kind(c):
    category = unicodedata.category(c)
    if category == 'Cn':
        raise ValueError('Unassigned code point: Unicode-version parity is not established')
    if c.isspace():
        return 'S'
    return category[0] if category[0] in ('L', 'N') else 'P'


def byte_pieces(text):
    """Digits(individual) followed by the GPT-2 byte-level split, before bytes."""
    chunks, start = [], 0
    for i, c in enumerate(text):
        if kind(c) == 'N':
            if i > start:
                chunks.append(text[start:i])
            chunks.append(c)
            start = i+1
    if start < len(text):
        chunks.append(text[start:])
    for chunk in chunks:
        i = 0
        while i < len(chunk):
            contraction = next((value for value in CONTRACTIONS if chunk.startswith(value, i)), None)
            if contraction:
                yield contraction
                i += len(contraction)
                continue
            begin = i
            j = i+1 if chunk[i] == ' ' and i+1 < len(chunk) and kind(chunk[i+1]) != 'S' else i
            category = kind(chunk[j])
            if category != 'S':
                j += 1
                while j < len(chunk) and kind(chunk[j]) == category:
                    j += 1
                yield chunk[begin:j]
                i = j
            else:
                j = i+1
                while j < len(chunk) and kind(chunk[j]) == 'S':
                    j += 1
                # Greedy whitespace with (?!non-space) backtracks one before text.
                if j < len(chunk) and j-i > 1:
                    j -= 1
                yield chunk[i:j]
                i = j


def gpt2_byte_pieces(text):
    """Canonical GPT-2 ByteLevel regex split, including grouped number runs."""
    i = 0
    while i < len(text):
        contraction = next((value for value in CONTRACTIONS if text.startswith(value, i)), None)
        if contraction:
            yield contraction
            i += len(contraction)
            continue
        start = i
        j = i+1 if text[i] == ' ' and i+1 < len(text) and kind(text[i+1]) != 'S' else i
        category = kind(text[j])
        if category in ('L', 'N'):
            j += 1
            while j < len(text) and kind(text[j]) == category:
                j += 1
        elif category != 'S':
            j += 1
            while j < len(text) and kind(text[j]) not in ('S', 'L', 'N'):
                j += 1
        else:
            j = i+1
            while j < len(text) and kind(text[j]) == 'S':
                j += 1
            if j < len(text) and j-i > 1:
                j -= 1
        yield text[start:j]
        i = j


def qwen_byte_pieces(text):
    """Mirror the pinned Qwen Split expression over Unicode categories."""
    i = 0
    while i < len(text):
        contraction = next((value for value in CONTRACTIONS
                            if text[i:i+len(value)].lower() == value), None)
        if contraction:
            yield text[i:i+len(contraction)]
            i += len(contraction)
            continue
        current = kind(text[i])
        if current == 'L' or (text[i] not in '\r\n' and current not in ('L', 'N') and
                              i+1 < len(text) and kind(text[i+1]) == 'L'):
            start = i
            if current != 'L':
                i += 1
            while i < len(text) and kind(text[i]) == 'L':
                i += 1
            yield text[start:i]
            continue
        if current == 'N':
            yield text[i]
            i += 1
            continue
        start = i
        if text[i] == ' ' and i+1 < len(text) and kind(text[i+1]) not in ('S', 'L', 'N'):
            i += 1
        if i < len(text) and kind(text[i]) not in ('S', 'L', 'N'):
            while i < len(text) and kind(text[i]) not in ('S', 'L', 'N'):
                i += 1
            while i < len(text) and text[i] in '\r\n':
                i += 1
            yield text[start:i]
            continue
        i = start
        if text[i].isspace():
            while i < len(text) and text[i].isspace() and text[i] not in '\r\n':
                i += 1
            if i < len(text) and text[i] in '\r\n':
                while i < len(text) and text[i] in '\r\n':
                    i += 1
            elif i < len(text) and i-start > 1:
                i -= 1
            yield text[start:i]
            continue
        # Every assigned non-space code point is covered above or is a line break.
        yield text[i]
        i += 1


class Tokenizer:
    def __init__(self, path, expected_sha256=TOKENIZER_SHA256):
        path = Path(path)
        if not 0 < path.stat().st_size <= 16*1024*1024:
            raise ValueError('Tokenizer exceeds the supported 16 MiB artifact bound')
        raw = path.read_bytes()
        if not expected_sha256 or hashlib.sha256(raw).hexdigest() != expected_sha256:
            raise ValueError('Tokenizer digest differs from the verified bundle digest')
        data = json.loads(raw)
        model = data.get('model', {})
        pretokenizer = data.get('pre_tokenizer')
        bytelevel_pre=pretokenizer in ({'type':'ByteLevel','add_prefix_space':False,'trim_offsets':True},
                                      {'type':'ByteLevel','add_prefix_space':False,'trim_offsets':True,'use_regex':True})
        bytelevel_decoder=data.get('decoder') in ({'type':'ByteLevel','add_prefix_space':True,'trim_offsets':True},
                                                  {'type':'ByteLevel','add_prefix_space':False,'trim_offsets':True,'use_regex':True})
        bytelevel_post=data.get('post_processor') in ({'type':'ByteLevel','add_prefix_space':True,'trim_offsets':False},
                                                     {'type':'ByteLevel','add_prefix_space':False,'trim_offsets':True,'use_regex':True})
        standard_gpt2 = (model.get('type') in (None,'BPE') and 'vocab' in model and 'merges' in model and
                         ((bytelevel_pre and bytelevel_decoder and bytelevel_post and
                           data.get('normalizer') in (None, {'type':'NFC'}))))
        if model.get('type') != 'BPE' and not standard_gpt2:
            raise ValueError('Only BPE tokenizer JSON is supported')
        normalizer = data.get('normalizer')
        sentencepiece_normalizer={'type':'Sequence','normalizers':[
            {'type':'Prepend','prepend':'▁'},
            {'type':'Replace','pattern':{'String':' '},'content':'▁'}]}
        sentencepiece_decoder={'type':'Sequence','decoders':[
            {'type':'Replace','pattern':{'String':'▁'},'content':' '},
            {'type':'ByteFallback'},{'type':'Fuse'},
            {'type':'Strip','content':' ','start':1,'stop':0}]}
        sentencepiece=(normalizer==sentencepiece_normalizer and pretokenizer is None and
                       model.get('byte_fallback') is True and model.get('fuse_unk') is True and
                       model.get('unk_token') in model.get('vocab',{}) and
                       data.get('decoder')==sentencepiece_decoder and
                       isinstance(data.get('post_processor'),dict) and
                       data['post_processor'].get('type')=='TemplateProcessing')
        if normalizer not in (None, {'type': 'NFC'}) and not sentencepiece:
            raise ValueError('Unsupported tokenizer normalizer')
        steps = pretokenizer.get('pretokenizers') if isinstance(pretokenizer,dict) else None
        def byte_level(step):
            return (isinstance(step, dict) and step.get('type') == 'ByteLevel' and
                    step.get('add_prefix_space') is False and
                    step.get('use_regex') in (True, False))
        smol_steps = (isinstance(steps, list) and len(steps) == 2 and
                      steps[0] == {'type': 'Digits', 'individual_digits': True} and byte_level(steps[1]))
        qwen_pattern = "(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?\\p{L}+|\\p{N}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+"
        qwen_steps = (isinstance(steps, list) and len(steps) == 2 and
                      steps[0] == {'type': 'Split', 'pattern': {'Regex': qwen_pattern}, 'behavior': 'Isolated', 'invert': False} and byte_level(steps[1]))
        if standard_gpt2:
            self.normalizer = 'NFC' if normalizer=={'type':'NFC'} else None
            self.standard_gpt2 = True
            self.bos_token_id = None
        elif smol_steps and normalizer is None:
            self.normalizer = None
            self.standard_gpt2 = False
            self.bos_token_id = None
        elif qwen_steps and normalizer == {'type': 'NFC'}:
            self.normalizer = 'NFC'
            self.standard_gpt2 = False
            self.bos_token_id = None
        elif sentencepiece:
            self.normalizer = 'sentencepiece'
            self.standard_gpt2 = False
            self.bos_token_id = None
        else:
            raise ValueError('Tokenizer pre-tokenizer recipe is not supported')
        self.vocab = data['model']['vocab']
        self.tokens = {value: key for key, value in self.vocab.items()}
        if len(self.tokens) != len(self.vocab) or any(type(token_id) is not int or token_id < 0 for token_id in self.tokens):
            raise ValueError('Tokenizer vocabulary has duplicate or invalid token IDs')
        merges = data['model']['merges']
        if not isinstance(merges,list) or any(
                not ((isinstance(pair,str) and len(pair.split(' '))==2) or
                     (isinstance(pair,list) and len(pair)==2 and all(isinstance(piece,str) for piece in pair)))
                for pair in merges):
            raise ValueError('Unsupported BPE merge table')
        self.ranks = {(tuple(pair.split(' ')) if isinstance(pair,str) else tuple(pair)): i
                      for i,pair in enumerate(merges)}
        self.added_tokens = {}
        self.added = {}
        self.special_ids = set()
        for token in data.get('added_tokens', []):
            token_id = token['id']
            previous = self.tokens.get(token_id)
            if previous is not None and previous != token['content']:
                raise ValueError('Tokenizer has conflicting token IDs')
            self.tokens[token_id] = token['content']
            if token['content'] in self.added and self.added[token['content']] != token_id:
                raise ValueError('Tokenizer has duplicate added-token strings')
            self.added[token['content']] = token_id
            self.added_tokens[token_id] = token['content']
            if token.get('special'):
                self.special_ids.add(token_id)
        alphabet = list(range(33,127))+list(range(161,173))+list(range(174,256))
        chars, counter = alphabet[:], 0
        for b in range(256):
            if b not in alphabet:
                alphabet.append(b)
                chars.append(256+counter)
                counter += 1
        self.encoder = {b: chr(c) for b, c in zip(alphabet, chars)}
        self.decoder = {c: b for b, c in self.encoder.items()}
        self.cache = {}

    def _ordinary(self, text):
        result = []
        if self.normalizer=='sentencepiece':
            return self._sentencepiece_piece(text)
        pieces = (qwen_byte_pieces(text) if self.normalizer == 'NFC' else
                  gpt2_byte_pieces(text) if self.standard_gpt2 else byte_pieces(text))
        for piece in pieces:
            raw = piece.encode('utf-8')
            if len(raw) > 2048:
                raise ValueError('Pretoken exceeds bounded development BPE size')
            encoded = ''.join(self.encoder[b] for b in raw)
            if encoded not in self.cache:
                parts = list(encoded)
                while len(parts) > 1:
                    pairs = zip(parts, parts[1:])
                    pair = min(pairs, key=lambda value: self.ranks.get(value, float('inf')))
                    if pair not in self.ranks:
                        break
                    merged, i = [], 0
                    while i < len(parts):
                        if i+1 < len(parts) and (parts[i], parts[i+1]) == pair:
                            merged.append(parts[i]+parts[i+1])
                            i += 2
                        else:
                            merged.append(parts[i])
                            i += 1
                    parts = merged
                if len(self.cache) >= 1024:
                    self.cache.clear()
                self.cache[encoded] = tuple(self.vocab[value] for value in parts)
            result.extend(self.cache[encoded])
        return result

    def _sentencepiece_piece(self,text):
        symbols=[]
        for character in text:
            try:category_supported=bool(kind(character))
            except ValueError:category_supported=False
            if character=='▁' or category_supported:
                if character in self.vocab:
                    symbols.append(character)
                    continue
            for byte in character.encode('utf-8'):
                fallback=f'<0x{byte:02X}>'
                if fallback not in self.vocab:
                    raise ValueError(f'SentencePiece byte fallback is missing {fallback}')
                symbols.append(fallback)
        while len(symbols)>1:
            best=None;best_at=0
            for index in range(len(symbols)-1):
                rank=self.ranks.get((symbols[index],symbols[index+1]))
                if rank is not None and (best is None or rank<best):
                    best=rank;best_at=index
            if best is None:
                break
            merged=symbols[best_at]+symbols[best_at+1]
            if merged not in self.vocab:
                raise ValueError('SentencePiece merge result is missing from vocabulary')
            symbols[best_at:best_at+2]=[merged]
        try:
            return [self.vocab[token] for token in symbols]
        except KeyError as error:
            raise ValueError(f'SentencePiece token is missing from vocabulary: {error.args[0]!r}') from error

    def _sentencepiece_encode(self,text,special):
        specials={token:token_id for token,token_id in self.added.items()
                  if token_id in self.special_ids} if special else {}
        output=[];start=0
        while start<len(text):
            matches=[(text.find(token,start),-len(token),token) for token in specials]
            matches=[match for match in matches if match[0]>=0]
            if not matches:
                output.extend(self._sentencepiece_piece('▁'+text[start:].replace(' ','▁')))
                break
            at,_,token=min(matches)
            if at>start:
                output.extend(self._sentencepiece_piece('▁'+text[start:at].replace(' ','▁')))
            output.append(specials[token]);start=at+len(token)
        if len(output)>65536:
            raise ValueError('Tokenizer output exceeds the 65536-token bound')
        return output

    def encode(self, text, special=True):
        if not isinstance(text, str) or len(text.encode('utf-8')) > 65536:
            raise ValueError('Text exceeds bounded tokenizer input')
        if self.normalizer=='sentencepiece':
            return self._sentencepiece_encode(text,special)
        if not special:
            return self._ordinary(text)
        if self.normalizer == 'NFC':
            text = unicodedata.normalize('NFC', text)
            if len(text.encode('utf-8')) > 65536:
                raise ValueError('Normalized tokenizer input exceeds its byte budget')
        result, start = [], 0
        while start < len(text):
            matches = [(text.find(value, start), -len(value), value) for value in self.added]
            matches = [value for value in matches if value[0] >= 0]
            if not matches:
                result.extend(self._ordinary(text[start:]))
                break
            at, _, marker = min(matches)
            result.extend(self._ordinary(text[start:at]))
            result.append(self.added[marker])
            start = at+len(marker)
        return result

    def decode_bytes(self, ids, skip_special=True):
        if len(ids) > 65536 or any(type(token) is not int or token not in self.tokens for token in ids):
            raise ValueError('Invalid or excessive token IDs')
        output = bytearray()
        if self.normalizer=='sentencepiece':
            for token in ids:
                if skip_special and token in self.special_ids:
                    continue
                value=self.tokens[token]
                if len(value)==6 and value.startswith('<0x') and value.endswith('>'):
                    try:output.append(int(value[3:5],16))
                    except ValueError as error:raise ValueError('Malformed SentencePiece byte token') from error
                else:
                    output.extend(value.encode('utf-8'))
            output=bytearray(output.replace('▁'.encode('utf-8'),b' '))
            if output.startswith(b' '):del output[0]
            return bytes(output)
        for token in ids:
            if token in self.added_tokens:
                if not (skip_special and token in self.special_ids):
                    output.extend(self.added_tokens[token].encode('utf-8'))
            else:
                output.extend(self.decoder[c] for c in self.tokens[token])
        return bytes(output)

    def decode(self, ids, skip_special=True):
        return self.decode_bytes(ids, skip_special).decode('utf-8', errors='replace')


def chat_text(messages, generation=True, renderer='chatml-v1'):
    if len(messages) > 128:
        raise ValueError('Too many messages')
    if renderer == 'mistral-v0.1-instruct-v1':
        if not isinstance(messages, (list, tuple)) or not messages:
            raise ValueError('Mistral chat requires at least one user message')
        if any(not isinstance(message, dict) for message in messages):
            raise ValueError('Unsupported message')
        system = None
        start = 0
        if messages[0].get('role') == 'system':
            system = messages[0].get('content')
            if not isinstance(system, str):
                raise ValueError('Unsupported message')
            start = 1
            if any(marker in system for marker in ('[INST]', '[/INST]', '<s>', '</s>')):
                raise ValueError('Mistral control-token-like content requires explicit literal handling')
        turns = messages[start:]
        if not turns or len(turns) > 127 or turns[0].get('role') != 'user':
            raise ValueError('Mistral chat must start with a user message after optional system context')
        parts = ['<s>']
        expected = 'user'
        for index, message in enumerate(turns):
            role, content = message.get('role'), message.get('content')
            if role != expected or not isinstance(content, str):
                raise ValueError('Mistral messages must alternate user and assistant roles')
            if any(marker in content for marker in ('[INST]', '[/INST]', '<s>', '</s>')):
                raise ValueError('Mistral control-token-like content requires explicit literal handling')
            if role == 'user':
                prefix = '[INST] '
                if index == 0 and system is not None:
                    content = system+'\n\n'+content
                parts.append(prefix+content+' [/INST]')
                expected = 'assistant'
            else:
                parts.append(content+'</s> ')
                expected = 'user'
        if generation and expected != 'assistant':
            raise ValueError('Mistral generation requires the conversation to end with a user message')
        result = ''.join(parts)
        if len(result.encode('utf-8')) > 65536:
            raise ValueError('Chat exceeds tokenizer input budget')
        return result
    if renderer not in ('chatml-v1', 'llama3-instruct-v1'):
        raise ValueError('Unsupported chat renderer: '+renderer)
    parts = []
    if renderer == 'llama3-instruct-v1':
        parts.append('<|begin_of_text|>')
        if messages and messages[0]['role'] != 'system':
            messages = [{'role': 'system', 'content': DEFAULT_SYSTEM}, *messages]
    elif messages and messages[0]['role'] != 'system':
        parts.append('<|im_start|>system\n'+DEFAULT_SYSTEM+'<|im_end|>\n')
    for message in messages:
        role, content = message['role'], message['content']
        if role not in ('system', 'user', 'assistant') or not isinstance(content, str):
            raise ValueError('Unsupported message')
        if '<|' in content:
            raise ValueError('Control-token-like message content requires explicit literal handling')
        if renderer == 'llama3-instruct-v1':
            parts.append('<|start_header_id|>'+role+'<|end_header_id|>\n\n'+content+'<|eot_id|>')
        else:
            parts.append('<|im_start|>'+role+'\n'+content+'<|im_end|>\n')
    if generation:
        parts.append('<|start_header_id|>assistant<|end_header_id|>\n\n' if renderer == 'llama3-instruct-v1'
                     else '<|im_start|>assistant\n')
    result = ''.join(parts)
    if len(result.encode('utf-8')) > 65536:
        raise ValueError('Chat exceeds tokenizer input budget')
    return result
