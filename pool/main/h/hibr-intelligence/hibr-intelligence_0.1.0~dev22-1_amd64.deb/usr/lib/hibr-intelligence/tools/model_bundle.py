"""Validate local Hibr model bundles against registered runtime capabilities."""
import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.parse
from hibr_runtime import resolve_hibr

FORMAT = "hibr-model-bundle"
VERSION = 3
ADAPTER_REGISTRY = json.loads((Path(__file__).resolve().parents[1] /
                               "engine/adapter-registry.json").read_text(encoding="utf-8"))
if ADAPTER_REGISTRY.get("format") != "hibr-inference-adapter-registry" or ADAPTER_REGISTRY.get("version") != 1:
    raise ValueError("unsupported inference adapter registry format or version")
SUPPORTED = {
    "tokenizer_format": "huggingface-tokenizer-json",
    "training": [],
}
TOKENIZER_RECIPES = {
    "gpt2-byte-bpe-digit-split-v1": {"runtime": "gpt2-byte-bpe-digit-split-v1",
                                     "native": True, "normalizer": None},
    "byte-bpe-unicode-nfc-v1": {"runtime": "byte-bpe-unicode-nfc-v1",
                                "native": True, "normalizer": "NFC"},
    "gpt2-byte-bpe-v1": {"runtime": "gpt2-byte-bpe-v1",
                          "native": True, "normalizer": None},
    "gpt2-byte-bpe-nfc-v1": {"runtime": "gpt2-byte-bpe-nfc-v1",
                               "native": True, "normalizer": "NFC"},
    "sentencepiece-bpe-byte-fallback-v1": {"runtime": "sentencepiece-bpe-byte-fallback-v1",
                                             "native": True, "normalizer": "metaspace"},
}
CHAT_RENDERERS = {
    'chatml-v1': {'native': True, 'prompt_mode': 'chat',
                  'roles': ('system', 'user', 'assistant')},
    'llama3-instruct-v1': {
        'native': True, 'prompt_mode': 'chat',
        'roles': ('system', 'user', 'assistant'),
        'special_tokens': {
            '<|begin_of_text|>': 'bos_token_id',
            '<|start_header_id|>': None,
            '<|end_header_id|>': None,
            '<|eot_id|>': 'eos_token_id',
        },
    },
    'mistral-v0.1-instruct-v1': {
        'native': True, 'prompt_mode': 'chat',
        'roles': ('system', 'user', 'assistant'),
        'special_tokens': {'<s>': 'bos_token_id', '</s>': 'eos_token_id'},
    },
    'gpt2-completion-v1': {'native': True, 'prompt_mode': 'completion',
                           'roles': ('system', 'user')},
}


def _registry_names(item, field):
    names = item.get(field)
    if (not isinstance(names, list) or not names or
            any(not isinstance(name, str) or not name for name in names) or
            len(set(names)) != len(names)):
        raise ValueError(f"invalid {field} in inference adapter registry")
    return tuple(names)


def _load_adapters(extra=()):
    items = ADAPTER_REGISTRY.get("adapters")
    if not isinstance(items, list) or not items:
        raise ValueError("inference adapter registry must contain adapters")
    adapters = {}
    for item in list(items) + list(extra):
        if not isinstance(item, dict):
            raise ValueError("inference adapter registrations must be objects")
        identifier = item.get("id")
        if not isinstance(identifier, str) or not identifier or identifier in adapters:
            raise ValueError(f"invalid or duplicate inference adapter ID: {identifier!r}")
        adapter = dict(item)
        for field in ("families", "architectures", "weight_formats", "weight_dtypes", "tokenizer_recipes", "chat_renderers"):
            adapter[field] = _registry_names(item, field)
        if any(name not in ADAPTER_REGISTRY["weight_formats"] for name in adapter["weight_formats"]):
            raise ValueError(f"unknown weight format in adapter {identifier!r}")
        if any(name not in TOKENIZER_RECIPES for name in adapter["tokenizer_recipes"]):
            raise ValueError(f"unknown tokenizer recipe in adapter {identifier!r}")
        if any(name not in CHAT_RENDERERS for name in adapter["chat_renderers"]):
            raise ValueError(f"unknown chat renderer in adapter {identifier!r}")
        context_limit = adapter.get("context_limit")
        if (not isinstance(adapter.get("configuration_schema"), str) or
                not adapter["configuration_schema"] or
                (context_limit is not None and
                 (type(context_limit) is not int or context_limit < 1))):
            raise ValueError(f"invalid schema or context limit for adapter {identifier!r}")
        if "prepend_bos" in adapter and type(adapter["prepend_bos"]) is not bool:
            raise ValueError(f"prepend_bos must be a boolean for adapter {identifier!r}")
        adapters[identifier] = adapter
    return adapters


ADAPTERS = _load_adapters()
WEIGHTS_FORMATS = _registry_names(ADAPTER_REGISTRY, "weight_formats")
ADAPTER_BOUNDS = {key: tuple(bounds) for key, bounds in
                  ADAPTER_REGISTRY["configuration_bounds"].items()}
MAX_ARTIFACT_BYTES = (1 << 63) - 1  # signed 64-bit file offsets used by the native reader


def fail(message):
    raise ValueError(message)


def validate_renderer_special_tokens(renderer, tokenizer_path, bos_token_id, eos_token_id):
    required = CHAT_RENDERERS[renderer].get('special_tokens', {})
    if not required:
        return
    try:
        source=json.loads(Path(tokenizer_path).read_text(encoding='utf-8'))
    except (OSError,UnicodeError,json.JSONDecodeError) as error:
        fail(f"cannot inspect renderer special tokens: {error}")
    added=source.get('added_tokens',[]) if isinstance(source,dict) else []
    special_ids={item.get('content'):item.get('id') for item in added
                 if isinstance(item,dict) and item.get('special') is True}
    ids={'bos_token_id':bos_token_id,'eos_token_id':eos_token_id}
    for token,field in required.items():
        token_id=special_ids.get(token)
        if type(token_id) is not int:
            fail(f"chat_renderer {renderer!r} requires special token {token}")
        if field and token_id!=ids[field]:
            fail(f"chat_renderer {renderer!r} token {token} must match {field}")


def query_provider(adapter_id, hibr, module_directory):
    """Ask Hibr's module loader for a provider's self-declared capabilities."""
    if (not isinstance(adapter_id, str) or not 1 <= len(adapter_id) < 64 or
            any(not (c.isascii() and (c.islower() or c.isdigit() or c == '-'))
                for c in adapter_id)):
        fail("invalid external adapter ID")
    script = ("need hibr-intelligence; intelligence adapter-info " + adapter_id +
              "; json emit RET\n")
    executable,extra_modules=resolve_hibr(hibr)
    env = dict(os.environ,
               HIBR_MODPATH=str(Path(module_directory).resolve()) + ":" +
               str(extra_modules.resolve()))
    try:
        result = subprocess.run([str(executable), "-c", script],
                                env=env, capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.TimeoutExpired) as error:
        fail(f"cannot query Hibr adapter provider {adapter_id!r}: {error}")
    if result.returncode or result.stderr:
        fail(f"Hibr refused adapter provider {adapter_id!r}: {result.stderr.strip() or result.stdout.strip()}")
    try:
        metadata = json.loads(result.stdout)
    except json.JSONDecodeError as error:
        fail(f"Hibr returned invalid metadata for adapter {adapter_id!r}: {error}")
    if not isinstance(metadata, dict) or metadata.get("id") != adapter_id:
        fail("Hibr adapter metadata does not match the requested adapter ID")
    return validate_provider_contract(metadata)


def validate_provider_contract(metadata):
    """Check provider-authored bundle claims against the loaded runtime table."""
    if not isinstance(metadata, dict) or not isinstance(metadata.get("capabilities"), dict):
        fail("Hibr adapter metadata must include a capabilities object")
    capabilities = metadata["capabilities"]
    contract = metadata.get("runtime_contract")
    if not isinstance(contract, dict):
        fail("Hibr adapter metadata does not include its runtime contract")
    renderer = contract.get("renderer")
    prompt_mode = contract.get("prompt_mode")
    prepend_bos = contract.get("prepend_bos")
    runtime_operations = contract.get("required_operations")
    operations_owner = contract.get("operations_owner", "engine")
    provider_api_version = contract.get("provider_api_version")
    runtime_backends = contract.get("supported_backends")
    if not isinstance(renderer, str) or not renderer:
        fail("provider runtime contract must name its renderer")
    if prompt_mode not in ("chat", "completion"):
        fail("provider runtime contract must name its prompt mode")
    if type(prepend_bos) is not bool:
        fail("provider runtime contract prepend_bos must be boolean")
    known_operations = set(ADAPTER_REGISTRY["operations"])
    if operations_owner not in ("engine", "provider"):
        fail("provider runtime contract has an unknown operations_owner")
    if (not isinstance(runtime_operations, list) or
            any(not isinstance(item, str) or item not in known_operations
                for item in runtime_operations) or
            len(set(runtime_operations)) != len(runtime_operations)):
        fail("provider runtime contract has an invalid required_operations list")
    declared_operations = capabilities.get("required_operations")
    if (not isinstance(declared_operations, list) or
            any(not isinstance(item, str) for item in declared_operations) or
            set(declared_operations) != set(runtime_operations) or
            len(declared_operations) != len(runtime_operations)):
        fail("provider capability operations disagree with its runtime operation mask")
    if operations_owner == "provider":
        if runtime_operations or declared_operations:
            fail("provider-owned operations must not claim engine operation bits")
        if provider_api_version != 2:
            fail("provider runtime contract has an unsupported public ABI version")
        if (not isinstance(runtime_backends,list) or not runtime_backends or
                any(item not in ("cpu","gpu") for item in runtime_backends) or
                len(set(runtime_backends))!=len(runtime_backends)):
            fail("provider runtime contract must enumerate its supported backends")
        if capabilities.get("supported_backends") != runtime_backends:
            fail("provider capabilities disagree with runtime-supported backends")
        if "cpu" not in runtime_backends:
            fail("provider ABI v2 must retain CPU support")
    if capabilities.get("prompt_mode") != prompt_mode:
        fail("provider capability prompt_mode disagrees with its runtime table")
    renderers = capabilities.get("chat_renderers")
    if not isinstance(renderers, list) or renderer not in renderers:
        fail("provider runtime renderer is absent from its capability declaration")
    if renderer not in CHAT_RENDERERS or CHAT_RENDERERS[renderer]["prompt_mode"] != prompt_mode:
        fail("provider runtime renderer does not support its declared prompt mode")
    if capabilities.get("prepend_bos") is not prepend_bos:
        fail("provider capability prepend_bos disagrees with its runtime table")
    supported_backends = capabilities.get("supported_backends")
    if supported_backends is not None:
        if (not isinstance(supported_backends, list) or not supported_backends or
                any(item not in ("cpu", "gpu") for item in supported_backends) or
                len(set(supported_backends)) != len(supported_backends)):
            fail("provider supported_backends must be a unique CPU/GPU list")
    return metadata


def _estimate_gqa_model_bytes(config):
    """Conservative persistent CPU model estimate matching decoder/cache shapes."""
    hidden = config["hidden_size"]
    kv_width = config["kv_heads"] * config["head_dimension"]
    context = config["context"]
    bias_floats = (hidden + 2 * kv_width) if config["attention_bias"] else 0
    qk_norm_floats = 2 * config["head_dimension"] if config.get("query_key_norm", False) else 0
    # Decoder workspace/parameters: 8H + 2F + 2K + optional bias; cache:
    # 2*context*K + context scores + H result workspace. Reserve 4096 bytes
    # per layer and model for descriptors, pointers and allocator alignment.
    layer_floats = (9 * hidden + 2 * config["intermediate_size"] +
                    2 * kv_width + bias_floats + qk_norm_floats +
                    2 * context * kv_width + context + hidden)
    return (4096 + config["layers"] * (4096 + 4 * layer_floats) +
            4 * (3 * hidden + config["vocabulary"]))


def digest(path):
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def validate(path, verify_artifacts=True, model_memory_bytes=None, provider_metadata=None):
    if model_memory_bytes is not None and (
            type(model_memory_bytes) is not int or not 0 < model_memory_bytes <= sys.maxsize):
        fail("model_memory_bytes must be a positive platform byte count")
    path = Path(path).resolve()
    try:
        bundle = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        fail(f"cannot read bundle manifest: {error}")
    if not isinstance(bundle, dict) or bundle.get("format") != FORMAT:
        fail(f"manifest format must be {FORMAT!r}")
    if type(bundle.get("version")) is not int or bundle["version"] != VERSION:
        fail(f"unsupported bundle manifest version: {bundle.get('version')!r}")
    adapter_id = bundle.get("adapter_id")
    adapters = ADAPTERS
    if provider_metadata is not None:
        if not isinstance(provider_metadata, dict) or provider_metadata.get("id") != adapter_id:
            fail("external provider metadata must match the bundle adapter_id")
        capabilities = provider_metadata.get("capabilities")
        if not isinstance(capabilities, dict):
            fail("external provider metadata must contain a capabilities object")
        adapters = _load_adapters([dict(capabilities, id=adapter_id)])
    if adapter_id not in adapters:
        fail(f"unsupported adapter_id: {adapter_id!r}; supported adapters: {', '.join(adapters)}")
    adapter = adapters[adapter_id]
    if bundle.get("family") not in adapter["families"]:
        fail(f"runtime adapter {adapter_id!r} does not support family {bundle.get('family')!r}")
    if bundle.get("architecture") not in adapter["architectures"]:
        fail(f"runtime adapter {adapter_id!r} does not support architecture {bundle.get('architecture')!r}")
    for key, expected in SUPPORTED.items():
        if bundle.get(key) != expected:
            fail(f"unsupported {key}: {bundle.get(key)!r}; this runtime accepts {expected!r}")
    if bundle.get("weights_format") not in WEIGHTS_FORMATS:
        fail(f"unsupported weights_format: {bundle.get('weights_format')!r}; this runtime accepts {WEIGHTS_FORMATS!r}")
    if bundle["weights_format"] not in adapter["weight_formats"]:
        fail(f"adapter {adapter_id!r} does not support weights_format {bundle['weights_format']!r}; "
             f"supported formats: {', '.join(adapter['weight_formats'])}")
    execution = bundle.get("execution")
    if (not isinstance(execution,list) or not execution or
            any(not isinstance(item,str) or item not in ("cpu","gpu") for item in execution) or
            len(set(execution)) != len(execution)):
        fail("execution must be a non-empty unique list drawn from ['cpu', 'gpu']")
    if adapter.get("supported_backends") is not None and not set(execution).issubset(adapter["supported_backends"]):
        fail("bundle execution requests a backend not supported by this adapter provider")
    if "experimental_execution" in bundle:
        fail("experimental_execution is not an executable capability; list only verified backends in execution")
    architecture = bundle.get("architecture_config")
    if not isinstance(architecture, dict):
        fail("architecture_config must be an object")
    if adapter["configuration_schema"] == "gpt-neox-parallel-gelu":
        required={"layers","hidden_size","intermediate_size","attention_heads","vocabulary",
                  "context","rotary_dimension","rope_theta","layer_norm_eps","parallel_residual"}
        if set(architecture)!=required:
            fail(f"GPT-NeoX architecture_config keys must be exactly {sorted(required)}")
        bounds={"layers":(1,64),"hidden_size":(2,8192),"intermediate_size":(1,32768),
                "attention_heads":(1,128),"vocabulary":(2,262144),"context":(1,adapter["context_limit"]),
                "rotary_dimension":(2,8192)}
        for key,(minimum,maximum) in bounds.items():
            value=architecture[key]
            if type(value) is not int or not minimum<=value<=maximum:
                fail(f"architecture_config.{key} must be an integer in {minimum}..{maximum}")
        if architecture["hidden_size"]%architecture["attention_heads"]:
            fail("attention_heads must divide hidden_size")
        if architecture["rotary_dimension"]>architecture["hidden_size"]//architecture["attention_heads"] or architecture["rotary_dimension"]%2:
            fail("rotary_dimension must be even and no larger than the attention head dimension")
        if architecture["parallel_residual"] is not True:
            fail("GPT-NeoX adapter currently requires parallel_residual=true")
        for key,minimum,maximum in (("rope_theta",2.0,1e9),("layer_norm_eps",1e-9,0.1)):
            value=architecture[key]
            if type(value) not in (int,float) or not minimum<=value<=maximum:
                fail(f"architecture_config.{key} must be a number in {minimum}..{maximum}")
        h=architecture["hidden_size"];f=architecture["intermediate_size"];context=architecture["context"]
        estimated_bytes=(architecture["layers"]*(15*h+2*f+2*context*h+context)*4+
                         (7*h+architecture["vocabulary"])*4)
        if model_memory_bytes is not None and estimated_bytes>model_memory_bytes:
            fail(f"estimated model state {estimated_bytes} bytes exceeds the requested {model_memory_bytes}-byte model memory budget")
        for key in ("bos_token_id","eos_token_id"):
            value=bundle.get(key)
            if type(value) is not int or not 0<=value<architecture["vocabulary"]:
                fail(f"{key} must be a token ID within the declared vocabulary")
        recipe=bundle.get("tokenizer_recipe")
        if recipe not in adapter["tokenizer_recipes"]:
            fail(f"runtime adapter {adapter_id!r} does not support tokenizer_recipe {recipe!r}")
        if bundle.get("tokenizer_runtime")!=TOKENIZER_RECIPES[recipe]["runtime"]:
            fail(f"tokenizer_recipe {recipe!r} requires tokenizer_runtime={TOKENIZER_RECIPES[recipe]['runtime']!r}")
    elif adapter["configuration_schema"] == "gpt2-conv1d-gelu":
        required = {"layers", "hidden_size", "attention_heads", "vocabulary",
                    "position_embeddings", "context", "layer_norm_eps"}
        if set(architecture) != required:
            fail(f"GPT-2 architecture_config keys must be exactly {sorted(required)}")
        for key, (minimum, maximum) in {"layers": (1, 64), "hidden_size": (2, 8192),
                "attention_heads": (1, 128), "vocabulary": (2, 262144),
                "position_embeddings": (1, 4096), "context": (1, adapter["context_limit"])}.items():
            value = architecture[key]
            if type(value) is not int or not minimum <= value <= maximum:
                fail(f"architecture_config.{key} must be an integer in {minimum}..{maximum}")
        eps = architecture["layer_norm_eps"]
        if type(eps) not in (int, float) or not 1e-9 <= eps <= 0.1:
            fail("architecture_config.layer_norm_eps must be a number in 1e-9..0.1")
        if architecture["hidden_size"] % architecture["attention_heads"]:
            fail("attention_heads must divide hidden_size")
        if architecture["context"] > architecture["position_embeddings"]:
            fail("context cannot exceed position_embeddings")
        estimated_bytes = (architecture["layers"] *
            (23 * architecture["hidden_size"] +
             2 * architecture["context"] * architecture["hidden_size"] + architecture["context"]) * 4 +
            (7 * architecture["hidden_size"] + architecture["vocabulary"]) * 4)
        if model_memory_bytes is not None and estimated_bytes > model_memory_bytes:
            fail(f"estimated model state {estimated_bytes} bytes exceeds the requested {model_memory_bytes}-byte model memory budget")
        for key in ("bos_token_id", "eos_token_id"):
            value = bundle.get(key)
            if type(value) is not int or not 0 <= value < architecture["vocabulary"]:
                fail(f"{key} must be a token ID within the declared vocabulary")
        recipe = bundle.get("tokenizer_recipe")
        if recipe not in adapter["tokenizer_recipes"]:
            fail(f"runtime adapter {adapter_id!r} does not support tokenizer_recipe {recipe!r}")
        if bundle.get("tokenizer_runtime") != TOKENIZER_RECIPES[recipe]["runtime"]:
            fail(f"tokenizer_recipe {recipe!r} requires tokenizer_runtime={TOKENIZER_RECIPES[recipe]['runtime']!r}")
    elif adapter["configuration_schema"] == "gqa-swiglu":
        for key, (minimum, maximum) in ADAPTER_BOUNDS.items():
            value = architecture.get(key)
            if type(value) is not int or not minimum <= value <= maximum:
                fail(f"architecture_config.{key} must be an integer in {minimum}..{maximum}")
        for key, minimum, maximum in (("rope_theta", 2.0, 1000000000.0),
                                      ("rms_norm_eps", 1e-9, 0.1)):
            value = architecture.get(key)
            if type(value) not in (int, float) or not minimum <= value <= maximum:
                fail(f"architecture_config.{key} must be a number in {minimum}..{maximum}")
        if type(architecture.get("attention_bias")) is not bool:
            fail("architecture_config.attention_bias must be boolean")
        if "query_key_norm" in architecture and type(architecture["query_key_norm"]) is not bool:
            fail("architecture_config.query_key_norm must be boolean when present")
        if architecture.get("query_key_norm", False) and bundle["weights_format"] == "gguf-v3":
            fail("query/key head normalization is currently supported through SafeTensors only")
        if bundle.get("architecture") == "qwen3" and architecture.get("query_key_norm") is not True:
            fail("Qwen3 bundles must declare query_key_norm=true")
        if architecture["head_dimension"] * architecture["query_heads"] != architecture["hidden_size"]:
            fail("query_heads * head_dimension must equal hidden_size")
        if architecture["query_heads"] % architecture["kv_heads"]:
            fail("query_heads must be divisible by kv_heads")
        if architecture["head_dimension"] % 2:
            fail("architecture_config.head_dimension must be even for rotary embedding")
        if architecture["intermediate_size"] % 2:
            fail("architecture_config.intermediate_size must be even for SwiGLU")
        if "attention_window" in architecture and (
                type(architecture["attention_window"]) is not int or
                not 1 <= architecture["attention_window"] <= architecture["context"]):
            fail("architecture_config.attention_window must be an integer in 1..context")
        if bundle.get("architecture") == "mistral" and "attention_window" not in architecture:
            fail("Mistral architecture_config must declare attention_window")
        rope_scaling=architecture.get("rope_scaling")
        if rope_scaling is not None:
            if not isinstance(rope_scaling,dict):
                fail("architecture_config.rope_scaling must be an object")
            kind=rope_scaling.get("type")
            if kind=="linear":
                if set(rope_scaling)!={"type","factor"}:
                    fail("linear rope_scaling keys must be exactly type and factor")
                factor=rope_scaling["factor"]
                if type(factor) not in (int,float) or not 1.0<factor<=1000.0:
                    fail("linear rope_scaling.factor must be in (1, 1000]")
            elif kind=="llama3":
                expected={"type","factor","low_freq_factor","high_freq_factor","original_context"}
                if set(rope_scaling)!=expected:
                    fail(f"llama3 rope_scaling keys must be exactly {sorted(expected)}")
                factor=rope_scaling["factor"];low=rope_scaling["low_freq_factor"]
                high=rope_scaling["high_freq_factor"];original=rope_scaling["original_context"]
                if (any(type(value) not in (int,float) for value in (factor,low,high)) or
                        not 1.0<factor<=1000.0 or not 0.0<low<high<=1000.0 or
                        type(original) is not int or not 1<=original<=4294967295):
                    fail("llama3 rope_scaling factors or original_context are invalid")
            else:
                fail(f"unsupported rope_scaling type: {kind!r}")
            if bundle["weights_format"]=="gguf-v3":
                fail("scaled RoPE requires SafeTensors until GGUF scaling metadata is verified")
        estimated_bytes = _estimate_gqa_model_bytes(architecture)
        if model_memory_bytes is not None and estimated_bytes > model_memory_bytes:
            fail(f"estimated model state {estimated_bytes} bytes exceeds the requested {model_memory_bytes}-byte model memory budget")
    elif (provider_metadata is not None and
          adapter["configuration_schema"] == "provider-json-v1" and
          adapter.get("configuration_encoding") == "json-object-v1"):
        for key in ("context", "vocabulary"):
            value = architecture.get(key)
            minimum = 1 if key == "context" else 2
            if type(value) is not int or not minimum <= value <= sys.maxsize:
                fail(f"provider architecture_config.{key} must be an integer in {minimum}..{sys.maxsize}")
        if (adapter["context_limit"] is not None and
                architecture["context"] > adapter["context_limit"]):
            fail(f"provider context exceeds its declared {adapter['context_limit']} token limit")
        # Architecture math and model-owned memory are provider responsibilities.
        # The provider receives the runtime memory budget when it opens the model.
    else:
        fail(f"runtime adapter {adapter_id!r} declares an unimplemented configuration schema")
    for key in ("bos_token_id", "eos_token_id"):
        value = bundle.get(key)
        if type(value) is not int or not 0 <= value < architecture["vocabulary"]:
            fail(f"{key} must be a token ID within the declared vocabulary")
    recipe = bundle.get("tokenizer_recipe")
    if recipe not in adapter["tokenizer_recipes"]:
        fail(f"runtime adapter {adapter_id!r} does not support tokenizer_recipe {recipe!r}")
    expected_recipe = TOKENIZER_RECIPES[recipe]["runtime"]
    if bundle.get("tokenizer_runtime") != expected_recipe:
        fail(f"tokenizer_recipe {recipe!r} requires tokenizer_runtime={expected_recipe!r}")
    renderer = bundle.get("chat_renderer")
    if not isinstance(renderer, str) or renderer not in CHAT_RENDERERS or not CHAT_RENDERERS[renderer]["native"]:
        fail(f"unsupported chat_renderer: {renderer!r}")
    if renderer not in adapter["chat_renderers"]:
        fail(f"runtime adapter {adapter_id!r} does not support chat_renderer {renderer!r}")
    context = architecture.get("context")
    if (type(context) is not int or not 1 <= context <= sys.maxsize or
            (adapter["context_limit"] is not None and context > adapter["context_limit"])):
        limit = adapter["context_limit"] if adapter["context_limit"] is not None else sys.maxsize
        fail(f"architecture_config.context must be an integer from 1 to {limit}")
    weight_dtypes = bundle.get("weight_dtypes")
    if (not isinstance(weight_dtypes, list) or not weight_dtypes or
            any(not isinstance(dtype, str) or dtype not in adapter["weight_dtypes"] for dtype in weight_dtypes) or
            len(set(weight_dtypes)) != len(weight_dtypes)):
        fail(f"weight_dtypes must be a non-empty unique list drawn from {adapter['weight_dtypes']}")
    quantized = {"Q8_0", "Q4_0", "Q4_1", "Q4_K", "Q5_0", "Q5_1", "Q5_K", "Q6_K", "Q2_K", "Q3_K", "IQ4_NL"}
    if quantized.intersection(weight_dtypes) and bundle["weights_format"] != "gguf-v3":
        fail("quantized tensors require weights_format='gguf-v3'")
    artifacts = bundle.get("artifacts")
    if not isinstance(artifacts, dict) or set(artifacts) != {"weights", "tokenizer"}:
        fail("artifacts must declare exactly weights and tokenizer")
    resolved = {}
    for name, record in artifacts.items():
        allowed_keys={"path", "sha256", "size", "source_url"}
        if name=="weights" and isinstance(record,dict) and "shards" in record:
            allowed_keys.add("shards")
        if not isinstance(record, dict) or set(record) != allowed_keys:
            fail(f"artifacts.{name} must contain path, size, source_url and sha256")
        relative = record["path"]
        expected = record["sha256"]
        if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
            fail(f"artifacts.{name}.path must be a non-empty relative path")
        if not isinstance(expected, str) or len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
            fail(f"artifacts.{name}.sha256 must be a lowercase SHA-256 digest")
        if type(record["size"]) is not int or not 0 < record["size"] <= MAX_ARTIFACT_BYTES:
            fail(f"artifacts.{name}.size must fit a positive signed 64-bit file offset")
        parsed = urllib.parse.urlparse(record["source_url"])
        if parsed.scheme != "https" or not parsed.netloc:
            fail(f"artifacts.{name}.source_url must use HTTPS")
        artifact = (path.parent / relative).resolve()
        if path.parent not in artifact.parents:
            fail(f"artifacts.{name}.path escapes the bundle directory")
        has_shards=name=="weights" and "shards" in record
        shard_records=record.get("shards",[]) if has_shards else []
        shard_paths=[]
        if has_shards:
            if (bundle["weights_format"]!="safetensors" or
                    not relative.endswith(".safetensors.index.json") or
                    not isinstance(shard_records,list) or not shard_records):
                fail("shards require a SafeTensors index artifact")
            for index,shard in enumerate(shard_records):
                if not isinstance(shard,dict) or set(shard)!={"path","sha256","size","source_url"}:
                    fail(f"artifacts.weights.shards[{index}] must contain path, size, source_url and sha256")
                shard_relative=shard["path"]
                if (not isinstance(shard_relative,str) or not shard_relative or
                        Path(shard_relative).is_absolute() or Path(shard_relative).name!=shard_relative or
                        not shard_relative.endswith(".safetensors") or
                        any(not (c.isascii() and (c.isalnum() or c in "._-")) for c in shard_relative)):
                    fail(f"artifacts.weights.shards[{index}].path must be a shard filename")
                if (not isinstance(shard["sha256"],str) or len(shard["sha256"])!=64 or
                        any(c not in "0123456789abcdef" for c in shard["sha256"])):
                    fail(f"artifacts.weights.shards[{index}].sha256 must be a lowercase SHA-256 digest")
                if type(shard["size"]) is not int or not 0<shard["size"]<=MAX_ARTIFACT_BYTES:
                    fail(f"artifacts.weights.shards[{index}].size must fit a positive signed 64-bit file offset")
                shard_url=urllib.parse.urlparse(shard["source_url"])
                if shard_url.scheme!="https" or not shard_url.netloc:
                    fail(f"artifacts.weights.shards[{index}].source_url must use HTTPS")
                candidate=(artifact.parent/shard_relative).resolve()
                if candidate.parent!=artifact.parent or candidate==artifact:
                    fail("weight shard paths must be sibling files beside the index")
                if candidate in shard_paths:
                    fail("weight shard paths must be unique")
                shard_paths.append(candidate)
                if verify_artifacts:
                    if not candidate.is_file():
                        fail(f"weight shard is missing: {shard_relative}")
                    if candidate.stat().st_size!=shard["size"]:
                        fail(f"weight shard size mismatch: {shard_relative}")
                    if digest(candidate)!=shard["sha256"]:
                        fail(f"weight shard SHA-256 mismatch: {shard_relative}")
        elif name=="weights" and relative.endswith(".safetensors.index.json"):
            fail("SafeTensors index artifacts must declare every shard")
        if verify_artifacts:
            if not artifact.is_file():
                fail(f"artifacts.{name} is missing: {relative}")
            if artifact.stat().st_size != record["size"]:
                fail(f"artifacts.{name} size mismatch: expected {record['size']}, got {artifact.stat().st_size}")
            actual = digest(artifact)
            if actual != expected:
                fail(f"artifacts.{name} SHA-256 mismatch: expected {expected}, got {actual}")
            if name == "weights":
                if has_shards:
                    try:index_data=json.loads(artifact.read_text(encoding="utf-8"))
                    except (OSError,UnicodeError,json.JSONDecodeError) as error:
                        fail(f"cannot read SafeTensors shard index: {error}")
                    weight_map=index_data.get("weight_map") if isinstance(index_data,dict) else None
                    if (not isinstance(weight_map,dict) or
                            any(not isinstance(value,str) for value in weight_map.values()) or
                            set(weight_map.values())!={item.name for item in shard_paths}):
                        fail("declared weight shards do not exactly match the index weight_map")
                if bundle["weights_format"] == "gguf-v3":
                    inventory = inspect_weights(artifact)
                    if inventory["format"] != "gguf":
                        fail("weights_format='gguf-v3' requires a GGUF artifact")
                else:
                    inventory = inspect_weights(artifact)
                    if inventory["format"] != "safetensors":
                        fail("weights_format='safetensors' requires a SafeTensors artifact")
                actual = set(inventory["dtype_counts"])
                allowed = set(weight_dtypes)
                if not actual.issubset(allowed):
                    fail(f"weight tensor dtypes {sorted(actual)} exceed declared weight_dtypes {sorted(allowed)}")
                if not actual:
                    fail("weights artifact contains no tensors")
        resolved[name] = artifact
    if verify_artifacts:
        expected_digest = artifacts["tokenizer"]["sha256"]
        expected_normalizer = TOKENIZER_RECIPES[recipe]["normalizer"]
        if recipe == 'sentencepiece-bpe-byte-fallback-v1':
            try:
                source = json.loads(resolved["tokenizer"].read_text(encoding="utf-8"))
            except (OSError, UnicodeError, json.JSONDecodeError) as error:
                fail(f"cannot inspect SentencePiece tokenizer configuration: {error}")
            model = source.get("model", {})
            if (source.get("normalizer") != {'type':'Sequence','normalizers':[
                    {'type':'Prepend','prepend':'▁'},
                    {'type':'Replace','pattern':{'String':' '},'content':'▁'}]} or
                    source.get("pre_tokenizer") is not None or
                    source.get("decoder") != {'type':'Sequence','decoders':[
                        {'type':'Replace','pattern':{'String':'▁'},'content':' '},
                        {'type':'ByteFallback'},{'type':'Fuse'},
                        {'type':'Strip','content':' ','start':1,'stop':0}]} or
                    model.get("byte_fallback") is not True or model.get("fuse_unk") is not True or
                    model.get("unk_token") not in model.get("vocab",{})):
                fail("tokenizer file does not match sentencepiece-bpe-byte-fallback-v1")
            tokenizer_tokens = {token_id: token for token, token_id in model.get("vocab",{}).items()}
            tokenizer_tokens.update({item["id"]: item["content"] for item in source.get("added_tokens",[])})
        else:
            from byte_bpe import Tokenizer
            tokenizer = Tokenizer(resolved["tokenizer"], expected_digest)
            actual_normalizer = getattr(tokenizer, 'normalizer', None)
            if actual_normalizer != expected_normalizer:
                fail("tokenizer file normalizer does not match tokenizer_recipe")
            tokenizer_tokens = tokenizer.tokens
        if not tokenizer_tokens or max(tokenizer_tokens) >= architecture["vocabulary"]:
            fail("tokenizer token IDs exceed architecture_config.vocabulary")
        if bundle["bos_token_id"] not in tokenizer_tokens or bundle["eos_token_id"] not in tokenizer_tokens:
            fail("declared BOS/EOS token IDs must exist in the tokenizer vocabulary")
        validate_renderer_special_tokens(renderer,resolved["tokenizer"],
                                         bundle['bos_token_id'],bundle['eos_token_id'])
    if bundle.get("model_id") is None or not isinstance(bundle["model_id"], str) or not bundle["model_id"].strip():
        fail("model_id must be a non-empty provenance label")
    if bundle.get("license") is None or not isinstance(bundle["license"], str) or not bundle["license"].strip():
        fail("license must record the model's declared license")
    return bundle, resolved


def inspect_weights(path):
    """Use the native importer as the format authority for bounded inventory."""
    executable = Path(__file__).resolve().parents[1] / "build" / "engine-weights"
    if not executable.is_file():
        fail("native weight inspector is unavailable; build it with make engine")
    try:
        result = subprocess.run([str(executable), "inspect", str(path)],
            check=False, capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as error:
        fail(f"cannot inspect weights with the native importer: {error}")
    if result.returncode:
        fail(f"native weight inspection refused artifact: {result.stderr.strip()}")
    try:
        inventory = json.loads(result.stdout)
    except json.JSONDecodeError as error:
        fail(f"native weight inspector returned invalid inventory: {error}")
    counts = collections.Counter(tensor["dtype"] for tensor in inventory.get("tensors", []))
    inventory["dtype_counts"] = dict(sorted(counts.items()))
    return inventory


def capability_report(extra_adapters=()):
    adapters = _load_adapters(extra_adapters)
    return {
        "format": "HIBR-MODEL-CAPABILITIES-1",
        "weight_formats": list(WEIGHTS_FORMATS),
        "operations": list(ADAPTER_REGISTRY["operations"]),
        "adapters": [
            {**{key: adapter[key] for key in (
                "id", "native_driver", "families", "architectures",
                "configuration_schema", "weight_formats", "weight_dtypes", "context_limit",
                "compatibility_status", "tokenizer_recipes", "chat_renderers",
                "required_operations")},
             **({"compatibility_limits": adapter["compatibility_limits"]}
                if "compatibility_limits" in adapter else {}),
             **({"prepend_bos": adapter["prepend_bos"]}
                if "prepend_bos" in adapter else {})}
            for adapter in adapters.values()
        ],
        "limits": [
            "Only declared architecture/configuration and tensor layouts are accepted.",
            "Tokenizer and chat-renderer compatibility must also match.",
            "This inventory does not claim physical-GPU parity or answer quality.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, nargs="?")
    parser.add_argument("--json", action="store_true", help="emit validated metadata and resolved artifact paths")
    parser.add_argument("--provider-metadata-json",
                        help="runtime-checked Hibr intelligence adapter-info output for an external adapter")
    parser.add_argument("--external-adapter",
                        help="include one installed external adapter in --capabilities")
    parser.add_argument("--hibr", type=Path,
                        help="built Hibr checkout used to query --external-adapter")
    parser.add_argument("--module-directory", type=Path,
                        default=Path(__file__).resolve().parents[1] / "build/prototype-mods",
                        help="module directory used to query --external-adapter")
    parser.add_argument("--capabilities", action="store_true",
                        help="list registered model execution capabilities without a manifest")
    args = parser.parse_args()
    if args.capabilities:
        if args.manifest is not None:
            parser.error("--capabilities does not take a bundle manifest")
        if args.external_adapter:
            if args.hibr is None:
                parser.error("--external-adapter requires --hibr")
            try:
                metadata=query_provider(args.external_adapter,args.hibr,args.module_directory)
                external=dict(metadata["capabilities"],id=args.external_adapter)
                report=capability_report([external])
            except (OSError,ValueError,KeyError,TypeError) as error:
                parser.error(str(error))
        else:
            report = capability_report()
        if args.json:
            print(json.dumps(report, sort_keys=True))
        else:
            print("Registered Hibr model adapters:")
            for adapter in report["adapters"]:
                print(f"- {adapter['id']}: {', '.join(adapter['architectures'])}; "
                      f"weights {', '.join(adapter['weight_formats'])}; "
                      f"tokenizers {', '.join(adapter['tokenizer_recipes'])}; "
                      f"renderers {', '.join(adapter['chat_renderers'])}")
            for limit in report["limits"]:
                print("Limit: "+limit)
        return 0
    if args.manifest is None:
        parser.error("provide a bundle manifest or use --capabilities")
    try:
        provider_metadata=(json.loads(args.provider_metadata_json)
                           if args.provider_metadata_json else None)
        if provider_metadata:
            manifest_data=json.loads(args.manifest.read_text(encoding="utf-8"))
            if isinstance(manifest_data,dict) and manifest_data.get("adapter_id") in ADAPTERS:
                provider_metadata=None
            else:
                provider_metadata=validate_provider_contract(provider_metadata)
        bundle, artifacts = validate(args.manifest,provider_metadata=provider_metadata)
    except json.JSONDecodeError as error:
        print(f"invalid provider metadata JSON: {error}", file=sys.stderr)
        return 2
    except (OSError,ValueError) as error:
        print(f"model bundle refused: {error}", file=sys.stderr)
        return 2
    capabilities=(provider_metadata.get("capabilities",{}) if provider_metadata else
                  ADAPTERS[bundle["adapter_id"]])
    result = {"status": "validated", "model_id": bundle["model_id"],
              "family": bundle["family"], "adapter_id": bundle["adapter_id"], "execution": bundle["execution"],
              "compatibility_status": capabilities.get("compatibility_status","experimental"),
              "training": bundle["training"], "architecture_config": bundle["architecture_config"],
              "artifacts": {key: str(value) for key, value in artifacts.items()}}
    if (provider_metadata and capabilities.get("configuration_schema")=="provider-json-v1" and
            capabilities.get("configuration_encoding")=="json-object-v1"):
        result["provider_config_json"]=json.dumps(
            {"architecture":bundle["architecture_config"],
             "bos_token_id":bundle["bos_token_id"],"eos_token_id":bundle["eos_token_id"]},
            separators=(",",":"),ensure_ascii=True)
    if args.json:
        print(json.dumps(result, sort_keys=True))
    else:
        print(f"Validated {bundle['model_id']} ({bundle['family']}); declared execution evidence={bundle['execution']}, training unsupported")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
