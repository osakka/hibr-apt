#!/usr/bin/env python3
"""Build a bounded, identity-checked Hibr function context using Hibr inspect."""
import argparse
import json
from pathlib import Path
import re
import sys
import hashlib
import os
import subprocess

from export_briefs import ROOT, collect, source_bytes
from hibr_runtime import as_layout, hibr_layout


def fnv1a64(data):
    value = 14695981039346656037
    for byte in data:
        value = ((value ^ byte) * 1099511628211) & 0xffffffffffffffff
    return f'fnv1a64:{value:016x}'


def inspect_variables(hibr, source, function):
    """Return Hibr's raw, source-bound variable inspection result."""
    script = ('need inspect\n'
              'if result := inspect vars "$1" "$2" -j; then :; fi\n'
              'json emit result\n')
    env = os.environ.copy()
    # The HUI process may be running inside a held desktop. Inspection is a
    # headless helper and must not inherit that session's terminal protocol.
    for key in ('HIBR_HOLD', 'HIBR_HOLDCOPY', 'HIBR_TESTIDLE'):
        env.pop(key, None)
    env = as_layout(hibr).environment(env)
    run = subprocess.run(
        [str(as_layout(hibr).executable), '-c', script, '_', str(source), function],
        env=env,
        capture_output=True, text=True, timeout=90)
    if run.returncode != 0 or run.stderr:
        return {'state': 'blocked', 'reason': run.stderr.strip() or 'variable inspection unavailable'}
    try:
        return json.loads(run.stdout.strip())
    except json.JSONDecodeError as error:
        raise ValueError('Hibr returned malformed variable inspection output.') from error


def normalize_variable_inspection(result, source, identity, size, function, declaration):
    """Adapt Hibr inspect-vars generations without deriving language facts here."""
    if not isinstance(result, dict):
        raise ValueError('Hibr returned a non-object variable inspection.')
    if (result.get('inspect') != 1 or result.get('state') != 'ok' or
            result.get('partial') is not False):
        return {'state': 'blocked', 'reason': 'Hibr did not provide a complete variable inspection.'}
    proof = result.get('source', {})
    if (not isinstance(proof, dict) or proof.get('path') != str(source) or proof.get('id') != identity or
            proof.get('size') != size):
        raise ValueError('Hibr returned variable inspection for a different source snapshot.')
    raw_sites = result.get('vars', [])
    if not isinstance(raw_sites, list) or len(raw_sites) > 512:
        raise ValueError('Hibr returned malformed or oversized variable inspection.')

    sites = []
    candidates = {}
    binding_evidence_seen = False
    binding_incomplete = False
    binding_unavailable = False
    binding_truncated = False
    for raw in raw_sites:
        if not isinstance(raw, dict):
            raise ValueError('Hibr returned a non-object variable-site record.')
        raw_source = raw.get('source', {})
        span = raw.get('span', {})
        known = raw.get('known')
        name = raw.get('name', '')
        owner = raw.get('owner') or ''
        exact = raw.get('exact', True)
        if (not isinstance(raw_source, dict) or not isinstance(span, dict) or
                raw_source.get('path') != str(source) or raw_source.get('id') != identity or
                raw_source.get('size') != size or owner != function or
                known not in {'syntax', 'inferred'} or
                type(exact) is not bool or
                not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name) or
                type(span.get('line')) is not int or type(span.get('endline')) is not int or
                span['line'] < 1 or span['endline'] < span['line']):
            raise ValueError('Hibr returned malformed or mismatched variable-site evidence.')

        kind = raw.get('kind')
        binding = raw.get('binding_analysis')
        scope_id = raw.get('scope_id', '')
        if kind is None:
            # Hibr's original vars contract uses access/form. Keep its exact
            # classifications and mark binding analysis unavailable below.
            access, form = raw.get('access'), raw.get('form')
            if access == 'read':
                kind = 'read'
            elif access == 'name':
                kind = 'reference'
            elif access == 'write' and form == 'param':
                kind = 'parameter'
            elif access == 'write' and form == 'local':
                kind = 'declaration'
            elif access == 'write' and form in {'declare', 'typeset', 'export', 'readonly'}:
                kind = 'declaration'
            elif access == 'write':
                kind = 'write'
            else:
                raise ValueError('Hibr returned an unsupported variable access classification.')
            scope_id = f'function:{function}'
        if kind not in {'parameter', 'declaration', 'write', 'prefix', 'bind',
                        'loop-write', 'array-write', 'read', 'reference'}:
            raise ValueError('Hibr returned an unsupported variable-site kind.')
        site = {'source': raw_source, 'known': known, 'span': span, 'name': name,
                'kind': kind, 'owner': function, 'scope_id': scope_id, 'exact': exact}
        if binding is not None:
            binding_evidence_seen = True
            if (not isinstance(binding, dict) or binding.get('complete') is not False or
                    binding.get('state') not in {'candidate-set', 'incomplete', 'unavailable'} or
                    not isinstance(binding.get('candidates', []), list) or
                    len(binding.get('candidates', [])) > 4096):
                raise ValueError('Hibr returned malformed binding-analysis evidence.')
            site['binding_analysis'] = binding
            binding_incomplete |= binding.get('state') == 'incomplete'
            binding_unavailable |= binding.get('state') == 'unavailable'
            binding_truncated |= binding.get('truncated') is True
            for candidate in binding.get('candidates', []):
                if not isinstance(candidate, dict):
                    raise ValueError('Hibr returned a malformed binding candidate.')
                relation = candidate.get('relation')
                if relation in {'dynamic-caller', 'possible-global'}:
                    candidate_id = candidate.get('id')
                    if not isinstance(candidate_id, str) or not candidate_id:
                        raise ValueError('Hibr returned a binding candidate without a stable ID.')
                    key = (candidate_id, relation)
                    candidates[key] = candidate
        sites.append(site)

    parameters = {item.get('name') for item in declaration.get('params', [])}
    reported_parameters = {item['name'] for item in sites if item['kind'] == 'parameter'}
    if not parameters.issubset(reported_parameters):
        return {'state': 'blocked', 'reason': 'Hibr did not return all declared parameters as variable sites.'}
    return {'state': 'ready', 'version': '1', 'identity': identity,
            'name': function, 'path': str(source), 'size': size,
            'variables': sites, 'dynamic_candidates': list(candidates.values()),
            'binding_incomplete': binding_incomplete,
            'binding_unavailable': binding_unavailable or not binding_evidence_seen,
            'binding_truncated': binding_truncated}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hibr', required=True, type=Path,
                        help='Hibr source checkout or executable (in a desktop: $HIBR)')
    parser.add_argument('--desktop', type=Path,
                        help='folder holding desktop.hibr (in a desktop: $DT_HERE)')
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--function', required=True)
    parser.add_argument('--max-source-bytes', required=True, type=int)
    args = parser.parse_args()
    try:
        args.hibr = hibr_layout(args.hibr, args.desktop)
    except ValueError as error:
        parser.error(str(error))
    if not 64 <= args.max_source_bytes <= 4096:
        parser.error('--max-source-bytes must be in 64..4096')
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', args.function):
        parser.error('function name must be a simple Hibr identifier')
    source = args.source.resolve(strict=True)
    if not source.is_file():
        parser.error('--source must name a regular Hibr source file')

    origin, packets = collect(args.hibr, source, args.function)
    if len(packets) != 1 or packets[0].get('state') != 'ready':
        reason = packets[0].get('reason', 'canonical brief unavailable') if packets else 'no brief returned'
        raise ValueError(f'Hibr refused this function brief: {reason}')
    packet = packets[0]
    declaration = packet.get('declaration', {})
    identity = origin.get('identity')
    size = origin.get('bytes')
    if (packet.get('version') != '1' or packet.get('identity') != identity or
            packet.get('name') != args.function or
            declaration.get('name') != args.function or
            declaration.get('source', {}).get('path') != str(source) or
            declaration.get('source', {}).get('id') != identity or
            declaration.get('source', {}).get('size') != size):
        raise ValueError('The canonical brief lacks a complete, identity-matched declaration.')
    span = declaration.get('span', {})
    start, end = span.get('start'), span.get('end')
    if type(start) is not int or type(end) is not int or start < 0 or end <= start or end > size:
        raise ValueError('The canonical brief returned an invalid function source span.')

    raw = source_bytes(source)
    if len(raw) != size or fnv1a64(raw) != identity or hashlib.sha256(raw).hexdigest() != origin.get('sha256'):
        raise ValueError('The source changed after Hibr built its brief; reload and try again.')
    snippet = raw[start:end]
    if len(snippet) > args.max_source_bytes:
        raise ValueError(f'The exact function source is {len(snippet)} bytes; the active model budget allows '
                         f'{args.max_source_bytes}. Choose a shorter function or a larger-context model.')
    try:
        source_text = snippet.decode('utf-8')
    except UnicodeDecodeError as error:
        raise ValueError('The inspected function span is not valid UTF-8.') from error

    first_line = span.get('line', 0)
    last_line = span.get('endline', first_line)
    author = declaration.get('summary')
    author_summary = ''
    author_summary_line = 0
    author_summary_endline = 0
    if author is not None:
        if not isinstance(author, dict):
            raise ValueError('The canonical brief returned malformed author-description evidence.')
        author_source = author.get('source', {})
        author_span = author.get('span', {})
        if not isinstance(author_source, dict) or not isinstance(author_span, dict):
            raise ValueError('The canonical brief returned malformed author-description provenance.')
        author_text = author.get('text')
        author_start = author_span.get('start')
        author_end = author_span.get('end')
        author_summary_line = author_span.get('line', 0)
        author_summary_endline = author_span.get('endline', 0)
        if (author.get('known') != 'declared' or
                not isinstance(author_text, str) or not author_text or len(author_text) > 4096 or
                author_source.get('path') != str(source) or author_source.get('id') != identity or
                author_source.get('size') != size or type(author_start) is not int or
                type(author_end) is not int or author_start < 0 or author_end <= author_start or
                author_end > size or type(author_summary_line) is not int or
                type(author_summary_endline) is not int or author_summary_line < 1 or
                author_summary_endline < author_summary_line):
            raise ValueError('The canonical brief returned malformed or mismatched author-description evidence.')
        author_summary = author_text
    brief_lines = packet['text'].splitlines()
    if not brief_lines or not brief_lines[0].startswith(args.function + ' - captured source facts'):
        raise ValueError('The canonical brief has an unexpected fact layout.')
    expected_labels = ('Declared inputs:', 'Static call sites:', 'Named callers in this file:',
                       'Literal name references:', 'Unknown:')
    facts = {}
    for label in expected_labels:
        matches = [line for line in brief_lines if line.startswith(label)]
        if len(matches) != 1:
            raise ValueError('The canonical brief is missing or repeats a required fact category.')
        facts[label] = matches[0]
    source_call_sites = []
    for site in packet.get('calls', []):
        meta = site.get('source', {})
        site_span = site.get('span', {})
        if (site.get('known') != 'syntax' or meta.get('path') != str(source) or
                meta.get('id') != identity or meta.get('size') != size or
                site.get('owner') != args.function or
                type(site_span.get('line')) is not int or type(site_span.get('endline')) is not int or
                site_span['line'] < 1 or site_span['endline'] < site_span['line']):
            raise ValueError('The canonical brief returned malformed or mismatched call-site evidence.')
        source_call_sites.append({'name': site.get('name', ''),
                                  'resolution': site.get('resolution', 'unresolved'),
                                  'owner': site.get('owner', ''),
                                  'line': site_span['line'], 'endline': site_span['endline']})
    source_incoming_sites = []
    for site in packet.get('incoming', []):
        meta = site.get('source', {})
        site_span = site.get('span', {})
        if (site.get('known') != 'syntax' or meta.get('path') != str(source) or
                meta.get('id') != identity or meta.get('size') != size or
                site.get('name') != args.function or site.get('resolution') != 'function' or
                type(site_span.get('line')) is not int or type(site_span.get('endline')) is not int or
                site_span['line'] < 1 or site_span['endline'] < site_span['line']):
            raise ValueError('The canonical brief returned malformed or mismatched caller evidence.')
        source_incoming_sites.append({'name': site['name'], 'owner': site.get('owner') or 'top level',
                                      'line': site_span['line'], 'endline': site_span['endline']})
    try:
        raw_variable_packet = inspect_variables(args.hibr, source, args.function)
        variable_packet = normalize_variable_inspection(
            raw_variable_packet, source, identity, size, args.function, declaration)
    except (OSError, TimeoutError, ValueError) as error:
        raise ValueError(f'Could not obtain canonical Hibr variable evidence: {error}') from error
    variable_state = 'unavailable'
    variable_sites = []
    binding_candidates = []
    binding_state = 'unavailable'
    variable_context = 'Hibr variable inspection is unavailable from this provider; no variable-site absence claim is made.'
    if variable_packet.get('state') == 'ready':
        if (variable_packet.get('version') != '1' or variable_packet.get('identity') != identity or
                variable_packet.get('name') != args.function or variable_packet.get('path') != str(source) or
                int(variable_packet.get('size', -1)) != size):
            raise ValueError('Hibr returned variable evidence for a different source snapshot.')
        sites = variable_packet.get('variables', [])
        if not isinstance(sites, list):
            raise ValueError('Hibr returned malformed variable-site evidence.')
        declared_parameters = {item.get('name') for item in declaration.get('params', [])}
        reported_parameters = {item.get('name') for item in sites if item.get('kind') == 'parameter'}
        if not declared_parameters.issubset(reported_parameters):
            variable_context = ('This Hibr provider did not return all declared parameters as variable sites; '
                                'variable inspection is unavailable and no site-absence claim is made.')
            sites = []
        elif len(sites) > 32:
            variable_state = 'limited'
            binding_state = 'limited'
            variable_context = 'Hibr found more than 32 variable sites; this attachment omits the list and makes no site-absence claim.'
        else:
            for site in sites:
                source_meta = site.get('source', {})
                site_span = site.get('span', {})
                if (site.get('known') not in {'syntax', 'inferred'} or site.get('owner') != args.function or
                        source_meta.get('path') != str(source) or source_meta.get('id') != identity or
                        source_meta.get('size') != size or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', site.get('name', '')) or
                        site.get('kind') not in {'parameter', 'declaration', 'write', 'prefix', 'bind', 'loop-write', 'array-write', 'read', 'reference'} or
                        type(site_span.get('line')) is not int or type(site_span.get('endline')) is not int or
                        site_span['line'] < 1 or site_span['endline'] < site_span['line']):
                    raise ValueError('Hibr returned malformed or mismatched variable-site evidence.')
                variable_sites.append({'name': site['name'], 'kind': site['kind'], 'known': site['known'],
                                       'exact': site['exact'],
                                       'line': site_span['line'], 'endline': site_span['endline'],
                                       'scope_id': site.get('scope_id', ''),
                                       'binding_state': site.get('binding_analysis', {}).get('state', 'not-applicable')})
            variable_state = 'ready'
            raw_candidates = variable_packet.get('dynamic_candidates', [])
            if not isinstance(raw_candidates, list):
                raise ValueError('Hibr returned malformed binding candidates.')
            if len(raw_candidates) > 32:
                binding_state = 'limited'
            else:
                for candidate in raw_candidates:
                    candidate_source = candidate.get('source', {})
                    candidate_span = candidate.get('span', {})
                    relation = candidate.get('relation')
                    call_path = candidate.get('call_path', [])
                    if (candidate.get('known') != 'syntax' or
                            candidate_source.get('path') != str(source) or
                            candidate_source.get('id') != identity or
                            candidate_source.get('size') != size or
                            not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', candidate.get('name', '')) or
                            candidate.get('kind') not in {'declaration', 'parameter', 'write', 'bind', 'loop-write', 'array-write'} or
                            relation not in {'dynamic-caller', 'possible-global'} or
                            type(candidate_span.get('line')) is not int or
                            type(candidate_span.get('endline')) is not int or
                            candidate_span['line'] < 1 or candidate_span['endline'] < candidate_span['line'] or
                            not isinstance(call_path, list) or len(call_path) > 16):
                        raise ValueError('Hibr returned malformed or mismatched binding-candidate evidence.')
                    calls = []
                    for call in call_path:
                        call_source = call.get('source', {})
                        call_span = call.get('span', {})
                        if (call.get('known') != 'syntax' or call_source.get('path') != str(source) or
                                call_source.get('id') != identity or call_source.get('size') != size or
                                not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', call.get('name', '')) or
                                not call.get('owner') or type(call_span.get('line')) is not int or
                                type(call_span.get('endline')) is not int or call_span['line'] < 1 or
                                call_span['endline'] < call_span['line']):
                            raise ValueError('Hibr returned malformed or mismatched caller-path evidence.')
                        calls.append({'name': call['name'], 'owner': call['owner'],
                                      'line': call_span['line'], 'endline': call_span['endline']})
                    if relation == 'dynamic-caller' and (not candidate.get('owner') or not calls or calls[-1]['name'] != args.function):
                        raise ValueError('Hibr returned a caller candidate without a path to the selected function.')
                    binding_candidates.append({'name': candidate['name'], 'kind': candidate['kind'],
                                               'owner': candidate.get('owner') or 'top level',
                                               'storage': candidate.get('storage', ''),
                                               'relation': relation, 'line': candidate_span['line'],
                                               'endline': candidate_span['endline'], 'call_path': calls})
                binding_state = 'reported' if binding_candidates else 'none-reported'
            rendered = '; '.join(
                f"{site['name']} {site['kind']}" + (' (inferred)' if site.get('known') == 'inferred' else '') +
                (' (approximate span)' if not site.get('exact', True) else '') +
                f" at L{site['line']}" for site in variable_sites)
            variable_context = ('Hibr variable access sites: ' + (rendered or 'none were reported by this complete request') +
                                '. Reads and writes are not resolved to declarations. '
                                'No runtime values, execution order, branch choices or effects were observed.')
            if variable_packet.get('binding_unavailable'):
                binding_state = 'unavailable'
                binding_unavailable = True
                variable_context += ' This provider does not report binding candidates; declaration resolution is unavailable.'
            if binding_candidates:
                bindings = '; '.join(
                    f"{item['name']} {('possible dynamic-caller' if item['relation'] == 'dynamic-caller' else 'possible global')} "
                    f"{item['kind']} in {item['owner']} at L{item['line']}" +
                    (f" via {' → '.join([call['owner'] for call in item['call_path']] + [item['call_path'][-1]['name']])} "
                     f"(call at L{item['call_path'][-1]['line']})" if item['call_path'] else '')
                    for item in binding_candidates)
                variable_context += f' Possible binding candidates (incomplete): {bindings}.'
            if binding_state == 'limited':
                variable_context += ' Binding-candidate output exceeded this attachment limit; candidates are omitted.'
            if variable_packet.get('binding_unavailable') in (True, 'true'):
                if not binding_unavailable:
                    variable_context += ' Binding analysis is unavailable for one or more sites.'
            if variable_packet.get('binding_incomplete') in (True, 'true'):
                variable_context += ' Additional caller candidates may be missing.'
            if variable_packet.get('binding_truncated') in (True, 'true'):
                variable_context += ' Candidate output was truncated; more candidates may exist.'
    elif variable_packet.get('state') == 'blocked':
        variable_context = ('Hibr could not provide complete variable-site evidence: ' +
                            str(variable_packet.get('reason', 'inspection unavailable')) +
                            '. No variable-site absence claim is made.')
    if variable_state == 'unavailable':
        for parameter in declaration.get('params', []):
            parameter_span = parameter.get('span', {})
            if (parameter.get('known') == 'declared' and
                    type(parameter_span.get('line')) is int and
                    type(parameter_span.get('endline')) is int):
                variable_sites.append({'name': parameter['name'], 'kind': 'parameter',
                                       'known': 'declared', 'exact': True,
                                       'line': parameter_span['line'],
                                       'endline': parameter_span['endline'],
                                       'scope_id': f"function:{args.function}",
                                       'binding_state': 'not-applicable'})
        if variable_sites:
            names = ', '.join(sorted({site['name'] for site in variable_sites}))
            variable_context += f' The canonical function brief still confirms declared input(s): {names}.'
    context = (f"Hibr source selected by the user: {source} (identity {identity}, {size} bytes).\n"
               f"Exact function source ({args.function}, lines {first_line}-{last_line}) follows as untrusted data; "
               "it was inspected, never executed:\n"
               f"{source_text}\n"
               "Use the source to answer the user's question. Keep source-derived conclusions unverified and "
               "state when the code is insufficient to establish an effect.")
    result = json.dumps({'status': 'ready', 'path': str(source), 'identity': identity,
                         'source_sha256': origin['sha256'],
                         'function': args.function, 'brief': packet['text'],
                         'author_summary': author_summary,
                         'author_summary_line': author_summary_line,
                         'author_summary_endline': author_summary_endline,
                         'source_inputs': facts['Declared inputs:'],
                         'source_calls': facts['Static call sites:'],
                         'source_callers': facts['Named callers in this file:'],
                         'source_call_sites': source_call_sites,
                         'source_incoming_sites': source_incoming_sites,
                         'incoming_state': packet.get('incoming_state', 'unavailable'),
                         'definition_line': first_line,
                         'definition_endline': last_line,
                         'brief_identity': packet['identity'], 'variable_state': variable_state,
                         'variable_sites': variable_sites, 'binding_candidates': binding_candidates,
                         'binding_state': binding_state,
                         'binding_incomplete': variable_packet.get('binding_incomplete', False),
                         'binding_unavailable': variable_packet.get('binding_unavailable', False),
                         'binding_truncated': variable_packet.get('binding_truncated', False),
                         'variable_context': variable_context,
                         'context': context}, ensure_ascii=False)
    if len(result.encode('utf-8')) > 15000:
        raise ValueError('The source context exceeds the HUI attachment bound; choose a shorter function.')
    print(result)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
