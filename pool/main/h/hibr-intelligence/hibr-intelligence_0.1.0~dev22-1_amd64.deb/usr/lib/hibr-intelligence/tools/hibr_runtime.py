"""Resolve a Hibr checkout or installed executable for local model tools."""
from pathlib import Path


def resolve_hibr(value):
    """Return the executable and adjacent module directories for Hibr."""
    path=Path(value).expanduser().resolve()
    if path.is_dir():
        executable=path/'build/hibr'
        modules=path/'build/mods'
    elif path.is_file():
        executable=path
        if path.parent.name=='build':
            modules=path.parent/'mods'
        elif path.parent.name=='bin':
            modules=path.parent.parent/'lib/hibr'
        else:
            modules=path.parent/'mods'
    else:
        raise ValueError(f'Hibr path is neither a checkout nor an executable: {path}')
    if not executable.is_file():
        raise ValueError(f'Hibr executable does not exist: {executable}')
    return executable,modules


class HibrLayout:
    """Where a Hibr build or installation keeps what helpers run.

    A source checkout has build/hibr, build/mods and programs/desktop. An
    installed Hibr is an executable such as /usr/bin/hibr, with its desktop
    library under PREFIX/share/hibr/desktop and modules on its default path.
    """

    def __init__(self, executable, modules, desktop):
        self.executable = executable
        self.modules = modules
        self.desktop = desktop

    def environment(self, base=None):
        """Environment for running this Hibr; a checkout needs its own modules."""
        import os
        env = dict(os.environ if base is None else base)
        if self.modules is not None:
            env['HIBR_MODPATH'] = str(self.modules)
        return env


def as_layout(value, desktop=None):
    """Accept an existing HibrLayout or resolve a path."""
    return value if isinstance(value, HibrLayout) else hibr_layout(value, desktop)


def hibr_layout(value, desktop=None):
    """Resolve a Hibr source checkout or an installed executable.

    In a desktop, pass the running shell (`$HIBR`) and the desktop's own folder
    (`$DT_HERE`); install prefixes differ between Debian, Homebrew and source
    installs, so nothing here assumes one. HIBR_DESKTOP_DIR is the fallback
    for the folder, then the conventional location beside the executable.
    """
    import os
    desktop = desktop or os.environ.get('HIBR_DESKTOP_DIR') or None
    path = Path(value).expanduser()
    if path.is_dir():
        path = path.resolve()
        layout = HibrLayout(path / 'build/hibr', path / 'build/mods',
                            path / 'programs/desktop/desktop.hibr')
    elif path.is_file():
        executable = path.resolve()
        if executable.parent.name == 'build':
            checkout = executable.parent.parent
            layout = HibrLayout(executable, executable.parent / 'mods',
                                checkout / 'programs/desktop/desktop.hibr')
        else:
            prefix = executable.parent.parent
            layout = HibrLayout(executable, None, prefix / 'share/hibr/desktop/desktop.hibr')
    else:
        raise ValueError(f'Hibr path is neither a checkout nor an executable: {path}')
    if desktop:
        layout.desktop = Path(desktop).expanduser().resolve() / 'desktop.hibr'
    if not layout.executable.is_file() or not os.access(layout.executable, os.X_OK):
        raise ValueError(f'Hibr executable does not exist: {layout.executable}')
    if not layout.desktop.is_file():
        raise ValueError(f'Hibr desktop library does not exist: {layout.desktop}')
    return layout
