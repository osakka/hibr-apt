"""Local immutable reference snapshots/deltas. Does not train or promote models."""
import argparse
import hashlib
import json
import os
import stat
from pathlib import Path
import subprocess

FORMAT = 'HIBR-KNOWLEDGE-1'


def git(repo, *args):
    return subprocess.check_output(['git','--no-pager','-c','core.fsmonitor=false','-c','core.hooksPath=/dev/null',
                                    '-C',str(repo),*args], stderr=subprocess.PIPE)



def identity(sources, records):
    stable_sources = [{k:v for k,v in s.items() if k!='location'} for s in sources]
    raw = json.dumps({'format':FORMAT,'sources':stable_sources,'records':records},sort_keys=True,separators=(',',':')).encode()
    return hashlib.sha256(raw).hexdigest()


def registration_identity(sources):
    raw = json.dumps(sources,sort_keys=True,separators=(',',':')).encode()
    return hashlib.sha256(raw).hexdigest()


def load(path):
    raw = path.read_bytes()
    if len(raw)>16*1024*1024:
        raise ValueError('Manifest exceeds 16 MiB')
    data = json.loads(raw)
    if data.get('format')!=FORMAT or data.get('snapshot_id')!=identity(data['sources'],data['records']):
        raise ValueError('Invalid prior snapshot identity')
    keys = [(r['source'],r['path']) for r in data['records']]
    if len(keys)!=len(set(keys)):
        raise ValueError('Duplicate snapshot records')
    return data


def build(sources, output, previous=None, max_file=1048576, max_total=50000000):
    if max_file<=0 or max_total<=0:
        raise ValueError('Byte limits must be positive')
    prior = load(previous) if previous else None
    for source in sources:
        if source['kind']=='docs' and output.resolve().is_relative_to(Path(source['location']).resolve()):
            raise ValueError('Snapshot output must be outside document sources')
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    objects = output/'objects'; objects.mkdir(mode=0o700)
    records, metadata, names = [], [], set()
    total = 0
    def consume(name, path, size, read, reason=None, blob=None):
        nonlocal total
        if len(records)>=20000:
            raise ValueError('Snapshot record limit exceeded')
        record = {'source':name,'path':path,'bytes':size}
        if blob:
            record['git_blob']=blob
        if reason is None and size>max_file:
            reason = 'file-byte-limit'
        if reason is None:
            raw = read()
            if len(raw)!=size:
                raise ValueError('Source size changed during read: '+path)
            if raw.startswith(b'%PDF-'):
                reason = 'pdf-text-extraction-not-implemented'
            elif b'\0' in raw:
                reason = 'binary-content'
            else:
                try:
                    raw.decode('utf-8')
                except UnicodeDecodeError:
                    reason = 'non-utf8-content'
            if reason is None and raw.startswith(b'version https://git-lfs.github.com/spec/v1\n'):
                reason = 'lfs-pointer-not-payload'
            if reason is None:
                total += len(raw)
                if total>max_total:
                    raise ValueError('Total byte budget exceeded; no complete snapshot published')
                digest = hashlib.sha256(raw).hexdigest()
                target = objects/(digest+'.txt')
                if not target.exists():
                    with os.fdopen(os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as f:
                        f.write(raw)
                record.update({'state':'reference','sha256':digest})
        if reason:
            record.update({'state':'excluded','reason':reason})
        records.append(record)
    for source in sorted(sources,key=lambda x:x['name']):
        name,kind,location = source['name'],source['kind'],Path(source['location']).resolve()
        if not name or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789_-' for c in name) or name in names:
            raise ValueError('Source names must be unique lower-case identifiers')
        names.add(name)
        if kind=='git':
            ref = source.get('ref','HEAD')
            revision = git(location,'rev-parse','--verify','--end-of-options',ref+'^{commit}').decode().strip()
            tree = git(location,'ls-tree','-r','-z','-l',revision)
            metadata.append({'name':name,'kind':kind,'location':str(location),'revision':revision,'tracked_ref':ref,'working_tree_included':False})
            for entry in tree.split(b'\0'):
                if not entry:
                    continue
                fields,path = entry.split(b'\t',1); mode,obj,oid,size = fields.split()
                path = path.decode('utf-8'); oid = oid.decode('ascii')
                reason = 'git-symlink' if mode==b'120000' else 'gitlink' if obj!=b'blob' else None
                consume(name,path,int(size) if size!=b'-' else 0,
                        lambda oid=oid:git(location,'cat-file','blob',oid),reason,oid)
        elif kind=='docs':
            if not location.is_dir():
                raise ValueError('Document source must be a local directory')
            first = len(records)
            for path in sorted(location.rglob('*')):
                relative = path.relative_to(location).as_posix()
                if any(part in {'.git','.worktrees','__pycache__'} for part in Path(relative).parts):
                    continue
                if path.is_symlink():
                    consume(name,relative,0,lambda:b'',reason='document-symlink')
                elif path.is_file():
                    before = path.stat()
                    def read(path=path,before=before):
                        with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK),'rb') as f:
                            opened = os.fstat(f.fileno())
                            if not stat.S_ISREG(opened.st_mode) or opened.st_ino!=before.st_ino:
                                raise ValueError('Document is no longer the expected regular file')
                            raw = f.read(max_file+1)
                        after = path.stat()
                        if (before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_ino,after.st_size,after.st_mtime_ns):
                            raise ValueError('Document changed during read')
                        return raw
                    consume(name,relative,before.st_size,read)
            collection = hashlib.sha256(json.dumps(records[first:],sort_keys=True).encode()).hexdigest()
            metadata.append({'name':name,'kind':kind,'location':str(location),'revision':collection,'atomic_directory_snapshot':False})
        else:
            raise ValueError('Unknown source kind')
    records.sort(key=lambda r:(r['source'],r['path']))
    def live(data):
        return {(r['source'],r['path']):r['sha256'] for r in data if r['state']=='reference'}
    old,new = live(prior['records']) if prior else {},live(records)
    delta = {'added':[],'changed':[],'removed':[],'unchanged':0}
    for key in sorted(old.keys()|new.keys()):
        item = {'source':key[0],'path':key[1]}
        if key not in old:
            delta['added'].append(item)
        elif key not in new:
            delta['removed'].append(item)
        elif old[key]!=new[key]:
            delta['changed'].append(item)
        else:
            delta['unchanged']+=1
    result = {'format':FORMAT,'snapshot_id':identity(metadata,records),
              'source_registration_sha256':registration_identity(metadata),
              'sources':metadata,'records':records,
              'stage':'reference-snapshot-only','training_performed':False,'active_model_changed':False,
              'previous_snapshot':prior['snapshot_id'] if prior else None,'delta':delta,
              'limits':{'file_bytes':max_file,'total_reference_bytes':max_total},
              'reference_bytes':total,'unique_objects':len(list(objects.iterdir())),
              'builder_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with os.fdopen(os.open(output/'manifest.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w') as f:
        f.write(json.dumps(result,indent=2)+'\n')
    return result


def refresh(previous, output, expected_snapshot_id=None, expected_registration_sha256=None):
    """Create a new snapshot from the source registrations in a prior one."""
    prior = load(previous)
    current_registration = registration_identity(prior['sources'])
    if prior.get('source_registration_sha256') != current_registration:
        raise ValueError('Source registrations are not integrity-bound; rebuild this snapshot before using --refresh')
    if expected_snapshot_id is not None and expected_snapshot_id != prior['snapshot_id']:
        raise ValueError('Snapshot changed after its source registrations were reviewed')
    if expected_registration_sha256 is not None and expected_registration_sha256 != current_registration:
        raise ValueError('Source registrations changed after review')
    sources = []
    names = set()
    for source in prior['sources']:
        if not isinstance(source, dict):
            raise ValueError('Invalid source registration in prior snapshot')
        name, kind, location = source.get('name'), source.get('kind'), source.get('location')
        if not isinstance(name, str) or not isinstance(location, str) or kind not in ('git', 'docs'):
            raise ValueError('Invalid source registration in prior snapshot')
        if name in names:
            raise ValueError('Duplicate source registration in prior snapshot')
        names.add(name)
        registration = {'name': name, 'kind': kind, 'location': location}
        if kind == 'git':
            ref = source.get('tracked_ref')
            if not isinstance(ref, str) or not ref:
                raise ValueError('Git source has no recorded ref')
            registration['ref'] = ref
        sources.append(registration)
    limits = prior.get('limits')
    if not isinstance(limits, dict):
        raise ValueError('Prior snapshot has no valid source limits')
    max_file, max_total = limits.get('file_bytes'), limits.get('total_reference_bytes')
    if type(max_file) is not int or type(max_total) is not int or max_file <= 0 or max_total <= 0:
        raise ValueError('Prior snapshot has invalid source limits')
    if not sources:
        raise ValueError('Prior snapshot has no registered sources')
    return build(sources, output, previous, max_file, max_total)


def describe(path):
    """Return a bounded, escaped source-registration preview for explicit review."""
    prior = load(path)
    if prior.get('source_registration_sha256') != registration_identity(prior['sources']):
        raise ValueError('Source registrations are not integrity-bound; rebuild this snapshot before using --refresh')
    if len(prior['sources']) > 4:
        raise ValueError('More than 4 source registrations cannot be reviewed in the HUI dialog; use the CLI')
    lines = ['Sources read if you confirm:']
    for source in prior['sources']:
        name, kind, location = source['name'], source['kind'], source['location']
        label = f"{name} ({kind}"
        if kind == 'git':
            label += f", ref {source.get('tracked_ref', 'HEAD')}"
        lines.append(f"- {label}): {json.dumps(location, ensure_ascii=True)}")
    limits = prior.get('limits', {})
    lines.extend([f"File limit: {limits.get('file_bytes')} bytes",
                  f"Total limit: {limits.get('total_reference_bytes')} bytes",
                  'No source has been read yet. Refresh uses these paths and does not fetch network data.'])
    result = '\n'.join(lines)
    if len(result.encode('utf-8')) > 700:
        raise ValueError('Source registration preview exceeds the HUI dialog limit; use the CLI')
    return {'status':'ready','snapshot_id':prior['snapshot_id'],
            'registration_sha256':prior['source_registration_sha256'],
            'preview':result}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--git',action='append',default=[],metavar='NAME=LOCAL_REPO')
    parser.add_argument('--docs',action='append',default=[],metavar='NAME=LOCAL_DIRECTORY')
    parser.add_argument('--ref',action='append',default=[],metavar='NAME=REF')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--previous',type=Path)
    parser.add_argument('--refresh',type=Path,metavar='MANIFEST',
                        help='reuse registered local sources and limits from a prior snapshot')
    parser.add_argument('--expected-snapshot-id',metavar='SHA256',
                        help='refuse refresh if this reviewed snapshot identity changed')
    parser.add_argument('--expected-registration-sha256',metavar='SHA256',
                        help='refuse refresh if reviewed local source registrations changed')
    parser.add_argument('--describe',type=Path,metavar='MANIFEST',
                        help='print the exact local registrations before a refresh')
    parser.add_argument('--max-file-bytes',type=int)
    parser.add_argument('--max-total-bytes',type=int)
    args = parser.parse_args(); sources = []
    if args.describe:
        if args.output or args.refresh or args.previous or args.git or args.docs or args.ref or args.expected_snapshot_id or args.expected_registration_sha256 or args.max_file_bytes is not None or args.max_total_bytes is not None:
            parser.error('--describe cannot be combined with source, output, refresh, previous or limit options')
        try:
            print(json.dumps(describe(args.describe),ensure_ascii=True))
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
            parser.error(str(error))
        return
    if args.refresh:
        if not args.output or args.git or args.docs or args.ref or args.previous or args.max_file_bytes is not None or args.max_total_bytes is not None:
            parser.error('--refresh requires --output and cannot be combined with source, ref, previous or limit options')
        try:
            result = refresh(args.refresh, args.output,args.expected_snapshot_id,
                             args.expected_registration_sha256)
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
            parser.error(str(error))
        print(json.dumps({'snapshot_id':result['snapshot_id'],
                          'reference_bytes':result['reference_bytes'],
                          'unique_objects':result['unique_objects'],
                          'training_performed':result['training_performed'],
                          'active_model_changed':result['active_model_changed'],
                          'excluded_records':sum(r['state']=='excluded' for r in result['records']),
                          'delta':{key:len(value) if isinstance(value,list) else value
                                   for key,value in result['delta'].items()}},indent=2))
        return
    if not args.output:
        parser.error('--output is required when registering or extending sources')
    if args.expected_snapshot_id or args.expected_registration_sha256:
        parser.error('expected identity options require --refresh')
    refs = dict(item.split('=',1) for item in args.ref)
    for kind,items in [('git',args.git),('docs',args.docs)]:
        for item in items:
            name,location = item.split('=',1)
            sources.append({'name':name,'kind':kind,'location':location,**({'ref':refs.get(name,'HEAD')} if kind=='git' else {})})
    if not sources and args.previous:
        prior = load(args.previous)
        sources = [{'name':s['name'],'kind':s['kind'],'location':s['location'],
                    **({'ref':refs.get(s['name'],s.get('tracked_ref','HEAD'))} if s['kind']=='git' else {})}
                   for s in prior['sources']]
    if not sources or set(refs)-{s['name'] for s in sources if s['kind']=='git'}:
        parser.error('Register at least one source and use refs only for registered git sources')
    result = build(sources,args.output,args.previous,
                   args.max_file_bytes if args.max_file_bytes is not None else 1048576,
                   args.max_total_bytes if args.max_total_bytes is not None else 50000000)
    print(json.dumps({key:result[key] for key in ['snapshot_id','reference_bytes','unique_objects','training_performed','active_model_changed']},indent=2))
    print('Delta:',{key:len(value) if isinstance(value,list) else value for key,value in result['delta'].items()})
    print('Excluded:',sum(r['state']=='excluded' for r in result['records']))


if __name__=='__main__':
    main()
