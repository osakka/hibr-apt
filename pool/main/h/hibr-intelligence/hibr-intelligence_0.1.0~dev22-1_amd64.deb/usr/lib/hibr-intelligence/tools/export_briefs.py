"""Export the same Hibr-native brief packets displayed by HUI; no source execution/training."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import stat
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from hibr_runtime import as_layout

def source_bytes(path):
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK),'rb') as stream:
        st=os.fstat(stream.fileno())
        if not stat.S_ISREG(st.st_mode) or st.st_size>4*1024*1024:raise ValueError('Expected a bounded regular source file')
        raw=stream.read(4*1024*1024+1)
        if len(raw)>4*1024*1024:raise ValueError('Source exceeds inspection limit')
        return raw

def collect(hibr,source,function=None):
    hibr=as_layout(hibr)
    source=source.absolute();before=source_bytes(source)
    script=('. '+shlex.quote(str(hibr.desktop))+'\n'
            '. '+shlex.quote(str(ROOT/'apps/Development/coding.hibr'))+'\n'
            'need inspect\nif captured := inspect functions "$3" -j; then :; fi\njson emit captured\n'
            'coding_open 1 "$1"\nwait\ndt_jobtick\n'
            'i=0\nn=0\nwhile [ -n "${HC[1][document][views][functions][functions][$i][name]+x}" ]; do\n'
            ' if [ -z "$2" ] || [ "${HC[1][document][views][functions][functions][$i][name]}" = "$2" ]; then\n'
            '  [ "$n" -lt 32 ] || exit 7\n'
            '  coding_select 1 "$i"\nwait\ndt_jobtick\n'
            '  b := coding_brief_packet 1\nprintf "%s\\n" "$b"\nn=$((n + 1))\n'
            ' fi\ni=$((i + 1))\ndone\n'
            '[ "$n" -gt 0 ] || { b := coding_brief_block "no matching definitions"; printf "%s\\n" "$b"; }\n')
    with tempfile.TemporaryDirectory(prefix='hibr-brief-export-') as runtime:
        captured=Path(runtime)/'captured.hibr';captured.write_bytes(before);captured.chmod(0o600)
        env=os.environ.copy()
        # A HUI-launched helper inherits its held desktop session. Keep the
        # inspection CLI headless so it returns only its JSON packet stream.
        for key in ('HIBR_HOLD','HIBR_HOLDCOPY','HIBR_TESTIDLE'):
            env.pop(key,None)
        env=hibr.environment(env);env.update(XDG_RUNTIME_DIR=runtime)
        run=subprocess.run([str(hibr.executable),'-c',script,'_',str(source),function or '',str(captured)],
                           env=env,capture_output=True,text=True,timeout=90)
    if run.returncode==7:raise ValueError('Source exceeds 32 functions; select --function explicitly')
    if run.returncode or run.stderr:raise ValueError('Native packet export refused: '+run.stderr)
    if source_bytes(source)!=before:raise ValueError('Source changed during export')
    try:
        records=[json.loads(line) for line in run.stdout.splitlines()]
    except json.JSONDecodeError as error:
        raise ValueError('Native packet export returned malformed JSON.') from error
    if not records or any(not isinstance(record,dict) for record in records):
        raise ValueError('Native packet export returned no valid JSON records.')
    proof=records[0];packets=records[1:]
    if not packets or len(packets)>32:raise ValueError('Invalid bounded packet collection')
    for packet in packets:
        if packet['state']=='ready' and (packet['identity']!=proof['source']['id'] or int(packet['size'])!=len(before) or proof['source']['size']!=len(before)):
            raise ValueError('Packet does not match captured source bytes')
        if packet['version']!='1' or packet['state'] not in ['ready','blocked']:raise ValueError('Unsupported native brief')
    return {'path':str(source),'identity':proof.get('source',{}).get('id'),'sha256':hashlib.sha256(before).hexdigest(),'bytes':len(before)},packets

def write(path,raw):
    with os.fdopen(os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as stream:stream.write(raw)

def export(hibr,sources,output,function=None):
    hibr=as_layout(hibr)
    if not 1<=len(sources)<=32:raise ValueError('Export requires 1..32 sources')
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    manifest={'format':'HIBR-BRIEF-CORPUS-1','renderer_sha256':hashlib.sha256((ROOT/'apps/Development/coding.hibr').read_bytes()).hexdigest(),
              'hibr_version':subprocess.check_output([str(hibr.executable),'--version'],text=True).strip(),
              'training_performed':False,'active_model_changed':False,'sources':[],'packets':[],'examples':[],'blocked':[]}
    total=0
    for source_index,source in enumerate(sources):
        origin,packets=collect(hibr,source,function);manifest['sources'].append(origin)
        for index,packet in enumerate(packets):
            raw=json.dumps(packet,indent=2).encode()+b'\n';total+=len(raw)
            if total>16*1024*1024:raise ValueError('Corpus packet budget exceeded; no complete manifest')
            name=f'source-{source_index}-function-{index}.json';write(output/name,raw)
            manifest['packets'].append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'source_index':source_index,'state':packet['state']})
            if packet['state']=='ready':
                manifest['examples'].append({'packet':name,'question':f"Explain the declared inputs, outgoing call sites, named callers, literal mentions and unknowns for {packet['name']}.",
                    'answer_pointer':'.text','evidence_pointer':'.evidence','source_identity':packet['identity'],
                    'line':packet['declaration']['span']['line'],'endline':packet['declaration']['span']['endline']})
            else:manifest['blocked'].append({'packet':name,'reason':packet['reason']})
    write(output/'manifest.json',json.dumps(manifest,indent=2).encode()+b'\n')
    return manifest

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hibr',required=True,type=Path);parser.add_argument('--source',required=True,type=Path,action='append')
    parser.add_argument('--function');parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();result=export(args.hibr,args.source,args.output,args.function)
    print(f"Exported {len(result['examples'])} source-bound examples, {len(result['blocked'])} blocked packets; training_performed=false")
