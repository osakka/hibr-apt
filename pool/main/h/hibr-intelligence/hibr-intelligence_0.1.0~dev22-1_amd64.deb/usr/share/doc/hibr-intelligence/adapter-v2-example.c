/* SPDX-License-Identifier: LGPL-3.0-or-later */
#define _POSIX_C_SOURCE 200809L
#include <hibr.h>
#include "hibr-intelligence/adapter-v2.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TEST_ADAPTER_ID "test-public-v2"
#define TEST_MODULE_ID "hibr-intelligence-test-adapter-v2"
#define TEST_PROVIDER HI_ADAPTER_V2_PROVIDER_PREFIX TEST_ADAPTER_ID
#define TEST_OUTPUT_VALUE 8.0f

typedef struct {
	uint32_t next_token;
	uint32_t vocabulary;
	uint32_t hidden;
	uint32_t position;
	uint32_t context;
	const hi_adapter_v2_host *weights;
} test_model;

static int adapter_open(const hi_adapter_v2_host *weights,const char *configuration,
			const hi_adapter_v2_options *options,hi_adapter_v2_model *model,
			char *error,uint32_t error_capacity)
{
	hi_adapter_v2_tensor embedding;
	if(!weights||weights->version!=HI_ADAPTER_V2_API_VERSION||
	   weights->struct_size<sizeof(*weights)||!weights->find_tensor||!weights->read_f32||
	   !weights->reserve_model_bytes||!weights->release_model_bytes||
	   !weights->is_cancelled||!weights->project||
	   (weights->backend!=HI_ADAPTER_V2_CPU&&weights->backend!=HI_ADAPTER_V2_GPU)||!options||options->version!=HI_ADAPTER_V2_API_VERSION||
	   options->struct_size<sizeof(*options)||!options->cpu_workers||options->backend!=weights->backend||
	   !options->model_memory_bytes||!configuration||!model||model->state||
	   model->version!=HI_ADAPTER_V2_API_VERSION||model->struct_size<sizeof(*model)){
		if(error&&error_capacity)snprintf(error,error_capacity,"invalid v2 adapter host contract");
		return HI_ADAPTER_V2_INVALID;
	}
	if(weights->is_cancelled(weights->context))return HI_ADAPTER_V2_CANCELLED;
	if(options->model_memory_bytes<sizeof(test_model))return HI_ADAPTER_V2_LIMIT;
	if(weights->find_tensor(weights->context,"model.embed_tokens.weight",&embedding)!=HI_ADAPTER_V2_OK||
	   embedding.dtype!=HI_ADAPTER_V2_F32||embedding.rank!=2||embedding.shape[0]<2||
	   embedding.shape[0]>UINT32_MAX||embedding.shape[1]<2||embedding.shape[1]>UINT32_MAX||
	   embedding.elements>SIZE_MAX/sizeof(float)){
		if(error&&error_capacity)snprintf(error,error_capacity,"test provider requires a bounded F32 embedding matrix");
		return HI_ADAPTER_V2_UNSUPPORTED;
	}
	uint64_t staging_bytes=embedding.elements*sizeof(float);
	if(weights->reserve_model_bytes(weights->context,staging_bytes)!=HI_ADAPTER_V2_OK)
		return HI_ADAPTER_V2_LIMIT;
	float *values=malloc((size_t)embedding.elements*sizeof(*values));
	if(!values){weights->release_model_bytes(weights->context,staging_bytes);return HI_ADAPTER_V2_MEMORY;}
	int result=weights->read_f32(weights->context,embedding.name,0,embedding.elements,values);
	if(result!=HI_ADAPTER_V2_OK){free(values);weights->release_model_bytes(weights->context,staging_bytes);return result;}
	uint32_t output=0;
	for(uint32_t row=0;row<(uint32_t)embedding.shape[0];row++)
		if(values[(size_t)row*(size_t)embedding.shape[1]]==TEST_OUTPUT_VALUE){output=row;break;}
	free(values);weights->release_model_bytes(weights->context,staging_bytes);
	if(!output)return HI_ADAPTER_V2_UNSUPPORTED;
	/* Exercise the host dense projection on the session backend: a one-hot
	 * input over the [vocabulary,hidden] embedding must reproduce column 0. */
	uint64_t rows=embedding.shape[0],columns=embedding.shape[1];
	uint64_t projection_bytes=(rows+columns)*sizeof(float);
	if(weights->reserve_model_bytes(weights->context,projection_bytes)!=HI_ADAPTER_V2_OK)return HI_ADAPTER_V2_LIMIT;
	float *unit=calloc((size_t)columns,sizeof(*unit)),*projected=malloc((size_t)rows*sizeof(*projected));
	if(!unit||!projected){free(unit);free(projected);weights->release_model_bytes(weights->context,projection_bytes);return HI_ADAPTER_V2_MEMORY;}
	unit[0]=1.0f;
	result=weights->project(weights->context,embedding.name,HI_ADAPTER_V2_OUT_IN,1,columns,rows,unit,projected,rows);
	int matched=result==HI_ADAPTER_V2_OK&&projected[output]==TEST_OUTPUT_VALUE;
	free(unit);free(projected);weights->release_model_bytes(weights->context,projection_bytes);
	if(result!=HI_ADAPTER_V2_OK)return result;
	if(!matched){if(error&&error_capacity)snprintf(error,error_capacity,"host projection disagreed with the stored embedding");return HI_ADAPTER_V2_NUMERIC;}
	test_model *state=calloc(1,sizeof(*state));
	if(!state)return HI_ADAPTER_V2_MEMORY;
	if(weights->reserve_model_bytes(weights->context,sizeof(*state))!=HI_ADAPTER_V2_OK){free(state);return HI_ADAPTER_V2_LIMIT;}
	state->next_token=output;state->vocabulary=(uint32_t)embedding.shape[0];
	state->hidden=(uint32_t)embedding.shape[1];state->context=4096;
	state->weights=weights;
	model->state=state;model->context=state->context;model->vocabulary=state->vocabulary;
	model->hidden=state->hidden;model->bos=0;model->eos=2;
	return HI_ADAPTER_V2_OK;
}

static void adapter_close(hi_adapter_v2_model *model)
{
	if(!model)return;
	/* The provider releases the exact reservation when its allocation ends. */
	if(model->state){test_model *state=model->state;
		state->weights->release_model_bytes(state->weights->context,sizeof(*state));}
	free(model->state);memset(model,0,sizeof(*model));
}

static int adapter_rewind(hi_adapter_v2_model *model,uint32_t length)
{
	if(!model||!model->state||length>((test_model *)model->state)->context)return HI_ADAPTER_V2_INVALID;
	((test_model *)model->state)->position=length;return HI_ADAPTER_V2_OK;
}

static int adapter_logits(hi_adapter_v2_model *model,float *logits)
{
	if(!model||!model->state||!logits)return HI_ADAPTER_V2_INVALID;
	test_model *state=model->state;
	for(uint32_t i=0;i<state->vocabulary;i++)logits[i]=i==state->next_token?1.0f:0.0f;
	return HI_ADAPTER_V2_OK;
}

static int adapter_prefill(hi_adapter_v2_model *model,const uint32_t *tokens,uint32_t count,
			   float *logits,uint64_t logits_capacity)
{
	if(!model||!model->state||(!tokens&&count)||logits_capacity<model->vocabulary)return HI_ADAPTER_V2_INVALID;
	test_model *state=model->state;
	if(count>state->context)return HI_ADAPTER_V2_LIMIT;
	state->position=count;
	return adapter_logits(model,logits);
}

static int adapter_advance(hi_adapter_v2_model *model,const uint32_t *tokens,uint32_t count)
{
	if(!model||!model->state||(!tokens&&count))return HI_ADAPTER_V2_INVALID;
	test_model *state=model->state;
	if(count>state->context-state->position)return HI_ADAPTER_V2_LIMIT;
	state->position+=count;return HI_ADAPTER_V2_OK;
}

static int adapter_step(hi_adapter_v2_model *model,uint32_t token,float *logits,uint64_t logits_capacity)
{
	if(!model||!model->state||token>=model->vocabulary||logits_capacity<model->vocabulary)return HI_ADAPTER_V2_INVALID;
	test_model *state=model->state;
	if(state->position>=state->context)return HI_ADAPTER_V2_LIMIT;
	state->position++;return adapter_logits(model,logits);
}

static const hi_adapter_v2_api adapter_api={
	.version=HI_ADAPTER_V2_API_VERSION,.struct_size=sizeof(hi_adapter_v2_api),
	.id=TEST_ADAPTER_ID,
	.capabilities_json="{\"native_driver\":\"provider-v2\",\"prompt_mode\":\"completion\",\"prepend_bos\":false,\"configuration_schema\":\"provider-json-v1\",\"configuration_encoding\":\"json-object-v1\",\"chat_renderers\":[\"gpt2-completion-v1\"],\"families\":[\"test\"],\"architectures\":[\"test\"],\"weight_formats\":[\"safetensors\"],\"weight_dtypes\":[\"F32\"],\"context_limit\":4096,\"compatibility_status\":\"experimental\",\"tokenizer_recipes\":[\"gpt2-byte-bpe-digit-split-v1\"],\"required_operations\":[],\"supported_backends\":[\"cpu\",\"gpu\"]}",
	.renderer="gpt2-completion-v1",.completion=1,.prepend_bos=0,
	.open=adapter_open,.close=adapter_close,.rewind=adapter_rewind,
	.prefill=adapter_prefill,.advance=adapter_advance,.step=adapter_step
};

static int adapter_init(sh *shell)
{ return hibr_provide(shell,TEST_PROVIDER,HI_ADAPTER_V2_API_VERSION,(void *)&adapter_api); }
static void adapter_fini(sh *shell)
{ (void)hibr_unprovide(shell,TEST_PROVIDER); }
static const hibr_bi builtins[]={HIBR_BI_END};
HIBR_MODULE_P(TEST_MODULE_ID,"0.1.0-test",
	"Test provider for the experimental Hibr Intelligence adapter v2 contract",
	builtins,adapter_init,adapter_fini,TEST_PROVIDER);
