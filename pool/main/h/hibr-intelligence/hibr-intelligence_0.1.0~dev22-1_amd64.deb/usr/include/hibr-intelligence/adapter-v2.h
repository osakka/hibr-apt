/* SPDX-License-Identifier: LGPL-3.0-or-later */
#ifndef HIBR_INTELLIGENCE_ADAPTER_V2_H
#define HIBR_INTELLIGENCE_ADAPTER_V2_H

/*
 * Hibr Intelligence external text-provider ABI, version 2 (experimental).
 *
 * Architectures that ship with Hibr Intelligence are compiled into the
 * hibr-intelligence module; this contract exists only for providers built
 * outside this repository (ADR 0032). It uses fixed-width values and opaque
 * contexts and exposes no engine structures. A provider offers its table
 * through Hibr as `hibr-intelligence-adapter-v2-<id>` at version 2. The
 * provider implements model math; the host supplies bounded read-only weight
 * access, memory reservation, cancellation and dense projections on the
 * session's selected CPU or GPU backend. This is not a stable ABI.
 */
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HI_ADAPTER_V2_API_VERSION 2u
#define HI_ADAPTER_V2_PROVIDER_PREFIX "hibr-intelligence-adapter-v2-"
#define HI_ADAPTER_V2_ID_MAX 64u
#define HI_ADAPTER_V2_RENDERER_MAX 48u
#define HI_ADAPTER_V2_TENSOR_NAME_MAX 128u

typedef enum {
	HI_ADAPTER_V2_OK = 0,
	HI_ADAPTER_V2_INVALID = 1,
	HI_ADAPTER_V2_NOT_FOUND = 2,
	HI_ADAPTER_V2_UNSUPPORTED = 3,
	HI_ADAPTER_V2_LIMIT = 4,
	HI_ADAPTER_V2_MEMORY = 5,
	HI_ADAPTER_V2_IO = 6,
	HI_ADAPTER_V2_NUMERIC = 7,
	HI_ADAPTER_V2_CANCELLED = 8
} hi_adapter_v2_status;

typedef enum {
	HI_ADAPTER_V2_F16 = 1,
	HI_ADAPTER_V2_BF16,
	HI_ADAPTER_V2_F32,
	HI_ADAPTER_V2_Q8_0,
	HI_ADAPTER_V2_Q4_0,
	HI_ADAPTER_V2_Q4_1,
	HI_ADAPTER_V2_Q4_K,
	HI_ADAPTER_V2_Q5_0,
	HI_ADAPTER_V2_Q5_1,
	HI_ADAPTER_V2_Q6_K,
	HI_ADAPTER_V2_Q5_K,
	HI_ADAPTER_V2_Q2_K,
	HI_ADAPTER_V2_Q3_K,
	HI_ADAPTER_V2_IQ4_NL,
	HI_ADAPTER_V2_U8
} hi_adapter_v2_dtype;

typedef enum {
	HI_ADAPTER_V2_CPU = 1,
	HI_ADAPTER_V2_GPU = 2
} hi_adapter_v2_backend;

typedef enum {
	/* Stored weight is [output,input]. */
	HI_ADAPTER_V2_OUT_IN = 1,
	/* Stored weight is [input,output], as in GPT-2 Conv1D. */
	HI_ADAPTER_V2_IN_OUT = 2
} hi_adapter_v2_orientation;

typedef struct {
	char name[HI_ADAPTER_V2_TENSOR_NAME_MAX];
	uint32_t dtype;
	uint32_t rank;
	uint64_t shape[4];
	uint64_t elements;
} hi_adapter_v2_tensor;

typedef struct {
	uint32_t version;
	uint32_t struct_size;
	void *context;
	/* Reserve model-owned bytes before allocating, including temporary staging,
	 * KV state and cached token conversion. Release on free; host enforces cap. */
	int (*reserve_model_bytes)(void *context, uint64_t bytes);
	void (*release_model_bytes)(void *context, uint64_t bytes);
	uint64_t (*tensor_count)(void *context);
	int (*tensor_info)(void *context, uint64_t index, hi_adapter_v2_tensor *tensor);
	int (*find_tensor)(void *context, const char *name, hi_adapter_v2_tensor *tensor);
	int (*read_f32)(void *context, const char *name, uint64_t first,
	                uint64_t count, float *destination);
	int (*read_u8)(void *context, const char *name, uint64_t first,
	               uint64_t count, uint8_t *destination);
	int (*is_cancelled)(void *context);
	/* Selected session backend for project(); host-owned device budget. */
	uint32_t backend;
	uint32_t device_index;
	uint64_t device_memory_bytes;
	/* Dense projection of rows x inputs by the named 2-D weight on the
	 * session backend. The host validates orientation and dimensions. */
	int (*project)(void *context, const char *weight,
	               uint32_t orientation, uint64_t rows,
	               uint64_t inputs, uint64_t outputs,
	               const float *source, float *destination,
	               uint64_t destination_capacity);
} hi_adapter_v2_host;

typedef struct {
	uint32_t version;
	uint32_t struct_size;
	uint32_t cpu_workers;
	uint32_t backend;
	uint32_t device_index;
	uint32_t reserved;
	uint64_t model_memory_bytes;
	uint64_t device_memory_bytes;
} hi_adapter_v2_options;

typedef struct {
	uint32_t version;
	uint32_t struct_size;
	void *state;
	uint32_t context;
	uint32_t vocabulary;
	uint32_t hidden;
	uint32_t bos;
	uint32_t eos;
} hi_adapter_v2_model;

typedef struct hi_adapter_v2_api {
	uint32_t version;
	uint32_t struct_size;
	const char *id;
	/* Bounded provider capability JSON; same schema used by adapter-info. */
	const char *capabilities_json;
	const char *renderer;
	uint32_t completion;
	uint32_t prepend_bos;
	int (*open)(const hi_adapter_v2_host *host, const char *configuration,
	            const hi_adapter_v2_options *options,
	            hi_adapter_v2_model *model, char *error,
	            uint32_t error_capacity);
	void (*close)(hi_adapter_v2_model *model);
	int (*rewind)(hi_adapter_v2_model *model, uint32_t length);
	int (*prefill)(hi_adapter_v2_model *model, const uint32_t *tokens,
	               uint32_t count, float *logits, uint64_t logits_capacity);
	int (*advance)(hi_adapter_v2_model *model, const uint32_t *tokens,
	               uint32_t count);
	int (*step)(hi_adapter_v2_model *model, uint32_t token, float *logits,
	            uint64_t logits_capacity);
} hi_adapter_v2_api;

#ifdef __cplusplus
}
#endif

#endif
