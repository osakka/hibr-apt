#ifndef HIBR_H
#define HIBR_H

#include <stddef.h>
#include <sys/types.h>

#ifndef HIBR_ABI
#define HIBR_ABI 17u
#endif
#ifndef HIBR_VER
#define HIBR_VER "0.99.434"
#endif
#ifndef HIBR_OK
#define HIBR_OK 0
#endif
#ifndef HIBR_FAIL
#define HIBR_FAIL 1
#endif
#ifndef HIBR_NOCMD
#define HIBR_NOCMD 127
#endif
#ifndef HIBR_NOEXEC
#define HIBR_NOEXEC 126
#endif
#ifndef HIBR_IOCH
#define HIBR_IOCH 4096
#endif
/* The largest datagram a read may meet: UDP's own 16-bit length fixes it. */
#ifndef HIBR_DGRAM
#define HIBR_DGRAM 65536
#endif
#ifndef HIBR_MTNS
#ifdef __APPLE__
#define HIBR_MTNS(st) ((st).st_mtimespec.tv_nsec)
#else
#define HIBR_MTNS(st) ((st).st_mtim.tv_nsec)
#endif
#endif
#ifndef HIBR_ARCH
#define HIBR_ARCH 4096
#define HIBR_ARKEEP 4u
#endif
#ifndef HIBR_HIST
#define HIBR_HIST 500
#endif
#ifndef HIBR_HDMAX
#define HIBR_HDMAX 32768
#endif
#ifndef HIBR_DEPTH
#define HIBR_DEPTH 2000
#endif
#ifndef HIBR_AXDEPTH
#define HIBR_AXDEPTH 1000
#endif
#ifndef HIBR_FNHASH
#define HIBR_FNHASH 16
#endif
/* How many entries a map has before it is worth indexing: below this a walk
   is cheaper than a hash, and the index is never allocated at all. */
#ifndef HIBR_MPHASH
#define HIBR_MPHASH 16
#endif
#ifndef HIBR_TAB0
#define HIBR_TAB0 64
#endif

#ifndef HIBR_LERR
#define HIBR_LERR 0
#endif
#ifndef HIBR_LWRN
#define HIBR_LWRN 1
#endif
#ifndef HIBR_LINF
#define HIBR_LINF 2
#endif
#ifndef HIBR_LDBG
#define HIBR_LDBG 3
#endif
#ifndef HIBR_LTRC
#define HIBR_LTRC 4
#endif

#ifndef HIBR_XONE
#define HIBR_XONE 1
#endif
#ifndef HIBR_XPAT
#define HIBR_XPAT 2
#endif
#ifndef HIBR_XASG
#define HIBR_XASG 4
#endif
#ifndef HIBR_XNOTIL
#define HIBR_XNOTIL 8
#endif

#ifndef P_TXT
#define P_TXT 0
#define P_VAR 1
#define P_CMD 2
#define P_ARI 3
#define P_PSUB 4
#endif

#ifndef V_NONE
#define V_NONE 0
#define V_DEF 1
#define V_ASG 2
#define V_ERR 3
#define V_ALT 4
#define V_LEN 5
#define V_RS 6
#define V_RL 7
#define V_SS 8
#define V_SL 9
#define V_SUB 10
#define V_SUBA 11
#define V_KEYS 12
#define V_SUBSTR 13
#define V_UP 14
#define V_UPALL 15
#define V_LOW 16
#define V_LOWALL 17
#define V_SUBP 18
#define V_SUBF 19
#define V_IND 20
#define V_NAMES 21
#define V_XQ 22
#define V_XE 23
#define V_XA 24
#define V_XAT 25
#define V_XP 26
#define V_XK 27
#define V_XKW 28
#define V_INDF 0x100
#endif

#ifndef A_INT
#define A_INT 1u
#define A_REF 2u
#define A_LOW 4u
#define A_UPP 8u
#define A_ASSOC 16u
#define A_TYSH 8
#define A_TYMASK 0xf00u
#endif

#ifndef O_NULLGLOB
#define O_NULLGLOB 1u
#define O_NOCASEGLOB 2u
#define O_DOTGLOB 4u
#define O_FAILGLOB 8u
#define O_NOCASEMATCH 16u
#define O_INHERITERR 32u
#define O_AGENT 64u
#define O_CHECK 128u
#define O_PLAN 256u
#define O_KEEPGOING 512u
#define O_DASHC 1024u
#define O_DASHS 2048u
#define O_LOGTIME 4096u
#define O_NOGLOB 8192u
#define O_FIXON 1
#define O_FIXOFF 2
#endif
#ifndef O_PATSUB
#define O_PATSUB 16384u
#endif
#ifndef O_EXECFAIL
#define O_EXECFAIL 32768u
#endif
#ifndef O_ALLEXP
#define O_ALLEXP 65536u
#endif

#ifndef J_STR
#define J_STR 0
#define J_NUM 1
#define J_BOOL 2
#define J_NULL 3
#define J_OBJ 4
#define J_ARR 5
#endif

#ifndef R_IN
#define R_IN 0
#define R_OUT 1
#define R_APP 2
#define R_DUP 3
#define R_RW 4
#define R_HERE 5
#endif

#ifndef RF_BOTH
#define RF_BOTH 1
#define RF_CLOB 2
#define RF_STR 4
#define RF_NOFD 8
#endif

#ifndef N_CMD
#define N_CMD 0
#define N_PIPE 1
#define N_AND 2
#define N_OR 3
#define N_SEQ 4
#define N_BG 5
#define N_NOT 6
#define N_SUB 7
#define N_GRP 8
#define N_IF 9
#define N_WHILE 10
#define N_UNTIL 11
#define N_FOR 12
#define N_FUNC 13
#define N_CASE 14
#define N_CLAUSE 15
#define N_ARITH 16
#define N_CFOR 17
#define N_COND 18
#define N_SELECT 19
#define N_TIME 20
#endif

typedef struct blk blk;
typedef struct arena arena;
typedef struct amark amark;
typedef struct str str;
typedef struct vec vec;
typedef struct part part;
typedef struct word word;
typedef struct redir redir;
typedef struct node node;
typedef struct var var;
typedef struct mod mod;
typedef struct ent ent;
typedef struct job job;
typedef struct sh sh;

struct blk { blk *nx; size_t cap, use; char d[]; };
struct arena { blk *b, *fr; size_t ch, nfr; };
struct amark { blk *b; size_t use; };
struct str { char *p; size_t n, cap; };
struct vec { void **p; size_t n, cap; };

struct part { part *nx; word *arg, *idx; char *t; size_t n; short k, op; unsigned q, col, arr; };
struct word { word *nx; part *p; };
struct redir { redir *nx; word *w; char *var; int fd; short k, fl; };
struct node { node *l, *r, *x; word *w, *aw, *bw; redir *rd; char *s, *tx, *rt; short k, f; unsigned ln; };
/* An index of one map's chain: entry pointers in an open table, kept by the
   chain's own first entry, so mp_find can use it with no caller knowing.
   A slot holding MP_GONE held an entry that has since been removed. */
typedef struct mix mix;
struct mix { size_t cap, n, dead; ent *t[]; };
#ifndef MP_GONE
#define MP_GONE ((ent *)-1)
#endif
/* nx, k, s, map, n and ty are the entry itself; tl and ix belong to the
   whole chain and only its first entry keeps them -- the tail, so an append
   is not a walk, and the index, built once a chain reaches HIBR_MPHASH
   entries. A module that links entries itself (csv, db) may leave both 0:
   mp_add finds the tail once and writes it down. */
struct ent { ent *nx; char *k, *s; ent *map; unsigned n; short ty; ent *tl; mix *ix; };
struct var { var *nx; char *k, *v; ent *map; unsigned n; short ty; unsigned ex, ro, am, at; };

struct sh {
	arena *ar, *xa;
	vec held, mods, fns, sbf, vbf, hist, jobs, scope, psub;
	vec als, axp, dirs, schemes, opts, cmds, apis;
	char *odesc;
	var **tab;
	size_t tsz, tn;
	char **av;
	int ac, avo;
	char *arg0, *rty, *etrap, *dtrap, *rtrap;
	int st, lv, it, dep, nofork, tst, pfs, stop, uset, intry, noclob, noexec, strict, bind, hx, xerr;
	long t0;
	char **trap;
	int tty, jid, jcur, jprv;
	long pgid, pid;
	char *hfile;
	int ret, brk, cont, quit, keep, xtr, errx;
	char **amask;
	unsigned sopt;
	const char *ifsc;
	unsigned ifsok;
	int optpos, optind;
	unsigned ncap;
	const char *src;
	vec fsrc, srcs;
	size_t fni;
	size_t *fht, fhsz;
	int fhok;
	unsigned ln;
	int strictg, sfl, decl, srefuse;
	size_t srcdep;
	vec sf;
};

#ifndef HIBR_MTIM
#ifdef __APPLE__
#define HIBR_MTIM(st) ((st).st_mtimespec)
#define HIBR_ATIM(st) ((st).st_atimespec)
#else
#define HIBR_MTIM(st) ((st).st_mtim)
#define HIBR_ATIM(st) ((st).st_atim)
#endif
#endif

int u8len(unsigned char c);
int u8dec(const char *p, size_t n, unsigned *cp);
void u8put(str *o, unsigned c);
int u8w(unsigned c);
int ed_cols(void);
int ed_width(const char *p);

typedef int (*hibr_fn)(sh *s, int ac, char **av);

typedef struct hibr_bi { const char *nm; hibr_fn fn; const char *hp; } hibr_bi;

typedef struct hibr_mod {
	unsigned abi;
	const char *nm, *ver, *dsc;
	const hibr_bi *bi;
	int (*ini)(sh *s);
	void (*fin)(sh *s);
	/* The interface this module offers, if it offers one. Named here as
	   well as registered in the module's init so that hibr_require can
	   find a provider that is not loaded yet, without loading every
	   module to ask. */
	const char *prov;
} hibr_mod;

#ifndef HIBR_BI_END
#define HIBR_BI_END { 0, 0, 0 }
#endif

#ifndef HIBR_MODULE
#define HIBR_MODULE(nm_, ver_, dsc_, bi_, ini_, fin_) \
	const hibr_mod hibr_module = { HIBR_ABI, nm_, ver_, dsc_, bi_, ini_, \
				       fin_, 0 }
#define HIBR_MODULE_P(nm_, ver_, dsc_, bi_, ini_, fin_, prov_) \
	const hibr_mod hibr_module = { HIBR_ABI, nm_, ver_, dsc_, bi_, ini_, \
				       fin_, prov_ }
#endif

extern int hibr_lv;

void lg(int lv, const char *f, ...);
void *xm(size_t n);
void *xr(void *p, size_t n);
char *xs(const char *s);

arena *ar_new(size_t ch);
void *ar_alloc(arena *a, size_t n);
void *ar_raw(arena *a, size_t n);
char *ar_dup(arena *a, const char *s, size_t n);
amark ar_mark(arena *a);
void ar_rel(arena *a, amark m);
void ar_reset(arena *a);
void ar_free(arena *a);

void s_init(str *s);
void s_grow(str *s, size_t n);
void s_add(str *s, const char *p, size_t n);
void s_cat(str *s, const char *p);
void s_ch(str *s, int c);
void s_free(str *s);
void s_num(str *s, long v);
void s_sqb(str *s, const char *p, size_t n);
void s_sq(str *s, const char *p);
int hibr_rdfd(int fd, str *o);
int hibr_slurp(const char *path, str *o);
const char *hibr_jws(const char *p);
const char *hibr_jstr(const char *p, str *o);
int hibr_tlswrap(int sock, const char *host, int noverify, pid_t *pid,
		 const char **why);
void s_fmt(str *s, const char *f, ...);
void v_add(vec *v, void *x);
void v_free(vec *v);
str *sb_get(sh *s);
void sb_put(sh *s, str *b);
vec *vb_get(sh *s);
void vb_put(sh *s, vec *v);

const char *hibr_get(sh *s, const char *k);
int hibr_set(sh *s, const char *k, const char *v, int ex);
int hibr_run(sh *s, const char *src);

const char *hibr_getp(sh *s, const char *nm, char **ks, int nk);
void hibr_setp(sh *s, const char *nm, char **ks, int nk, const char *v);
size_t hibr_count(sh *s, const char *nm, char **ks, int nk);
void hibr_list(sh *s, const char *nm, char **ks, int nk, vec *out, int keys);
void hibr_ret(sh *s, const char *v);
void hibr_retn(sh *s, char **vals, size_t n);
void hibr_fail(sh *s, const char *msg);
int hibr_dial(const char *host, const char *port, int udp);
long hibr_conntimeo(long dflt);
struct sockaddr;
int hibr_uconn(int fd, const struct sockaddr *sa, unsigned n, long ms);

typedef int (*hibr_open_fn)(sh *s, const char *rest);
int hibr_scheme(sh *s, const char *nm, hibr_open_fn fn);
/* A scheme whose open reads something already on this machine says so, and
   that is what lets `source` read it: source runs what it reads, so a scheme
   that connects is not one it may run (ADR 0043). hibr_scheme claims
   nothing, so the default is refusal. */
#ifndef HIBR_SCH_LOCAL
#define HIBR_SCH_LOCAL 1u
#endif
int hibr_schemef(sh *s, const char *nm, hibr_open_fn fn, unsigned f);

/* Write everything to a descriptor the caller owns, without a vanished peer
   killing the process with SIGPIPE: a module writing to a pipe or socket of
   its own uses this rather than write(), so its own EPIPE handling is
   reachable (Gitea #229). Answers n, or -1 with errno set. */
ssize_t hibr_wrall(int fd, const void *p, size_t n);

/* Rename the running process, the way the `title` builtin renames a
   script's: what ps prints and /proc/pid/comm. For a module process that
   is not running a script, such as a forked server or a relay. */
void hibr_title(const char *name);
/* The same, saying both names: the sentence `ps` shows, and the 15-byte
   name the kernel keeps, which `top` and `pgrep` read (Gitea #168). */
void hibr_title2(const char *shortnm, const char *name);

/* One module offers a table of functions under a name and a version; another
   asks for it. This is the only way for modules to reach each other: they are
   opened RTLD_LOCAL on purpose, so a symbol in one is invisible to the rest. */
int hibr_provide(sh *s, const char *nm, unsigned ver, void *api);
void *hibr_require(sh *s, const char *nm, unsigned ver);
int hibr_unprovide(sh *s, const char *nm);
int hibr_unscheme(sh *s, const char *nm);

/* A module whose children must not outlive an exec in place -- Restart
   Desktop's, or any script's `exec` -- registers a hook that ends them and
   waits for them; exec runs every hook, last registered first, just before
   it replaces the process, and only in the process that registered it, so
   a subshell's exec never touches its parent's children. A child meant to
   cross the exec (a terminal's program) is simply not registered. The
   finaliser unregisters with the same pair. */
void hibr_onexec(sh *s, void (*fn)(sh *, void *), void *arg);
int hibr_offexec(sh *s, void (*fn)(sh *, void *), void *arg);
/* In a helper a module forks: close every descriptor but a, b and the
   standard three, so it holds no other connection or pipe open. */
void hibr_closerest(int a, int b);

#endif
