# `wm/` — the window manager, one concern to a file

`desktop.hibr` is the window manager's table of contents: it asks for a
display, then sources [`../interface.hibr`](../interface.hibr) -- the app
interface (ADR 0050): the files here that say `# interface: shared`, and the
widget library in [`../widgets/`](../widgets/README.md), which every app's
own process sources too -- and then the rest of these files in the order it
names them. Each file here defines functions and sets state, so each can be
read on its own. A shared file acts on nothing the desktop alone owns: a
request, a declaration or a registration at load belongs in one of the
others, and `tests/appcalls.py` fails one that does (`tools/appcalls.py
--manifest` says what the app runtime needs, and from where). The other
half is [`../requests.hibr`](../requests.hibr): every request and
declaration in the calls table as a function of the platform's own
signature that sends itself to the desktop. It is generated from the table
(`tools/appcalls.py --stubs`), sourced only by the app runtime, never by the
desktop, and `tests/appcalls.py` fails when it is not what the table says.

The app interface's own files, beside `state`, `glyphs`, `lang`, `locale`,
`budget`, `draw`, `jobs` and `ime` below:

| file | what it holds |
|---|---|
| `loop.hibr` | what the frame loop offers code on either side of it: `dt_want`, `dt_ticker`, `dt_log`, `dt_ms`, double clicks, a cell's pixels, `dt_live`, hover |
| `names.hibr` | `dt_has`, `dt_needs`, `dt_wintitle`, `dt_ext` |
| `keymatch.hibr` | the shortcut a key is: `dt_keynorm`, `dt_keyin`, `dt_keyis`, an app's own actions, the label a key is shown by |
| `chrome.hibr` | how a frame looks and whether the desktop is light or dark |
| `winfacts.hibr` | what an app may ask of a window's record: `dt_title`, and the rectangle a display gives a window or a point, less the bar on the primary (`dt_windisp`, `dt_dispat`, into `DTW_R`/`C`/`H`/`W`), worked out on each process's own copy of `DT_DISPLAYS` and the primary's place |
| `namefacts.hibr` | what things are called, for a list or a button: an opener (`dt_openertitle`), a note's action (`dt_notehist_what`), every app (`dt_appnames`) |
| `wallfacts.hibr` | what the wallpaper comes to on this terminal, `dt_walldrawn` |
| `prayerfacts.hibr` | the next prayer as the bar says it, `dt_pbar`, from `prayertimes.hibr`'s times |
| `vaultfacts.hibr` | when the vault locks itself (`dt_vwuntil`, from the file in the shared `DT_VWRUN`) and the host a sign-in address names (`dt_vwhost`); nothing that reads the session key |
| `orders.hibr` | the lists a person arranges, as they stand: the bar's items (`dt_barlist`, and `dt_barreading` for the Menu Bar pane), the Control Strip's modules (`cs_ordered`) and the title bar's buttons (`dt_btnlist`), each answered in a list of the process's own |
| `servers.hibr` | the WebDAV servers a person has set up, and whether a path is on one |
| `picmode.hibr` | how a picture is drawn here: pixels, half blocks or characters |
| `prayertimes.hibr` | prayer times worked out by the salat module; `prayer.hibr` keeps the bar's segment and the notes |
| `powerlist.hibr` | the power actions this machine offers; `machine.hibr` runs them |
| `rtwire.hibr` | the wire to an app's own process: a line a message, each word percent-encoded, the protocol's number the hello carries, and the one line reader both ends use (`dt_rtlines`: never waits, at most `DT_RTLINES` a pass, a line past `DT_RTLINEMAX` with no end refused) |

`../runtime.hibr` is the app side: the interface, the generated requests,
the socket they go through, and the app's own loop (`dt_rtrun`: one wait on
the socket, what the app watches and its timers, then its tickers -- the
runner in `loop.hibr` the desktop uses too -- then what the desktop told
it, `tell NAME words` running only the app's own functions);
`rtserve.hibr` below is the desktop's end.

The rest:

| file | what it holds |
|---|---|
| `state.hibr` | the state every part shares: focus, dragging, sizing, the keyboard grab, drag and drop |
| `glyphs.hibr` | every character the desktop draws that is not plain text, by name (`GL[vline]`), from the glyph set chosen in Appearance |
| `settings.hibr` | what the user chooses — keys, theme, wallpaper, cursor, shadows, frames — and `dt_keep`, `dt_load`, `dt_save` |
| `lang.hibr` | the language the desktop speaks and whether it orders right-to-left text itself; `dt_tr` itself is `lib/tr.hibr`, shared with the login screen (ADR 0032) |
| `session.hibr` | `dt_open`, `dt_run` (the event loop, asleep until something needs a frame), `dt_close` |
| `budget.hibr` | every callback timed one way: `slow:` past 50 ms and `held:` past 150 ms in the log, and the totals and longest runs `desktop ctl stats` reads (ADR 0049); nothing is ever done to the app |
| `latency.hibr` | how long the person's input takes to reach the screen, per app (ADR 0050): each key, press, release or wheel turn numbered as `dt_run` acts on it, the window whose handler it reached noted in `dt_appcall`, input to answer and input to screen (the frame after the answer, when it drew the window) kept per app in `desktop ctl stats` (`latency`), and a `late:` line past `DT_HOLDMS`, judged as `held:` is, which the suites fail on; `tests/inputlat.py` |
| `windows.hibr` | `dt_new`, `dt_del`, what an app may ask about windows, moving, sizing, zooming, minimising, the grab |
| `workspaces.hibr` | the virtual workspaces: which one is shown, which a window is on, sticky windows |
| `tile.hibr` | a workspace the window manager lays out itself, Window > Tile Workspace and Make Main |
| `place.hibr` | where a window the desktop opens lands: smart, cascade or centre |
| `frame.hibr` | a window's border, title and title-bar buttons |
| `draw.hibr` | `dt_draw`: one frame of the whole desktop, bottom of the stack upwards |
| `wallpaper.hibr` | the background: a glyph, or an image fitted to the screen |
| `input.hibr` | `dt_event` and `dt_mouse`: where each key and click goes, and dispatching the desktop's own shortcuts |
| `keys.hibr` | shortcuts: what each action is called, capturing a key for one, clearing it, the keys the desktop keeps, and moving a key rather than letting two actions share it |
| `menus.hibr` | menus: `dt_menu`/`dt_item` for an app, drawing them, moving through them |
| `bar.hibr` | the menu bar's items and how they are laid out: `dt_baritem`, `dt_baripin`, `dt_barilabel` and the rest; the items themselves, the desktop's own four included, are files in `menubar/` |
| `context.hibr` | menus that open at the pointer |
| `apps.hibr` | `dt_app`, finding apps in their folders, the hibr menu, `dt_launch` |
| `files.hibr` | drag and drop between windows, move, copy, the trash, the clipboard |
| `fullscreen.hibr` | a window taking every cell of its display, `dt_fullscreen`: no bar, frame, shadow or strip, the bar's pane off the top, Leave Full Screen, and a high note as one line along the bottom (Gitea #405) |
| `keyphase.hibr` | a window's keys with their press, repeat and release, for a game: `dt_keyphases`, what it holds, and every release when it stops having the keys |
| `copying.hibr` | moving and copying files: the question about a name already there, renames at once, and a copy in a window of its own over the copy module, with a bar and a Stop |
| `saver.hibr` | the screen saver: the idle timer, and giving the screen to a saver from `savers/` until a key or click, reading the terminals' ptys meanwhile |
| `lock.hibr` | the screen lock: the saver with a password box over it, the password checked by the auth module through PAM, no key reaching the desktop until it opens |
| `restart.hibr` | Restart Desktop: the desktop replaces itself with whatever hibr is installed now, in the same process, windows and running programs kept |
| `recover.hibr` | the supervisor of a held desktop, which starts it again from its last snapshot when it dies |
| `locations.hibr` | somewhere Files goes that is not a folder here: `dt_location scheme prefix`, `dt_locof`, `dt_loccan`, and the list of functions a location answers -- Files names no scheme (ADR 0053) |
| `remote.hibr` | folders on WebDAV servers, the first location (`rdav_`): `dav://` paths moved, copied and deleted in background jobs, remote files opened from a cache and put back when saved, the server dialog |
| `seam.hibr` | the one place the desktop calls into code that is not its own (ADR 0050): `dt_appfn` (an app's window callbacks, and every callback an app handed in, recorded with its owner, `DT_CALLER`), `dt_wincall`/`dt_winget` (a window's input handlers), `dt_hookfn`/`dt_prefixfn` (an installable's hooks, recorded with the file that registered them); part of the shared app interface, loaded first by `interface.hibr`, since shared code the desktop runs (a text field, a scrollbar, a list's namer) calls into an app through it too; how each kind of call is met across a process -- asked, pushed or told -- is `tools/seamcalls.py`'s, in `programs/desktop/seamcalls.tsv` |
| `rtserve.hibr` | the desktop's end of the app runtime's socket: listening from the first app process on, a hello checked against the protocol and the hibr version (refused, with a note offering Restart Desktop), and only the told requests `interface.tsv` names carried; an app process started with three descriptors and no more and a token for its launch (`dt_rtspawn`, `dt_rtissue`) -- the hello spends the token, and the app is the launch's, never what the hello says -- told to run its own functions by launch (`dt_rttell`), and answered with `send -p` up to `DT_RTQMAX` waiting |
| `handlers.hibr` | `dt_handler`: what opens a file, by its extension |
| `openfacts.hibr` | what opens a file and what else can be done to it (`dt_openers`, `dt_isbundle`, `dt_openverbs`, `dt_openbrowse`), worked out from the declared openers and verbs on each process's own copy, never asking the declarer |
| `filepick.hibr` | `dt_filepick`: the Open and Save dialog any app can use, with a preview of what is selected |
| `shot.hibr` | screenshots: the whole screen, the focused window or an area |
| `clip.hibr` | the clipboard and its history, `dt_clipset`; a copied secret is never kept |
| `icons.hibr` | the desktop's own icons: home, disks, trash |
| `hold.hibr` | staying detachable, and the displays attached to a held session |
| `standby.hibr` | displays that wait to be joined (`--standby`) and wait again when let go, and displays blanked: joined but dark and out of use |
| `notify.hibr` | `dt_note`, `dt_notify`: stacked notifications and their history |
| `confirm.hibr` | `dt_confirm`: a question with a yes and a no |
| `ask.hibr` | `dt_ask`: a question with one line of text for an answer -- a label, a field (masked for a secret), a line of help, OK and Cancel; the callback is given the answer and keeps the dialog open by refusing it |
| `jobs.hibr` | `dt_job`, `dt_jobrunning`, `dt_joblast`, `dt_jobfile`: work run in the background with its output kept, and its callback run after a frame once it ends -- marked done first, its files gone after; `wm/remote.hibr`'s transfers run on it |
| `strip.hibr` | the Control Strip |
| `ctl.hibr` | the control socket `desktop ctl` talks to: displays, windows, moves, `rescan`, `state`, `stats` |
| `hud.hibr` | the desktop's section of Blit's performance panel (Blit ADR 0203), sent only while the panel asks |
| `prayer.hibr` | prayer times: today's times, a note at each, the athan (ADR 0035) |
| `vault.hibr` | the Bitwarden or Vaultwarden vault, unlocked once for the whole desktop (ADR 0036) |
| `polkit.hibr` | the password polkit asks for, asked in a dialog of the desktop's own |
| `machine.hibr` | Sleep, Hibernate, Restart and Shut Down through logind, on the Special menu |

The split was made by moving text, not by rewriting it: every function's
definition is what it was in the single `desktop.hibr` it came from, and once
loaded the two leave exactly the same functions and variables behind. A new
file here must be added to `desktop.hibr`'s own list, by name — a table of
contents that lists itself cannot quietly grow a part nobody meant to load.
