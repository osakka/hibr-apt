# The desktop's architecture

[Windows on a console](README.md) says what the desktop does. This says how
it is built — the three layers, the event loop, the rendering model, and the
contract an app is written against. Every screenshot below is a real render
of real hibr output, made with [`tools/screenshot.py`](../../tools/README.md),
not a mockup.

![An empty desktop: the menu bar, the wallpaper, and the three fixed icons](img/desktop-empty.png)

## Three layers, X's shape

| X | here | what it is |
|---|---|---|
| the server | the `console` module | owns the terminal, the grid, the mouse, stacking, hit testing |
| the window manager | `programs/desktop/desktop.hibr`, sourcing `wm/` | the event loop, focus, dragging, title bars, menus — one concern to a file, see [`wm/README.md`](wm/README.md) |
| the widget library | `programs/desktop/widgets/` | checkbox, dropdown, slider, text field, scrollbar — see [`widgets/README.md`](widgets/README.md) |
| `~/.xinitrc` | your own session file | which windows open, and where |

None of it is C beyond the display module itself. The window manager is a
hibr script; every app is a hibr script; the session that starts them is a
hibr script you write and own, the same way an X session is whatever
`~/.xinitrc` says to run — see
[decision 0020](../../docs/adr/0020-windows-are-drawn-not-composited.md) for why this
split was chosen over compositing panes together in the display module
itself.

![Three windows open: a calculator, the file browser, and a real terminal running a nested hibr shell](img/desktop-apps.png)

That terminal window is not a screenshot of a screenshot — it is a real
`hibr` process, started by `term.hibr` on a pseudo terminal, showing its own
real prompt with the actual git branch this repository is on. Nothing about
what a window shows is faked or simulated for the picture.

## The frame budget

Every app runs inside the window manager's own process, between frames, so a
callback that takes long stops every display while it runs. Each one is
timed (`wm/budget.hibr`, ADR 0049): past 50 ms it is a `slow:` note in the
log, past 150 ms a `held:` stall, which the suites fail on; the app itself
is never stopped or paused for it (0.99.401): a stall is for whoever wrote
the code to find, never for the person at the screen to pay for. Slow work
is a job (`dt_job`, or `dt_jobvars` for a load that sets variables); the
rule is written for app authors in [`WRITING.md`](WRITING.md).

What a desktop spends its time on can be read while it runs, rather than
guessed. `desktop ctl stats reset` turns timing on and `desktop ctl stats`
answers: each callback's total and its longest single run (`max_ms`), what
ended each wait of the loop (`woke`: input, a watched descriptor, or the
timer of whoever asked for the soonest frame), why each app's windows were
drawn rather than left (`drawn_why`), the parts of a frame
(`part:arrange`, `part:wall`, `part:windows` ...) and the steps of a
wallpaper repaint (`part:wall.picture` ...), and whether the wallpaper was
kept or placed again (`img`). The fields are listed in
[WRITING.md](WRITING.md#controlling-a-running-desktop). On Blit the same
timing feeds a section of its performance panel (`wm/hud.hibr`, Blit ADR
0203): eight lines a second, sent only while the panel asks for them.

## The event loop

`dt_run`, in `wm/session.hibr`, is the whole of it:

<!-- not run: a sketch of the loop in wm/session.hibr; it needs the desktop -->
```sh
while [ "$DT_QUIT" = 0 ]; do
    dt_draw
    k := console key "${DT_WANT:-$DT_IDLEMS}"
    dt_event "$k"
done
```

(Simplified — the real loop also debounces a burst of resize events into one
settled redraw, and skips drawing a drag or wheel report while the next one
is already waiting (`console waiting`), described in `wm/session.hibr`'s own
comments.) `console key
MS` blocks for up to `MS` milliseconds waiting for one decoded key or mouse
report, and returns the instant one arrives. A resize interrupts the wait
the same way (`SIGWINCH`), and so does output from any terminal window's
program, since `term.hibr` asks `console watch` to include its pty.

Nothing else wakes it. There is no refresh rate: `DT_WANT` is the soonest
of every `dt_want MS` any `_draw` asked for during the frame just drawn,
and each ask lasts that one frame. Everything that changes on its own asks
for its own next change — the bar clock for the next minute, the Clock desk
accessory and the Date & Time pane for the next second, a blinking terminal
cursor for its next half-second, a game for its next step, Tasks and About
for their own refresh settings, a note for the moment it expires, the
desktop icons for their 5-second mount rescan. When nothing asks, the loop
sleeps for `DT_IDLEMS` (60s), a net under anything that forgot to.

It used to be a periodic poll: `DT_TICK`, first 200ms, later 2000ms,
redrew the whole desktop that often whether anything had changed or not.
Raising the default did not reach anyone whose settings file had already
saved 200 — `dt_save` writes every kept setting, so a default frozen into
it outlives the code that set it — and the shipped `session.hibr` set 200
itself. A live session measured 19% of a core doing nothing. With the tick
gone an idle desktop with a terminal window open measures about 0.2 wakes
a second and 0.2% CPU; a blinking cursor cost about 1.5% when that was
measured, because each blink ran every window's `_draw`. A window whose app
offers `_dirty` and answers clean is left undrawn, the screen keeping its
cells, unless a window drawn under it in this frame overlaps it, its shadow
included (`dt_clean` and `dt_under`, `wm/frame.hibr`; before 0.99.410 any
overlap at all meant drawing it every frame). Windows are drawn bottom to
top, so that is the only way a window's cells can have been written over.
A window that moved, and those its old or new place overlaps, are drawn
whole; the wallpaper is kept rather than painted again whenever nothing it
paints has changed, and painted at least once a second (0.99.413).
`uifuzz.py oracle` compares such frames against forced full ones.
`tests/desktop.py` counts the
process's own wakes with nothing happening, so a tick cannot come back
unnoticed.

`dt_draw` walks every open window bottom to top, drawing its face and letting
its own `_draw` callback fill it in, then the menu bar and whatever floats
above everything — a menu, a drag, the confirm box. `dt_event` decodes one
key or mouse line and dispatches it. A held pointer's reports go to the
window holding it, and Release Pointer and Leave Full Screen are taken
before anything else; then a confirm box or a rebind capture if one is
pending, the open menu if one is, and the keys every window shares --
Save, Undo, Redo, Copy, Cut, Paste and the Menu Bar key -- before the
focused window sees them. Then the focused window's own key handler, and
only once it has declined a key, the rest of the global shortcuts (Control
Panel > Shortcuts has the current list).

## Redrawing costs only what changed

The console module keeps two grids, front and back. Every `dt_draw` writes
into the back grid; `console flush` compares it against the front and sends
only the cells that differ, then makes the two match. A full first paint of
an 80x24 screen costs a few kilobytes; a completely unchanged frame costs
zero bytes, not a redraw with nothing in it — the comparison itself is real
CPU work, but nothing crosses the pty. This is what makes a frame woken by
a clock or a cursor blink cheap: it costs a wake-up and a grid diff, not a
full terminal repaint.

A window whose draw repaints every cell inside its frame can say so with
`<app>_paintsall`; while its frame has not changed and nothing else has
drawn over it, only its content is drawn, not its face and frame again
(`dt_contentonly`, 0.99.394). The Terminal does while its program runs.

A picture is not cells. The console places it once and keeps it until the
cells under it stop matching (ADR 0037). On Blit, where every display can
take them, a window's pictures go by descriptor instead of through the
terminal: a sealed memfd on Blit's frame socket, and only the placement on
the pty (Blit ADR 0202, `console imgfd`, Control Panel > Pictures > Frames
to Blit). The wallpaper always goes through the terminal.

## An app is a prefix, not a class

There is no window object, no base class, no registration beyond a name. An
app called `calc` is whichever of these functions it happens to define —
`calc_draw`, `calc_key`, `calc_click` or `calc_mouse`, `calc_open`,
`calc_close`, `calc_menus` and the rest of the table below — checked for
with `command -v` once, when the
window is made, and only the ones that exist are ever called. Everything an
app remembers is keyed by the window id it was handed, never a bare global,
since two windows of the same app must not share one:

<!-- not run: an app's callback; the desktop calls it -->
```sh
fn calc_draw(int id, int h, int w, int row, int col) {  # id, body size, place
    console put -p "w$id" 1 2 "${CA[$id]["out"]}"
}
```

Every function the desktop defines declares its parameters this way, and a
callback declares the whole of what it is called with, whether it uses all
of it or not -- a declared function refuses an argument it has no name for,
so `fn calc_draw(id)` would fail on the first frame. The ones every call
has shown to be integers say so -- `int`, or `int?` where empty is allowed
(`docs/adr/0024`) -- so a wrong argument fails at the call rather than
drawing in the wrong place. The calls:

| callback | arguments |
|---|---|
| `_open` | `id arg` -- `arg` is `dt_new`'s seventh argument or `dt_launch`'s second, often empty |
| `_close` | `id` |
| `_draw` | `id h w row col` -- the body's size, and the window's place on screen |
| `_key` | `id key` |
| `_click` | `id r c btn` |
| `_mouse` | `id act btn r c mods` -- and while the window holds the pointer (`dt_pointerlock`, granted only within two seconds of a key or click), `id rel btn dy dx rel` for movement, a press, release or wheel with its own deltas and `rel` as mods, and `id unlock none 0 0 ""` when the lock ends |
| `_wheel` | `id dir r c` -- dir is up, down, left or right, never wheelup |
| `_hover` | `id r c` -- the pointer over the window with no button held, where hovering is on; `-1 -1` when it leaves |
| `_scroll` | `id key top` -- a scrollbar drawn with that key, held and dragged |
| `_copy`, `_cut` | `id` -- hand back the selection with `ret`, or fail with nothing selected |
| `_paste` | `id text op` -- `op` is `cut` or `copy`; a paste from the host terminal comes the same way, as a copy |
| `_undo`, `_redo`, `_selall`, `_find` | `id` -- the Edit menu's rows, dimmed for an app without them; fail to say there was nothing to do |
| `_savefile` | `id` -- the Save key |
| `_signin`, `_signfill` | `id` -- the host a sign-in form is for, with `ret`, failing while it has none; and `id user pass` -- a login from the vault to put in its fields. Fill Sign-In, the key mark (`dt_signmark`) and an Edit row come with them |
| `_canclose` | `id` -- asked before a close someone asked for; fail to keep the window, and close it yourself later |
| `_refresh` | `id` -- something on disk changed |
| `_dirty` | `id` -- asked before a window is left undrawn; succeed when it has changed (an app without one is drawn every frame) |
| `_paintsall` | `id` -- succeed when this window's draw repaints every cell inside its frame, so a changed window whose frame is unchanged is drawn content only, without its face cleared or its frame drawn again (`dt_contentonly`); the Terminal does while its program runs |
| `_fullscreen` | `id on\|off` -- the window has gone full screen or come back, by its own `dt_fullscreen` or the desktop's Full Screen key |
| `_about` | nothing -- the hibr menu's About for the front app, in place of the desktop's card |
| `_drop` | `id r c op paths...` |
| `_menus` | nothing -- the menus are built for whichever window has focus, `$DT_FOCUS` |
| `_context` | `id` |
| `_idle` | `id` -- each frame, for a window that is not drawn (minimised, or on another workspace), and on a frame the desktop holds back for a window that is -- so it may run beside a drawn window, and must not cancel work that window is waiting on |
| `_awake` | `id` -- only when the screen saver is due; succeed to keep it, and the lock, away for another idle period |
| `_stash` | `id dir` -- Restart Desktop is about to exec; write down what a map cannot hold, in `dir` if it is a file |
| `_resume` | `id` -- after a restart, once the maps named by `dt_keepstate` are back |

A Control Panel pane is called with its own set -- `_rows id` and
`_do id key dir` for a pane of rows, `_draw id h w x` for one with a body
of its own, `_key id key`, `_click id r c`, `_mouse id act btn r c`,
`_drop id r c key`, `_wheel id dir`, `_slide id key value` and
`_order id group name...` -- and a Control Strip module with `_draw row col`
and `_click row col`. `_slide` is a `wtype=slider` row being set where its
track was clicked or dragged: the value is already in the row's own
`min`..`max`, and the pane clamps and snaps it to whatever step the setting
has, because the step is the setting's business and not the track's. A function
that takes a list ends in one, as `fn dt_row(tick, int dim, lb, k, ...rest)`
does; the old `name() { local id=$1 ...` form still works for an app of
your own, unchecked.

`console put -p "w$id" row col text` writes into that window's own pane,
in the coordinates the window draws in — row 0 is its own top border, not
some outer coordinate system the app has to translate into. A `_click`
callback is told a click in exactly those same coordinates; a richer
`_mouse` callback additionally gets the raw press, drag, and release, which
is what a terminal emulator or a file browser's own drag-and-drop needs.

## Menus, two kinds

The bar across the top is drawn into **a pane of its own**, so its cells
belong to it: the wallpaper paints behind it rather than over it, and a
frame on which nothing the bar shows has changed does not draw it at all.
That is worth about 380 us of a settled two-window frame -- 1027 us against
645, medians of four runs each -- which is more than half the 0.7 ms budget
a 1%-of-a-core desktop has. `dt_bar` composes a key out of everything it
reads and compares it with the last one; `dt_barput` is the only thing that
knows about the pane, since every column everything stores stays absolute,
which is what a mouse report carries. Two things deliberately sit *outside*
that gate: the shadow, because it falls on the row below and those cells are
not the bar's to keep, and the clock's own `dt_want`, because a gated
drawing would otherwise take with it the thing that asks for the next frame.

An app can put **an item** on the bar with `dt_baritem name text [cmd...]`,
drawn left of the notification icon, and clicked it runs the words it was
given. A bar item is for *a state that changes* -- messages waiting, a sync
in flight, a vault left unlocked -- which is what a Control Strip module is
not: the strip is a glyph and a click the person positions themselves. The
text is a value the app sets when it changes, never a callback the bar asks
per frame; setting it is what clears the bar's gate. An empty text takes the
item off.

Every item is a file of `menubar/` since 0.99.351 (Gitea #392), the
desktop's own four too: the application menu (`appmenu.hibr`), the clock,
the notification icon and the workspace numbers. Those four say
`# platform:` and are loaded by `desktop.hibr` itself, so a desktop with no
session still has its bar; the rest are catalogue entries -- the network,
the speaker, Bluetooth and power each in a bundle with the pane that acts
through it, and the next prayer as a part of Prayer Times -- and the
session reads them as it reads apps. One
layout places all of them from the bar's outer end inwards. `dt_baripin
name n` keeps an item in a place of its own -- 1 is the corner, a negative
place is beyond every ordinary item -- until `DT_BARORDER` names it, which
moves it to the place the order gives (Gitea #396); only the corner, pin 1,
is never moved. `dt_bariwide name w adj` keeps a width whatever the
text measures, `dt_baridraw name fn` draws an item with pens of its own,
`dt_baripress name fn` takes a press with its button and column, and
`dt_barhook fn` runs before the bar's gate on every frame, for an item
whose text follows the desktop's own state -- the clock's minute, the count
of notes -- and calls `dt_baritem` only when it changed. `dt_baristop name
fn` is what stops a watcher when a rescan finds its file gone; the item, its
hooks and its tickers are taken off with it.

`dt_barilabel name label` says what the item is called. Control Panel >
Menu Bar > Menu Bar Items lists items by that label, so the panel keeps no
list of who puts what on the bar (Gitea #341, #396). `DT_BARORDER` is the
names in the order they read across the bar. An item it does not name goes
after the last ordinary item it does name, and a name with no item is
passed over, so unset the bar is as it always was. `DT_BARHIDE` names the
items taken off; an item that already has a setting of its own for that --
the speaker's `DT_SNDBAR` -- says so with `dt_bariswitch name VAR fn`, and
the list's checkbox is then that setting, with `fn` run after it changes.

The list is a Control Panel row of a kind any pane can use: a row with
`["ord"]=group` and `["oname"]=name` draws a grip, moves with a drag or
with shift and an arrow, and the pane is told the group's new order with
`<pane>_order w group name...`. A press on such a row is held until it is
known to be a drag, and one let go where it was is passed on as the click
it would have been. The Control Strip pane uses the same rows for its
modules, kept in `CS_ORDER` and `CS_HIDE`.

The hibr menu gives the applications every letter its own items have not
taken. Those letters are read from the items themselves: the About above
the applications, and `dt_hibrtail` below them, built once with only their
letters collected. Nothing is kept by hand beside them, so a new item
cannot share a letter with an application.

The rest of the bar reads the same in every window: the hibr menu, **File**, **Edit**, then
the focused app's own menus, then Window. Edit and Window belong to the
desktop rather than to any app. An app defines `<app>_menus` and builds its
menus with `dt_menu`, `dt_item`, `dt_sub` and `dt_sep`; it opens with File
and calls `dt_editmenu` before its second menu, which
`tests/540-examples.t` enforces. An app that defines no `_menus` at all --
Clock, Control Panel, About This Computer, Screenshot, and every dialog --
is given `File > Close` and Edit by the window manager, so the two menus a
person reaches for most never move.

![The hibr menu open: About This Computer, Applications, the desktop's own programs from Catalogue to Task Manager, Screen Saver, Lock Screen, Restart Desktop, Detach dimmed because this session is not held, and Quit](img/desktop-menu.png)

A right-click gets a different menu, specific to what was clicked rather
than to what has focus — the desktop background, a title bar, or an app's
own `<app>_context` if it defines one:

![A right-click on the desktop background: Arrange Icons, Change Wallpaper, Next Wallpaper, Empty Trash (dimmed while the trash is empty) and Refresh Desktop](img/desktop-context.png)

## Control Panel settings are a script, not a format

The desktop's configuration is data (ADR 0054). `dt_save` writes
`~/.config/hibr/desktop.json`, and `dt_load` reads it back with `json parse`,
giving a value only to a name `dt_keep` has named. Nothing in it runs, and
it is exactly the plain variables the
window manager already reads every frame (`DT_WALL`, `DT_ICONS`, `DT_KEYS`,
and so on), so a change takes effect the moment it is written, in every
window at once, without anything being told to refresh. `panel.hibr`, the
Control Panel app, is what edits it interactively — not with settings of
its own, but as a host for panes, each an ordinary file under
`programs/desktop/control-panel`, System 7's Control Panels folder rather than one
long scrolling list:

![Control Panel: its panes in groups down the left, Appearance open on its Look, Shadows and Controls rows](img/desktop-controlpanel.png)

A pane down the left, its own rows on the right — arrows move the picker,
tab or right or enter steps into the selected pane, and the same keys then
move its row cursor instead. The picker has three groups under headings:
**Hardware** — Date & Time (the machine's clock and time zone), Displays,
Keyboard, Mouse, and Network, Sound, Bluetooth and Power once installed
from the catalogue — then **Desktop** — Appearance, Control Strip, Desktop,
File Types, Menu Bar, Notifications, Shortcuts, Wallpaper, Windows and the
rest, sorted by name — and **Apps**, one pane per app that has something to choose:
Files, Terminal and Stickies as shipped, and Mail, Calendar & Contacts,
Vault, Browser, Web Apps, YouTube, X Screen and Prayer Times once installed. An app's pane is one of the
files the app brings, so it is there exactly when the app is (ADR 0047);
it says so when its app is installed and not loaded in this session.
Everything an app keeps across restarts has a row in
some pane; `tests/540-examples.t` fails otherwise. Appearance holds the
theme, the colours, the glyphs, the trees, the shadows and the controls;
Wallpaper holds the wallpaper — a glyph, or an image chosen in a picker
window of its own, for all displays or one; Menu Bar holds the bar's look
and its Menu Bar Items; Windows holds a window's chrome — frame, title bar,
see-through, button side, title alignment, button glyphs, read by `dt_win`
and `dt_btn` themselves, not by the pane; Mouse holds how a
window is moved, resized and double-clicked; Keyboard holds how keys reach
a terminal window -- whether the desktop's shortcuts work while one has
focus, and whether ctrl with a letter always goes to its program; Shortcuts
holds every key the desktop acts on, the menu bar's and Copy's included, and
any app's, each cleared by the ✕ beside it or delete on its row, with
`wm/keys.hibr` asking before taking a key another action holds; Date & Time draws its own body
instead of rows — the clock, the date, and a small
world map with a mark near the machine's own time zone, reusing
`examples/traceroute.hibr`'s own map and zone1970.tab lookup rather than a
second copy of either. See
[Control Panel panes](WRITING.md#control-panel-panes) for the two shapes a
pane can take and how `CP_PANEDIRS` finds them.

## A real app, for scale

The task manager reads the process table through the `proctab` module, in
one call and without forking, once a second, and is drawn only when it has
something new (`tasks_dirty`); it is not a mockup of a process list, it is
this machine's actual processes at the moment the screenshot was taken:

![The task manager, sorted by CPU, showing real processes from this machine](img/desktop-tasks.png)

## What this is not

It is not a compositor: a cell has no alpha, so a window's See Through is
an opaque colour worked out per cell from the picture beneath it, nothing
overlaps with blending, and a window's shadow is a darkened copy of the
cells under it,
computed once per frame, not a rendering effect. It is not accelerated:
every cell is a real character cell, drawn with real SGR escape sequences,
at whatever rate the terminal it runs in can keep up with. And it is one
process: every app runs in it, so a slow callback stops every display while
it runs -- which is why each is timed ([the frame budget](#the-frame-budget))
and ADR 0050 weighs apps in processes of their own. The project's own
[backlog](../../docs/backlog.md) has what is still open.
