# `widgets/` — what an app draws with

The desktop's widget library: the controls an app puts in its own window —
a checkbox, a dropdown, a slider, a text field, an address field with suggestions, a scrollbar, a button, a tree, a search, text that fits a box — and the hit
regions that tell it which one a click landed on. `desktop.hibr` sources every
file here, in no particular order, before any app is loaded.

| file | what it offers |
|---|---|
| `hit.hibr` | `dt_wclear`, `dt_wreg`, `dt_hit`, `dt_wcol`: the regions widgets register as they draw (`dt_wreg` takes an optional height), and which one a point is in; `dt_hotreg`, `dt_hot` and `dt_hotpen` for a region that lights under the pointer, and `dt_tip` for its tooltip |
| `check.hibr` | `dt_check`: an on/off choice and its label, as a box `[x]`, a knob, a block or a tick, by `DT_CHECKS` |
| `dropdown.hibr` | `dt_wdrop`, `dt_droplist`, `dt_dropcontext`: a value with a `▾`, and the popup of choices under it |
| `slider.hibr` | `dt_slider`: a track with a marker, changed with the arrows or by clicking and dragging on the track (`dt_slidepos`) |
| `text.hibr` | `dt_textdraw`, `dt_textkey`, `dt_textpaste`, `dt_pastefold`: a one-line text field, one key applied to it, a paste into it, and how a paste's lines fold (a space, or `url` for an address field) |
| `omnibox.hibr` | `dt_omnidraw`, `dt_omnilist`, `dt_omnikey`, `dt_omnihit`, `dt_omniselect`, `dt_omnisig`, `dt_omnifree`: an address field with a list of suggestions under it, as a browser's has -- the field is `dt_textdraw`'s and its text the app's own; a callback the app names answers the rows for what is typed, up and down move through them, escape puts back what was typed, a press takes a row, and the top row completes the field, selected. It keeps the list under the window id, freed by `dt_omnifree` |
| `textarea.hibr` | `tb_*`: a multi-line editor -- lines, cursor, selection, undo and redo, soft wrap -- keeping its buffer in `TB` under the window id, the one widget that keeps state, freed by the app's `_close` with `tb_free`. Stickies uses it whole; the markdown editor uses its editing and draws its own way |
| `textfit.hibr` | `dt_textwrap`, `dt_textfit`, `dt_fitmark`: text in a box with a smallest and a largest size -- wrapped, laid out between the two, and marked with `▾` on the box's edge when it was cut or `▴` when it was opened past its usual size, so what did not fit is never silently gone. The box itself, its border and where it goes are the caller's; a notification is the first user |
| `scrollbar.hibr` | `dt_scrollbar` and `dt_hscrollbar` draw a track and thumb, and given a key can be held and dragged (`<app>_scroll id key top`); `dt_scrollfit`, `dt_scrollsel`, `dt_scrollmove` and `dt_scrollview` are the behaviour behind them, and `DT_SCROLLWHEEL` is how far one wheel notch moves anything |
| `bidi.hibr` | `bd_row`, `bd_col`, `bd_at`, `bd_glyph`, `bd_put`: one row of a line holding right-to-left text in display order, through `uni map` -- the line one paragraph, each row reordered on its own -- with where each character went, so a cursor or a click stays logical; fails at once for plain text or with bidi off, so a caller keeps its plain path. The textarea and Write draw through it |
| `band.hibr` | `dt_band`: the rubber band a drag across empty space draws, in the look Control Panel ▸ Desktop ▸ Rubber Band chose -- a single frame, dashed, solid, or translucent at Band Intensity, the last two through `console tint` so what it covers stays readable -- on the screen or inside a pane; the desktop's and Files' are both this |
| `split.hibr` | `dt_split`, `dt_splitbar`, `dt_splitmove`: a window cut in two at a divider the mouse drags, its column kept in a variable the app names so it can be kept as a setting |
| `button.hibr` | `dt_button`, `dt_buttons`, `dt_dlgbtns`: filled push buttons with a Turbo Vision shadow, one or a row of them, or a dialog's centred along its bottom; `dt_focus` and `dt_focuskey`: moving focus through fields and buttons with tab, shift-tab and the arrows |
| `search.hibr` | `dt_searchopen`, `dt_searchkey`, `dt_searchdraw`, `dt_searchq`, `dt_searchon`, `dt_searchrows`, `dt_searchshut`, `dt_searchclear`, `dt_searchset`, `dt_searchfree`: one search, in every window that has one. **Nothing is drawn until `/` is pressed**, and then a bar on the window's own bottom row, gone again on escape -- so no window spends a row on a search nobody is making. An app asks `dt_searchrows` for how many rows to keep clear, offers each key to `dt_searchkey` first, filters on `dt_searchq`, and defines `<app>_find` so the Edit menu's Find row is not dimmed. Before it there were six searches in six shapes: two in the title bar, one right-aligned, one left, one grey inside a list and one a label beside a field |
| `putruns.hibr` | `dt_putruns`, `dt_runpens`: a row of text drawn run by run, each run in a pen of its own -- how the runs `sysinfo` and `mermaid` hand back reach a window in the theme's colours |
| `tree.hibr` | `dt_treespec`, `dt_treepre`, `dt_treelead`, `dt_treew`: what goes in front of a row of a collapsible tree -- `[+]` and `[-]` by default, arrows, triangles or dots by `DT_TREESTYLE`, with the rules joining a child to its branch unless `DT_TREELINES` is off -- both of them theme fields (`tree`, `treelines`) as well as Control Panel ▸ Appearance rows, beside the theme and the glyph set -- a tree is a look, not a window. An app keeps its own rows, their order and which are open, because that is its data; this is only how they look, so every tree in the desktop looks the same and one setting changes all of them. Every style is **three columns wide**, so changing it never moves the columns beside it |

## The contract

A widget **keeps no state of its own**. The app holds the value — under its
own window id, never in a global, since two windows of one app must not share
one — passes it in to draw, and changes it when `dt_hit` names the widget's
tag in its `_click`. So a widget is a function of what it is given, drawn
fresh every frame, and there is nothing to create, destroy or keep in step.

Every widget draws into the window's own pane (`console put -p "w$id"`), in
the coordinates the app itself draws in: row 0 is the title bar, and a click
reaches `_click` in those same coordinates. An app calls `dt_wclear "$id"` at
the top of its `_draw`, before drawing any widget, so last frame's regions
cannot answer this frame's click.

## What makes a file a library

hibr has no separate notion of a library; a library is a script that keeps
five rules, and every file here keeps them:

1. **It only defines.** Functions, and `declare -gA` or plain assignments for
   the state they share. Nothing runs, draws or reads input while it is being
   sourced, so the order files are sourced in never matters.
2. **It is safe to source twice.** A second source redefines the same
   functions and resets nothing that matters.
3. **It owns a prefix.** Everything here is `dt_`, the desktop's own; a
   library of your own should pick one that nothing else uses — see
   `CLAUDE.md` on how a name that collides with the shell's own is silently
   bound to the wrong function.
4. **It says what it offers**, in a one-line comment above each function and
   a row in a table like the one above.
5. **It declares its parameters**: `fn dt_check(int id, int r, int c, int on, label, tag = "")`,
   not `local id=$1 r=$2 ...`. The signature is the documentation a caller
   reads, a wrong number of arguments fails the call rather than drawing
   something plausible in the wrong place, and binding costs less than the
   `local` line it replaces.

A library of your own can live anywhere on `PATH` and be loaded by name --
`. mylib` -- since `.` looks a bare name up there before the current
directory, the way bash does.

`tests/540-examples.t` parses every file here and fails when a function name
is defined twice anywhere across the desktop and its parts.
