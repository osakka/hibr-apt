# Arabizi data

The Arabizi engine (arabizi.c, arabizi.h) reads these files from a root
directory its host passes to `arabizi_load()`. The hibr-ime-arabizi package
installs them in /usr/share/hibr-ime/arabizi; a host may point at any other.

- `arabizi.rules`: the rules: the convention the engine follows,
  the owner's to tune. The format is described at its top.
  LGPL-3.0-or-later, like the engine.
- `ar-words.txt`: the 100,000 most frequent Arabic words (Arabic letters
  only, seen at least 3 times), one `<word> <count>` per line.
- `en-words.txt`: the most frequent English words, used only to leave
  English typed as English.
- `ar-common.txt` (optional, 0.1.4): the words people type every day that
  a list of subtitles ranks low -- Levantine (كمان، هون، بدي) and names
  (عمر، بيروت، غزة) -- one `<word> <count>` per line like `ar-words.txt`.
  Its counts are added over that list's, overriding a lower one, so these
  win wherever the rules can spell them; they do not count towards the
  total the English check weighs. A count is chosen against the word's
  rivals, not just set high: عم is 100,000 so that `3am` gives it over
  عام and `umm` still gives أم. Written for hibr-ime, LGPL-3.0-or-later.

## Credit and licence of the word lists

Both word lists are derived from **FrequencyWords** by Hermit Dave
(https://github.com/hermitdave/FrequencyWords, commit
525f9b560de45753a5ea01069454e72e9aa541c6), word counts from the
OpenSubtitles 2018 corpus (http://www.opensubtitles.org/,
http://opus.nlpl.eu/OpenSubtitles2018.php).

They are licensed under **Creative Commons Attribution-ShareAlike 4.0
International** (CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/).
The changes are those made by `make-word-lists.sh`: the Arabic list is
filtered to Arabic letters and at least 3 occurrences and cut to 100,000
words; the English list is lower-cased and filtered to letters. These
derived lists are offered under the same licence.

Checksums (`make-word-lists.sh` prints them):

```
dd406b8c902c8dffc1ae27717a7f128a00a66f8a0beae5eee8d47cc35067e1d6  ar-words.txt
de97b4135c2702c97d7be3315f798d13adcaafc33615d4eec300a7933b4fe323  en-words.txt
```
