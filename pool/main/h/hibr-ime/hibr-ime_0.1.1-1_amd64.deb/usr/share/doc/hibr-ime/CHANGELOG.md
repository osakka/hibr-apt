# Changelog

## 0.1.1

**The hibr module, and the packages.** `ime.so` gives hibr the `ime`
builtin -- methods, an engine per place typed into, a key fed and its
commit, whether it passes and the preedit answered together, flush,
pending, close, and the dry run -- which hibr's desktop types through from
0.99.517 on (hibr Gitea #543). Keys are the names hibr's console gives. Two
Debian packages: `hibr-ime` (the module and `ime-convert`) and
`hibr-ime-arabizi` (the data, `/usr/share/hibr-ime/arabizi`, which Blit
reads too). `make check` drives the module from hibr as well (9 checks).

## 0.1.0

**The first release: one interface to every input method, and Arabizi as
the first.** `ime.h` is what a host calls -- hibr's module and Blit's
compositor alike -- so a second method needs no change in either. Arabizi's
engine came over from Blit (ADR 0233) unchanged, behind an adapter that
turns `ime.h`'s keys into the ASCII it reads. Its rules, word lists and test
set came with it. The tests drive the interface through a second, test-only
method so nothing in it can lean on Arabizi, check that the interface gives
exactly what the engine gives on all 218 lines of the test set, typed key by
key as well as converted whole, and hold word accuracy at its baseline: 193
of 241 words, 80.1%. Escape is decided by the interface, the same for every method: with
something held it drops it and is consumed, with nothing held it passes.
`IME_API` (1) rises with each addition to `ime.h`, so a host can build
against more than one release. Clean under tcc, gcc with every warning, and ASan and
UBSan.
