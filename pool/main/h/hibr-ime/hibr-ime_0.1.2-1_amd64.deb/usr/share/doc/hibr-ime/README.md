# hibr-ime

Input methods for hibr and Blit: keys go in, and what comes out is the text
held under the caret (the preedit) and the text committed. One engine for
every place a person types: hibr's own fields and terminal windows wherever
hibr runs, and, through Blit's adaptor, program windows and bare Blit
sessions. Neither host knows which method it is running.

The first method is **Arabizi**: Arabic typed in Latin letters and digits
(`salam` → سلام, `3ali` → علي), read as you type, with tashkeel when asked.

## What is here

| path | what it is |
|---|---|
| `include/ime.h` | the interface every host calls: load a method's data, an engine per place typed into, feed a key, preedit, flush, and the dry run |
| `src/ime.c`, `src/method.h`, `src/methods.c` | the interface handing each call to its method, and the list of methods compiled in |
| `methods/arabizi/` | the Arabizi engine (`arabizi.c`, libc and libm only) and its adapter to `ime.h` |
| `data/arabizi/` | its rules and word lists, installed in `/usr/share/hibr-ime/arabizi` |
| `tools/ime-convert.c` | the dry run from the command line: `ime-convert arabizi /usr/share/hibr-ime [tashkeel]` |
| `tools/make-word-lists.sh` | rebuilds the word lists from their pinned source |
| `tests/` | the interface driven through a second, test-only method (`shout.c`), and Arabizi against its test set |

## Keys

A key is a Unicode code point, or one of `IME_BACKSPACE`, `IME_ENTER`,
`IME_TAB`, `IME_ESCAPE`, the arrows, `IME_HOME`, `IME_END` and
`IME_DELETE`. `ime_feed` answers the text a key commits and whether the key
then *passes*: a key that passes is the host's to act on, after inserting
what was committed. A key a method has no use for commits what is held and
passes, so a cursor key never strands half a word. Escape is the interface's own, the
same for every method: with something held it drops it and is consumed;
with nothing held it passes. `IME_API` rises with every addition to `ime.h`.

## In hibr

The `ime` module (`mod/ime.c`, `/usr/lib/hibr/ime.so`) gives hibr the
`ime` builtin:

    ime methods                      the methods compiled in
    ime open METHOD [OPTIONS]        an engine; its handle is the answer
    ime feed H KEY                   RET: committed text, 1 if the key passes, the preedit
    ime preedit H | flush H | pending H | close H
    ime convert METHOD TEXT [OPTIONS]    the dry run

A key is a character or a name hibr's console gives (`backspace`, `enter`,
`escape`, the arrows...). The data is read from `/usr/share/hibr-ime`, or
from `HIBR_IME_ROOT`. hibr's desktop (0.99.517 on) types through the method
its current keyboard names -- Blit's "Arabic (Arabizi)" is `arabizi` -- in
its own fields, textareas and terminal windows; Blit converts in program
windows with the same engine.

## Your own layer

What a person tunes lives in `$XDG_CONFIG_HOME/hibr/ime/<method>/` and is
read over the shipped data by the library, so hibr and Blit always agree.
For Arabizi: `arabizi.rules` in the shipped rules' own format (a `unit`
line replaces the shipped readings for a digit; `word salam = سلامات` is a
word of your own) and `options` (`tashkeel`). The Control Panel's Arabizi
pane writes both; nothing else needs to.

## Packages

- `hibr-ime`: the module and `ime-convert`.
- `hibr-ime-arabizi`: Arabizi's rules and word lists, in
  `/usr/share/hibr-ime/arabizi`, read by hibr's module and by Blit alike,
  and its Control Panel pane.

Each method's data is a package of its own, so nobody downloads another
language's dictionaries.

## Building

    make            # build/ime-convert, with tcc
    make check      # the tests
    make strict     # gcc with every warning, then the tests under ASan and UBSan
    make mod        # build/mods/ime.so, against a hibr checkout (HIBR=~/hibr)
    make install    # PREFIX=/usr: the tool, and the data under share/hibr-ime
    packaging/deb/build-deb.sh   # the two packages

A host compiles `src/*.c` and `methods/*/*.c` with `-Iinclude -Isrc` and
calls `ime.h` alone.

## Licence

The engine, the interface, the rules and the tests are LGPL-3.0-or-later
(`LICENSE`, with the GPL it builds on in `COPYING`). The word lists are CC
BY-SA 4.0, derived from Hermit Dave's FrequencyWords: see
`data/arabizi/README.md`.
