# Changelog

## 0.1.2

**Arabizi is tunable, and the same everywhere it types.** A person's own
layer, `$XDG_CONFIG_HOME/hibr/ime/<method>/`, is read over the shipped data
by the library itself (`IME_API` 2: `ime_load_user`, `ime_stale`), so hibr's
module and Blit's compositor convert alike, and neither carries any of it
on its own. In it, `arabizi.rules` is the shipped rules' own format: a
`unit` line for a digit replaces the shipped readings for it, a `word` line
is one of the person's own words and wins over the word lists, and a line
that is not a rule is named by file and line and left out while the rest
stands. `options` holds the method's words -- `tashkeel` -- which an engine
takes when its host gives none. A change is noticed at the next word's end
and loaded again, with no restart.

**The Arabizi pane** (Control Panel, from `hibr-ime-arabizi` and the
catalogue): Write Tashkeel, the reading of each Arabizi digit as a
dropdown, My Words to add, change and remove, Try Arabizi to see what typing
becomes before using it, and a way back to the shipped readings. It writes
only the person's own layer, and keeps any line of it it does not manage.

**`ime info METHOD`**: a method's short label and name, from its data's
`info` (Arabizi: AR, Arabic (Arabizi)), which hibr's bar and Blit's keyboard
list show. **`ime convert -u DIR`** previews a layer before it is saved.

Tests: 22 in the library (tcc, gcc, ASan and UBSan), 15 for the module, 11
for the pane's own file handling, and 5 for the pane in a real desktop.

## 0.1.1

**The hibr module, and the packages.** `ime.so` gives hibr the `ime`
builtin -- methods, an engine per place typed into, a key fed and its
commit, whether it passes and the preedit answered together, flush,
pending, close, and the dry run -- which hibr's desktop types through from
0.99.517 on (hibr Gitea #543). Keys are the names hibr's console gives. Two
Debian packages: `hibr-ime` (the module and `ime-convert`) and
`hibr-ime-arabizi` (the data, `/usr/share/hibr-ime/arabizi`, which Blit
reads too). `make check` drives the module from hibr as well (9 checks).

## 0.1.0

**The first release: one interface to every input method, and Arabizi as
the first.** `ime.h` is what a host calls -- hibr's module and Blit's
compositor alike -- so a second method needs no change in either. Arabizi's
engine came over from Blit (ADR 0233) unchanged, behind an adapter that
turns `ime.h`'s keys into the ASCII it reads. Its rules, word lists and test
set came with it. The tests drive the interface through a second, test-only
method so nothing in it can lean on Arabizi, check that the interface gives
exactly what the engine gives on all 218 lines of the test set, typed key by
key as well as converted whole, and hold word accuracy at its baseline: 193
of 241 words, 80.1%. Escape is decided by the interface, the same for every method: with
something held it drops it and is consumed, with nothing held it passes.
`IME_API` (1) rises with each addition to `ime.h`, so a host can build
against more than one release. Clean under tcc, gcc with every warning, and ASan and
UBSan.
