# Changelog

## 0.1.5

**Cycle, or teach** (hibr-ime #1). Arabizi reads 70% of the owner's own
typing right, and more than half the misses are words no list offers, so
the rest is put right where it is typed.

- **Cycle.** A key moves the word being typed through what else it could
  be: the method's own reading first, then the other spellings it found,
  then the word as typed, wrapping both ways. `ime_cycle`, `ime_choice`.
- **What is chosen is remembered.** The spelling showing when the word is
  let go of -- a space, punctuation, Enter, a flush, or held for the next
  word -- goes to the person's own `arabizi.rules` as a word of theirs, in
  one append, and is in force at once. Escape teaches nothing; typing
  another letter goes back to the method's own reading. What commits is
  what was showing, whether or not it can be remembered (Blit with no
  person's layer); a picked word is committed, never held to be read with
  the next (al, wa); a word kept in Latin is remembered lowercase, as the
  pane writes words; and changing your mind is cycling again, since the
  last line for a word wins.
- **A correction costs no load.** Loading Arabizi is about 72 ms, nearly
  all of it the word lists, and a write to the person's layer made every
  host's data stale. The data that taught stays current; another host's
  sees the change, and `ime_reload` reads the rules again in place -- the
  shipped ones and the person's over them, the word lists kept -- in
  0.15 ms. hibr's module uses it whenever the layer changes, a word
  added in the pane included, so that is no longer a whole load either.
- **The file is shared, so both writers take care.** A last line with no
  newline is ended before the new one goes on, and the Arabizi pane reads
  the file again before choosing a reading, so a word taught while it is
  open is kept (pane 0.1.5).
- **Teach.** `ime_teach(data, latin, text)` for a word no spelling fits,
  with `ime_word` the word as typed: the host asks, the library writes.
- **`IME_API` 3.** The method table grows `drop`, `cycle`, `choice`, `word`
  and `teach`, each optional; Escape drops through `drop` where a method
  has one, so a picked spelling is never taught by being thrown away.
- **In hibr**: `ime cycle H [STEP]`, `ime word H`, `ime teach METHOD LATIN
  TEXT`.

## 0.1.4

**Arabizi reads more words right.**

| | before | after |
|---|---|---|
| the public set | 193 of 241 (80.1%) | 231 of 238 (97.1%) |
| the owner's own typing (80 words, scored privately by Blit, only the number shared) | 67.5% | 70.0% |

The second line is the one that counts. Most of the public set's gain is
the set itself: its misses were classified one by one (how each word split,
whether the expected Arabic could be spelled at all, where it ranked), and
fixed structure first, then vocabulary, so the fixes fit those words best.
Most of what is left in the owner's typing is the medial long a, dropped
and added alike, and words a list cannot know. That points at learning
from the person's own choices rather than at more rules.

- **A word may split differently.** The longest match hid readings: ay in
  sayyara took the first of its two y's, ah in sabah had no ح, sh in ashal
  was never s then h, an in 3an never a silent a then n. A multi-letter
  unit may now also be read as its letters, at a cost: cheaply for an
  ending, more for a diphthong, most for a consonant digraph. Never
  between two vowels, which would let both fall silent.
- **The hamza's seat follows its vowels**: kasra, then damma, then
  fatha, on either side. mu2min مؤمن، ma2moun مأمون.
- **The alef at the start of a word carries its hamza**, as standard
  spelling writes it (أنا، أهلا). Control Panel > Arabizi > **Hamza at the
  Start of a Word** turns it off for a plain alef (انا), the owner's
  choice of a setting. It is the `plainalef` option word, applied in the
  library itself, so hibr's fields and Blit's windows agree. The engine
  takes flags now (`ARABIZI_TASHKEEL`, `ARABIZI_PLAINALEF`); 0 and 1 mean
  what they did.
- **Everyday Levantine and names, ranked above the subtitles**:
  `ar-common.txt` (كمان، هون، بس، بدي، كيفك، نحنا، عمر، ليلى، بيروت، غزة …).
- **The hyphenated article follows the same rule as the spaced one**: a
  sun-letter form only before its own letter, so as-salam is السلام and
  as-hal أسهل.
- **-allah, -ullah and -illah are endings**, written الله (عبدالله).
- The pane keeps any line of the options file it does not manage.

The test set is written in standard spelling now. Its plain-alef lines
are `tests/arabizi/plain.tsv`, run with `plainalef`. Seven words still miss:
- three need a decision about the Levantine glottal stop for ق, or 6 as ض
  (el 2amar, ahwe, rama6an);
- one cannot be spelled from its letters (mashour);
- heya against hayya cannot be told apart;
- durus;
- inti's final i, under plain alef.

## 0.1.3

**The Arabizi pane, fixed** (the owner's report).
- Its icon is a keyboard. It was the letter ع, which on its own looks like a 3, and made the pane's whole row in the Control Panel's list right-to-left, pushed to the right edge.
- Write Tashkeel is a checkbox, switched with one click (with hibr 0.99.521, where a Control Panel checkbox first switches on one click). It was a dropdown of On and Off.
- The readings' heading says what they are: The Letter Each Digit Writes.
- Its menus follow the focused window.

## 0.1.2

**Arabizi is tunable, and the same everywhere it types.** A person's own
layer, `$XDG_CONFIG_HOME/hibr/ime/<method>/`, is read over the shipped data
by the library itself (`IME_API` 2: `ime_load_user`, `ime_stale`), so hibr's
module and Blit's compositor convert alike, and neither carries any of it
on its own. In it, `arabizi.rules` is the shipped rules' own format: a
`unit` line for a digit replaces the shipped readings for it, a `word` line
is one of the person's own words and wins over the word lists, and a line
that is not a rule is named by file and line and left out while the rest
stands. `options` holds the method's words -- `tashkeel` -- which an engine
takes when its host gives none. A change is noticed at the next word's end
and loaded again, with no restart.

**The Arabizi pane** (Control Panel, from `hibr-ime-arabizi` and the
catalogue): Write Tashkeel, the reading of each Arabizi digit as a
dropdown, My Words to add, change and remove, Try Arabizi to see what typing
becomes before using it, and a way back to the shipped readings. It writes
only the person's own layer, and keeps any line of it it does not manage.

**`ime info METHOD`**: a method's short label and name, from its data's
`info` (Arabizi: AR, Arabic (Arabizi)), which hibr's bar and Blit's keyboard
list show. **`ime convert -u DIR`** previews a layer before it is saved.

Tests: 22 in the library (tcc, gcc, ASan and UBSan), 15 for the module, 11
for the pane's own file handling, and 5 for the pane in a real desktop.

## 0.1.1

**The hibr module, and the packages.** `ime.so` gives hibr the `ime`
builtin -- methods, an engine per place typed into, a key fed and its
commit, whether it passes and the preedit answered together, flush,
pending, close, and the dry run -- which hibr's desktop types through from
0.99.517 on (hibr Gitea #543). Keys are the names hibr's console gives. Two
Debian packages: `hibr-ime` (the module and `ime-convert`) and
`hibr-ime-arabizi` (the data, `/usr/share/hibr-ime/arabizi`, which Blit
reads too). `make check` drives the module from hibr as well (9 checks).

## 0.1.0

**The first release: one interface to every input method, and Arabizi as
the first.** `ime.h` is what a host calls -- hibr's module and Blit's
compositor alike -- so a second method needs no change in either. Arabizi's
engine came over from Blit (ADR 0233) unchanged, behind an adapter that
turns `ime.h`'s keys into the ASCII it reads. Its rules, word lists and test
set came with it. The tests drive the interface through a second, test-only
method so nothing in it can lean on Arabizi, check that the interface gives
exactly what the engine gives on all 218 lines of the test set, typed key by
key as well as converted whole, and hold word accuracy at its baseline: 193
of 241 words, 80.1%. Escape is decided by the interface, the same for every method: with
something held it drops it and is consumed, with nothing held it passes.
`IME_API` (1) rises with each addition to `ime.h`, so a host can build
against more than one release. Clean under tcc, gcc with every warning, and ASan and
UBSan.
