# Architecture

Anything in these documents that is designed but not built is marked `*(planned: M3)*` (the milestone that builds it,
see [ROADMAP](ROADMAP.md)). Everything else describes what the code does; `make check` compares the two.

## 1. The model: one switch, many ports

longwire is a **software Ethernet switch whose ports are encrypted UDP sessions**. All the nodes on one *line*
together make a single distributed learning switch:

- **Learn.** When a frame arrives, remember that its source MAC lives behind the port (the local port, or a peer) it
  came from. An entry moves at once when the MAC shows up somewhere else, and ages out after 300 s.
- **Forward.** A frame for a known MAC goes to exactly one place: the local port or one peer. A frame between two
  local MACs never leaves the site.
- **Flood.** Broadcast, multicast and unknown-unicast frames go to every peer on the line (and, from a peer, to the
  local port). If the peer a MAC was learned behind has gone, its frames are flooded again instead of dropped.
- **Split horizon.** A frame that arrived *from a peer* is never sent on to another peer. Sites form a full mesh,
  so every peer already received it directly. This rule is what removes the need for spanning tree.

There is no routing protocol, no address plan and no controller. "A client is a server" because there are no
clients or servers here, only ports.

```
         site A                                  site B                          site C
  ┌───────────────────┐                   ┌───────────────────┐          ┌───────────────────┐
  │ LAN 10.0.0.0/24   │                   │ LAN 10.0.0.0/24   │          │ LAN 10.0.0.0/24   │
  │  hosts ── eth0    │                   │  eth0 ── hosts    │          │  eth0 ── hosts    │
  │           │       │                   │    │              │          │    │              │
  │     [longwire]════╪═══ encrypted UDP ═╪═[longwire]════════╪══════════╪═[longwire]        │
  │      MAC table    │                   │   MAC table       │          │   MAC table       │
  └─────────╫─────────┘                   └───────────────────┘          └─────╫─────────────┘
            ╚═══════════════════════════ full mesh ════════════════════════════╝
                    ▲                         ▲                                 ▲
                    └──────── register / dial / punch only ─────────────────────┘
                                         [switchboard]
```

A call is between two nodes, and a node can be on many calls at once. When a call comes up the two ends find out
whether either holds a **line**, and a node that is called by a newcomer vouches for it, so calls accumulate into the full
mesh in the picture ([PROTOCOL §6](PROTOCOL.md#6-control-messages-and-lines), [ADR 0022](adr/0022-lines-form-by-vouching.md)).
A node is on one line of up to 16. A pair that cannot connect directly is relayed by another member
([PROTOCOL §5](PROTOCOL.md#5-relay-built-m3-stage-2)); if no member will relay, the pair splits the line, and the node says so.

## 2. Attaching a node: ports

Every node has exactly one **local port**, the place where frames enter and leave the line on this machine. The
modes differ only in what that port is:

| Port | Mechanism | Privilege | Notes |
|---|---|---|---|
| **splice** | `AF_PACKET` raw socket on a NIC (Linux) | `CAP_NET_RAW`, granted once to the node's service as an **ambient capability**, and dropped as soon as the socket is open | **No interface is created.** Wired Ethernet only: most Wi-Fi client links drop frames with foreign source MACs (4-address/WDS mode excepted). The splice box's *own* stack doesn't see injected frames, so if that box itself needs the far side, add a jack too. |
| **jack** | A tap device (`IFF_TAP \| IFF_NO_PI`) | Created once, owned by the user, by a root helper run through `pkexec` (`longwire jack`, `longwire on`, or the pane's Turn on; [ADR 0034](adr/0034-a-connection-is-a-profile.md), [ADR 0041](adr/0041-the-helpers-and-the-launcher-are-hibr-scripts.md)). In the same step it may put on an address or start a DHCP client, add routes through a gateway on the line, send everything through the line and set up to three name servers, or share the machine's internet; it can also remove a jack. Everything through the line and sharing are a polkit action of their own, the same helper run as `jack-everything` ([ADR 0058](adr/0058-the-device-and-the-whole-machine-are-two-permissions.md)). By hand: `ip tuntap add mode tap user $USER` | Ordinary host membership. The tap's MTU should be 1400. It has carried real calls on the author's desktop; the machine this was built on has no `/dev/net/tun`, so the tests use stand-ins. |
| **sock** | frames as datagrams on a Unix socket | none | for tests and experiments only |
| **none** | no local port | none | what the switchboard uses: it never sees a frame |
| **shell** | A tap inside an unprivileged user + network namespace | **None** | *(planned: M5)* `longwire shell` hands you a shell whose only network is the line. |
| **member** | An L3 TUN from the OS: Android `VpnService` (built, [ADR 0076](adr/0076-the-phone-is-a-member-with-an-adapter-and-an-app.md)); macOS utun, Windows wintun *(planned: M6)* | The OS VPN consent prompt | See §5. |
| **BSD / macOS splice** | BPF device | access to `/dev/bpf*` | *(planned: M5)* |

**A node always runs as an ordinary user.** For splice, the service manager starts the node script with
`CAP_NET_RAW` as an ambient capability. `lw start --splice eth0` opens the packet socket, then clears *every* capability set (effective, permitted,
inheritable and ambient) and forks the engine worker, which inherits the empty sets; it also sets
`no_new_privs`. No script code after that holds any privilege, and hibr itself never gains one, in keeping with hibr's
ADR 0016 (see [ADR 0004](adr/0004-a-node-never-runs-as-root.md)). `longwire setup splice NIC` prints the service unit.

Splice details (Linux):
- `socket(AF_PACKET, SOCK_RAW, ETH_P_ALL)` bound to the interface. Promiscuous mode comes from
  `PACKET_ADD_MEMBERSHIP` / `PACKET_MR_PROMISC`, which the kernel releases when the socket closes, so nothing is left
  behind after a crash.
- **No loop.** `PACKET_IGNORE_OUTGOING` (Linux 4.20 and later) keeps the frames this box injects from being read back
  as local traffic, and the read path also discards anything the kernel marks as outgoing.
- **Unfinished checksums are completed.** A frame from a virtual NIC (veth, virtio) can arrive with its TCP/UDP
  checksum only partly done; the packet socket says so (`PACKET_AUXDATA`) and longwire finishes it before the frame
  goes anywhere else, or the far LAN would drop it.
- **Coalesced frames are cut.** See §6.
- Reading uses one `recvmsg` per frame; a `TPACKET_V3` ring and batching, for speed, *(planned: M7)*.

### The jack's road

A jack can be given an address in the far network, and then the kernel would send the packets that bring the line up into the line itself. The node therefore treats as "the jack's networks"
every network connected to the jack and every IPv4 route the kernel sends through it (read from `/proc/net/route`), sends anything for those through a second UDP socket tied to the real device
(`SO_BINDTODEVICE`, no privilege, Linux 5.7 and later), and never offers its own jack address as a candidate ([ADR 0037](adr/0037-traffic-to-the-other-end-never-goes-into-our-own-jack.md),
[ADR 0044](adr/0044-routes-beyond-the-line-go-through-a-gateway-on-it.md)).

**Everything through the line** ([ADR 0045](adr/0045-everything-through-the-line-is-a-table-of-the-jacks-own.md)). The helper puts a default route through a gateway on the line (or the exit gateway, below) into a table of
the jack's own (7700 + N for `lwN`), with two rules: `7700: lookup main suppress_prefixlength 0` and `7701: lookup 7700+N`. The main table is never touched; an IPv6 default route into the
jack goes into the same table. Every socket of the engine is tied to the real device before it is bound. The helper sets `ignore_routes_with_linkdown` on the jack and refuses unless the jack
has no carrier: a tap that no process holds has none, so when the node stops or crashes the kernel passes over the jack's routes and the machine is back on its own road. This fails open;
a switch that blocks instead *(planned: M4)*.

**The exit** ([ADR 0056](adr/0056-a-member-can-share-its-internet.md)). With no gateway named, the default route goes to 169.254.77.1, with the MAC 02:6c:77:65:78:74 fixed beside it by the
helper (`nud permanent`): no machine has either, and no ARP is asked or believed. A member that shares its internet (`--exit`) tells every member it has a session with, every 10 s, `M_EXIT` with
its jack's MAC; the switch hands every frame for 02:6c:77:65:78:74 to the chosen exit's session, with that MAC put in, and with no exit drops it and counts it (never floods it). So the gateway
is a member's key, not an address. The exit's side is its kernel's: the helper's `--share` turns forwarding on and adds an nftables table of the jack's own (`longwire-lwN`) that masquerades the
line's network out through the machine's own default device, lets only answers back and keeps the line off the machine's other networks; it is written down in `/run/longwire/share-lwN` and
undone exactly.

**Roaming** ([ADR 0046](adr/0046-a-node-that-takes-everything-lets-go-when-the-road-changes.md)). Once a second the engine compares the default route's device (not the jack) with the one its
sockets are tied to. When it changes or goes, the engine closes the jack, which drops its carrier, and emits `roamed`; the node script then starts the node again on the new road. A device named
with `--underlay` is not followed.

**Names** ([ADR 0047](adr/0047-names-through-the-line-are-set-on-the-jack.md)). With everything through the line, a profile's `dns` is set on the jack in systemd-resolved for every name (`~.`);
resolved passes over a device with no carrier, so names return to the machine's own server when the node is gone. Without systemd-resolved, names stay with the machine's own server.

## 3. Keeping the WAN quiet

Bridging L2 over the internet carries the LAN's chatter. longwire trims it without breaking anything:

- **ARP suppression, and its IPv6 twin.** Each node keeps an IP→MAC cache learned from ARP packets crossing the switch. When a
  local host asks who has an address the cache knows to be across the line (the MAC is learned behind a peer, and the
  entry is under 120 s old), the node answers the request itself and the question never crosses the WAN. Probes and
  announcements (sender address 0, or sender = target) always cross. IPv6 neighbour solicitations are answered the same way
  (the cache is learned from solicitations and advertisements, and duplicate-address detection always crosses).
- **Flood budget.** Frames flooded to a peer are limited to 1000 a second after a burst of 200, per peer. A
  broadcast storm costs the WAN almost nothing; a unicast frame to a known address is never limited.
- **DHCP stays honest, and only a member you asked for may be the network's server.** A line has one subnet and normally one DHCP server. The switch watches the DHCP offers
  that pass through it, and when two different servers have offered within ten minutes it says so once (the
  `dhcp-conflict` event, and the `dhcp_conflicts` count in status). And it **guards the node's own side**
  ([ADR 0080](adr/0080-only-a-member-we-asked-for-may-speak-for-the-network.md)): a DHCP reply, a DHCPv6 reply or a router advertisement from a member this node did not ask for (a number a person dialled, or a peer
  the configuration names with an address) or is not told to trust (`--dhcp-server`) is refused before anything is learned from it, through priority tags and extension headers, and counted (`dhcp_guarded`, the `dhcp-blocked` event). It is on for a
  splice, a jack and a phone.
- **What a bridge never carries.** The link-local control frames (`01:80:C2:00:00:00` to `0F`: spanning tree, pause, LACP, 802.1X, LLDP; and Cisco's CDP, VTP, DTP and PVST+) are for the wire they were sent on: they cross the line in
  neither direction, so two sites' spanning trees are not joined and a switch's BPDU guard is not tripped by a box ([ADR 0083](adr/0083-a-pair-of-boxes-is-one-site-and-a-bridge-carries-no-control-frames.md)).
- **A pair of boxes is one site, and a loop is stopped even if the election fails.** A frame from a member whose bytes are those of one that just came off our LAN (or the reverse) has come round: it is dropped, and a member that does it
  three times in five seconds is on our own segment and carries nothing to or from the LAN for a minute. A box tells its members which boxes share its segment (`SITE`), so a client that dialled one box lets the other answer its DHCP.

## 4. Two boxes on one segment: site groups

Split horizon prevents loops *between* sites. The remaining danger is **two splice boxes on the same physical LAN
segment**: each would forward the other's frames, and a loop follows. Boxes that share a secret avoid it by electing
one to forward:

- The secret is derived from the line key, so boxes of one line share it automatically (a rotated key is accepted
  alongside the previous one for 30 seconds, so an eviction doesn't flap a site). A file of 64 hex digits given with
  `--site-key FILE` overrides it, which is how two boxes work that are not on a line. A box with neither does not look
  for others, so two boxes on one segment **must** have one or the other.
- Every box sends a **probe** once a second: a broadcast frame with EtherType `0x88B5` (IEEE local experimental),
  carrying its key id, the time, and a MAC under the site secret. Probes are consumed locally and never forwarded
  over the line. A probe more than 30 s off the local clock is ignored.
- A box that has heard no other member for 3.5 seconds is alone. Among the boxes heard, the one with the **lowest key
  id is active**; the rest are **standby**. A standby box keeps its sessions up (so a takeover needs no handshake) but
  forwards nothing and delivers nothing to the LAN. A new box listens for 3 seconds before it forwards anything.
- The active box shares, every 2 seconds, the list of remote hosts it knows (up to 64 MACs). When a standby box takes
  over it sends one frame from each of those addresses onto the LAN, so every switch on the segment learns at once that
  they are now behind it, and then sends gratuitous ARP for the hosts it has seen ARP. Without this, the LAN would keep
  sending their traffic to the box that went quiet until its tables aged out.

In the test suite the active box is killed and traffic resumes, with nothing done to any host, in about 4 seconds
(the test allows up to 14). A takeover within two seconds of the group forming, before the first list has been shared, falls back to
ordinary learning and is slower.

## 5. Member mode: a phone as an Ethernet host

Android and macOS give apps an IP tunnel, not Ethernet. longwire bridges the gap **in userspace**, on the device:

1. The device gets a stable, locally administered MAC derived from its key: `02:` + 5 bytes of `BLAKE2b(key-id)`.
2. A built-in **DHCPv4 client** sends its DISCOVER over the line. *The far LAN's own DHCP server hands out the
   lease*, so the phone gets a real address, gateway and DNS from home.
3. An **ARP responder** answers for that address, and **IPv6** runs SLAAC and an NDP responder.
4. IP packets from the OS tunnel are wrapped in Ethernet frames toward the learned gateway or peer MACs, and frames
   for our MAC are unwrapped back into the tunnel.
5. The tunnel gets the lease's address and, by default, only the line's subnet (*split*). `--all-traffic` also
   routes the default route through the far site's gateway.

*Built* (Android, [ADR 0076](adr/0076-the-phone-is-a-member-with-an-adapter-and-an-app.md)): 1, 2, the ARP half of 3, 4 and 5 (the tunnel carries the line's subnet, or everything with `all traffic`), in `engine/member.c`, tested
against a scripted LAN and on a real line (`tests/leaf.sh`, `tests/leafnet.sh`). *Planned (M6):* IPv6 (SLAAC and an NDP responder: until then IPv6 is dropped, and with `all traffic` the tunnel black-holes it rather than let it past the line), and the leaf role below.

Members, along with laptops in jack mode that ask for it, are **leaves** *(planned: M6)*: a leaf keeps *one* session, to the node it
dialed, and that node treats the leaf like a host on its local port. One session means one keepalive, which a phone
battery appreciates. Sites are **trunks**, a full mesh.

## 6. Packet sizes

Overhead per data packet: IP (20) + UDP (8) + longwire header (12) + payload kind (1) + Poly1305 tag (16) = 57 bytes
over IPv4 (a further 20 over IPv6). The underlay is both: a node holds an IPv4 and an IPv6 socket
([ADR 0027](adr/0027-ipv6-is-a-second-socket.md)).

| Situation | Handling |
|---|---|
| jack, sock | `longwire setup jack` prints the command that sets the tap's MTU to **1400**, so frames are at most 1414 bytes and fit one datagram. The engine does not enforce it: a larger frame is split like any other. A `sock` port has no MTU. |
| splice | LAN hosts send 1500-byte frames and we can't change them. So: **(1)** clamp the TCP MSS in SYN and SYN-ACK frames as they pass, to **1340** (IPv4) or **1320** (IPv6). A segment carrying 1340 bytes and the usual 12 bytes of TCP options is a 1406-byte frame, which travels in one datagram. **(2)** A frame up to **1428** bytes goes in one datagram (1428 + 29 + 28 = 1485, and 1489 once a relay wraps it, which fits PPPoE's 1492). A larger one is split across two datagrams (`FRAG`) and put back together on arrival; each peer holds four reassembly slots with a 2 s timeout. **(3)** A NIC can hand a splice box a *coalesced* TCP frame of up to 64 KB (GRO, or a virtual NIC's GSO), so oversize TCP frames are cut into line-sized segments with fresh lengths, sequence numbers and checksums; that is always valid TCP. Other oversize frames are dropped and counted. |
| path MTU | Probing the real path MTU per peer *(planned: M7)*. Until then the constants above assume an IPv4 path of 1492 or better, and IPv4 datagrams go without "don't fragment", so a narrower path behind a router that sends no ICMP splits them instead of dropping them ([ADR 0051](adr/0051-longwires-datagrams-may-be-split-on-the-way.md)). Over IPv6 the same frame is 20 bytes larger (a 1428-byte frame makes a 1505-byte packet, and a handshake fragment 1296), so on a 1500-byte IPv6 path the kernel fragments it. |

## 7. The three components

| | Component | Language | Owns |
|---|---|---|---|
| 1 | `longwire-switchboard` | hibr script | **policy**: who may register (tokens, a token reserving a number, a limit per source address) and whose ring goes through (a limit per callee per minute) |
| 2 | `longwire` (the node) | hibr script | the commands; the answer policy (ask, known, auto, never); turning events into sentences; setup helpers |
| 3 | `longwire.so` | C (hibr module) | **mechanism**: everything that touches bytes or keys, in a forked worker process: sockets, ports, handshake, sessions, the switch, NAT punching, the switchboard's registry and call routing, pins, cookies |

**C handles bytes and keys; hibr makes the decisions.** A script never sees a packet or a key, and it can make the
engine more restrictive but never less ([ADR 0015](adr/0015-scripts-decide-c-enforces.md)).

### Process model

```
 systemd / hold / a terminal
   └─ hibr longwire up                     node script: policy, UI
        │  lw start --splice eth0          ← opens the port, clears every capability, forks
        ├─ worker (C only)                 sockets, port, sessions, crypto, switch, NAT punching
        │    └─ serves ~/.longwire/ctl     control socket, mode 0600, peer uid checked
        └─ while read ev </dev/longwire/events     ring → answer policy → lw pickup / lw reject
                                                   key-changed, call-lost, hangup … → sentences

 another terminal:  longwire dial 312-884-076    → lw dial → control socket → worker
```

- **The worker is pure C, forked by the module** (the same shape as hibr's `hold` server). The packet path never
  enters the interpreter, so a busy script can't stall traffic. It closes every inherited descriptor and locks its key
  memory.
- **Every `lw` verb works from any hibr process,** through the control socket. That is how `longwire dial` in a
  second terminal reaches the running node.
- **Events** stream from the worker as JSON lines on `/dev/longwire/events` (see [CLI](CLI.md#events)).
  hibr parses them with `json parse`.
- **If the node script dies,** the worker keeps every established call up. A ring that nobody answers is refused
  after 60 s. A restarted script finds the worker still running and attaches to it (`up` says so), so a service manager can
  restart the script freely; `longwire down` stops the worker.
- **The switchboard has the same split.** `lw sb start` forks a C worker that handles sessions, handshakes, `HELLO`,
  cookies, heartbeats, presence, the number registry and call routing. Only two decisions reach the script, a
  registration from a key it hasn't seen and a ring, so a few events per call and none per heartbeat (see
  [SWITCHBOARD](SWITCHBOARD.md#how-tiny)).

### Source layout

```
engine/                      plain C99: never includes hibr.h, so the Android app can reuse it
  lw.h                       the engine's public API: configuration, open/serve, identity
  int.h                      internal structures and the function map between the files below
  proto.h                    message ids, candidates, the small codecs shared by node and switchboard
  words.h                    the 256 words of the safety phrase
  id.c                       identity from the seed, key derivation, handshake AEAD, the lw1... address
  hs.c                       the handshake, its fragments, the load budget and cookies
  sess.c                     sessions and the peer table: data packets, replay window, rekey, keepalive
  sw.c                       the switch: MAC table, flood, split horizon, frame split, MSS clamp, ARP, re-segmenting
  site.c                     site groups: probes, election, standby, takeover
  member.c                   the phone's adapter: a MAC, DHCPv4, ARP, IPv4 wrapped and unwrapped (a state machine over frames and a clock), and the node's side of it (ADR 0076)
  line.c                     lines: members, admits, eviction, persistence, the mesh maintainer
  exit.c                     the exit: a member that shares its internet says so (M_EXIT), the choice of exit, frames for the exit gateway handed to it (ADR 0056)
  relay.c                    relaying: the route table, wrapped datagrams, relay requests, path upgrade
  spray.c                    port spray: a strict NAT end opens many sockets, the easy end probes, the socket that is hit becomes that peer's
  pmp.c                      NAT-PMP: ask the home router to keep a port open, offered as a candidate
  ban.c                      strikes and bans on a switchboard: fixed tables, only for failures on an authenticated session, everything expires (ADR 0043)
  sandbox.c                  the node, once up, can make only the system calls its loop needs (seccomp, ADR 0062)
  road.c                     the road under the node, watched once a second always: a changed road is told to every peer at once, a lost one waited out quietly (ADR 0061)
  under.c                    the road under the line: the jack's networks (connected, and routed through it: ADR 0037, 0044), the underlay socket tied to the real device, tying every socket with everything through the line (ADR 0045), and following the road for the jack's own socket (ADR 0046, now timed by road.c)
  port.c                     local ports: splice, jack, sock, none
  caps.c                     clears every capability set once the port is open
  ctl.c                      the control socket and the event stream
  call.c                     the node: numbers, HELLO, candidates, pins, the call table, punching, its commands
  board.c                    the switchboard worker
  node.c                     opening a node and the event loop
  all.c                      unity build of the files above
module/longwire.c            hibr glue: the `lw` builtin and the /dev/longwire/ scheme; forks the worker
scripts/longwire.hibr        component 2: the node
scripts/longwire-switchboard.hibr   component 1: the switchboard
tests/                       the suites `make check` runs (listed in [BUILD](BUILD.md#the-tests)), shared helpers (lwtest.py, lwnat.py), the documentation check (docs.py)
vendor/monocypher/           X25519, Ed25519, ChaCha20-Poly1305, BLAKE2b
vendor/mlkem768/             PQClean ML-KEM-768 "clean" + fips202, with a 5-line compat shim for TCC
brand/                       the mark and wordmark
docs/                        these documents
control-panel/longwire.hibr the client's control panel pane, a catalogue entry of its own
apps/switchboard.hibr       the switchboard application, a catalogue entry of its own
man/                        the manual pages: longwire(1), longwire-switchboard(1), longwire-profiles(5), longwire-security(7)
menubar/longwire.hibr       the telephone on the menu bar, with its menu and the ring that interrupts (ADR 0035)
control-strip/longwire.hibr the same as a Control Strip module
bundles/longwire.json       the catalogue bundle that installs the pane, the bar item and the strip module together
packaging/                   deb, rpm and arch builds, the launcher, the two root helpers (longwire-jack, installed as jack and jack-everything, and longwire-site) and their three polkit actions, the group, the systemd units (Homebrew *(planned: M5)*)
```

The Android app builds `engine/` with TCC for arm64 into a library (`android/jni.c`) behind a small `VpnService` in Java (`android/app/`). That is the
only place the engine is used without hibr; there it runs *embedded*, on a thread of the app's own process ([ADR 0076](adr/0076-the-phone-is-a-member-with-an-adapter-and-an-app.md)).

**The control socket.** The worker owns the sockets, the port and all keys. The node script, `longwire` commands
in other terminals and the desktop pane all reach it through `lw` verbs, which travel over a Unix socket (mode 0600
in `~/.longwire/`). A request is one text line; the reply is one JSON object (put in `$RET`), or, after `watch`, the
connection stays open and carries events. Keys never cross the control socket.

**State on disk (`~/.longwire/`).** This isn't configuration, just state:

| File | Contents |
|---|---|
| `seed` | 32 bytes, mode 0600. *This is your identity and your number.* |
| `known` | pins: switchboard key id, number, key id, one line each; written when a call comes up, edited by `longwire unpin` |
| `answer` | the answer policy `up` was given or `longwire answer` last set; read at each ring |
| `lines` | the line this node is on: its id, founder, line key (sealed under the seed), the node's own admit, the members, and the evictions |
| `ctl` | the control socket |
| `switchboard/numbers.log` | on a switchboard: every number issued, with its key id and bundle |
| `switchboard/codes.log` | on a registry: which switchboard key holds which short code |
| `switchboard/names.log` | on a switchboard: which key holds each listed name (append-only, the last line for a key wins) |
| `switchboard/seed`, `switchboard/ctl` | the switchboard's own identity and control socket |
