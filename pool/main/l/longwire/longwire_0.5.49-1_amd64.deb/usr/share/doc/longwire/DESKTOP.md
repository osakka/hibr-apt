# longwire on the desktop

Everything longwire does can be done from hibr's desktop without opening a terminal. This guide is the tour. For the first
connection, start with the [QUICKSTART](QUICKSTART.md).

There are four things on the desktop, and they all talk to the same node:

| | Where | What it is for |
|---|---|---|
| **The Longwire pane** | Control Panel → Longwire | set up a connection, turn it on and off, dial, answer, see the line |
| **The telephone** | the menu bar | whether it is on, your number, a ring that interrupts, a menu of what you do with a phone line |
| **The strip telephone** | the Control Strip | the same, as one glyph that changes colour |
| **The Switchboard window** | the hibr menu → Switchboard | for someone who *runs* a switchboard: its traffic, who is on it, who is ringing whom, and its bans |

They share one saved connection (a **profile**), so a change in one shows in the others.

## Install

```
please apt install longwire        # or dnf, or pacman: the engine, the launchers, the network-device helper, man pages
catalogue refresh
catalogue install longwire       # the command, the pane, the menu bar telephone and the strip module, together
```

The Switchboard window is its own catalogue entry: `catalogue install switchboard` on the machine whose desktop watches the switchboard.

Then **Refresh Desktop** (or log in again). The pane is under **Apps** in the Control Panel; the telephone is on the menu bar.
The menu bar telephone needs hibr 0.99.351 or newer; the Blit telephone icons need 0.99.364 or newer with the Blit glyph set and Blit 0.2.44, and the classic rotary phone 0.99.366 with Blit 0.2.45.
On an older hibr the pane and the command work and the telephone is simply absent.

## The Longwire pane

### When it is off

The page says **Longwire is off** and shows the connection. These rows are shown, and changed, while longwire is off; a change takes effect at the next **Turn on**.

| Row | What it is |
|---|---|
| **Profile** | the saved connection being shown. Click it (or use the arrows) to switch to another. |
| **Switchboard** | where to register: `HOST:PORT/KEY`, the address, a slash, and the switchboard's key (`lw1…`). |
| **Token** | the invitation your switchboard gave you, if it wants one. It is typed into a masked box and kept in a file only you can read. The row shows `none` or `set (14 characters)`, never the token itself. |
| **Attach** | **jack** for one machine, **splice** for a whole site. Splice makes this machine a site node: **Turn on** asks for your administrator password once and starts the service `longwire@CARD` (the helper `longwire site`); the pane then follows it through the **Node** row, and **Stop the service** stops it. |
| **Interface** | for a jack, the network device (`lw0`; it is made for you); for a splice, the network card. |
| **Address** | this machine's address on the line, like `10.77.0.2/24` (jack profiles; every machine its own, in one subnet), or `dhcp` to ask a DHCP server on the line; put on the device for you. |
| **Containment** / **Privileges** / **Files it can reach** | what the node itself says it is confined by, read from its status and never assumed: its system calls are limited to what it needs, it holds no capability and cannot gain one, and the files it can reach are *not* confined yet (Landlock *(planned: M8)*). There is no switch: containment is not an option ([ADR 0062](adr/0062-the-node-can-make-only-the-system-calls-it-needs.md)). On a kernel without seccomp the row says *NOT limited*; on a node older than 0.5.49, *unknown*. |
| **Network** | shown only while the machine has no network under the line: the node waits quietly, sends nothing, and reconnects the moment one is back ([ADR 0061](adr/0061-a-changed-road-is-found-at-once-and-a-lost-one-is-waited-out-quietly.md)). |
| **Password to connect** / **Password for everything** | whose password connecting asks, read from Administrative Access (`org.longwire.jack`, and `org.longwire.everything` while everything through the line or sharing is on): *an administrator's password*, *your own password*, *none (just you)* or *none (group osakka)* when it is you or a group you are in, or *not allowed*. Longwire only shows it; the row opens Administrative Access, the one place to change it ([ADR 0060](adr/0060-the-pane-shows-the-password-setting-and-never-writes-it.md)). To connect and disconnect with no prompt, choose *No Password, Just Me* there (hibr 0.99.444 or newer; before that, no password for your own group), for both. |
| **Gateway** / **Routes** | networks *beyond* the line, through a router that is on it: Gateway like `192.168.152.254`, Routes like `192.168.150.0/24 10.20.0.0/16` (commas or spaces between them; a wrong one is named, and routes need a Gateway and a fixed Address, said before any password). Put on in the same password step as the device. Never the default route ([ADR 0044](adr/0044-routes-beyond-the-line-go-through-a-gateway-on-it.md)); needs a static Address (not `dhcp`) in the Gateway's network. |
| **Send everything through the line** | all of this machine's traffic leaves through the line, as if plugged in at the far end: with no Gateway, out through the member that shares its internet ([ADR 0056](adr/0056-a-member-can-share-its-internet.md)); with a Gateway, by that router. The line's own packets, and your own network, still go the usual way; when longwire is off or stops, everything goes the usual way again at once ([ADR 0045](adr/0045-everything-through-the-line-is-a-table-of-the-jacks-own.md)). Needs an Address (a static one, or `dhcp` when there is no Gateway). Switching it on switches **Share this machine's internet** off. Switched on or off, it takes effect at the next Turn on. It fails open: a block while the line is down *(planned: M4)*. |
| **Through** | shown when everything goes through the line and there is no Gateway: the number of the member to go out through, when more than one shares its internet. Empty (it reads *the member that shares its internet*): the only one, or the lowest number. |
| **Name servers** | up to three name servers; with everything through the line any server, without it only ones on the line's network or a route ([ADR 0059](adr/0059-name-servers-without-everything.md)), typed with commas or spaces between them, asked through the line for every name, so the network you sit on does not see what you look up. Through a member that shares its internet any resolver works, like `1.1.1.1`; with a Gateway, often the Gateway itself. Needs systemd-resolved; empty reads *this machine's own (names are not private)*: names are then still asked of your own network's name server ([ADR 0047](adr/0047-names-through-the-line-are-set-on-the-jack.md)). |
| **Share this machine's internet** | on: this machine is the way out for the members that send everything through the line with no Gateway; they go out by its internet, and the internet sees its address. It sees everything they send outside the line, as their internet provider would, so share only from a machine the line trusts that much ([ADR 0056](adr/0056-a-member-can-share-its-internet.md)). Needs a fixed Address (not `dhcp`) and nftables; switching it on switches **Send everything through the line** off. At the next Turn on, the same password step as the device turns on forwarding and adds a firewall table of the jack's own that lets the line's network out and nothing else; switched off, the next Turn on undoes it exactly, and so does removing the jack. |
| **Keep the jack when turned off** | on (the default): Turn off stops the node and leaves the network device, so the next Turn on asks for no password. Off: Turn off removes the device too (and a DHCP client of ours on it), at the price of the password again when you turn on (none, if `org.longwire.jack` is set to ask none: below). Jack profiles only. |
| **Name** | what callers see when you ring them. A claim, never proof. |
| **List in the directory** | on: others can find you by name on the switchboard. Off by default. |
| **When a call rings** | how this machine answers: `ask`, `known`, `auto` or `never` (see below). |
| **Longwire on the Menu Bar** | show or hide the telephone. |
| **Phone Style** | **modern** (a handset) or **classic** (a rotary desk phone). Shown only where the glyph set draws telephones (Blit's); it chooses the picture for both the menu bar and the Control Strip. |
| **A service node runs here** | shown when a site service runs on this machine and you cannot reach it: join the group `longwire`, then log in again. |
| **Turn on** | does everything: makes the network device if it is missing, and puts the address on it (that asks for your password), starts the node in the background, and tells you your number. |
| **New profile…** / **Rename profile** / **Remove profile** | keep several connections (home, office, a friend's switchboard) and switch between them. |

When the pane, the installed engine and the running node are not the same version it says so at the top (**Out of step**), with what to do; the scripts come from the catalogue and the engine from the package, and a running node keeps its old engine until it is turned off and on.

The first profile you make becomes the default. When you press **Turn on** and the network device has to be made (the first time, and after each restart, because the device does
not survive one), a dialog asks for a password, and its title says whose: polkit names the account (*Password for Omar Sakka (osakka)* when your own is asked, *Root's password* when it wants root's). Under the title it says what for: *To set up longwire's network device*, or, when everything goes through the line or this machine shares its internet, *To send this computer's traffic via longwire*. polkit remembers an approval for a few minutes. Who is asked, with whose password, whether it is remembered, and whether a group gets it with no password at all, is set in **Control Panel > Administrative Access**, where longwire's three actions (*Set up the network device longwire uses on this computer (its address and routes)*, `org.longwire.jack`; *Send all of this computer's traffic through longwire, or share its internet*, `org.longwire.everything`; and *Make this computer a longwire site node for a network card*, `org.longwire.site`) are listed beside every other package's; longwire ships no rule of its own. Set the first to no password to turn on and off without one, routes or not and with **Keep the jack when turned off** off, while everything through the line and sharing still ask ([ADR 0058](adr/0058-the-device-and-the-whole-machine-are-two-permissions.md)). If `pkexec` is not
installed, or the password is refused, the pane says it could not make the jack and why (a refused password is said as one: nothing was changed); `longwire jack` in a terminal prints the full
instructions, including the two commands to run by hand as root.

### When it is on

| Section | What you see |
|---|---|
| **This node** | your **Number**, your **Name**, the **Switchboard** (it says `dial tone` when all is well) and your **NAT** type. With everything through the line and no Gateway, **Way out** names the member it goes out through, or says *none: no member shares its internet now, so nothing goes out*; on a machine that shares, **Sharing** says *this machine's internet, with the line*. **Turn off** stops the node (calls end; it asks first). If the Switchboard stays at `registering`, `longwire show` says why ([TROUBLESHOOTING](TROUBLESHOOTING.md)). |
| **Node** | shown when more than one node answers on this machine (your own, and a service such as `longwire@eth0`): choose which this pane, the telephone and the strip show and control. |
| **Calls** | anything ringing or being set up. A ring shows who and the caller's name as a claim; click it to **pick up**, or **decline** below it. Each connected person is a row (path, how long, speed in and out; click it to hang up), with the **safety phrase** under it once the two ends have agreed it (a fellow member's too; a note interrupts only for a call you made or answered, [ADR 0057](adr/0057-the-safety-phrase-belongs-to-the-session.md)), and a **Verify…** row: type the words they see, and a match marks the phrase *verified* (a difference ends the call; [ADR 0054](adr/0054-a-phrase-is-checked-by-typing-the-other-ends-words.md)). **Dial…** rings a number. |
| **Line** | the machines you are connected to as one network. Each can be evicted (the line key then changes), unless the line has an operator, who alone decides. |
| **Answering** | **When a call rings**: the policy for this running node, changeable here. |

If the node is a **service** run by an administrator under another user, the pane shows it and says **Runs as: a service**; you
can use it if you are in the group `longwire`; **Stop the service** stops it after the administrator's password, and **When a call rings** reads *set by the service (/etc/longwire)*.

## The telephone on the menu bar

| It shows | It means |
|---|---|
| `☎ ○` | off |
| `☎ ◌` | on, waiting for the switchboard to give a number |
| `☎ ●` | on, and you have a number |
| `☎ ● 2` | on, and two people are connected |
| `☎ ◉ 312-884-076` | that number is **ringing you** |

(In the plain-text glyph set it writes `tel -`, `tel ~`, `tel *`, `tel ! 312-…`. With the Blit glyph set and hibr 0.99.364 it is
Blit's own telephone: outline when off, dashed while connecting, filled when on, with ring waves when ringing. **Phone Style** in the pane picks the
modern handset or the classic rotary phone (classic needs hibr 0.99.366 and Blit 0.2.45; without them it shows the modern one).)

**Click it** for a menu that depends on the state:

- *Off:* the profile it would use, and **Turn On**. With no connection set up it says so.
- *On:* **your number**, any ring with **Pick up…**, each connection with its path and speed and, under it, its safety phrase, **Dial…**, and **Turn Off**.
- Always: **Longwire Settings…**, which opens the pane.

### A ring interrupts

When someone rings you, a note appears and a dialog asks:

> 312-884-076 (Alice) rings. Pick up? It joins your network.

Picking up adds the caller to your network (your line): it stays a member, and reconnects by itself, until you evict it. The name is the caller's own claim.

Answer **Yes** to pick up, **No** to leave it. A moment after the call connects, a note tells the **safety phrase**: eight words, the same at both ends, which stay under
the call in the pane and in the telephone's menu. **Compare them with the caller on another channel.** A match is good evidence that nobody is in the middle
([SECURITY](SECURITY.md#the-safety-phrase-honestly)); if the words differ, hang up at once. The same dialog appears once per call, however long it rings (a call that nobody answers is refused after a minute).

A ring is only heard while the desktop is running. The node itself keeps running without it (`longwire on` starts it in the
background), but it is the desktop that rings.

## The Control Strip telephone

One glyph on the Control Strip, coloured by the theme: **dim** when off, the theme's *info* colour while waiting for a number, its *good* colour
(usually green) when on, and its *warning* colour (usually amber) when someone is ringing. Click it for the same menu as the menu bar. The bar and the strip are independent: show either, both, or neither
(Control Panel → Menu Bar Items, or the pane's **Longwire on the Menu Bar** switch for the bar).

## The Switchboard window

Only for someone who runs a switchboard. It is a live view of it: traffic **in and out** (rates and a sparkline each), how full it is (online, handshake load), the
registrations, rings, calls put through and ended since it started, the **bans**, the nodes with the names they gave, and the calls being set up right now (who is ringing whom, for a few seconds).

| Key | Menu | Does |
|---|---|---|
| `/` | Edit > Find, View > Search… | search the nodes by a part of a name, or of a number (dashes or not) |
| `o` | View > Online Only | only the nodes online |
| `b` | View > Bans | the banned keys instead of the nodes: time left, which ban in a row |
| `x` | Node > Lift Ban… | lift the ban chosen (asks first; the switchboard's owner only) |
| `c` | Node > Copy Number, Edit > Copy | the chosen node's number (among the bans, the whole key) |
| `s` | File > Switchboard Socket… | which switchboard to watch, when it is not the usual one |
| `t` | View > Tokens | the unspent tokens instead of the nodes ([ADR 0050](adr/0050-a-switchboards-tokens-are-made-in-its-window.md)); a service's are read when you press `r`, after a password (the dialog's title says whose, as polkit names the account) |
| `n` / `x` / `c` / `r` | Tokens > New Token, Remove Token…, Copy Token, Read Again | make one (a note says it), remove one (asks first), copy one to hand to a machine, read the file again |
| `T` | File > Tokens File… | which tokens file, when it is not the one the switchboard is found to use |

It shows no node's address or key ([ADR 0049](adr/0049-the-switchboard-window-shows-traffic-and-names-every-key.md); only the switchboard's own address and code in its heading, and a banned key's first digits among the bans), keeps no
history, and decides nothing; the switchboard's script does that. It shows a switchboard you started yourself, or one an
administrator runs as a service if you are in the group `longwire` (`please usermod -aG longwire YOURNAME`, then log in again).

Traffic and the counters come from the switchboard itself: its machine needs the longwire package 0.5.29 or newer, or they stay at zero. On a switchboard run as a service the group may look,
but only its own user or root lifts a ban: there **Lift Ban** says so, and `please longwire-switchboard bans clear KEY` on that machine does it. With no switchboard to watch, the window says where it
looked and how to start one or join the group.

## The answer policy, in one table

| Policy | A ring from… |
|---|---|
| **ask** (default) | anyone: wait for you |
| **known** | a number you have been connected to before is answered; anyone new waits for you |
| **auto** | anyone: answered. Only for a headless machine you have decided to trust |
| **never** | anyone: refused |

A machine **vouched for by a member of your line**, or holding the line operator's admit, is answered under every policy except
`never`; that is how a mesh of sites builds itself without a prompt on each.

## Good habits

- Always compare the **safety phrase** on a first call (the note, or under the call in the pane).
- After an update, check the pane has no **Out of step** rows (or run `longwire doctor`).
- Keep **When a call rings** on `ask` or `known`.
- Do not put the token in a chat or a screenshot. Once it has been used it does nothing; before that it is a key.
- Back up your identity once: `longwire key export` prints it as 33 words ([OPERATING](OPERATING.md)).

When something looks wrong, [TROUBLESHOOTING](TROUBLESHOOTING.md) lists the symptoms we know.
