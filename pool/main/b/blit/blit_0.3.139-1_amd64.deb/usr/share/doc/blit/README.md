# Blit

**A display server for text.** Blit drives your monitors directly through
the Linux kernel, with no X11 or Wayland, and fills them with fast,
good-looking terminals: truecolour, colour emoji, Nerd Font and icon
glyphs, Kitty and Sixel images, CRT effects. Everything is controlled
through an HTTP and WebSocket API.

Blit is the display under the [Hibr](https://github.com/osakka/hibr) text
desktop, but it does not need Hibr: any program can run in a Blit session.
Graphical programs -- Wayland ones (Firefox, GTK, Qt, Vulkan) and X11 ones
through Xwayland (Steam, xterm) -- open in Hibr windows through
`blit-compositor`, Blit's own Wayland compositor and X window manager,
which turns each window into a picture Blit shows and gives it Blit's
keyboard, pointer, input methods, Hibr's clipboard and drag and drop, at
a program scale per display for HiDPI
(ADR 0228, ADR 0229, ADR 0242; [programs in windows](docs/programs-in-windows.md)).

Current release: see [`packaging/VERSION`](packaging/VERSION).
Repository: [github.com/osakka/blit](https://github.com/osakka/blit).

## What it does

- **Monitors:** several at once, each at its own refresh rate, each split
  into a grid of up to 8×8 panes. Monitors can be plugged in while running.
- **Fast:** frames are composed on the GPU (OpenGL ES), and only what
  changed is redrawn. Choose the CPU in the Control Panel if you prefer;
  if the GPU can't be used, the CPU takes over by itself.
- **Terminals:** xterm-compatible with the Kitty keyboard protocol, mouse
  reporting, bracketed paste, synchronized output, hyperlinks and pointer
  lock for games. See the [terminal reference](docs/terminal.md).
- **Images:** the Kitty graphics protocol (including in-place edits) and
  Sixel. Hibr's wallpaper and video play through it.
- **Fonts:** Hack, JetBrains Mono NL, Fira Code, IBM Plex Mono, IBM 3270,
  Spleen (pixel-exact at each of its five masters' sizes and their
  multiples) and Terminus, any size from 8 to 64 pixels, changed live. Drop
  in your own monospaced font. Under every font sits one glyph stack: Nerd
  Fonts, colour emoji, Arabic shaped as words, Unifont, and Blit's own
  colour icons and drawn shapes (window chrome, controls, player glyphs,
  sliders, scroll bars). Programs can look a glyph up by set and name
  (`/v1/fonts/sets`) and ask what Blit draws with the Glyph Protocol.
- **Input:** keyboards, mice, touchpads and gamepads, found as they are
  plugged in, each configurable: repeat rate, remapping, pointer speed,
  natural scrolling, a choice of pointer looks, shake to find the pointer,
  and a busy pointer over a program that stops answering.
- **Keyboards and typing:** layouts from the system's xkb, listed and
  switched live, with dead keys and compose; Arabizi, typing Arabic in Latin
  letters, in terminals and programs alike.
- **Display modes:** pick a monitor's resolution and refresh; a new mode
  is tried and goes back by itself unless you keep it.
- **Effects:** rounded corners, scanlines, screen curvature, glow, RGB
  shift, an old CRT's hum bar, flicker, jitter, static noise, a phosphor
  tint, brightness and contrast, burn-in and a CRT mask, per pane, also
  on zoomed displays.
- **Sound and power:** sound cards' volume and mixer, backlight brightness.
- **Safe to run:** a bearer token on every request, an allow-list of
  commands, an unprivileged mode, updates only of a signed release, through
  a separate checked helper, and Ctrl+Alt+Backspace to stop it.

The full list, with when each arrived and how it has been proved, is in
[features](docs/features.md).

![Blit's text fonts, icons, file icons, Nerd glyphs and colour emoji, drawn by its own raster](docs/images/blit-fonts.png)

## Install

Blit is published in Hibr's apt repository (amd64; built on Debian 13, it
needs glibc 2.38 and HarfBuzz 6.0 or later, so Debian 13, Ubuntu 24.04 or
newer):

```sh
curl -fsSL https://osakka.github.io/hibr-apt/hibr.gpg \
  | sudo tee /usr/share/keyrings/hibr.gpg > /dev/null
echo "deb [signed-by=/usr/share/keyrings/hibr.gpg] https://osakka.github.io/hibr-apt stable main" \
  | sudo tee /etc/apt/sources.list.d/hibr.list
sudo apt update
sudo apt install blit hibr
```

The package installs and enables `blit.service` and generates an API token
in `/etc/blit/blit.env`; start it with `sudo systemctl start blit` (or
reboot), and it shows Hibr's login screen on the first monitor. `apt
upgrade` keeps it current: the new version takes over the next time the
login screen is showing with nobody signed in, or at `sudo systemctl
restart blit` (ADR 0205). For programs in windows,
`sudo apt install blit-compositor`; Hibr starts it with the desktop (Control
Panel > Windows > Programs in Windows), and a terminal opened after that
has `WAYLAND_DISPLAY`.

## First steps

```sh
man blit                                   # the server, its settings and files
blit --version                             # the installed Blit
TOKEN=$(sudo sed -n 's/^BLIT_AUTH_TOKEN=//p' /etc/blit/blit.env)
curl -s -H "Authorization: Bearer $TOKEN" http://127.0.0.1:8080/v1/version  # the running Blit
curl -s -H "Authorization: Bearer $TOKEN" http://127.0.0.1:8080/v1/displays
```

Start a shell as yourself in a session:

```sh
curl -s -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d "{\"command\":\"/bin/bash\",\"arguments\":[\"-l\"],\"user\":\"$USER\"}" \
  http://127.0.0.1:8080/v1/terminal-sessions
```

From the Hibr desktop, everything is in the Control Panel: the **Blit**
pane (fonts, panes per monitor, the compositor, the login screen, Restart
Blit, the Ctrl+Alt+Backspace switch), **Blit Mouse**, **Blit Keyboard** and
**Blit Effects**; **Blit Glyphs** shows Blit's fonts and glyph sets, read
only. The [pane guide](https://github.com/osakka/hibr-apps/blob/main/docs/blit.md)
explains each control, and
[Blit Glyphs](https://github.com/osakka/hibr-apps/blob/main/docs/blit-glyphs.md)
has its own.

## Configure

- **Startup values** go in `/etc/blit/blit.env`
  ([`blit.env(5)`](man/blit.env.5)), then `sudo systemctl restart blit`.
- **Everything else** is saved through the API in one settings document
  (`/v1/settings`) and replaces the startup value. The Control Panel uses
  the same API.
- **Restart** without a reboot: `sudo systemctl restart blit`, or Restart
  Blit in the Control Panel.
- **Recover** from a bad setting: stop the service and start once with
  `BLIT_SETTINGS=ignore` (see `man blit`).

## Documentation

| If you want to… | Read |
| --- | --- |
| See everything Blit can do | [Features](docs/features.md) |
| Run and configure it | `man blit`, `man blit.env`, [operator runbook](docs/api.md#operator-runbook-prove-the-server-before-touching-a-desktop) |
| Write a client | [API guide](docs/api.md), then the [OpenAPI document](openapi/blit-0.1.yaml) |
| Know which escape sequences work | [Terminal reference](docs/terminal.md) |
| Use glyphs and icons from an application | [Font and glyph reference](docs/font-reference.md) |
| Integrate a desktop | [Hibr integration](docs/integration-hibr.md) |
| Understand how it is built | [Architecture](docs/architecture.md), [decision records](docs/adr/README.md) |
| Contribute | [Development workflow](docs/development-workflow.md), [engineering constitution](docs/engineering-constitution.md) |
| Know what is next | [Roadmap](docs/roadmap.md) |
| Check what has been proved | [Verification ledger](docs/verification-status.md) |

All of it: [docs/README.md](docs/README.md).

## Build from source

Blit is C, compiled by TCC and linked by the system linker
(`tools/tcc-link.sh`, ADR 0238), on any current Linux distribution, from
the system's own development packages found through `pkg-config`: libdrm,
FreeType, HarfBuzz (≥ 6.0.0; its headers pinned in `vendor/harfbuzz`),
zlib, xkbcommon, the EGL/GLES/GBM headers (the libraries are loaded at run
time) and, for `blit-compositor`, wayland (server, scanner, protocols) and
xcb. Two pinned checkouts sit under `build/`: hibr-ime (the input methods,
built in; `packaging/IME_VERSION`) and, for a package, Hibr itself (the
adapter, `packaging/HIBR_VERSION`). The minimum versions, each
distribution's package names and the checkouts are in
[the toolchain](docs/toolchain.md); `tools/build-flags.sh --check` checks
them.

```sh
tools/build-tcc.sh                                      # build/blit/blit-server
tools/build-tcc.sh build/blit/blit-update-helper helper
tools/build-tcc.sh build/blit/blit-compositor compositor
tools/run-gates.sh all                                  # the test suites
BLIT_HIBR_ROOT=build/hibr-$(cat packaging/HIBR_VERSION) \
  packaging/build-deb.sh build/pkg                      # the .debs
```

Releases are built by `tools/release/build-release.sh OUTDIR` in the
Debian 13 build environment (`tools/build-env/`) and signed with the Blit
release key, whose public half every package carries
([`packaging/release-keys`](packaging/release-keys/README.md)); a host
installs an update through the API only when that signature verifies.

The package build makes two packages: `blit` and `blit-compositor` (programs
in windows, ADR 0228), which `blit` suggests. Suites and their
requirements are listed by `tools/run-gates.sh --help`; the [development workflow](docs/development-workflow.md) has the
release procedure.

## How it fits together

```text
 API clients, Hibr's Control Panel          keyboards, mice, touchpads
          │  HTTP + WebSocket                          │ evdev
          ▼                                            ▼
 ┌──────────────────────────── blit ─────────────────────────────┐
 │ settings · sessions · panes per monitor · input routing        │
 │ terminal emulator (PTY) · Kitty/Sixel images · glyph stack     │
 │ compositor: GPU (OpenGL ES) or CPU · effects                   │
 └────────────────────────────┬───────────────────────────────────┘
                              │ DRM/KMS
                              ▼
                          monitors
```

Blit owns the screens, input, terminals and the API. Hibr, or any other
program, runs inside sessions and owns its own desktop. Blit never edits
Hibr; it runs Hibr (`/usr/bin/hibr`) with its own small launchers in
`/usr/share/blit/hibr` and talks to it through the API and the frame
socket.

## License

Blit is free software under the GNU General Public License, version 3 or
later (`LICENSE`, `COPYING`). Bundled fonts and icon artwork keep their own
licences, recorded beside them under `assets/fonts/`; the Hibr adapter is
under Hibr's licence, the LGPL version 3 or later, and so are hibr-ime's
input methods, built into `blit-server` and `blit-compositor`.
