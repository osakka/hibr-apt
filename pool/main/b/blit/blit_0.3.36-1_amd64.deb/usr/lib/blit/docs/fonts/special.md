# Blit/Hibr special additions

[Developer guide](../font-reference.md) · [Canonical runtime catalogue](../../assets/fonts/icons/catalogue.json)

Generated from the same catalogue served by `GET /v1/fonts/icons`. These original intrinsic-colour icons are one cell each in every native font, from the glyph stack. Supplementary private-use assignments are a Blit contract, not standard Unicode or Nerd Fonts assignments.

| Semantic ID | Codepoint | JSON string | Signal level |
| --- | --- | --- | --- |
| `blit` | `U+100000` | `"\udbc0\udc00"` | — |
| `hibr-pen` | `U+100001` | `"\udbc0\udc01"` | — |
| `wifi-1` | `U+100002` | `"\udbc0\udc02"` | 1 |
| `wifi-2` | `U+100003` | `"\udbc0\udc03"` | 2 |
| `wifi-3` | `U+100004` | `"\udbc0\udc04"` | 3 |
| `wifi-4` | `U+100005` | `"\udbc0\udc05"` | 4 |
| `bluetooth` | `U+100006` | `"\udbc0\udc06"` | — |
| `battery-0` | `U+100009` | `"\udbc0\udc09"` | 0 |
| `battery-1` | `U+10000A` | `"\udbc0\udc0a"` | 1 |
| `battery-2` | `U+10000B` | `"\udbc0\udc0b"` | 2 |
| `battery-3` | `U+10000C` | `"\udbc0\udc0c"` | 3 |
| `battery-4` | `U+10000D` | `"\udbc0\udc0d"` | 4 |
| `battery-0-charging` | `U+10000E` | `"\udbc0\udc0e"` | 0 |
| `battery-1-charging` | `U+10000F` | `"\udbc0\udc0f"` | 1 |
| `battery-2-charging` | `U+100010` | `"\udbc0\udc10"` | 2 |
| `battery-3-charging` | `U+100011` | `"\udbc0\udc11"` | 3 |
| `battery-4-charging` | `U+100012` | `"\udbc0\udc12"` | 4 |
| `battery-ac` | `U+100013` | `"\udbc0\udc13"` | — |
| `volume-0` | `U+100014` | `"\udbc0\udc14"` | — |
| `volume-1` | `U+100015` | `"\udbc0\udc15"` | 1 |
| `volume-2` | `U+100016` | `"\udbc0\udc16"` | 2 |
| `volume-3` | `U+100017` | `"\udbc0\udc17"` | 3 |
| `hui-left` | `U+100018` | `"\udbc0\udc18"` | — |
| `hui-right` | `U+100019` | `"\udbc0\udc19"` | — |
| `power` | `U+10001A` | `"\udbc0\udc1a"` | — |
| `phone-off` | `U+10001B` | `"\udbc0\udc1b"` | — |
| `phone-wait` | `U+10001C` | `"\udbc0\udc1c"` | — |
| `phone-on` | `U+10001D` | `"\udbc0\udc1d"` | — |
| `phone-ring` | `U+10001E` | `"\udbc0\udc1e"` | — |
| `phone-classic-off` | `U+10001F` | `"\udbc0\udc1f"` | — |
| `phone-classic-wait` | `U+100020` | `"\udbc0\udc20"` | — |
| `phone-classic-on` | `U+100021` | `"\udbc0\udc21"` | — |
| `phone-classic-ring` | `U+100022` | `"\udbc0\udc22"` | — |
| `file-folder-classic-left` | `U+100033` | `"\udbc0\udc33"` | — |
| `file-folder-classic-right` | `U+100034` | `"\udbc0\udc34"` | — |
| `file-document-classic-left` | `U+100035` | `"\udbc0\udc35"` | — |
| `file-document-classic-right` | `U+100036` | `"\udbc0\udc36"` | — |
| `file-text-classic-left` | `U+100037` | `"\udbc0\udc37"` | — |
| `file-text-classic-right` | `U+100038` | `"\udbc0\udc38"` | — |
| `file-pdf-classic-left` | `U+100039` | `"\udbc0\udc39"` | — |
| `file-pdf-classic-right` | `U+10003A` | `"\udbc0\udc3a"` | — |
| `file-image-classic-left` | `U+10003B` | `"\udbc0\udc3b"` | — |
| `file-image-classic-right` | `U+10003C` | `"\udbc0\udc3c"` | — |
| `file-audio-classic-left` | `U+10003D` | `"\udbc0\udc3d"` | — |
| `file-audio-classic-right` | `U+10003E` | `"\udbc0\udc3e"` | — |
| `file-video-classic-left` | `U+10003F` | `"\udbc0\udc3f"` | — |
| `file-video-classic-right` | `U+100040` | `"\udbc0\udc40"` | — |
| `file-archive-classic-left` | `U+100041` | `"\udbc0\udc41"` | — |
| `file-archive-classic-right` | `U+100042` | `"\udbc0\udc42"` | — |
| `file-code-classic-left` | `U+100043` | `"\udbc0\udc43"` | — |
| `file-code-classic-right` | `U+100044` | `"\udbc0\udc44"` | — |
| `file-application-classic-left` | `U+100045` | `"\udbc0\udc45"` | — |
| `file-application-classic-right` | `U+100046` | `"\udbc0\udc46"` | — |
| `file-disk-classic-left` | `U+100047` | `"\udbc0\udc47"` | — |
| `file-disk-classic-right` | `U+100048` | `"\udbc0\udc48"` | — |
| `file-trash-classic-left` | `U+100049` | `"\udbc0\udc49"` | — |
| `file-trash-classic-right` | `U+10004A` | `"\udbc0\udc4a"` | — |
| `file-folder-blue-left` | `U+10004B` | `"\udbc0\udc4b"` | — |
| `file-folder-blue-right` | `U+10004C` | `"\udbc0\udc4c"` | — |
| `file-folder-green-left` | `U+100063` | `"\udbc0\udc63"` | — |
| `file-folder-green-right` | `U+100064` | `"\udbc0\udc64"` | — |
| `file-folder-amber-left` | `U+10007B` | `"\udbc0\udc7b"` | — |
| `file-folder-amber-right` | `U+10007C` | `"\udbc0\udc7c"` | — |
| `file-home-classic-left` | `U+100093` | `"\udbc0\udc93"` | — |
| `file-home-classic-right` | `U+100094` | `"\udbc0\udc94"` | — |
| `file-boxer-classic-left` | `U+10009B` | `"\udbc0\udc9b"` | — |
| `file-boxer-classic-right` | `U+10009C` | `"\udbc0\udc9c"` | — |
| `file-markdown-classic-left` | `U+1000A3` | `"\udbc0\udca3"` | — |
| `file-markdown-classic-right` | `U+1000A4` | `"\udbc0\udca4"` | — |
| `file-spreadsheet-classic-left` | `U+1000AB` | `"\udbc0\udcab"` | — |
| `file-spreadsheet-classic-right` | `U+1000AC` | `"\udbc0\udcac"` | — |
| `file-diagram-classic-left` | `U+1000B3` | `"\udbc0\udcb3"` | — |
| `file-diagram-classic-right` | `U+1000B4` | `"\udbc0\udcb4"` | — |
| `file-presentation-classic-left` | `U+1000BB` | `"\udbc0\udcbb"` | — |
| `file-presentation-classic-right` | `U+1000BC` | `"\udbc0\udcbc"` | — |
| `file-font-classic-left` | `U+1000C3` | `"\udbc0\udcc3"` | — |
| `file-font-classic-right` | `U+1000C4` | `"\udbc0\udcc4"` | — |
| `file-web-classic-left` | `U+1000CB` | `"\udbc0\udccb"` | — |
| `file-web-classic-right` | `U+1000CC` | `"\udbc0\udccc"` | — |
| `file-terminal-classic-left` | `U+1000D3` | `"\udbc0\udcd3"` | — |
| `file-terminal-classic-right` | `U+1000D4` | `"\udbc0\udcd4"` | — |
| `file-settings-classic-left` | `U+1000DB` | `"\udbc0\udcdb"` | — |
| `file-settings-classic-right` | `U+1000DC` | `"\udbc0\udcdc"` | — |
| `file-bundle-classic-left` | `U+1000E3` | `"\udbc0\udce3"` | — |
| `file-bundle-classic-right` | `U+1000E4` | `"\udbc0\udce4"` | — |
| `file-link-classic-left` | `U+1000EB` | `"\udbc0\udceb"` | — |
| `file-link-classic-right` | `U+1000EC` | `"\udbc0\udcec"` | — |
| `file-folder-git-classic-left` | `U+1000F3` | `"\udbc0\udcf3"` | — |
| `file-folder-git-classic-right` | `U+1000F4` | `"\udbc0\udcf4"` | — |
| `file-folder-git-blue-left` | `U+1000F5` | `"\udbc0\udcf5"` | — |
| `file-folder-git-blue-right` | `U+1000F6` | `"\udbc0\udcf6"` | — |
| `file-folder-git-green-left` | `U+1000F7` | `"\udbc0\udcf7"` | — |
| `file-folder-git-green-right` | `U+1000F8` | `"\udbc0\udcf8"` | — |
| `file-folder-git-amber-left` | `U+1000F9` | `"\udbc0\udcf9"` | — |
| `file-folder-git-amber-right` | `U+1000FA` | `"\udbc0\udcfa"` | — |
| `file-folder-config-classic-left` | `U+1000FB` | `"\udbc0\udcfb"` | — |
| `file-folder-config-classic-right` | `U+1000FC` | `"\udbc0\udcfc"` | — |
| `file-folder-config-blue-left` | `U+1000FD` | `"\udbc0\udcfd"` | — |
| `file-folder-config-blue-right` | `U+1000FE` | `"\udbc0\udcfe"` | — |
| `file-folder-config-green-left` | `U+1000FF` | `"\udbc0\udcff"` | — |
| `file-folder-config-green-right` | `U+100100` | `"\udbc0\udd00"` | — |
| `file-folder-config-amber-left` | `U+100101` | `"\udbc0\udd01"` | — |
| `file-folder-config-amber-right` | `U+100102` | `"\udbc0\udd02"` | — |
| `file-folder-local-classic-left` | `U+100103` | `"\udbc0\udd03"` | — |
| `file-folder-local-classic-right` | `U+100104` | `"\udbc0\udd04"` | — |
| `file-folder-local-blue-left` | `U+100105` | `"\udbc0\udd05"` | — |
| `file-folder-local-blue-right` | `U+100106` | `"\udbc0\udd06"` | — |
| `file-folder-local-green-left` | `U+100107` | `"\udbc0\udd07"` | — |
| `file-folder-local-green-right` | `U+100108` | `"\udbc0\udd08"` | — |
| `file-folder-local-amber-left` | `U+100109` | `"\udbc0\udd09"` | — |
| `file-folder-local-amber-right` | `U+10010A` | `"\udbc0\udd0a"` | — |
| `file-folder-system-classic-left` | `U+10010B` | `"\udbc0\udd0b"` | — |
| `file-folder-system-classic-right` | `U+10010C` | `"\udbc0\udd0c"` | — |
| `file-folder-system-blue-left` | `U+10010D` | `"\udbc0\udd0d"` | — |
| `file-folder-system-blue-right` | `U+10010E` | `"\udbc0\udd0e"` | — |
| `file-folder-system-green-left` | `U+10010F` | `"\udbc0\udd0f"` | — |
| `file-folder-system-green-right` | `U+100110` | `"\udbc0\udd10"` | — |
| `file-folder-system-amber-left` | `U+100111` | `"\udbc0\udd11"` | — |
| `file-folder-system-amber-right` | `U+100112` | `"\udbc0\udd12"` | — |
| `file-folder-desktop-classic-left` | `U+100113` | `"\udbc0\udd13"` | — |
| `file-folder-desktop-classic-right` | `U+100114` | `"\udbc0\udd14"` | — |
| `file-folder-desktop-blue-left` | `U+100115` | `"\udbc0\udd15"` | — |
| `file-folder-desktop-blue-right` | `U+100116` | `"\udbc0\udd16"` | — |
| `file-folder-desktop-green-left` | `U+100117` | `"\udbc0\udd17"` | — |
| `file-folder-desktop-green-right` | `U+100118` | `"\udbc0\udd18"` | — |
| `file-folder-desktop-amber-left` | `U+100119` | `"\udbc0\udd19"` | — |
| `file-folder-desktop-amber-right` | `U+10011A` | `"\udbc0\udd1a"` | — |
| `file-folder-downloads-classic-left` | `U+10011B` | `"\udbc0\udd1b"` | — |
| `file-folder-downloads-classic-right` | `U+10011C` | `"\udbc0\udd1c"` | — |
| `file-folder-downloads-blue-left` | `U+10011D` | `"\udbc0\udd1d"` | — |
| `file-folder-downloads-blue-right` | `U+10011E` | `"\udbc0\udd1e"` | — |
| `file-folder-downloads-green-left` | `U+10011F` | `"\udbc0\udd1f"` | — |
| `file-folder-downloads-green-right` | `U+100120` | `"\udbc0\udd20"` | — |
| `file-folder-downloads-amber-left` | `U+100121` | `"\udbc0\udd21"` | — |
| `file-folder-downloads-amber-right` | `U+100122` | `"\udbc0\udd22"` | — |
| `file-folder-documents-classic-left` | `U+100123` | `"\udbc0\udd23"` | — |
| `file-folder-documents-classic-right` | `U+100124` | `"\udbc0\udd24"` | — |
| `file-folder-documents-blue-left` | `U+100125` | `"\udbc0\udd25"` | — |
| `file-folder-documents-blue-right` | `U+100126` | `"\udbc0\udd26"` | — |
| `file-folder-documents-green-left` | `U+100127` | `"\udbc0\udd27"` | — |
| `file-folder-documents-green-right` | `U+100128` | `"\udbc0\udd28"` | — |
| `file-folder-documents-amber-left` | `U+100129` | `"\udbc0\udd29"` | — |
| `file-folder-documents-amber-right` | `U+10012A` | `"\udbc0\udd2a"` | — |
| `file-folder-music-classic-left` | `U+10012B` | `"\udbc0\udd2b"` | — |
| `file-folder-music-classic-right` | `U+10012C` | `"\udbc0\udd2c"` | — |
| `file-folder-music-blue-left` | `U+10012D` | `"\udbc0\udd2d"` | — |
| `file-folder-music-blue-right` | `U+10012E` | `"\udbc0\udd2e"` | — |
| `file-folder-music-green-left` | `U+10012F` | `"\udbc0\udd2f"` | — |
| `file-folder-music-green-right` | `U+100130` | `"\udbc0\udd30"` | — |
| `file-folder-music-amber-left` | `U+100131` | `"\udbc0\udd31"` | — |
| `file-folder-music-amber-right` | `U+100132` | `"\udbc0\udd32"` | — |
| `file-folder-pictures-classic-left` | `U+100133` | `"\udbc0\udd33"` | — |
| `file-folder-pictures-classic-right` | `U+100134` | `"\udbc0\udd34"` | — |
| `file-folder-pictures-blue-left` | `U+100135` | `"\udbc0\udd35"` | — |
| `file-folder-pictures-blue-right` | `U+100136` | `"\udbc0\udd36"` | — |
| `file-folder-pictures-green-left` | `U+100137` | `"\udbc0\udd37"` | — |
| `file-folder-pictures-green-right` | `U+100138` | `"\udbc0\udd38"` | — |
| `file-folder-pictures-amber-left` | `U+100139` | `"\udbc0\udd39"` | — |
| `file-folder-pictures-amber-right` | `U+10013A` | `"\udbc0\udd3a"` | — |
| `file-folder-videos-classic-left` | `U+10013B` | `"\udbc0\udd3b"` | — |
| `file-folder-videos-classic-right` | `U+10013C` | `"\udbc0\udd3c"` | — |
| `file-folder-videos-blue-left` | `U+10013D` | `"\udbc0\udd3d"` | — |
| `file-folder-videos-blue-right` | `U+10013E` | `"\udbc0\udd3e"` | — |
| `file-folder-videos-green-left` | `U+10013F` | `"\udbc0\udd3f"` | — |
| `file-folder-videos-green-right` | `U+100140` | `"\udbc0\udd40"` | — |
| `file-folder-videos-amber-left` | `U+100141` | `"\udbc0\udd41"` | — |
| `file-folder-videos-amber-right` | `U+100142` | `"\udbc0\udd42"` | — |
| `file-folder-apps-classic-left` | `U+100143` | `"\udbc0\udd43"` | — |
| `file-folder-apps-classic-right` | `U+100144` | `"\udbc0\udd44"` | — |
| `file-folder-apps-blue-left` | `U+100145` | `"\udbc0\udd45"` | — |
| `file-folder-apps-blue-right` | `U+100146` | `"\udbc0\udd46"` | — |
| `file-folder-apps-green-left` | `U+100147` | `"\udbc0\udd47"` | — |
| `file-folder-apps-green-right` | `U+100148` | `"\udbc0\udd48"` | — |
| `file-folder-apps-amber-left` | `U+100149` | `"\udbc0\udd49"` | — |
| `file-folder-apps-amber-right` | `U+10014A` | `"\udbc0\udd4a"` | — |
| `file-folder-games-classic-left` | `U+10014B` | `"\udbc0\udd4b"` | — |
| `file-folder-games-classic-right` | `U+10014C` | `"\udbc0\udd4c"` | — |
| `file-folder-games-blue-left` | `U+10014D` | `"\udbc0\udd4d"` | — |
| `file-folder-games-blue-right` | `U+10014E` | `"\udbc0\udd4e"` | — |
| `file-folder-games-green-left` | `U+10014F` | `"\udbc0\udd4f"` | — |
| `file-folder-games-green-right` | `U+100150` | `"\udbc0\udd50"` | — |
| `file-folder-games-amber-left` | `U+100151` | `"\udbc0\udd51"` | — |
| `file-folder-games-amber-right` | `U+100152` | `"\udbc0\udd52"` | — |
| `file-rc-classic-left` | `U+100153` | `"\udbc0\udd53"` | — |
| `file-rc-classic-right` | `U+100154` | `"\udbc0\udd54"` | — |
| `file-history-classic-left` | `U+10015B` | `"\udbc0\udd5b"` | — |
| `file-history-classic-right` | `U+10015C` | `"\udbc0\udd5c"` | — |
| `file-service-classic-left` | `U+100163` | `"\udbc0\udd63"` | — |
| `file-service-classic-right` | `U+100164` | `"\udbc0\udd64"` | — |
| `file-key-classic-left` | `U+10016B` | `"\udbc0\udd6b"` | — |
| `file-key-classic-right` | `U+10016C` | `"\udbc0\udd6c"` | — |
| `file-network-classic-left` | `U+100173` | `"\udbc0\udd73"` | — |
| `file-network-classic-right` | `U+100174` | `"\udbc0\udd74"` | — |
| `file-cron-classic-left` | `U+10017B` | `"\udbc0\udd7b"` | — |
| `file-cron-classic-right` | `U+10017C` | `"\udbc0\udd7c"` | — |
| `file-readme-classic-left` | `U+100183` | `"\udbc0\udd83"` | — |
| `file-readme-classic-right` | `U+100184` | `"\udbc0\udd84"` | — |
| `file-license-classic-left` | `U+10018B` | `"\udbc0\udd8b"` | — |
| `file-license-classic-right` | `U+10018C` | `"\udbc0\udd8c"` | — |
| `file-log-classic-left` | `U+100193` | `"\udbc0\udd93"` | — |
| `file-log-classic-right` | `U+100194` | `"\udbc0\udd94"` | — |
| `file-kernel-classic-left` | `U+10019B` | `"\udbc0\udd9b"` | — |
| `file-kernel-classic-right` | `U+10019C` | `"\udbc0\udd9c"` | — |
| `file-boot-classic-left` | `U+1001A3` | `"\udbc0\udda3"` | — |
| `file-boot-classic-right` | `U+1001A4` | `"\udbc0\udda4"` | — |
| `file-c-classic-left` | `U+1001AB` | `"\udbc0\uddab"` | — |
| `file-c-classic-right` | `U+1001AC` | `"\udbc0\uddac"` | — |
| `file-asm-classic-left` | `U+1001B3` | `"\udbc0\uddb3"` | — |
| `file-asm-classic-right` | `U+1001B4` | `"\udbc0\uddb4"` | — |
| `file-makefile-classic-left` | `U+1001BB` | `"\udbc0\uddbb"` | — |
| `file-makefile-classic-right` | `U+1001BC` | `"\udbc0\uddbc"` | — |
| `file-patch-classic-left` | `U+1001C3` | `"\udbc0\uddc3"` | — |
| `file-patch-classic-right` | `U+1001C4` | `"\udbc0\uddc4"` | — |
| `file-json-classic-left` | `U+1001CB` | `"\udbc0\uddcb"` | — |
| `file-json-classic-right` | `U+1001CC` | `"\udbc0\uddcc"` | — |
| `file-vector-classic-left` | `U+1001D3` | `"\udbc0\uddd3"` | — |
| `file-vector-classic-right` | `U+1001D4` | `"\udbc0\uddd4"` | — |
| `file-rom-classic-left` | `U+1001DB` | `"\udbc0\udddb"` | — |
| `file-rom-classic-right` | `U+1001DC` | `"\udbc0\udddc"` | — |
| `file-ebook-classic-left` | `U+1001E3` | `"\udbc0\udde3"` | — |
| `file-ebook-classic-right` | `U+1001E4` | `"\udbc0\udde4"` | — |
| `file-exe-classic-left` | `U+1001EB` | `"\udbc0\uddeb"` | — |
| `file-exe-classic-right` | `U+1001EC` | `"\udbc0\uddec"` | — |
| `file-disc-classic-left` | `U+1001F3` | `"\udbc0\uddf3"` | — |
| `file-disc-classic-right` | `U+1001F4` | `"\udbc0\uddf4"` | — |
| `file-package-classic-left` | `U+1001FB` | `"\udbc0\uddfb"` | — |
| `file-package-classic-right` | `U+1001FC` | `"\udbc0\uddfc"` | — |
| `file-library-classic-left` | `U+100203` | `"\udbc0\ude03"` | — |
| `file-library-classic-right` | `U+100204` | `"\udbc0\ude04"` | — |
| `file-lock-classic-left` | `U+10020B` | `"\udbc0\ude0b"` | — |
| `file-lock-classic-right` | `U+10020C` | `"\udbc0\ude0c"` | — |
| `file-database-classic-left` | `U+100213` | `"\udbc0\ude13"` | — |
| `file-database-classic-right` | `U+100214` | `"\udbc0\ude14"` | — |
| `file-usb-classic-left` | `U+10021B` | `"\udbc0\ude1b"` | — |
| `file-usb-classic-right` | `U+10021C` | `"\udbc0\ude1c"` | — |
| `file-share-classic-left` | `U+100223` | `"\udbc0\ude23"` | — |
| `file-share-classic-right` | `U+100224` | `"\udbc0\ude24"` | — |
| `file-share-blue-left` | `U+100225` | `"\udbc0\ude25"` | — |
| `file-share-blue-right` | `U+100226` | `"\udbc0\ude26"` | — |
| `file-share-green-left` | `U+100227` | `"\udbc0\ude27"` | — |
| `file-share-green-right` | `U+100228` | `"\udbc0\ude28"` | — |
| `file-share-amber-left` | `U+100229` | `"\udbc0\ude29"` | — |
| `file-share-amber-right` | `U+10022A` | `"\udbc0\ude2a"` | — |
| `file-image-jpg-left` | `U+10022B` | `"\udbc0\ude2b"` | — |
| `file-image-jpg-right` | `U+10022C` | `"\udbc0\ude2c"` | — |
| `file-image-png-left` | `U+10022D` | `"\udbc0\ude2d"` | — |
| `file-image-png-right` | `U+10022E` | `"\udbc0\ude2e"` | — |
| `file-image-gif-left` | `U+10022F` | `"\udbc0\ude2f"` | — |
| `file-image-gif-right` | `U+100230` | `"\udbc0\ude30"` | — |

## Themed text additions

Text aliases use the terminal foreground, not intrinsic colour.

| Semantic ID | Codepoint | JSON string |
| --- | --- | --- |
| `hibr-pen` (themed alias) | `U+270E` | `"\u270e"` |
| `berkanan` | `U+16D2` | `"\u16d2"` |
| `wired` | `U+21CC` | `"\u21cc"` |

Berkanan preserves its runic meaning; it is not the Bluetooth icon. Existing standard/Nerd assignments are not repurposed.

## Cell geometry

Drawn by the shared raster at every cell size, edge to edge, so neighbouring cells join without a seam: no outline font carries them. One cell each, in every font. Those marked colour (the Slate glyph sets, ADR 0210) carry their own colours; the rest are drawn in the terminal foreground.

| Semantic ID | Codepoint | JSON string | Colour | Shape |
| --- | --- | --- | --- | --- |
| `bar-corner-left` | `U+100007` | `"\udbc0\udc07"` | foreground | cell filled except a quarter-circle cut at its top-left, radius the cell's shorter side |
| `bar-corner-right` | `U+100008` | `"\udbc0\udc08"` | foreground | cell filled except a quarter-circle cut at its top-right, radius the cell's shorter side |
| `chalk-stripe` | `U+100231` | `"\udbc0\ude31"` | foreground | Chalk set: title bar: frame line, six stripes, rule |
| `chalk-stripe-first` | `U+100232` | `"\udbc0\ude32"` | foreground | Chalk set: title bar next to the left frame: stripes start 2 px in |
| `chalk-stripe-last` | `U+100233` | `"\udbc0\ude33"` | foreground | Chalk set: title bar next to the right frame: stripes stop 2 px short |
| `chalk-stripe-before-title` | `U+100234` | `"\udbc0\ude34"` | foreground | Chalk set: title bar before the title: stripes stop 5 px short |
| `chalk-stripe-after-title` | `U+100235` | `"\udbc0\ude35"` | foreground | Chalk set: title bar after the title: stripes start 5 px in |
| `chalk-title` | `U+100236` | `"\udbc0\ude36"` | foreground | Chalk set: title bar without stripes: under the title, and the inactive bar |
| `chalk-stripe-to-box` | `U+100237` | `"\udbc0\ude37"` | foreground | Chalk set: title bar before a box: stripes stop 2 px short |
| `chalk-stripe-from-box` | `U+100238` | `"\udbc0\ude38"` | foreground | Chalk set: title bar after a box: stripes start 2 px in |
| `chalk-stripe-between` | `U+100239` | `"\udbc0\ude39"` | foreground | Chalk set: title bar between two boxes: 2 px clear each side |
| `chalk-close` | `U+10023A` | `"\udbc0\ude3a"` | foreground | Chalk set: title bar with the close box: an 11x11 square, the cell's width |
| `chalk-shade` | `U+10023B` | `"\udbc0\ude3b"` | foreground | Chalk set: title bar with the window-shade box: the square with a bar across |
| `chalk-zoom` | `U+10023C` | `"\udbc0\ude3c"` | foreground | Chalk set: title bar with the zoom box: the square with a smaller square in its corner |
| `chalk-frame-left` | `U+10023D` | `"\udbc0\ude3d"` | foreground | Chalk set: window frame, left: a line against the content |
| `chalk-frame-right-top` | `U+10023E` | `"\udbc0\ude3e"` | foreground | Chalk set: window frame, right, beside the title bar: line, shadow from 2 px down |
| `chalk-frame-right` | `U+10023F` | `"\udbc0\ude3f"` | foreground | Chalk set: window frame, right: line and its 2 px shadow |
| `chalk-frame-bottom-left` | `U+100240` | `"\udbc0\ude40"` | foreground | Chalk set: window frame, bottom-left corner |
| `chalk-frame-bottom-first` | `U+100241` | `"\udbc0\ude41"` | foreground | Chalk set: window frame, first bottom cell: line, shadow from 2 px in |
| `chalk-frame-bottom` | `U+100242` | `"\udbc0\ude42"` | foreground | Chalk set: window frame, bottom: line and its 2 px shadow |
| `chalk-frame-bottom-right` | `U+100243` | `"\udbc0\ude43"` | foreground | Chalk set: window frame, bottom-right corner and shadow |
| `chalk-frame-top-left` | `U+100244` | `"\udbc0\ude44"` | foreground | Chalk set: frame without a title bar, top-left corner |
| `chalk-frame-top` | `U+100245` | `"\udbc0\ude45"` | foreground | Chalk set: frame without a title bar, top: a line against the content |
| `chalk-frame-top-right` | `U+100246` | `"\udbc0\ude46"` | foreground | Chalk set: frame without a title bar, top-right corner |
| `chalk-note-close` | `U+100247` | `"\udbc0\ude47"` | foreground | Chalk set: a notification's close box alone, transparent around it |
| `chalk-dialog-top-left` | `U+100248` | `"\udbc0\ude48"` | foreground | Chalk set: dialog double border, top-left corner |
| `chalk-dialog-top` | `U+100249` | `"\udbc0\ude49"` | foreground | Chalk set: dialog double border, top |
| `chalk-dialog-top-right` | `U+10024A` | `"\udbc0\ude4a"` | foreground | Chalk set: dialog double border, top-right corner, shadow from 2 px down |
| `chalk-dialog-left` | `U+10024B` | `"\udbc0\ude4b"` | foreground | Chalk set: dialog double border, left |
| `chalk-dialog-right` | `U+10024C` | `"\udbc0\ude4c"` | foreground | Chalk set: dialog double border, right, with its shadow |
| `chalk-dialog-bottom-left` | `U+10024D` | `"\udbc0\ude4d"` | foreground | Chalk set: dialog double border, bottom-left corner, shadow from 2 px in |
| `chalk-dialog-bottom` | `U+10024E` | `"\udbc0\ude4e"` | foreground | Chalk set: dialog double border, bottom, with its shadow |
| `chalk-dialog-bottom-right` | `U+10024F` | `"\udbc0\ude4f"` | foreground | Chalk set: dialog double border, bottom-right corner and shadow |
| `chalk-button-left` | `U+100250` | `"\udbc0\ude50"` | foreground | Chalk set: button, left end: rounded 1 px outline; SGR 51 draws the label's lines |
| `chalk-button-right` | `U+100251` | `"\udbc0\ude51"` | foreground | Chalk set: button, right end |
| `chalk-default-button-left` | `U+100252` | `"\udbc0\ude52"` | foreground | Chalk set: default button, left end: rounded 3 px ring; SGR 51:3 draws the label's |
| `chalk-default-button-right` | `U+100253` | `"\udbc0\ude53"` | foreground | Chalk set: default button, right end |
| `slate-light-stripe` | `U+100254` | `"\udbc0\ude54"` | colour | Slate light set: title bar: frame line, six stripes, rule |
| `slate-light-stripe-first` | `U+100255` | `"\udbc0\ude55"` | colour | Slate light set: title bar next to the left frame: stripes start 2 px in |
| `slate-light-stripe-last` | `U+100256` | `"\udbc0\ude56"` | colour | Slate light set: title bar next to the right frame: stripes stop 2 px short |
| `slate-light-stripe-before-title` | `U+100257` | `"\udbc0\ude57"` | colour | Slate light set: title bar before the title: stripes stop 5 px short |
| `slate-light-stripe-after-title` | `U+100258` | `"\udbc0\ude58"` | colour | Slate light set: title bar after the title: stripes start 5 px in |
| `slate-light-title` | `U+100259` | `"\udbc0\ude59"` | colour | Slate light set: title bar without stripes: under the title, and the inactive bar |
| `slate-light-stripe-to-box` | `U+10025A` | `"\udbc0\ude5a"` | colour | Slate light set: title bar before a box: stripes stop 2 px short |
| `slate-light-stripe-from-box` | `U+10025B` | `"\udbc0\ude5b"` | colour | Slate light set: title bar after a box: stripes start 2 px in |
| `slate-light-stripe-between` | `U+10025C` | `"\udbc0\ude5c"` | colour | Slate light set: title bar between two boxes: 2 px clear each side |
| `slate-light-close` | `U+10025D` | `"\udbc0\ude5d"` | colour | Slate light set: title bar with the close box: an 11x11 square, the cell's width |
| `slate-light-shade` | `U+10025E` | `"\udbc0\ude5e"` | colour | Slate light set: title bar with the window-shade box: the square with a bar across |
| `slate-light-zoom` | `U+10025F` | `"\udbc0\ude5f"` | colour | Slate light set: title bar with the zoom box: the square with a smaller square in its corner |
| `slate-light-frame-left` | `U+100260` | `"\udbc0\ude60"` | colour | Slate light set: window frame, left: a line against the content |
| `slate-light-frame-right-top` | `U+100261` | `"\udbc0\ude61"` | colour | Slate light set: window frame, right, beside the title bar: line, shadow from 2 px down |
| `slate-light-frame-right` | `U+100262` | `"\udbc0\ude62"` | colour | Slate light set: window frame, right: line and its 2 px shadow |
| `slate-light-frame-bottom-left` | `U+100263` | `"\udbc0\ude63"` | colour | Slate light set: window frame, bottom-left corner |
| `slate-light-frame-bottom-first` | `U+100264` | `"\udbc0\ude64"` | colour | Slate light set: window frame, first bottom cell: line, shadow from 2 px in |
| `slate-light-frame-bottom` | `U+100265` | `"\udbc0\ude65"` | colour | Slate light set: window frame, bottom: line and its 2 px shadow |
| `slate-light-frame-bottom-right` | `U+100266` | `"\udbc0\ude66"` | colour | Slate light set: window frame, bottom-right corner and shadow |
| `slate-light-frame-top-left` | `U+100267` | `"\udbc0\ude67"` | colour | Slate light set: frame without a title bar, top-left corner |
| `slate-light-frame-top` | `U+100268` | `"\udbc0\ude68"` | colour | Slate light set: frame without a title bar, top: a line against the content |
| `slate-light-frame-top-right` | `U+100269` | `"\udbc0\ude69"` | colour | Slate light set: frame without a title bar, top-right corner |
| `slate-light-note-close` | `U+10026A` | `"\udbc0\ude6a"` | colour | Slate light set: a notification's close box alone, transparent around it |
| `slate-light-dialog-top-left` | `U+10026B` | `"\udbc0\ude6b"` | colour | Slate light set: dialog double border, top-left corner |
| `slate-light-dialog-top` | `U+10026C` | `"\udbc0\ude6c"` | colour | Slate light set: dialog double border, top |
| `slate-light-dialog-top-right` | `U+10026D` | `"\udbc0\ude6d"` | colour | Slate light set: dialog double border, top-right corner, shadow from 2 px down |
| `slate-light-dialog-left` | `U+10026E` | `"\udbc0\ude6e"` | colour | Slate light set: dialog double border, left |
| `slate-light-dialog-right` | `U+10026F` | `"\udbc0\ude6f"` | colour | Slate light set: dialog double border, right, with its shadow |
| `slate-light-dialog-bottom-left` | `U+100270` | `"\udbc0\ude70"` | colour | Slate light set: dialog double border, bottom-left corner, shadow from 2 px in |
| `slate-light-dialog-bottom` | `U+100271` | `"\udbc0\ude71"` | colour | Slate light set: dialog double border, bottom, with its shadow |
| `slate-light-dialog-bottom-right` | `U+100272` | `"\udbc0\ude72"` | colour | Slate light set: dialog double border, bottom-right corner and shadow |
| `slate-light-button-left` | `U+100273` | `"\udbc0\ude73"` | colour | Slate light set: button, left end: rounded 1 px outline; SGR 51 draws the label's lines |
| `slate-light-button-right` | `U+100274` | `"\udbc0\ude74"` | colour | Slate light set: button, right end |
| `slate-light-default-button-left` | `U+100275` | `"\udbc0\ude75"` | colour | Slate light set: default button, left end: rounded 3 px ring; SGR 51:3 draws the label's |
| `slate-light-default-button-right` | `U+100276` | `"\udbc0\ude76"` | colour | Slate light set: default button, right end |
| `slate-dark-stripe` | `U+100277` | `"\udbc0\ude77"` | colour | Slate dark set: title bar: frame line, six stripes, rule |
| `slate-dark-stripe-first` | `U+100278` | `"\udbc0\ude78"` | colour | Slate dark set: title bar next to the left frame: stripes start 2 px in |
| `slate-dark-stripe-last` | `U+100279` | `"\udbc0\ude79"` | colour | Slate dark set: title bar next to the right frame: stripes stop 2 px short |
| `slate-dark-stripe-before-title` | `U+10027A` | `"\udbc0\ude7a"` | colour | Slate dark set: title bar before the title: stripes stop 5 px short |
| `slate-dark-stripe-after-title` | `U+10027B` | `"\udbc0\ude7b"` | colour | Slate dark set: title bar after the title: stripes start 5 px in |
| `slate-dark-title` | `U+10027C` | `"\udbc0\ude7c"` | colour | Slate dark set: title bar without stripes: under the title, and the inactive bar |
| `slate-dark-stripe-to-box` | `U+10027D` | `"\udbc0\ude7d"` | colour | Slate dark set: title bar before a box: stripes stop 2 px short |
| `slate-dark-stripe-from-box` | `U+10027E` | `"\udbc0\ude7e"` | colour | Slate dark set: title bar after a box: stripes start 2 px in |
| `slate-dark-stripe-between` | `U+10027F` | `"\udbc0\ude7f"` | colour | Slate dark set: title bar between two boxes: 2 px clear each side |
| `slate-dark-close` | `U+100280` | `"\udbc0\ude80"` | colour | Slate dark set: title bar with the close box: an 11x11 square, the cell's width |
| `slate-dark-shade` | `U+100281` | `"\udbc0\ude81"` | colour | Slate dark set: title bar with the window-shade box: the square with a bar across |
| `slate-dark-zoom` | `U+100282` | `"\udbc0\ude82"` | colour | Slate dark set: title bar with the zoom box: the square with a smaller square in its corner |
| `slate-dark-frame-left` | `U+100283` | `"\udbc0\ude83"` | colour | Slate dark set: window frame, left: a line against the content |
| `slate-dark-frame-right-top` | `U+100284` | `"\udbc0\ude84"` | colour | Slate dark set: window frame, right, beside the title bar: line, shadow from 2 px down |
| `slate-dark-frame-right` | `U+100285` | `"\udbc0\ude85"` | colour | Slate dark set: window frame, right: line and its 2 px shadow |
| `slate-dark-frame-bottom-left` | `U+100286` | `"\udbc0\ude86"` | colour | Slate dark set: window frame, bottom-left corner |
| `slate-dark-frame-bottom-first` | `U+100287` | `"\udbc0\ude87"` | colour | Slate dark set: window frame, first bottom cell: line, shadow from 2 px in |
| `slate-dark-frame-bottom` | `U+100288` | `"\udbc0\ude88"` | colour | Slate dark set: window frame, bottom: line and its 2 px shadow |
| `slate-dark-frame-bottom-right` | `U+100289` | `"\udbc0\ude89"` | colour | Slate dark set: window frame, bottom-right corner and shadow |
| `slate-dark-frame-top-left` | `U+10028A` | `"\udbc0\ude8a"` | colour | Slate dark set: frame without a title bar, top-left corner |
| `slate-dark-frame-top` | `U+10028B` | `"\udbc0\ude8b"` | colour | Slate dark set: frame without a title bar, top: a line against the content |
| `slate-dark-frame-top-right` | `U+10028C` | `"\udbc0\ude8c"` | colour | Slate dark set: frame without a title bar, top-right corner |
| `slate-dark-note-close` | `U+10028D` | `"\udbc0\ude8d"` | colour | Slate dark set: a notification's close box alone, transparent around it |
| `slate-dark-dialog-top-left` | `U+10028E` | `"\udbc0\ude8e"` | colour | Slate dark set: dialog double border, top-left corner |
| `slate-dark-dialog-top` | `U+10028F` | `"\udbc0\ude8f"` | colour | Slate dark set: dialog double border, top |
| `slate-dark-dialog-top-right` | `U+100290` | `"\udbc0\ude90"` | colour | Slate dark set: dialog double border, top-right corner, shadow from 2 px down |
| `slate-dark-dialog-left` | `U+100291` | `"\udbc0\ude91"` | colour | Slate dark set: dialog double border, left |
| `slate-dark-dialog-right` | `U+100292` | `"\udbc0\ude92"` | colour | Slate dark set: dialog double border, right, with its shadow |
| `slate-dark-dialog-bottom-left` | `U+100293` | `"\udbc0\ude93"` | colour | Slate dark set: dialog double border, bottom-left corner, shadow from 2 px in |
| `slate-dark-dialog-bottom` | `U+100294` | `"\udbc0\ude94"` | colour | Slate dark set: dialog double border, bottom, with its shadow |
| `slate-dark-dialog-bottom-right` | `U+100295` | `"\udbc0\ude95"` | colour | Slate dark set: dialog double border, bottom-right corner and shadow |
| `slate-dark-button-left` | `U+100296` | `"\udbc0\ude96"` | colour | Slate dark set: button, left end: rounded 1 px outline; SGR 51 draws the label's lines |
| `slate-dark-button-right` | `U+100297` | `"\udbc0\ude97"` | colour | Slate dark set: button, right end |
| `slate-dark-default-button-left` | `U+100298` | `"\udbc0\ude98"` | colour | Slate dark set: default button, left end: rounded 3 px ring; SGR 51:3 draws the label's |
| `slate-dark-default-button-right` | `U+100299` | `"\udbc0\ude99"` | colour | Slate dark set: default button, right end |

[Production-raster specimen: text fonts, Blit icons, file icons, Nerd glyphs and emoji](../images/blit-fonts.png).
