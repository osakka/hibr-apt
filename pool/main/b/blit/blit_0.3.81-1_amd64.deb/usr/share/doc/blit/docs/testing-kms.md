# Direct KMS boundary

Native DRM/KMS is Blit's only presentation backend (ADR 0184). It lives in
`src/blit_kms.c`; frames are composed by the GLES compositor (ADR 0181), the
default, or by the CPU compositor (`BLIT_KMS_COMPOSITOR=cpu`). Build the
server with the TCC toolchain:

```sh
tools/build-tcc.sh build/blit/blit-server
```

On a DRM-capable guest VT, run it. A network bind needs a token; without
`BLIT_AUTH_TOKEN` Blit listens on 127.0.0.1 only:

```sh
BLIT_AUTH_TOKEN=change-me BLIT_BIND_ADDRESS=0.0.0.0 \
  ./build/blit/blit-server 8080
```

It must report connected outputs or say why it has none. If KMS cannot be
opened, Blit still serves its API with no outputs and reports the reason as
the presentation error in `/v1/diagnostics`. A host without `/dev/dri/card0`
(or the device named by `BLIT_DRM_DEVICE`) is not a valid presentation test.
The environment variables used here are listed in [blit(8)](../man/blit.8).

The diagnostic probe enumerates cards, connectors, and modes independently of
the server and Hibr, without changing display state:

```sh
mkdir -p build/blit
tcc -std=c99 $(tools/build-flags.sh --cflags drm) \
  tools/probes/drm_kms.c \
  $(tools/build-flags.sh --libs drm) \
  -o build/blit/drm-kms-probe
sudo ./build/blit/drm-kms-probe
```

The production KMS backend uses the same inventory boundary with explicit
connector/CRTC ownership, scanout buffers (dumb buffers for the CPU
compositor, GBM for GLES), and page-flip completion.
The probe remains read-only; it is not a second presentation implementation.
If a driver does not deliver a page-flip completion within the bounded wait,
Blit records the connector and switches that output to a direct modeset path
instead of freezing the entire gateway.

The API reports the backend as `drm-kms` and `presentation_sync:
drm-page-flip`. If the explicit `BLIT_KMS_ASYNC_PAGEFLIP` diagnostic/test
policy is enabled, it reports `drm-page-flip-async`; that mode may tear and is
not the production default.

The page-flip wait is bounded to 100 ms per output by default. This prevents a
lost or delayed DRM event from turning one logical frame into a multi-second
stall; a timeout is logged with the connector and that output moves to the
explicit modeset fallback. `BLIT_KMS_FLIP_TIMEOUT_MS` may set a diagnostic
budget from 1 to 1000 ms.

The DRM file descriptor is part of the gateway's main `select()` set. A
pending page flip is serviced there; while one connector owns its back buffer,
Blit skips only that connector and continues servicing HTTP, PTY, input, and
the other displays. This prevents a slow monitor from blocking the gateway.
The descriptor is opened nonblocking as well, so a driver or virtual display
cannot turn page-flip submission itself into a process-wide blocking call.
Readiness, per-output pending state, and the bounded flip timeout remain the
only waiting mechanisms.

Connector hotplug is watched off the frame loop (ADR 0130): a monitor thread
wakes on DRM uevents, or every five seconds, and reads a connector snapshot
that the main loop then applies. A disconnected connector is marked `failed`
in the display API and is removed from the render work for that output;
surviving outputs continue presenting and servicing the gateway. A page-flip
timeout is reported as `recovering` while one bounded modeset restores the
output; it is not permanently marked failed unless the connector is actually
lost or the recovery modeset fails. The VKMS fault fixture sets connector
status to the DRM `disconnected` value and verifies this per-output behavior.

The recovery regression fixture adds `blit.kms_recovery=1` and
`blit.kms_timeout_ms=1` to the guest command line. It requires both
`entering modeset recovery` and `modeset recovery complete` in the server log,
then requires the ordinary two-output capture gate to pass.

After the first complete composition, direct KMS preserves each scanout back
buffer and uses the canonical surface revision/damage rectangle to repaint only
changed cells. A complete redraw is retained for the first frame and
output/view set changes. Pointer movement preserves the displayed front buffer,
repaints the old and new pointer rectangles at cell granularity, and does not
redraw the entire terminal; this prevents mouse motion from monopolizing a
slow DRM driver or leaving pointer trails.

Opaque API RGBA frames use a packed 32-bit channel conversion in the native-size
direct-KMS path. Translucent API, Kitty, and sixel images retain the alpha-aware
path; opacity is never assumed for compatibility images.

When all cells in an affected view have the same effective background color,
the renderer fills the view rectangle once before drawing glyphs. Mixed
backgrounds are coalesced into horizontal runs, and inverse cells continue
through the same effective-color path so color and attribute semantics remain
exact. Native-size PSF rows are cached in the shared font object and the KMS
compositor uses a native-size bitmap path; scaled cells retain the general
scaler. These are bounded hot-path optimizations, not a second compositor.
API-owned graphic frames use the same principle: an unscaled canvas avoids
the general source-coordinate scaler while clipped or resized frames retain
the existing alpha/compositing path. The direct-KMS API pixel gate exercises
this native-size path.

Surface damage is consumed only after the corresponding view is submitted.
If a connector is still waiting for its page-flip event, its damage remains
pending and is retried after that event; a one-cell API mutation therefore
cannot accumulate into a historical full-row redraw.

Expected output identifies every usable card and connected connector, then
lists every connector mode and the active mode. Blit selects the highest
refresh mode that preserves the connector's preferred/native geometry; it does
not silently trade away the display's native geometry for a lower-resolution
mode with a higher refresh. A missing card, connector, or mode is a structured
capability result, not something to paper over.

## Logical width and pointer input

With the default 8×16 `Blit-Terminus16.psf` font, direct KMS gives 128
columns on a 1024-pixel output. To request approximately 200 columns, start
the server with:

```sh
BLIT_KMS_CELL_WIDTH=5 blit 8080
```

The override is authoritative: pane discovery, rendering, cursor placement,
and pointer hit-testing all use the same metric. The default remains the font's
native width. The Hibr adapter receives targeted pointer motion and button
press/release events over the same stream as keyboard input; its session ID is
normalized to Blit's `session-N` stream identity before filtering.

`BLIT_FONT_SCALE` scales the loaded glyph bitmap into the complete logical
cell in both axes; it does not merely enlarge the cell while leaving an
unscaled glyph in its upper-left corner.

With no saved font and no `BLIT_PSF_FONT`, the server starts on the bundled
`Blit-Terminus16.psf`; it logs the selected font dimensions and glyph count.
The text fonts, pixel fonts and the glyph stack beneath them are described in
the [font reference](font-reference.md). Presentation is a hard refresh
invariant: each active output must schedule independently at the maximum
refresh supported by its selected mode, and no configured render interval may
intentionally under-run that cadence. Deadlines use a monotonic microsecond
clock and preserve each output's cadence phase after late work; they are not
reset from the completion time of the previous frame.
`BLIT_RENDER_INTERVAL_MS` remains a diagnostic override for measuring a
hardware trade-off; the scheduler clamps it so it cannot lower an output below
its mode refresh. Set `BLIT_KMS_TRACE_TIMING=1` to log measured KMS frame
durations. The KMS path does not submit a page flip when the output has no
changed surface, cursor, pointer, or topology state; this is the idle
CPU/latency guard. A first frame, changed pane, or pointer movement can still
incur the physical driver's page flip latency, which is reported per present
and bounded by `BLIT_KMS_FLIP_TIMEOUT_MS`.

The software pointer is an overlay, not terminal content. Each output retains
the pixels beneath its pointer and restores that underlay before drawing the
next position; pointer motion therefore cannot paint black trails over Hibr's
background or wallpaper.

If a page-flip event exceeds that timeout, Blit performs one explicit modeset
recovery for the affected output and then resumes ordinary page flips. A
timeout must never become a modeset-per-frame loop: repeated modesets blank
and visibly disturb the display while making pointer and terminal updates
appear stalled.
When the DRM descriptor is readable, Blit drains its page-flip events before
evaluating timeout age; a ready event is authoritative and cannot be falsely
classified as a timeout because the event loop reached the check late.

Evdev synchronization reports are not treated as pointer motion unless the
absolute pointer position or output actually changes. This prevents devices
that emit idle `SYN_REPORT` traffic from scheduling a full pointer redraw on
every report; button and wheel events remain independently routed.

## Two-output pixel gate

The production KMS path has a separate capture fixture so visual validation is
not inferred from HTTP state or the Hibr control path. Stage the current server
and run:

```sh
tools/probes/stage_kms_qemu.sh /tmp/hibr-initroot-current
(cd /tmp/hibr-initroot-current && \
  find . -print | cpio -o -H newc | gzip -1 > /tmp/alpine-vkms-capture-initramfs.gz)
qemu-system-x86_64 -M q35 -m 1024 -smp 2 \
  -kernel /tmp/linux-vkms-build/arch/x86/boot/bzImage \
  -initrd /tmp/alpine-vkms-capture-initramfs.gz \
  -append 'console=ttyS0 init=/init vkms.create_default_dev=0' \
  -display none -serial stdio -monitor none -no-reboot
```

`KMS_CAPTURE_PASS` requires two guest-generated PPMs, each with a 1024×768
header and the exact 24-bit payload size. The TCC-built `ppm-assert` oracle
also checks black background pixels and a known `READY` glyph in the expected
cell origin on both displays. Display 47 also emits a U+2500 wide cell and
the oracle requires foreground pixels in both eight-pixel halves, proving the
renderer paints the logical two-cell width rather than only its first cell.
Distinct SHA-256 hashes remain an additional check that the two outputs are
not the same buffer. The tiny VKMS kernel does
not include 9p, so the PPMs are validated over the serial log; an empty host
screenshot directory is not evidence that the frames were absent. The same
gate checks `/v1/graphics` for the VKMS vendor/device IDs, driver, DRM device
node, and hardware-acceleration capability fields; unavailable sysfs values
are reported as `unknown` rather than invented.
The fixture also checks `/v1/diagnostics` for the refresh-aware scheduler
mode, an effective interval, and one cadence record per output before
accepting the capture.

To exercise the scheduler's mixed-refresh branch, add
`blit.mixed_refresh=1` to the kernel command line. This enables an explicitly
test-only `BLIT_TEST_REFRESH_HZ=60,120` metadata override and requires
`REFRESH_SCHEDULER_MIXED_PASS`; it validates scheduler policy and API
diagnostics, not physical 120 Hz hardware timing. The normal fixture remains
the authoritative physical VKMS/pixel test.

For the high-refresh deadline branch, add `blit.high_refresh=1`. The fixture
uses the test-only `BLIT_TEST_REFRESH_HZ=60,240` override and requires
`REFRESH_SCHEDULER_240_PASS` with a 4 ms deadline. This validates the 240 Hz
deadline calculation and diagnostics only; it is not a physical 240 Hz claim.

To exercise the API-owned pixel canvas, add `blit.pixel_frame=1`. The fixture
creates a terminal session on display 47, sends a complete 32×32 RGBA frame
through the WebSocket API using the TCC-built `ws-pixel-frame-probe`, waits for
`pixel_frame_present`, then calls the direct-KMS screenshot endpoint and
requires `KMS_API_PIXEL_PASS` from the TCC-built BMP framebuffer oracle. This
also validates that a 4,096-byte binary frame is accepted through the bounded
network receive path and that the graphics update advances the surface
revision used by direct KMS damage suppression.

Use `blit.pixel_stream=1` for the timed workload variant. It sends 60 complete
RGBA frames at a 60 Hz producer cadence, requires all 60 to be accepted with
no additional missed deadlines over the fixture's startup baseline, and then
applies the same direct-KMS framebuffer oracle. The selected display mode may
be higher than the producer cadence because production scheduling follows the
display's maximum mode; this is not a physical 120/240 Hz claim.

Use `blit.pixel_stream_240=1` for the bounded high-refresh variant. It sends
240 complete RGBA frames at a 4.166 ms producer cadence and requires the
selected KMS mode to report 240 Hz from the device itself
(`refresh_source:"display-mode"`); it does not use the test-only refresh
metadata override. All 240 frames must be accepted with zero additional
missed deadlines over the fixture's initial virtual baseline, and the same
direct-KMS framebuffer oracle is applied. The baseline and post-stream
counters are printed because TCG/VKMS startup can miss virtual page flips
before the producer starts. This is virtual high-refresh timing evidence, not
a physical 240 Hz hardware claim.

Under QEMU TCG this variant has accepted all 240 frames but added missed
deadlines, failing the visible-cadence predicate. `/dev/kvm` is absent on the
test host; repeat this gate with KVM or physical hardware before changing the
production scheduler. Do not enable asynchronous page flips to turn this into
a pass.

For comparison only, `blit.kms_async=1` enables the existing asynchronous
page-flip policy in the fixture and reports `drm-page-flip-async`; it may tear
and does not relax the synchronized production gate.

The same fixture accepts `blit.output_loss=1` on the kernel command line. It
disables connector 47 during the run and requires `OUTPUT_LOSS_PASS`: the
failed connector remains in `/v1/displays` as `failed`, the other connector
remains `presenting`, and `/v1/diagnostics` reports
`display_presentation_failed` while the server stays ready.

The four-output boundary is exercised by
`tools/probes/qemu_kms_four_output_init.sh`. It creates four independent VKMS
connector/CRTC/encoder/plane paths, starts one API terminal session on each,
and requires `display_count:4`, four presenting outputs, four sessions, and
`KMS_FOUR_OUTPUT_PASS`. This validates the public discovery and presentation
path at the four-monitor case without changing the production display limit.
The fixture then places distinct red, green, blue, and yellow API overlays on
the four outputs, captures each output through the screenshot endpoint, and
checks the marker pixel with `bmp-pixel-assert`, producing
`FOUR_OUTPUT_INDEPENDENT_PIXEL_PASS`. This proves that the screenshot and
overlay target remain bound to the selected output rather than merely proving
that four output objects exist.
Adding `blit.hibr_four=1` to the same kernel command line replaces those probe
sessions with one primary Hibr desktop and three `desktop --join` clients; the
fixture then requires `KMS_FOUR_HIBR_PRIMARY_CONTENT_PASS` with four
Hibr-backed surfaces. Hibr deliberately keeps its bar and desktop chrome on
the primary display; an auxiliary join can therefore be a valid blank screen
until Hibr places a window there. The fixture records that as
`HIBR_CONTENT_AUXILIARY_EXPECTED_BLANK`, not as a renderer failure.
Adding `blit.hibr_window_control=1` selects the repository's deterministic
Hibr one-window workload for the same primary and join arrangement and
requires `KMS_FOUR_HIBR_WINDOW_CONTENT_PASS`, with visible pixels on all four
outputs. This separates Hibr's intended blank auxiliary state from Blit's
ability to compose populated joined output surfaces.
For the tall-pane lifecycle boundary, add `blit.hibr_tall=1` as well. This is
a diagnostic-only variant that creates four `240x135` Hibr surfaces and
checks for styled cells on the final row. The current released Hibr session
reports `KMS_FOUR_HIBR_TALL_HIBR_BOUNDARY_OPEN`: all four Blit surfaces and
KMS outputs are healthy, but Hibr's held desktop stream stops at its 24-row
startup paint. It is intentionally not converted into a Blit pass or hidden
by changing the compositor's geometry.
Use `tools/probes/stage_four_output_qemu.sh INITROOT HIBR_ROOT` to construct the
fixture initroot. It stages the current Blit binary, KMS pixel oracles, Hibr
runtime, and the four-output init script as one atomic test boundary; do not
combine the individual staging helpers manually.
The QEMU command must also include `vkms.create_default_dev=0`. Without that
parameter VKMS creates its single-output default card before the configfs card;
forcing Blit to `/dev/dri/card0` then tests the wrong card and reports one
display. The fixture now emits this exact correction when that setup error is
made.

The fixture also accepts `blit.kitty_stack=1`. This sends two overlapping
Kitty images with different z values and a two-pixel image positioned partly
outside the pane. `PPM_DISPLAY_47_WIDE_STACK_CLIP_PASS` requires the higher-z
pixel and the clipped image's visible second pixel at their exact coordinates.

The fixture accepts `blit.kitty_limits=1` for the resource-lifecycle gate.
`pty_input_echo.c --kitty-limits` sends one incomplete upload more than the
store holds (`BLIT_GRAPHICS_MAX_IMAGES` + 1, so 17 since the store grew to 16
in 0.3.17), then an upload one pixel wider than `BLIT_GRAPHICS_MAX_WIDTH`.
Both sizes come from `src/blit_graphics.h`, so the probe follows the store.
`KITTY_LIMITS_PASS` requires the session's `graphics_diagnostics` to report
one eviction and one rejection.
This mode is diagnostic-only and intentionally does not run the pixel oracle.

The fixture accepts `blit.kitty_query=1` for the PTY acknowledgement gate. A
query-only `a=q` upload must receive `ESC_Gi=31;OK ESC\\` without storing an
image; the probe records this as `KMS_KITTY_QUERY_PASS` through the session
title. Query responses follow the Kitty graphics protocol, including quiet
mode handling, and are not treated as rendered image state.

The fixture accepts `blit.sixel=1` for the initial sixel gate. It sends two
direct-color sixel columns with six-row raster data and requires
`PPM_DISPLAY_47_SIXEL_PASS`. This validates the shared RGBA graphics object
and the KMS compositor for the bounded sixel capability advertised in the
session contract.
A payload that cannot be parsed at all is still rejected diagnostically, but
geometry past the bound is clipped rather than discarded and neither colour
space nor an undefined colour register costs an image -- see the Sixel section
of the [terminal reference](terminal.md#sixel);
`tools/tests/sixel_decoder_gate.rb` asserts this against the framebuffer.

## Pointer stress gate

The input-only QEMU variant starts two terminal surfaces, routes the synthetic
evdev keyboard and pointer independently, and emits 180 pointer motions at
16 ms intervals with periodic primary-button and wheel events. It must report
both `BLIT_INPUT_KEYPAD_PASS` and `BLIT_INPUT_STREAM_PASS`. With
`BLIT_KMS_TRACE_TIMING=1`, the per-present timings are also retained in the
serial log; a multi-second redraw is a failure. For phase diagnosis,
`BLIT_KMS_TRACE_PHASES=1` additionally records wait, glyph-draw, and page-flip
intervals; the acceptance marker and pixel gate must still pass when timing is
enabled.

The refresh gate must record, per output, selected refresh, effective
scheduler cadence, missed-deadline count, and page-flip wait time. The
acceptance run uses at least two outputs with different selected refresh
rates and requires that the faster output is not reduced to the slower
output's cadence. A result is invalid if it only demonstrates that frames
were eventually drawn; it must separate scheduler delay from physical
vblank/page-flip delay.
The input fixture also crosses the synthetic pointer from output 1 to output
2 and verifies that streamed motion changes from the first PTY session to the
second rather than being broadcast to both. It overlaps left, middle, and
right button presses, verifies motion while buttons remain held, and checks
that each release preserves the remaining-button state. The pointer PTY also
enables DEC focus reporting and must receive the focus-in sequence after the
cross-display click.
The fixture additionally requires `BLIT_INPUT_RAW_EVDEV_PASS`, which reads
`/v1/diagnostics/runtime` and requires raw mouse records, synchronization,
motion, and button counters to be nonzero. This proves the input test crossed
the kernel-evdev boundary, not only the network stream and PTY boundary.
The fixture creates two independent relative mice and requires
`BLIT_INPUT_MULTI_MOUSE_PASS`, proving that Blit services every discovered
pointer FD instead of silently keeping only the first device.

The input-only invocation uses `-smp 1` with the current tiny VKMS kernel.
The kernel's SMP boot path can panic in `sched_clock_cpu` before `/init` when
this synthetic input workload is launched with two vCPUs; that is a fixture
kernel failure, not a Blit result. The two-output KMS and Hibr pane fixtures
continue to use two vCPUs.
