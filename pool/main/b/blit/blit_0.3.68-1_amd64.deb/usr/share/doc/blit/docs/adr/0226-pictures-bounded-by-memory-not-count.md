# ADR 0226: pictures bounded by memory, not by count

- Status: accepted; in use since 0.3.65
- Date: 2026-11-07
- Scope: graphics images and placements (Kitty, sixel, API, frame channel),
  the GPU and CPU compositors' image textures, `/v1/server` graphics limits,
  XTSMGRAPHICS, frame-channel input routes (ADR 0225)
- Supersedes: ADR 0202's "16 images per session" (its one frame in flight
  per image stays)

## Context

A Blit session holds at most 16 pictures (`BLIT_GRAPHICS_MAX_IMAGES`), each
shown in at most 9 places (the default placement and 8 numbered ones,
`BLIT_GRAPHICS_MAX_PLACEMENTS`). Every kind of picture shares the 16: Kitty
and sixel images, API images, and the frame channel's live pictures. When a
17th arrives, Blit frees the oldest complete picture that nothing shows
(`graphics_reclaim_unshown`); a picture on screen is never freed, so with 16
on screen the 17th is refused. Behind the compositor the GPU path keeps 32
image textures per output (`KMS_IMAGE_TEXTURES`), recycled least recently
drawn first.

The numbers come from Blit's terminal beginnings, when a session was one
program in one pane. A Hibr desktop is one Blit session per display, and
every picture on it shares that session: the wallpaper, the browser, films,
game windows (ADR 0225), and, in Files or Pictures, one thumbnail per item.
The owner asked: what if there are 500 thumbnails on a desktop? Today they
cannot all be pictures. They could not all be drawn either: past 32 on one
output, the texture table would re-upload pictures every frame. Hibr gets
by only because it uses few pictures, and every client that wants many must
composite them into one first, which is work each client repeats and the
display server exists to do.

The protocol's own guidance bounds pictures by memory, not by count (kitty
graphics protocol, "Image persistence and storage quotas"): a terminal
"should have a maximum storage quota for image data", allowing "at least a
few full screen images" (kitty's is 320 MB per buffer); when a new image
would exceed it, the terminal "should delete older images to make space",
and images "without placements will be preferentially deleted". No count
limit is stated. Blit already answers `ENOSPC` when its store is full and
`EFBIG` for a picture over its size bounds.

## Options considered

1. **Raise the constants** (512 pictures, 32 placements, 512 textures).
   Small change. But fixed arrays of the full struct in every one of the 16
   sessions cost memory whether used or not, a count still says nothing
   about bytes (512 4096x4096 RGBA pictures is 32 GiB), and the next desktop
   use finds the next wall.
2. **Clients composite many pictures into one** (Hibr draws a thumbnail
   grid as one image). What happens today. Moves the display server's job
   into every client, re-sends the whole grid when one thumbnail changes,
   and does not help the frame channel or input routes, which are per
   picture.
3. **Bound pictures by memory, with growable tables and a high safety
   ceiling** (kitty's model, adapted to a display server with a GPU).
   Larger change across the server, both compositors and the API; bounds
   what actually runs out.

## Decision (approved by the owner, 2026-11-08; phase 1 being built)

Option 3.

- **Tables grow.** A session's pictures and each picture's placements live
  in tables that grow on demand (doubling, freed with the session), not
  fixed arrays. Count ceilings remain only as a guard against a runaway
  program, far above any real desktop: **4096 pictures and 16384
  placements per session**, each refused past the ceiling (the Kitty reply
  `ENOSPC`, which Blit already gives for a full store, an API `409`). Frame-channel input routes (ADR 0225) follow
  pictures, one per picture, with no number of their own.
- **Memory is the limit.** Each session has a **picture budget**: the bytes
  of decoded pixels Blit keeps for it (CPU copies, sixel and Kitty
  scratch, and the GPU textures made from them; a picture with both a CPU
  copy and a texture is charged for both, which on an integrated GPU is the
  truth, since both are system memory). Default 256 MiB per
  session, and a **server budget** across sessions of a quarter of physical
  memory, capped at 2 GiB; both are settings. A dmabuf frame (ADR 0223) is
  the producer's memory and counts only its texture bookkeeping. When a new
  picture would exceed a budget, Blit first frees pictures nothing shows,
  least recently shown first, in that session and then across sessions for
  the server budget. If freeing every unshown picture would still not make
  room, nothing is freed and the new picture is refused (`ENOSPC`):
  pictures are not destroyed for a refusal that comes anyway. Nothing
  shown is ever freed to make room; this is stricter than kitty, which may
  delete placed images as a last resort, because on a desktop a picture
  vanishing from a window is worse than a new one refused. "Shown" means
  placed and not deleted, or with a placement held for its next frame (ADR
  0202's `a=p` that arrived before the picture: it is about to appear, and
  Hibr's game windows are made that way), or holding an input route (ADR
  0225: freeing it would end the route mid-game). A client that scrolls
  through many pictures deletes the placements it scrolls away (`a=d,d=i`
  lowercase keeps the data), so they become free-able.
- **The GPU keeps what it draws.** The per-output texture table becomes a
  byte-budgeted cache (default 512 MiB per GPU, a setting), recycled least
  recently drawn first, so every picture drawn in a frame keeps its
  texture and nothing is re-uploaded while it stays on screen. The CPU
  compositor needs no texture cache; its per-frame draw list grows like
  the tables.
- **Published limits say the truth.** `/v1/server` `graphics` reports
  `max_images` and `max_placements` (the ceilings), the budgets and their
  current use, and the existing per-picture bounds (`max_width`,
  `max_height`, `max_bytes`) unchanged. XTSMGRAPHICS answers as now. Each
  session reports its pictures' bytes, frees by reason (`unshown`,
  `budget`), and refusals by reason (`ceiling`, `budget`).
- **Source of truth.** One accounting function charges and credits a
  session's and the server's budgets; every allocation and free of picture
  memory goes through it, so the reported use and the enforced use cannot
  disagree.

**Phases.** (1) Growable tables and ceilings, the budgets and their one
accounting function, freeing least recently shown, the byte-budgeted
texture cache, the published limits. (2) Only if (1) measures too slow with
hundreds of small pictures on 10.52's Intel GPU: small pictures sharing
atlas textures (see Open questions).

## Consequences

- A desktop can show as many pictures as it has memory for: a Files window
  of 500 thumbnails is 500 pictures, drawn from a few atlas textures.
- Memory is bounded by what runs out, per session and across the server;
  an idle session costs nothing for pictures it does not have (today every
  session carries 16 picture structs).
- A program that floods pictures is stopped by the ceiling or the budget,
  and only its own unshown pictures are freed first.
- Larger change: the picture table is walked in about 70 places across the
  server, both compositors, the frame channel and the scene builder; they
  move to an iterator over the session's table. The draw list, today sized
  `BLIT_GRAPHICS_MAX_DRAWS`, grows per frame.
- Behaviour change: a 17th picture with 16 on screen is now accepted;
  freeing an unshown picture is now least recently shown, not oldest
  revision.
- Text to change when it lands: `docs/api.md`'s INPUT `EBUSY` ("or the
  connection already has 16, the most images a session holds") becomes the
  picture ceiling; ADR 0202's bounds paragraph points here.

## Open questions

- **An atlas for small pictures: not now (measured 2026-11-08).** Pictures
  with both sides at most 256 pixels could share atlas textures as glyphs
  do. Measured on 10.52 (Intel HD 515, GLES, the output rendered at 2x),
  500 thumbnails re-placed every 50 ms (a full scroll at 20 Hz, the worst
  case; a still grid costs nothing): a typical frame drew 504 quads in 504
  draw calls in 8.3 ms (4.8 ms on the CPU, 5.6 ms on the GPU, overlapping),
  inside the 16.7 ms of a 60 Hz frame, with no missed deadline reported and
  nothing re-uploaded; the worst frame in each half-second was 19-25 ms.
  The same grid as one picture drew in 1.7 ms. About 10 microseconds a
  draw on each side is the cost an atlas would remove; it becomes worth its
  complexity when a real view (Files, Pictures) scrolls hundreds of
  thumbnails and misses frames on the owner's hardware, which these numbers
  do not show. The 19-25 ms worst frames are worth finding first, since an
  atlas would not explain them.

## Evidence

Phase 1, built 2026-11-08, released in 0.3.65 and running on the mini PC and 10.52:

- `graphics_memory_gate` (tools/tests), on the CPU compositor:
  `GRAPHICS_MEMORY_PASS backend=native many=1000 placed=500 drawn=500 upload_bytes=0(flat) pixels=192000 textures=0 session_freed=1,3,4,2(least_recently_shown) kept=4 refused=ENOSPC server_freed=1:1,2:3,1:2 refused=ENOSPC ceiling=4097:ENOSPC`
- and on the GPU compositor (GLES, surfaceless softpipe):
  `GRAPHICS_MEMORY_PASS backend=gles many=1000 placed=500 drawn=500 upload_bytes=96000(flat) pixels=192000 textures=96000 session_freed=1,3,4,2(least_recently_shown) kept=2 refused=ENOSPC server_freed=1:1,2:3 refused=ENOSPC ceiling=4097:ENOSPC`
  The GPU run kept fewer pictures before refusing in both budget
  scenarios, because there a shown picture is also charged for its
  texture; the order of frees is the same. On the GPU the server budget
  refused with B still kept: freeing it alone would not have made room,
  and Blit frees nothing for nothing.
- `graphics_memory_frames_gate` (against the stand-in libei), both
  compositors: a frame picture holding an input route, the least recently
  shown of all, keeps its pixels and its route, and a picture placed by a
  held `a=p` keeps its placement, while the unshown Kitty picture is freed
  and the next shown one refused `ENOSPC`. Run against the build before
  this rule, the routed picture was freed first.
- The full set (`tools/run-gates.sh all`): `RUN_GATES_FAIL pass=184 skip=12 fail=1 (arabic_kms_ink, whose fixture still used the old picture array; fixed, then passing alone; the baseline's failing hibr_split_capture_gate passed)`;
  GLES `renderer`: `RUN_GATES_FAIL pass=81 skip=1 fail=1 (presentation_effects_gate's animation rate, 14.5/s against a 15/s floor at load 5; passing when run again, as on the baseline tree)`.
- An idle session's struct shrank from 53,432 to 39,848 bytes (16 picture
  records out of it); a picture record from 832 to 496 bytes, now
  allocated only when used.

Planned:

- A gate that creates 1000 small pictures in one session, places 500 on
  screen, and checks that all 500 draw (screenshot), that none is
  re-uploaded on the next frames (`graphics_upload_bytes` flat), and that
  the session's reported bytes match its pictures.
- Budget gates: a session pushed past its budget frees unshown pictures
  least recently shown first and refuses with `ENOSPC` once only visible
  pictures remain; the server budget does the same across two sessions;
  the ceiling refuses picture 4097.
- The existing graphics, frame and input gates unchanged in outcome; full
  set and GLES `renderer`.
- Done on 10.52 (see Open questions): 500 pictures of 64x64 pixels in one
  session used 16,384,000 bytes, the same as one picture of the grid, with
  nothing freed or refused; frame times above.
