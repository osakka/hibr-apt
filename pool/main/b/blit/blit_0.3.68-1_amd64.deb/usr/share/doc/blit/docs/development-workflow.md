# Blit development workflow

This is the operating procedure for every implementation cycle. It keeps the
repository, the running server, and the evidence about them aligned.

## Before changing code

1. Read the relevant schema, architecture note, ADR, and current verification
   entry before editing.
2. Check `git status --short --branch`. Existing untracked logs, screenshots,
   packages, and user files are preserved; they are never swept into a commit
   accidentally.
3. State the invariant being changed and the exact evidence that will prove it.
4. If the change affects a public API, protocol, renderer boundary, terminal
   semantics, display topology, dependency, security policy, or another
   subsystem, write or update an ADR before implementation. Record options,
   decision, consequences, migration, and rejected alternatives.

Small defect fixes may proceed without a new ADR when they preserve an existing
decision. They still require a test and an evidence update.

## One cycle, one source of truth

Each cycle has one narrow change set: change the canonical implementation or
schema; add a regression test; update normative documentation and the
verification ledger; build with TCC; run the relevant gates; inspect captures
and diagnostics; and clean up temporary processes and resources.

Adapters, packages, screenshots, generated bindings, and staging trees are
derived artifacts. They must not become a second implementation or an
undocumented source of behavior. Hibr remains an external dependency: Blit
tests its released executable and modules but does not modify the Hibr tree.
The adapter build must name the exact Hibr checkout whose `HIBR_VER` matches
`packaging/HIBR_VERSION`; a newer development checkout is a deliberate QEMU
fixture input, not a valid package build target.

## Commit and push cadence

### Public publication links

The public repository is `https://github.com/osakka/blit`. Use relative paths
for files within the repository and GitHub `blob/main` or `tree/main` links
when publishing externally. Internal Gitea remains the engineering origin
and backlog; do not replace the configured remote or create a parallel push
workflow for a documentation-link change. Verify the public GitHub branch
contains the intended commit before claiming publication. Internal issue
numbers are not automatically GitHub issue numbers: preserve their internal
identity rather than fabricating public issue links. Internal browser-route
failures do not establish failure of the public GitHub documentation.

### Completed-cycle commits

Every completed cycle ends with `git diff --check`, an intentional-file review,
a focused commit, `git push origin main`, and a final branch-status check. The
commit contains the implementation, tests, ADR/documentation changes, and the
evidence needed to understand the result. Do not make a “code now, docs later”
commit or push a package whose binary was not built from that commit. A
generated package may remain untracked locally, but its version, SHA-256, and
build commit belong in the handoff or verification ledger.

A failed cycle is also recorded: commit only a useful, coherent diagnostic or
test improvement, explain the failure, and do not claim the feature passed.
Never amend or rewrite pushed history to hide a failed experiment.

The commit message should identify the boundary changed and the evidence
updated, for example `document API lifecycle and release evidence`. Before
push, inspect the staged file list and confirm that it contains no package,
screenshot, log, QEMU image, token, or unrelated Hibr checkout. After push,
record the commit ID in the release manifest or evidence ledger before making
the next runtime claim.

## Reconcile and retire completed branches

`main` is the canonical integration branch. A temporary maintenance branch may
isolate a released runtime from pending feature work, but its complete tip,
including release/documentation follow-ups, must be reconciled back into main.
Copying/cherry-picking equivalent changes does not by itself reconcile ancestry.

Before merging, fetch the remote, inspect both worktrees (including ignored
build/evidence files), compare unique commits and actual content, and identify
changes already integrated. Merge the reviewed tip without rewriting history.
Resolve overlapping evidence by preserving one historical record and all newer
results, not by duplicating sections or downgrading current source/manifests.
If only history/docs differ, assert production-path tree identity and rebuild
to verify unchanged binary hashes; run the relevant regression gates anyway.

After verification, push main and retire only the exact merged branch tip.
Use an explicit expected remote revision when deleting the remote branch so a
concurrent update cannot be discarded. Preserve historical ignored artifacts:
detach their worktree at the integrated historical commit rather than forcing
its removal. Update the tracking issue and restart-point documentation. A
retained historical build snapshot is not an active development/config owner.

## Required gates

Raster-blending changes require `ruby tools/tests/raster_blend_gate.rb` and
normal font/backend composition gates. The standalone gate exhausts production
channel/alpha arithmetic against a frozen test-only oracle and checks TCC
instruction work. `--benchmark` reports same-process CPU medians, not live FPS;
`--observe` disables the division-count requirement and is not performance
acceptance (ADR 0179).

Image-ingestion changes require `ruby tools/tests/graphics_ingestion_gate.rb`.
It instruments the production decoder, not a parallel decoder. `--observe`
disables the performance assertions and must never be reported as a passing
performance gate (ADR 0178).

Graphics damage changes require
`ruby tools/tests/graphics_placement_damage_gate.rb`, on both
`BLIT_GATE_BACKEND=native` and `gles`. It compares production incremental
composition against full-redraw pixels; counts or screenshots alone are
insufficient. Preserve held/deferred snapshot acknowledgement and
unknown-caller fallback (ADR 0177).

The `font` suite also runs the production cache workload
(`ruby tools/probes/font_cache_workload.rb --check`), and `timing` verifies
the read-only baseline sampler's units, counter-reset rejection and
backend-change rejection. Report cache work separately from live frame
latency. Keep source/font identities and workload conditions with the result;
never promote an idle API sample into a Kitty comparison.

Use the narrowest gate that proves the change, then run the broader gate before
handoff:

- schema/API changes: schema validation, API conformance, and version identity;
- documentation changes: `ruby tools/tests/documentation_gate.rb` (in the
  schema suite) for environment variables in `blit(8)`, manual-page
  formatting and links;
- terminal changes: TCC build and `tools/tests/terminal_conformance.rb`;
- font/Unicode changes: glyph coverage, UTF-8 snapshots, and a Hibr capture;
- renderer/input changes: the renderer suite on `BLIT_GATE_BACKEND=native` and
  `gles`, plus KMS/VKMS pixel and input;
- multi-display/Hibr changes: two-output topology, pane matrix, primary plus
  `--join`, routing, and cleanup;
- packaging changes: allowlist, embedded version identity, install/service
  checks, and checksum;
- presentation startup/recovery changes: the lifecycle suite;
- performance/timing changes: diagnostics, measured intervals, CPU/RSS, and a
  bounded workload rather than a subjective “feels faster” claim.

For font/catalogue asset changes, regenerate `docs/fonts` with
`tools/fonts/build-reference.py` in the existing pinned fontTools 4.60.1
environment, then run its `--check` mode and
`ruby tools/tests/font_reference_gate.rb`. This documentation gate is included
in the font suite and uses no display. Tables and coverage inventories are
derived from canonical assets; never repair a glyph mapping by editing the
generated reference. A documentation-only change needs these focused checks,
asset identity and link checks, not a live renderer restart.

`tools/run-gates.sh` is that list, executable. Its suite names match the
categories above, so the narrowest run is one suite and the pre-handoff run is
`all`:

```sh
tools/run-gates.sh terminal          # the narrowest gate for a terminal change
tools/run-gates.sh all               # before handoff
BLIT_GATE_BACKEND=gles tools/run-gates.sh renderer   # on the GLES compositor
BLIT_GATE_PACKAGE=blit_X.Y.Z-1_amd64.deb tools/run-gates.sh packaging
BLIT_GATE_LIVE=http://HOST:8080 tools/run-gates.sh timing
```

Prefer it over invoking a gate directly. `packaging` is a suite of its own,
skipped unless `BLIT_GATE_PACKAGE` names a `.deb`.

The runner is measured, bounded and parallel (ADR 0216):

| Variable | Effect |
|---|---|
| `BLIT_GATE_JOBS` | Gates run at once; default `min(4, nproc/2)`. `1` is the plain serial run. |
| `BLIT_GATE_TIMEOUT` | Seconds one gate may take; default 300, with more for the few gates that wait on purpose. A gate over it is killed with its server and reported `FAIL ... TIMEOUT`; it is never retried. |
| `BLIT_GATE_PORT_OFFSET` | Added to every fixed gate port. Parallel workers add a stride of 1000 each. Give each checkout or agent running gates at the same time its own offset: 0, 4000, 8000 (the runner refuses offsets that reach the ephemeral port range). |

Gates that depend on a quiet machine (cadence, frame rate, "saved within N
ms", the soak, update/restart timing) are marked `run_serial_gate`: they run
alone, after every parallel gate, in the order they are listed, whatever
`BLIT_GATE_JOBS` is. A gate that fails only under parallel load is a bug in the
gate or the server, or belongs in that lane; it is not retried.

Every report line ends with the gate's wall time. The run ends with the 20
slowest gates and the time per suite, then the unchanged `RUN_GATES_PASS` or
`RUN_GATES_FAIL` line. "Time per suite" and "gate time" are sums over gates, so
with several jobs they exceed the `wall` time. Look at the slowest gates first:
a gate that is slow because it sleeps for a production period is a candidate for
a test-mode knob, not for a retry or a bigger timeout.

`all` includes every other suite, `font` among them: do not run `font` as well.
The release recipe below is `all`, then the renderer suite on GLES. When only
the compositor-sensitive gates need the GLES pass, `renderer-gles` runs the
renderer suite on GLES without the gates the compositor cannot change (their
own C probes, the CPU-path hotplug gates); `all` still runs every one of them:

```sh
tools/run-gates.sh all
BLIT_GATE_BACKEND=gles tools/run-gates.sh renderer   # the full GLES pass
tools/run-gates.sh renderer-gles                     # the sensitive subset
```

Every gate runs against native KMS on the DRM mock (ADR 0184).
`BLIT_GATE_BACKEND=gles` runs the same suites through the GLES compositor on
Mesa's surfaceless platform, reading each frame back. It needs working EGL/GLES
libraries; record its result alongside the native run for compositor changes.
It proves GL composition on software GL, not GPU scanout or physical
refresh-rate performance.

The gates do not share one calling
convention: some take `BLIT_TEST_SERVER`, some `BLIT_GATE_SERVER`, some
`BLIT_GATE_PORT`, some a positional argument; `terminal_conformance.rb` and
`terminal_soak_gate.rb` assert against a server the caller must start; and
`http_fragmentation_gate.rb` and `http_backpressure_gate.rb` are sub-gates
that `network_auth_gate.sh` invokes with its own port, so running either
standalone reports a failure that is not one. The runner owns those details.
A gate that needs QEMU, physical hardware, a package, or a live host is
skipped with that reason rather than counted as a pass or a failure.

QEMU is the repeatable multi-display oracle, and the runner never implies it:
run `tools/tests/qemu_hibr_lifecycle_gate.sh` explicitly. A physical host is
evidence for that host and its current hardware only; it cannot prove untested
monitor counts, refresh modes, GPUs, or input devices.

## What a green suite does not mean

`RUN_GATES_PASS pass=N skip=M fail=0` means the behaviour the suite can reach
is correct. It is not a statement about the behaviour it cannot reach, and the
distance between those two has cost this project multiple releases. The known
blind spots, so that a green run is read for what it is:

**Compositor coverage depends on the selected backend.** Gates once ran only
against a software renderer in a container without a GPU, while the physical
path used GLES. An optimisation that assumed render-target persistence
produced a visible screensaver trail that survived two "fixed" claims; five
reproductions passed because all five ran in software. See ADRs 0070/0099 and
issue 79. Run compositor changes on both `native` and `gles`; physical GPU
timing still requires host acceptance.

**A gate that cannot fail is not evidence.** Every gate should be run once
against the reverted change and observed to fail; a gate added alongside a fix
and never seen red proves only that it is consistent with the fix.
`deferred_damage_gate.rb` has no teeth and its header says so and why —
that is the minimum honest treatment, not a precedent to copy.
`evdev_char_gate.c` asserts all 26 letters rather than a sample for this
reason: the arithmetic it replaced was correct for exactly one letter, so a
spot check would have passed against the bug.

**The fixtures are not the devices.** A fabricated evdev node is a regular
file, so it is never opened as a keyboard and `state.open` stays false — the
hotplug gate exercises the device table but not the poll set, which had to be
measured on the host directly. Fabricated nodes also cannot reproduce a USB
hub that resets 66 times.

**The deployment path is partly unexercised.** The default run drives the
KMS code against the DRM mock, not a real card. `physical_multi_display_gate.rb`
and `screenshot_nonblocking_gate.sh` run only with `BLIT_GATE_LIVE` (otherwise
they are skips; an installed host also needs `BLIT_AUTH_TOKEN`, which both
send as a bearer token), and the QEMU oracle only when invoked.
`tools/probes/host_cell_pixel_agreement.rb`, which states the
cells-versus-pixels invariant, is run by no automated path at all.
Unprivileged-profile access to backlight and control devices is unmeasured.
A skip that is never taken is indistinguishable from a test that does not
exist.

**The external boundary is the thinnest-covered and the most load-bearing.**
`console-blit` is Blit-owned code compiled against external Hibr headers and
loaded into an external process. Two of four consecutive releases fixed
defects there — a key *release* translated into a keystroke, and
`'a' + code - KEY_A`, which assumes evdev numbers letters alphabetically when
it numbers them by QWERTY row. Both were invisible to a green suite, because
a plain terminal session goes through Blit's own correct keycode table and a
desktop does not. ADRs 0068 and 0069 and issue #81.

**A desktop's behaviour is not Blit's behaviour.** An owned surface takes
input from the event stream rather than the PTY (ADR 0057), so "keys not
delivered" is the expected reading for a desktop and not a fault. A pointer
click reaches Hibr only once the owner enables mouse reporting; a Blit-hosted
desktop that never sends `console mouse <mode>` cannot be clicked no matter
how correct Blit's `pointer_button` events are. Blit publishing an event and
the desktop acting on it are separate claims requiring separate evidence.

The general rule behind all of these: **the gate environment is not the
deployment environment**, and a fault that lives in the difference is one a
green suite will report as absent. When the machine and the suite disagree,
the machine is right.

## Evidence and claims

The verification ledger records the source commit, TCC version, package,
Hibr, kernel/QEMU fixture, command, result, and known limitations. “Implemented”
means source and focused tests pass; “validated” means the matching runtime
artifact passed the relevant end-to-end gate. Screenshots supplement API/state
assertions; neither substitutes for the other.

A release runs these steps in order. Building the package requires the
exact pinned Hibr checkout as an explicit input; omitting it fails closed:

```sh
hibr=/path/to/hibr-$(sed -n '1p' packaging/HIBR_VERSION)
deb=/tmp/blit-package/blit_X.Y.Z-1_amd64.deb
tools/build-tcc.sh
tools/build-tcc.sh build/blit/blit-helper helper
BLIT_HIBR_ROOT=$hibr tools/run-gates.sh all
BLIT_GATE_BACKEND=gles tools/run-gates.sh renderer
BLIT_HIBR_ROOT=$hibr packaging/build-deb.sh /tmp/blit-package
BLIT_SOURCE_COMMIT=<build-commit> BLIT_DOCUMENTATION_COMMIT=<build-commit> \
  tools/release/generate-manifest.sh "$deb" releases/X.Y.Z.yaml
tools/tests/package_artifact_gate.sh "$deb"
tools/deploy/update-live.sh HOST "$deb"
```

`packaging/build-deb.sh` writes two packages to the output directory:
`blit_X.Y.Z-1_amd64.deb` and `blit-font-sources_20120503-1_all.deb` (the
FreeMono source archive behind the Arabic font, versioned by upstream;
[ADR 0217](adr/0217-one-copy-of-the-documentation-font-sources-in-their-own-package.md)).
The manifest generator, the artifact gate and `update-live.sh` take the main
package; the gate also checks the sources package when it sits beside it.
The documentation is installed once, under `/usr/share/doc/blit/docs`. The
sources package only needs publishing (`publish.sh` given each `.deb`) when
its content changes, not every release.

`releases/<version>.yaml` is generated from the package, not written by
hand, apart from the `status:` line the operator adds. The two commit
variables are needed when the manifest is recorded in a later commit than
the build. `generate-manifest.sh --check PACKAGE MANIFEST` compares an
existing manifest with a package. The artifact gate and `update-live.sh`
both refuse a package whose SHA-256 differs from the manifest's;
`update-live.sh` also needs `BLIT_UPDATE_TOKEN` or `BLIT_UPDATE_TOKEN_FILE`.

The generator owns package/version/checksum/hash/Hibr-pin facts. Measured
acceptance results are recorded in the verification ledger; the generator
never invents physical, GPU, Hibr, or refresh results. The
release identity decision is [ADR 0091](adr/0091-generated-release-identity.md).

Package documentation is compared with `package_documentation_commit`, not
whatever handoff notes have since been committed to HEAD. Rebuilding that
artifact uses `BLIT_PACKAGE_DOCUMENTATION_COMMIT=<recorded-commit>` so updated
verification notes do not silently change the package or force a checksum
rewrite. The installed documentation derives from that snapshot.

When evidence contradicts an assumption, stop repeating the same invocation.
Preserve the log, identify the boundary that produced the contradiction, and
fix or instrument that boundary before the next cycle.

## End-of-cycle checklist

- [ ] Source of truth and affected contract are identified.
- [ ] ADR added or existing ADR explicitly applies.
- [ ] Regression test and relevant end-to-end gate pass.
- [ ] Exact binary/package version is recorded and matches the source version.
- [ ] Logs, captures, process state, and resource cleanup were checked.
- [ ] Documentation and verification ledger match the evidence.
- [ ] Only intended files are committed.
- [ ] Commit is pushed and branch status is reported.

## Service-boundary regression

`ruby tools/tests/service_boundary_gate.rb --static` verifies the shipped
unit policy. Without `--static`, it needs local systemd/passwordless sudo and
uses isolated transient units: real socket visibility and restart limiting.
`session_log_gate.rb` verifies private default log directories through API
sessions; both belong to the lifecycle suite. Neither test changes the live
display host or edits Hibr. See ADR 0167.
