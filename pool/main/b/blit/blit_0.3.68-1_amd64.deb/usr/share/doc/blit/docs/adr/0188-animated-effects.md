# ADR 0188: Animated effects re-present a held scene on a frame clock that exists only while one is on

- Status: accepted; in use since 0.2.31; amended in 0.2.33 (ticks only
  fill gaps) and 0.3.67 (the rate follows the display refresh)
- Date: 2026-10-26
- Scope: effects registry, main loop render scheduling, KMS present path,
  GLES presentation pass, diagnostics
- Builds on: ADR 0187 (presentation effects)

## Context

The owner wants cool-retro-term's "glowing line": a brightening that travels
down the screen. Its shader (`terminal_dynamic.frag`, `randomPass`) is:

    fract(smoothstep(-120, 0, y - (H + 120) * fract(time * 0.15)))

in cool-retro-term's virtual pixels. Read precisely:
- It is a broad, soft band, not a line. It ramps from nothing up to its
  brightest at the leading edge, then drops to zero just below it
  (`fract(1.0) = 0`).
- 120 virtual pixels is a third to a half of cool-retro-term's low virtual
  height.
- It sweeps the height plus its own length every 1 / 0.15 ≈ 6.7 s.
- It is added as white light, at most +0.2 at full strength (`glowingLine
  × 0.2`), on the flat picture, before curvature, so it bends with the tube.

It is the first effect that changes with time. Every effect so far changes
a frame only when the screen changes. Blit presents an output only when
something on it changed: "page flips are not a heartbeat" (`blit_kms.c`).
An idle screen costs nothing, and the owner asked that effects add no delay
or cost when they are off.

## Options considered

1. **Recompose the scene on a timer.** Redraws every view each tick and
   rebuilds glow. That is wasteful: nothing in the scene changed.
2. **Keep presenting at the display's refresh while the effect is on.**
   Simple, but 60 Hz of full presents for a band that moves about 3 px per
   frame.
3. **A frame clock that requests held-scene presents at a bounded rate, and
   exists only while an animated effect is on a powered output.** Chosen.

## Decision

**The registry gains animation.** Each spec says whether its effect
animates. `glowing_line: {intensity: 0..100}` is the first, a presentation
effect, titled "Hum bar" at the owner's choice: the real CRT artefact
it evokes. The key keeps cool-retro-term's name. The band and its timing are defined
once in `blit_effects.h`:
- **Band length:** a third of the pane's height.
- **Period:** 1 / 0.15 s, sweeping the pane's height plus one band length.
- **Shape:** brightness rising along a smoothstep to the leading edge, zero
  below it, as cool-retro-term's `fract(smoothstep(-L, 0, y - p))`.
- **Strength:** `intensity / 100 × 0.2`, added to each channel and clamped.

The band is placed in content space, at the warped coordinate, so it bends
with the curvature. It is added after glow and before the glass scanlines.

**The phase is computed in C.** The frame clock takes the monotonic time and
computes `fract(seconds × 0.15)` in double precision. Only that 0..1 phase
reaches the shader, as a uniform. A raw time in a float loses precision
after hours of uptime.

**A tick re-presents; it never recomposes.** It does not force a held
scene; it only makes its outputs due and changed:
- **Changed:** in the KMS present path, a new `animation_output_mask` marks
  such an output as changed for that frame, next to the screenshot and
  pointer masks. The rule "an unchanged output is not presented" still holds
  for everything else.
- **Nothing is redrawn:** with no view changed, GLES composition redraws no
  view, and (since 0.2.29) rebuilds no glow copy. Only the scene copy and
  the presentation pass run, with the new phase. A frame that recomposes
  anyway carries the new phase too.
- **Quiet windows:** inside a terminal quiet window or a Hibr frame barrier,
  the main loop limits presents to the outputs the pointer dirtied
  (`output_mask &= pointer_dirty_outputs`). Outputs due for animation are
  OR'd into that filter, so the band keeps moving. The frame is then a held
  scene, as for the pointer.
- **Pacing:** an output that is not yet initialised is skipped, and a flip
  still pending waits, as for the pointer.

**Implementation.**
- The registry gains an `animated` column, reported by `GET /v1/effects`.
- The band is `blit_effect_line_value` in C, and the same expression in the
  presentation shader. The phase is `blit_effect_line_phase` of the KMS
  monotonic clock, computed in C per frame.
- The KMS side takes an animation request, `blit_kms_request_animation`: a
  mask of outputs the next present treats as changed. The present call's
  signature and its callers are unchanged.

**The clock exists only while it is needed.**
- An output's animation is due only while all of these hold:
  - an animated effect is on, and switched on, in at least one of its panes;
  - its compositor draws presentation effects;
  - the output is presenting (powered, not blanked).
- **Rate:** 30 Hz by default (`document.server.effects_animation_hz`,
  10–30 in this release). At 30 Hz the band moves about 6 px per frame on a
  soft ramp. A higher ceiling waits for a measurement on the owner's GPU.
  (Since 0.3.67 the rate follows each display's refresh; see the amendment
  below.)
- With no due output there is no tick and no present, so an idle screen
  stays free.
- **The tick owns its own cadence.** After any present,
  `advance_render_schedule` makes an output due again one refresh later, and
  `render_work_remains` would keep `render_pending` set while anything is
  outstanding. So animation is not "work": `render_pending` stays 0 between
  ticks. The frame clock alone raises it, and sets the output's due time, at
  its own rate. Otherwise the loop would present every refresh: 60 Hz, not
  30. The present itself still goes through the render schedule and frame
  timing, so it is aligned to the vblank and coalesces with real changes.
- **No new timeout.** With nothing pending, the main loop already wakes
  every 10 ms (`render_wait_ms`). The clock is checked on each pass, so a
  tick lands within 10 ms of its time, on a 33 ms period.
- **"Presenting" is three facts the runtime already has:**
  - the display's DPMS `power_state` is on, or was never read;
  - its KMS `presentation_state` is `BLIT_KMS_PRESENTATION_PRESENTING`;
  - Blit holds the VT (`blit_vt_active`).
  A display that is off, failed, recovering or switched away gets no ticks.

**It is unavailable where presentation effects are:** on the CPU
compositor, and without `highp`. It is kept and reported per pane, as in
ADR 0187.

**Cost is visible.** Each output's `effects` diagnostics gain:
- `animation_hz`: 0 when the clock is off;
- `animation_frames`: the presents made only for animation;
- `animation_phase`: the phase of the last present, which also makes the
  band's position checkable.

## Consequences

- The first source of frames that is not a change. It is bounded by the
  rate, and off whenever no animated effect is on.
- A glowing line on an otherwise idle screen costs the presentation pass,
  30 times a second. ADR 0187 measured about 1.8 ms for both panes on the
  owner's Radeon, so roughly 5% of the GPU at 30 Hz. To be measured.
- The band does not bloom. In cool-retro-term the glowing line is added
  before bloom, so it glows. Here glow is sampled from the scene's blurred
  copy and the band is added after it. That is deliberate: it is what keeps
  a tick free of glow rebuilds. It is not a bug to "fix".
- Later animated effects (flicker, static noise, horizontal sync) use the
  same clock and phase. Flicker and noise also need a per-frame random seed,
  derived from the frame count in C, never from the clock.

## Evidence (to be met before acceptance)

`presentation_effects_gate` gains these cases, on gles:
- **The band's shape:** in one capture of a flat pane with a glowing line,
  the rows brighter than the flat colour form one contiguous run, about a
  third of the pane tall. Brightness rises monotonically toward the run's
  lower (leading) edge and is zero below it. The run's position matches the
  `animation_phase` the diagnostics report for that frame.
- **Direction:** a second capture a moment later has the run lower down,
  wrapping only past the bottom.
- **A tick only re-presents:** during an idle animation, `gpu_frames` and
  `animation_frames` rise at the configured rate, while `drawn_cells` and
  `glow_rebuilds` do not move.
- **No clock when off:** with the line at 0, switched off, or the pane
  switched off, `gpu_frames` stops rising on an idle screen.
- **CPU:** a saved glowing line on a CPU-composed output is reported
  unavailable, and the output presents no ticks.

Plus a measurement on the owner's Radeon of the GPU share at 30 Hz.

### Measured on the owner's Radeon (0.2.31, 2026-10-26)

DP-1 at 1920×2160, both panes with scanlines, corners, curvature, glow,
RGB shift and the hum bar at 15, during ordinary desktop use. 10 s per
row, A/B on the hum bar alone:

| Hum bar | GPU per frame | Frames per second | Animation-only frames per second |
|---|---|---|---|
| 15 | 2.33 ms | 39 | 22.6 |
| off | 2.36 ms | 31 | 0 |
| 15 again | 2.31 ms | 36 | 25.2 |

- The band adds no measurable GPU time per frame.
- Its cost is the frames it adds: about 8 per second above the desktop's own
  31, since the rest of the 30 Hz ticks coincide with frames the desktop
  was making anyway. In all, about 19 ms of GPU per second, roughly 2%.
- With the line off, `animation_hz` is 0 and no animation frames are made.


### Amended in 0.2.33: ticks only fill gaps

Measured on the owner's machine with video playing (0.2.32):
- **With the animated effects on:** 42 presents a second, 28 of them
  animation-only, and 4 to 5 late flips a second.
- **With them off:** 14 presents a second and under one late flip.

The video's own rate did not change; that was ADR 0192's ceiling. But the
extra flips delayed real frames and the pointer.

Real frames already carry the phase, which is read from the clock on every
frame. So now:
- An output is ticked only when it has presented nothing for a whole
  period. "Presented" is read from its KMS present count, so an unchanged
  output that was skipped does not hold the clock back.
- No tick fires inside a quiet window or a Hibr frame barrier.
- The quiet-window filter no longer lets ticks through. It is the pointer's
  alone again.

`presentation_effects_gate` gains `fills_gaps_only`:
- With a pane drawing continuously and curvature on in both runs, the
  present rate with the line is at least 85% of the rate without it.
- At most 3 animation-only frames a second are made.

### Amended in 0.3.67 (2026-11-08): the rate follows the display refresh

Owner-approved. Animated effects follow the display refresh (auto, the
default) since 0.3.67.

`document.server.effects_animation_hz` is now `"auto"` or an integer from
10 to 240:
- **`"auto"`** (the default, and what an absent key means): each animated
  output ticks at its own refresh.
- **A number** is a ceiling the display can keep: each output ticks every
  Nth vblank, N = ceil(refresh / setting), so its rate is refresh / N, the
  largest rate at or below the setting that divides the refresh into whole
  vblanks. 30 on 60 Hz is 30, 50 on 60 Hz is 30, 25 on 60 Hz is 20, 120 on
  144 Hz is 72, 240 on 60 Hz is 60. N is taken from the refresh in whole
  Hz, so a measured 60.02 Hz does not count as above 60 and halve the rate.
  The tick's period is N refreshes, and the after-vblank alignment, which
  puts each tick on the vblank nearest one period on, then lands it on
  every Nth vblank. (A first cut used the lower of the setting and the
  refresh as the period: 50 on 60 Hz then ticked every refresh, 60 a
  second, while reporting 50. The coordinator rejected that before merge:
  a set rate must be one the display keeps, and `animation_hz` what
  happens.)
- Anything else is refused, like the other server settings. An unset value
  is still left out of the stored document.

**One function decides an output's rate and period,**
`output_animation_hz`. Its refresh comes from `output_shown_refresh_hz`: the mode's refresh, refined by
the measured one (`observed_refresh_hz`) only when the two agree within 2%,
as the render schedule's `kms_aligned_due` already reads it; the measured
one alone when there is no mode; 60 Hz when neither is known. The 2% guard
matters: a source whose vblank numbers do not count vblanks (the DRM mock
without a vblank period, for one) "measures" its own present rate, and a
clock built on it would chase its own ticks. The vblank alignment of a tick
reads the same refresh.

**The gap-only rule is unchanged,** per output and at that output's period:
- An output is ticked only when it has presented nothing for three quarters
  of its period.
- No tick fires inside a quiet window or a Hibr frame barrier.
- Each tick is put just after a vblank.
At 60 Hz the gap a tick needs is 12.5 ms instead of 25 ms, so content that
presents at 20–40 frames a second can now leave gaps a tick fills, where at
30 Hz it left none. `fills_gaps_only` still holds on the mock under auto
(no animation-only frames while a pane draws continuously); the effect on
real video is to be measured.

**Diagnostics.** Each output's `effects.animation_hz` is its rate (0 when
off), so auto on a 60 Hz output reports 60. `GET /v1/settings` reports the
setting in use as `effective.effects_animation_hz`, `"auto"` or the number.

**Evidence.** `presentation_effects_gate` on gles: auto gives the DRM
mock's 60 Hz and about 50–57 animation frames a second; 30 and 10 give 30
and 10; 50 reports 30 and 25 reports 20, each measured at that rate; 240 is
clamped to 60; invalid values (9, 241, `"fast"`, `"Auto"`,
`true`) are refused; the document keeps `"auto"` or the number, and an
unset key stays absent; `fills_gaps_only` passes under auto.
`tube_effects_gate`, `zoomed_effects_gate` and `burn_in_gate` assert the
clock at the display's rate. To be measured on the owner's hardware: the
CPU, GPU and power cost of 60 against 30 Hz, and late flips with video.
