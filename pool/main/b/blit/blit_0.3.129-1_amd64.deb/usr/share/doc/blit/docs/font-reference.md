# Blit font and glyph developer reference

For Hibr application, desktop and Control Panel developers. This reference
describes the font set since Blit 0.2.36 (ADR 0195). Query the running
server for the fonts it found and the one selected. Nothing here needs a
change to Hibr core.

Public reference: [github.com/osakka/blit — font reference](https://github.com/osakka/blit/blob/main/docs/font-reference.md).

**Browse:** [every Nerd glyph by category](fonts/README.md),
[Blit/Hibr special additions](fonts/special.md),
[every pinned emoji by category](fonts/emoji.md),
[exact native font coverage](fonts/coverage.json).

![Production-raster font specimen, including original colour icons](images/blit-fonts.png)

The image is rendered by Blit's production rasterizer. Glyphs in the web
tables use your browser's fonts: a missing box or different colour there
does not describe Blit's rendering. Copy names/codepoints or JSON strings,
not a screenshot of a browser glyph.

## Families and sizing

**The font list is discovered,** not fixed:
- **Outline text fonts:** any regular, monospaced TTF or OTF in the fonts
  root's `text/` folder, plus `/usr/local/lib/blit/fonts/text` for your own.
- **Ids:** a font's id is its family name in kebab form, and its title is
  the family name.
- **`GET /v1/fonts`** lists `profiles` (with `title` and
  `source: shipped|local`) and `rejected` (with each reason).

The shipped text fonts are unmodified upstream releases:

| API id | Font | Licence |
| --- | --- | --- |
| `hack` | Hack 3.003 | MIT and Bitstream Vera |
| `ibm-3270` | IBM 3270 3.0.1 | BSD-3-Clause |
| `jetbrains-mono-nl` | JetBrains Mono NL 2.304 | OFL 1.1 |
| `fira-code` | Fira Code 6.2 | OFL 1.1 |
| `ibm-plex-mono` | IBM Plex Mono 1.1.0 | OFL 1.1 |
| `spleen` | Spleen 2.2.0, five masters (6x12 to 32x64), pixel-exact at their multiples (ADR 0227) | BSD-2-Clause |
| `blit-terminus16` | Bitmap pixel font | OFL |

**Every outline font draws through one glyph stack.** Arabic letters go
to Blit Arabic Modern. Every other character takes the first of these that
has it:
1. Blit's cell geometry: box drawing, blocks, Braille, Powerline, bar
   corners and the window-chrome glyph sets.
2. Blit's own colour icons.
3. Colour emoji, for emoji presentation.
4. Nerd Fonts Symbols, for a private-use codepoint, whatever the text font
   puts there.
5. The text font.
6. Blit's monochrome text glyphs (the themed pen, runic text, wired
   indicator).
7. Nerd Fonts Symbols, for anything else.
8. Text-presentation emoji, where asked for.
9. Noto Sans Symbols 2, Noto Sans Symbols and Noto Sans Math.
10. Unifont.

Stack glyphs are fitted to the chosen font at draw time, so every font has
every glyph, including one you add. Native grayscale antialiasing
rasterizes text at the requested size.

**The pixel font** (Blit Terminus 16; Blit Spleen 16 was retired in 0.3.68
for `spleen`, ADR 0227) draws every glyph it has itself, in its own pixels,
box drawing included. The stack
supplies the rest: Blit's icons, Nerd icons, symbols, emoji and Unifont's
one-column coverage, fitted to the font's own H (ADR 0199). Wide characters
come from Blit's wide pixel font. Only a character no face has shows the
font's `?`.

`size_px` is **cell height, 8 to 64**, not point size, browser zoom or display
resolution. Read `active.cell_pixels` after changing it; never calculate
image placement from an assumed half-width cell. Resizing changes the grid
and attached PTYs. Do not change the user's font just to display one icon.
Original icons are fitted to text metrics, not stretched to fill every pixel
of a cell. Their ink bounds and terminal advance are different concepts.

`hinting` (`full`, `light`, `none`; default `full`) sets how outline text is
hinted: it changes how crisp text is at small sizes, and nothing about the
cell grid. Fitted icons and symbols, emoji and cell-geometry glyphs ignore it
(ADR 0218). Set it with `PUT /v1/fonts`; it is stored with the font.

`arabic` (`naskh`, `modern`; default `naskh`) chooses how Arabic is drawn
(ADR 0241): `naskh` shapes it as words in Noto Naskh Arabic, for every text
font including the pixel fonts; `modern` draws it cell by cell in Blit
Arabic Modern. Set it with `PUT /v1/fonts`; it is stored with the font, and
`active.arabic` reports it.

**The icon pen** is the pen of Blit's colour icons (U+100000 and up that
carry colour), and it is per cell: SGR 68:v (`1` auto, `2` black, `3`
white), ended by SGR 69 (ADR 0221). Without it an icon is drawn in its own
colours. The other pens draw its monochrome shape: black, white, or the
cell's foreground (`auto`, which follows a light or dark bar like the text
beside it). The shape is decided when the icon font is built, from the SVG:
inactive levels are left out and paths marked `data-mono="knockout"` are
cut away, so a battery's level, charging bolt and mains plug, and the Wi-Fi
bars and volume waves that are on, read by shape; the `hui` badge is a
solid disc with its letters cut out (ADR 0220). Window glyphs, controls,
text and emoji ignore the pen. So a menu bar can draw its icons in one pen
while the desktop beside it keeps them in colour.

## Choose the right category

| Need | Reference | Rendering/integration rule |
| --- | --- | --- |
| Ordinary text, punctuation and source-font scripts | [Native coverage](fonts/coverage.json) | Primary face plus established fallback; asset cmap is not a promise of script shaping |
| App actions, files, development, devices, weather, brands | [17 Nerd categories](fonts/README.md) | 10,764 names/aliases, 10,386 distinct scalars, under every font; uses terminal foreground colour |
| Branded Blit/Hibr menu icons, Wi-Fi 1–4, Bluetooth | [Original colour additions](fonts/special.md) | Explicit semantic ID/private scalar, one cell, intrinsic palette |
| Themed Hibr pen, runic text, wired indicator | [Themed text additions](fonts/special.md#themed-text-additions) | U+270E, U+16D2, U+21CC retain documented text meanings |
| Window chrome: title bars, frames, dialogs, buttons (Chalk, Slate light, Slate dark) | [Cell geometry](fonts/special.md#cell-geometry), [below](#window-chrome-glyph-sets-chalk-and-slate) | Pixel-exact cell geometry; Chalk in the foreground, Slate in its own colours; label buttons with SGR 51 |
| Powerline separators and box/block UI geometry | [Powerline](fonts/pl.md), [Extras](fonts/ple.md) | Core U+E0B0..E0B3 use cell-fitted geometry; do not extend that guarantee to every Extra; box/half-block geometry is protected |
| Arabic and Arabic-Indic digits | [Arabic section below](#arabic-and-arabic-indic-numerals) | Native companions, shared baseline, existing Hibr visual ordering |
| Faces, people, nature, food, objects, symbols, flags | [Emoji categories](fonts/emoji.md) | Colour/text presentation and multi-scalar layout are distinct from Nerd icons |

Nerd `custom-*` names belong to the pinned upstream Nerd catalogue; they are
**not** the new original Blit private-use namespace. Multiple names can map
to the same character. Use the complete name and pinned version when
resolving a Nerd symbol; do not infer a scalar from an icon's label.

## Special additions: the application contract

The authoritative mapping is [icons/catalogue.json](../assets/fonts/icons/catalogue.json),
also served unchanged by authenticated `GET /v1/fonts/icons`.
[The generated table](fonts/special.md) gives every ID, codepoint and valid
JSON escape. Keep application choices semantic: `hibr-pen`, `wifi-signal-1`
through `wifi-signal-4` and `wifi-off` (Wi-Fi: a dot and three arcs, a cross when
off; in two columns `wifi-signal-wide-1-left` + `-right` through `wifi-signal-wide-4-left` + `-right`
and `wifi-off-wide-left` + `-right`), `cellular-1` through `cellular-4` (the mobile signal's four bars), `bluetooth`, `blit`, `battery-0` through `battery-4`,
`battery-0-charging` through `battery-4-charging`, `battery-ac` (lying in two columns
`battery-wide-0-left` + `-right` through `battery-wide-4-left` + `-right`,
`battery-wide-0-charging-left` + `-right` through `battery-wide-4-charging-left` + `-right`
and `battery-wide-ac-left` + `-right`), and
`volume-0` (muted) through `volume-3` (in two columns `volume-wide-0-left` + `-right` through
`volume-wide-3-left` + `-right`), `power`, `phone-off`, `phone-wait`,
`phone-on`, `phone-ring`, their classic counterparts `phone-classic-off`
through `phone-classic-ring` (in two columns `phone-classic-wide-off-left` + `-right`
through `phone-classic-wide-ring-left` + `-right`), the file
icons (`file-<kind>-<colour>-left` + `-right`, ADR 0201), `hui-left` +
`hui-right` (the badge: white letters on a teal disc) and `hui-mark-left` +
`hui-mark-right` (the H-U-i monogram, no disc), and `wiretap-left` + `wiretap-right`
(a water tap with a drop: wiretap on) and `wiretap-off-left` + `wiretap-off-right`
(the tap, no drop: off), and their one-column forms `wiretap-1` (on) and
`wiretap-1-off` (off). Resolve those IDs from the catalogue
instead of maintaining an independently numbered table in every application.

**`wifi-1` through `wifi-4` are deprecated (0.3.55).** The four bars are the
mobile signal, so they are named `cellular-1` through `cellular-4` (U+1002D6–1002D9,
the same drawing at each level); each `wifi-N` entry carries `deprecated: true`
and `replaced_by: ["cellular-N"]`, and Blit still draws it, unchanged, until a
release retires it. Deprecated, not retired: a deprecated id never names a
different picture. Wi-Fi itself is `wifi-signal-1` through `wifi-signal-4`
(U+1002D1–1002D4) and `wifi-off` (U+1002D5).

**One icon says the whole state.** The charging bolt and the mains plug are
drawn inside the battery, so a status bar shows one glyph per state, never a
mark beside a level.

**A badge two columns wide is two codepoints.** Write `hui-left` then
`hui-right` side by side (or `hui-mark-left` then `hui-mark-right`): each is
one column, and each draws its half of one badge (ADR 0197).

Icons and symbols are fitted to the cell at every size from 8 to 64 px
without trimming (ADR 0215): a colour icon is fitted by the layers it draws
(so the Wi-Fi bars and the volume waves, not just their first layer), a
spanning icon is drawn unhinted so its halves join, and a glyph that cannot
be fitted is shown as the fallback, never cut.

Every original uses **one terminal column** in every font.
They are plane 16 private-use scalars, not standard Unicode, ordinary emoji,
or portable assignments in an unrelated font. In particular:

- U+270E `✎` is the themed pen silhouette; it is not the multicolour pen.
- U+16D2 `ᛒ` is Berkanan, not the new Bluetooth drawing.
- Wi-Fi is `wifi-signal-1`..`wifi-signal-4` and `wifi-off` (0.3.55); the
  older `wifi-1`..`wifi-4` are deprecated, replaced by `cellular-1`..`-4`.
- Intrinsic-colour artwork keeps its palette; ordinary Nerd icons follow
  foreground colours. A truecolour terminal alone does not imply colour-font
  glyph support or these private mappings.

Use normal UTF-8 output. Do not send the visible text `U+100001`, treat a
supplementary character as two terminal cells, or append VS16 to a private
icon in an attempt to enable colour. JSON uses a surrogate pair for a
supplementary scalar; the generated table includes valid strings. For example,
U+100000 is `"\udbc0\udc00"`, not the invalid six-digit escape `"\u100000"`.

## Window chrome glyph sets: Chalk and Slate

ADR 0210 and 0211. 70 glyphs at U+100231–100276 draw retro Mac-style
window chrome out of cells. They are two sets of 35 in one order (Chalk,
Slate), listed in the catalogue's `cell_geometry` section as
`chalk-<name>` and `slate-light-<name>`. U+100277–100299, once Slate dark,
are retired.
- **A set per part.** Each part (title bar, frame, dialog border, button
  ends) takes its glyphs from whichever set the application picks for it,
  so the sets mix: a Slate title bar on a box-drawing frame, a Chalk title
  bar on a Slate frame. Every set has the same geometry, so parts from
  different sets meet at the same rows and columns.
- **Chalk** is one colour: the cell's foreground over its background, so a
  theme recolours it.
- **Slate** is the same geometry in the cell's pens. Each pixel is one of:
  - **the foreground:** lines and outlines;
  - **the underline colour (SGR 58, white if unset):** the bar's
    highlights, box faces, and a dialog's and a button's face;
  - **half the foreground and half the background, each channel:** the
    stripes and shades;
  - **the cell's background:** the bar.
  One set therefore serves light and dark schemes alike. The Pewter
  scheme (bar 214, ink black, SGR 58 white) draws 0.3.38's Slate light
  except for those half-and-half pixels.
- **The background shows wherever a glyph draws nothing.** On a held
  desktop that is the wallpaper, right up to the frame's line.
- **No shadow in the glyphs.** The frame and dialog pieces draw only their
  lines and borders, so `frame-right-top` draws as `frame-right` and
  `frame-bottom-first` as `frame-bottom`; both keep their codepoints. A
  drop shadow is SGR 66, which Blit draws under any glyph (see [the
  terminal reference](terminal.md#sgr)).
- They are pixel-designed for an 11x22 cell. At every size, lines,
  stripes and SGR 51 are 1 px, the dialog border's layers are 2/3/1/1 px
  and the default ring is 3 px. The boxes stay as wide as the cell, the
  stripes keep their proportion of the bar and a button's ends their
  roundness. Neighbouring cells always join.
- **A title** is text on the bar's background, framed to match the bar.
  Chalk uses SGR 51, which draws the frame line and the rule. Slate uses
  SGR 51:2, which also draws the bar's highlight and shade rows in the
  cell's pens. `stripe-before-title` and `stripe-after-title` stand either
  side.
- **A button** is `button-left`, the label with SGR 51 on the button's
  face, and `button-right`. A default button is `default-button-left`, the
  label with SGR 51:3, and `default-button-right`. Set the label's SGR 58
  to the ring's colour (the foreground of the caps). Slate's caps sit on
  the dialog's face (their background), with SGR 58 set to the button's
  face, which they paint inside the ring: the corners outside the ring
  show the dialog's face. The shade down and right is half the foreground
  and half that face. Chalk's caps and label share one background.
- **A dialog** is the `dialog-*` border round its content cells.
  - **Slate:** the frame cells keep the wallpaper as their background and
    set SGR 58 to the dialog's face, which the margin and gap paint. The
    3 px line is solid foreground. Nothing is drawn beyond the 7 px
    border, so there is no halo.
  - **Chalk,** being one colour, leaves its margin and gap transparent,
    so its frame cells take the dialog's face as background and the face
    shows round the border. For a black-and-white dialog with no halo, use
    the Slate glyphs with a black foreground and SGR 58 white.

## Window frame: one frame, its line on the outer edge

ADR 0214. 13 glyphs at U+1002AE–1002BA are the window frame as the owner
wants it: **one frame, and its line sits on the outermost edge of each
frame cell** (the left cell's left edge, the right cell's right edge, the
bottom row's bottom edge). Nothing else in the cell is drawn, so the cell's
own background is the padding: set the frame cells' background to the
window's face and the face runs out to the line.

| Glyph | Codepoint | Put it | Pens |
| --- | --- | --- | --- |
| `frame-left` | U+1002AE | left of each body row | fg = the line |
| `frame-right` | U+1002AF | right of each body row | fg = the line |
| `frame-bottom-left` | U+1002B0 | bottom-left corner (left and bottom lines) | fg = the line |
| `frame-bottom` | U+1002B1 | the bottom row | fg = the line |
| `frame-bottom-right` | U+1002B2 | bottom-right corner (right and bottom lines) | fg = the line |
| `chalk-title-end-left`, `-right` | U+1002B3, U+1002B4 | the title row's end cells | fg = the ink, bg = the bar |
| `slate-light-title-end-left`, `-right` | U+1002B5, U+1002B6 | the title row's end cells | bg = the bar, fg = the ink, SGR 58 = the highlight |
| `chalk-title-end-plain-left`, `-right` | U+1002B7, U+1002B8 | the inactive title row's end cells (no stripes) | fg = the ink, bg = the bar |
| `slate-light-title-end-plain-left`, `-right` | U+1002B9, U+1002BA | the inactive title row's end cells (no stripes) | bg = the bar, fg = the ink, SGR 58 = the highlight |

- **One frame set.** Chalk's and Slate's frame glyphs were the same 1 px
  foreground line, so the frame cells are one set (catalogue `set: frame`,
  coverage in the foreground). The right-hand cell of the title row is not
  `frame-right`: it is a title-end glyph.
- **A title-end cell is the title bar's end.** It carries the outer line, the
  bar's top line and rule (Slate: its bevel rows too), and **the stripes run
  into it**, starting (left) or stopping (right) 2 px from the cell's outer
  edge: the line and one clear pixel. They join the next cell's stripes at
  every cell size. Chalk's are coverage; Slate's use the cell's pens as the
  Slate bar glyphs do. The **plain** title ends (0.3.44) are the same cells
  without stripes, for the inactive bar: they sit beside the plain `title`
  cells and join them at every size. `stripe-first` and `stripe-last` are redundant.
- **The shadow is unchanged** (SGR 66, ADR 0211), but goes in the cells
  beyond the frame cells with **inset 0** (`66:kind:width:0`), so its strip
  begins at the pixel next to the frame's line.
- **Deprecated, not retired.** The window sets' `frame-left`,
  `frame-right-top`, `frame-right`, `frame-bottom-left`,
  `frame-bottom-first`, `frame-bottom`, `frame-bottom-right`, and
  `stripe-first`, `stripe-last` (Chalk and Slate: 18 glyphs) are marked
  `deprecated: true` with `replaced_by` in the catalogue and in
  [the special-glyph table](fonts/special.md). Blit still draws them,
  unchanged, until a later release retires them. The dialog, note and
  `frame-top-*` glyphs are not affected.

## Pressed boxes and the grow box

ADR 0219. 10 glyphs at U+1002BB–1002C4, five a set, Chalk's then Slate's:
the title bar's three boxes **pressed**, and the window's **grow box** (the
resize corner), normal and pressed.

| Glyph | Codepoint | Put it | Pens |
| --- | --- | --- | --- |
| `chalk-close-pressed`, `-shade-pressed`, `-zoom-pressed` | U+1002BB–1002BD | in place of `chalk-close`, `-shade`, `-zoom` while the box is pressed or hovered | fg = the ink, bg = the bar |
| `chalk-grow`, `chalk-grow-pressed` | U+1002BE, U+1002BF | the window's bottom-right cell, in place of `frame-bottom-right` | fg = the ink, bg = the window's face |
| `slate-light-close-pressed`, `-shade-pressed`, `-zoom-pressed` | U+1002C0–1002C2 | in place of `slate-light-close`, `-shade`, `-zoom` | bg = the bar, fg = the ink, SGR 58 = the highlight |
| `slate-light-grow`, `slate-light-grow-pressed` | U+1002C3, U+1002C4 | the window's bottom-right cell | bg = the window's face, fg = the ink, SGR 58 = the highlight |

- **Hover is pressed.** There is one set of states: draw the pressed glyph
  for a box the pointer is over or holding, the normal one otherwise.
- **Chalk pressed** is the box solid in the foreground with its mark cleared
  out, so the cell's background shows through it: close an X (7x7 at 11 px),
  zoom a square outline (6x6, one clear pixel inside the border, in the
  top-left), shade three bars (box rows 3, 5 and 7).
- **Slate pressed** is the mix pen inside the box, the unpressed bevel
  inverted (the foreground pen on the inner top and left, the line pen on the
  inner bottom and right), and the mark in the foreground pen, about 5 px.
- **The grow box** is an 11x11 square at the bottom of the cell (rows 11–21
  at 11x22). Its right and bottom edges are the frame's own outer lines, so
  the cell is the bottom-right corner of the frame (ADR 0214) with the box
  in it: put it where `frame-bottom-right` goes. Inside, a `/` hatch with a
  4 px period. Chalk: black lines. Slate: each a mix-pen line with a
  line-pen line beside it. Pressed (dragging): Chalk is solid with the hatch
  cleared out, Slate the mix pen with a foreground hatch.
- At other cell sizes the box is the title bar's box (the band's square) and
  the marks and hatch keep their pixel widths.

## The minimise box

ADR 0222. 4 glyphs at U+1002CD–1002D0, two a set, Chalk's then Slate's: a
**minimise** box for the title bar, beside close, shade and zoom, normal and
pressed.

| Glyph | Codepoint | Put it | Pens |
| --- | --- | --- | --- |
| `chalk-minimise`, `chalk-minimise-pressed` | U+1002CD, U+1002CE | in the title bar as a box; the pressed one while it is pressed or hovered | fg = the ink, bg = the bar |
| `slate-light-minimise`, `slate-light-minimise-pressed` | U+1002CF, U+1002D0 | the same, in Slate | bg = the bar, fg = the ink, SGR 58 = the highlight |

- **The mark** is a short 1 px bar along the bottom of the box (the classic
  minimise `_`): 5 px on the box's row 8 at 11 px, centred, one clear row
  above the border. Shade's bar runs across the middle and zoom's square sits
  top-left, so the three read apart.
- **Pressed** is ADR 0219's pressed box: Chalk solid with the bar cleared
  out (the same 5 px); Slate the mix pen, the bevel inverted and a 3 px bar
  in the foreground on box row 7.
- Put it beside the other boxes with `stripe-to-box`, `stripe-between` and
  `stripe-from-box`, as they are.

## The full-screen and sticky boxes

ADR 0224. 10 glyphs at U+10030A–100313: a **full-screen** box, normal and
pressed (U+10030A–10030D, two a set), and a **sticky** box, normal, pressed
and on (U+10030E–100313, three a set), Chalk's then Slate's in each, for the
title bar beside close, minimise, shade and zoom.

| Glyph | Codepoint | Put it | Pens |
| --- | --- | --- | --- |
| `chalk-fullscreen`, `chalk-fullscreen-pressed` | U+10030A, U+10030B | in the title bar as a box; the pressed one while it is pressed or hovered | fg = the ink, bg = the bar |
| `slate-light-fullscreen`, `slate-light-fullscreen-pressed` | U+10030C, U+10030D | the same, in Slate | bg = the bar, fg = the ink, SGR 58 = the highlight |
| `chalk-sticky`, `chalk-sticky-pressed`, `chalk-sticky-on` | U+10030E–100310 | in the title bar as a box; pressed while it is pressed or hovered; on while the window is sticky | fg = the ink, bg = the bar |
| `slate-light-sticky`, `slate-light-sticky-pressed`, `slate-light-sticky-on` | U+100311–100313 | the same, in Slate | bg = the bar, fg = the ink, SGR 58 = the highlight |

- **The box** is the minimise box's: the close box, its mark area the box
  less the border and a 1 px gap (7x7 at 11 px).
- **Full screen:** four corner brackets, one in each corner of the mark
  area, each two arms a third of the area long (2 px at 11 px): the window
  reaching to the edges. Nothing in the middle, so it is neither zoom's
  square nor close's X.
- **Sticky:** a pin, centred: a round head about half the area across (3x3
  at 11 px) on a 1 px stem half as long (2 px).
- **Sticky on** (the window is sticky; not being pressed): the unpressed box
  with the pin bold, every pixel beside it in the mark area inked too (the
  head 5 px across, the stem 3). It is apart from normal by its weight and
  from pressed by the face, which stays the unpressed box's.
- **Pressed** is ADR 0219's pressed box, as minimise's: Chalk solid with the
  mark cut out; Slate the mix pen, the bevel inverted and the mark in the
  foreground in a 5x5 area.
- Put them beside the other boxes with `stripe-to-box`, `stripe-between`
  and `stripe-from-box`, as they are.

## Controls: checkbox, switch and capsule

ADR 0212. 20 glyphs at U+10029A–1002AD draw controls out of cells, in the
same roles as the window chrome, listed in the catalogue's `cell_geometry`
section. The next free codepoint is U+100495 (the outer-edge frame, below,
is U+1002AE–1002BA, the pressed boxes and grow box U+1002BB–1002C4, the
hui mark, a colour icon, U+1002C5–1002C6, the wiretap icons, on and
off, U+1002C7–1002CA, their one-column forms U+1002CB–1002CC, and the
minimise box U+1002CD–1002D0, then the Wi-Fi signal and cellular icons
U+1002D1–1002D9, the two-column Wi-Fi and volume icons U+1002DA–1002EB,
the two-column classic phones U+1002EC–1002F3, the two-column batteries
U+1002F4–100309, the full-screen and sticky boxes U+10030A–100313, and the
player glyphs of ADR 0237: LCD digits U+100314–10035E, LED meters
U+10035F–100372, sliders U+100373–100377, faders U+100378–10037C,
transport U+10037D–1003A0, discs, records and cassettes U+1003A1–1003D0,
keys U+1003D1–1003D4, and the big discs U+1003D5–100494).
- **Checkbox,** one cell: an 11x11 square on the text row (as the window
  boxes), in Chalk and Slate, off, on and mixed (`chalk-check-off`, `-on`,
  `-mixed`; `slate-check-*`). Chalk: a plain 1 px square, an X when checked,
  a dash when mixed. Slate: an outline, a face (SGR 58), a shade down and
  right (the mean of foreground and background), a 2 px check mark, a
  heavier dash.
- **Compact switch,** two cells wide (22x11), written side by side: left
  then right, off and on, in Chalk and Slate (`chalk-switch-off-left`,
  `-off-right`, `-on-left`, `-on-right`; `slate-switch-*`). Chalk: a ring
  and a solid knob on the left when off, a solid track with an empty knob on
  the right when on. Slate: a bevelled track with a knob in SGR 58, a mixed
  grey track when on.
- **Capsule switch,** three cells wide (33x22), left, middle and right, off
  and on (`capsule-off-left`, `-off-mid`, `-off-right`, `-on-*`). It has no
  outline and no colour of its own: the track is the cell's **foreground**
  (green when on, grey when off: the application chooses), the knob SGR 58
  (white), the smoothed edge the mean of the foreground and background.
  It scales with the cell's height; the checkbox and switch scale as the
  window boxes do. At a 4x8 cell the checkbox's *on* and *mixed* are the
  same pixel.
- **Pens to set,** for every cell-geometry glyph, are in the catalogue as
  data (`part`, `cells`, `background`, `foreground`, `line`) and described in
  [the icon contract](../assets/fonts/icons/README.md): a control's cells sit
  on the panel; Slate's checkbox sets SGR 58 to its face, its switch to the
  knob; the capsule sets the foreground to the track's colour and SGR 58
  white.

## Player glyphs: LCD digits, LED meters, sliders, transport, discs

From 0.3.126 ([ADR 0237](adr/0237-player-glyphs.md)), for a music player or
any program that wants an instrument's face. Their ids and codepoints are in
the catalogue (`GET /v1/fonts/icons`) and [special additions](fonts/special.md).

- **LCD digits** are drawn in the cell's foreground (choose the LCD's
  colour with it); unlit segments are faint. A big digit is four cells,
  `lcd-big-<c>-tl` `-tr` on one row and `-bl` `-br` below; a small digit
  two cells, `lcd-<c>-left` `-right`; `<c>` is `0`-`9`, `minus` or `blank`
  (all segments faint). `lcd-big-colon-t`/`-b` and `lcd-colon` are one cell.
  So `04:51` in big digits is 9 columns by 2 rows.
- **LED meters**: `led-h-<n>` holds two LEDs, `n` of 8 steps lit from the
  left; a bar of 20 cells has 160 steps. `led-v-<n>` holds four, lit from
  the bottom. Colour each cell (green, yellow, red); `led-peak-h`/`-v` mark
  a peak.
- **Sliders and faders**: `slider-cap-left`, then `slider-track-filled`
  up to the knob, `slider-knob`, `slider-track` after it, `slider-cap-right`;
  faders the same top to bottom with `fader-*`.
- **Transport**: `transport-<name>` in one cell, `transport-wide-<name>-left`
  and `-right` in two; in the text colour.
- **Keys** (0.3.127): `key-left`, the icon cells, `key-right`, on one row.
  Set the key's face as the background (SGR 48) on all its cells, the light
  edge and icon as the foreground, the dark edge as SGR 58. Give the icon
  cells SGR 51:6 (raised) or 51:7 (pressed, the icon 1 px lower), ended by
  SGR 54, and use `key-pressed-left`/`-right` for a pressed key's ends.
- **Now playing**: `disc-<f>`, `vinyl-<f>`, `cassette-<f>`, each `-left` and
  `-right`, in their own colours; step `f` 0-7 while playing, 0 when stopped.
  Bigger (0.3.127): `disc-big-<f>-r<row>c<col>` and the same for `vinyl` and
  `cassette`, four cells by two rows, `r0c0`-`r0c3` on one row and
  `r1c0`-`r1c3` below.

## Discover first; retain a fallback

Read-only discovery (the update credential is not needed):

```sh
curl --fail-with-body "$BLIT_URL/v1/fonts" \
  -H "Authorization: Bearer $BLIT_AUTH_TOKEN"
curl --fail-with-body "$BLIT_URL/v1/fonts/icons" \
  -H "Authorization: Bearer $BLIT_AUTH_TOKEN"
```

Recommended integration sequence:

1. Read the selected font from `active.id`. The catalogue's `profiles` is
   `["*"]`: the originals come from the glyph stack, so every font has them.
   `available` on an inactive profile does not mean it is selected.
2. Fetch the catalogue, check `version`, and resolve the exact semantic ID.
   Parse hexadecimal `codepoint` into a Unicode scalar; emit UTF-8. Respect
   catalogue `columns` for these icons, not UTF-8 byte/UTF-16-unit length.
3. If the route is not Blit, the active font is unsupported, discovery fails
   or a version/ID is unknown, retain the application's Nerd/Unicode/ASCII
   fallback. Do not change the global font or equate terminal name with
   capability discovery.
4. Cache discovery for the connection, then invalidate after reconnect or a
   font/profile change. Do not poll the catalogue on every repaint.

`GET /v1/fonts/icons` returning 503 `font_icon_catalogue_unavailable` is a
diagnostic condition, not an empty successful catalogue. A 404 on an older
server means the client should retain its fallback. Future catalogue versions
must be checked, not assumed compatible.

For a language-independent implementation, the essential conversion is:

```python
entry = next(i for i in catalogue["icons"] if i["id"] == "hibr-pen")
character = chr(int(entry["codepoint"], 16))
# Write character as UTF-8 through the application's normal terminal path.
```

This illustrates scalar conversion, not a Hibr API or a replacement for its
UI/glyph abstraction. Installing the font does not change the icons an
application already chooses.

## Arabic and Arabic-Indic numerals

Every outline text font attaches the one Arabic companion, Blit Arabic
Modern, automatically, and under the default `arabic: "naskh"` every text
font, pixel fonts included, also attaches the word face, Noto Naskh Arabic.
Inspect `active.arabic_companion` for the loaded family/path, shared
`baseline_px` and `shaping`: `"words"` with `words_family`/`words_path` when
the word face is attached, else `"visual-cell-marks"`. Each profile reports
`arabic_companion_path`, null for the pixel fonts; a pixel font's
`active.arabic_companion` has a null `path` and `family` under `naskh` and
is null under `modern`.
Primary `glyphs`/`mappings` counts describe the PSF fallback, not total
coverage.

The requested Arabic-Indic/Hindi numerals are **`٠١٢٣٤٥٦٧٨٩`**, U+0660..0669.
They are separate from Western `0123456789`, U+0030..0039; Devanagari digits
are not the same set. Core specimens include `حِبْر`, vocalized Bismillah,
lam-alef variants, greetings and mixed numeral sets.

Hibr already emits visual-order presentation forms. Blit preserves their
cell allocation and uses OpenType cell-local mark positioning; **do not apply
a second bidi pass or reverse the text again**. Blit is not an implicit
paragraph bidi/shaping engine for arbitrary clients. Diacritics and joining
ink may extend beyond a cell while the advance remains unchanged.

[View the actual shared-raster Arabic specimen](images/blit-arabic-candidates.png).
The [captured logical/visual corpus](../assets/fonts/arabic-specimens.json)
is finite; neither the corpus nor raw companion cmap coverage guarantees all
Arabic, Quranic annotations or religious ligatures. The corpus's original
acceptance annotations are historical; current implementation evidence is in
the [verification ledger](verification-status.md) and [ADR 0174](adr/0174-arabic-companion-rasterization.md).

## Emoji: characters, presentation and sequences

The [complete categorized reference](fonts/emoji.md) lists all 5,244 pinned
Emoji 18.0 test entries: 3,972 RGI entries plus 1,272 qualification variants.
Each row includes the complete scalar sequence, JSON string and qualification,
not just its first visible character. Group and subgroup names come from
the Unicode corpus, not a second Blit classification system.

Noto Color Emoji 2.057 supplies intrinsic colour; Noto Emoji 3.002 supplies
text-presentation outlines. VS15 U+FE0E requests text and VS16 U+FE0F requests
emoji presentation for supported sequences. ZWJ, modifiers, regional-indicator
flags, keycaps and tags are multi-scalar clusters, not individual Nerd glyphs.

Scalar layout remains the compatibility default. An application deliberately
using cluster layout must follow the [explicit emoji layout API](api.md#explicit-emoji-cell-layout),
including owner/continuation cells and width. Do not switch the existing Hibr
desktop's layout policy globally to make an icon work. Font/corpus coverage,
browser appearance and passing local raster tests are not universal terminal
or physical conformance guarantees; internal issue #110 tracks the rest.

## Machine-readable sources and reproducibility

- [Original icon catalogue](../assets/fonts/icons/catalogue.json): stable
  semantic IDs, profile compatibility, one-cell allocation and signal levels;
  served by the existing discovery endpoint.
- [Pinned Nerd glyph names](../assets/fonts/nerd-glyphnames-v3.4.0.json): all
  names, aliases, scalar hex and UTF-8 characters; not a new HTTP endpoint.
- [Generated native coverage](fonts/coverage.json): exact SHA256 and inclusive
  scalar ranges from each native font's best Unicode cmap. This is asset
  coverage, not runtime routing, fallback, ink or shaping conformance.
- [Font provenance](../assets/fonts/fonts.source.json),
  [Arabic provenance](../assets/fonts/arabic-fonts.source.json),
  [Emoji corpus](../assets/unicode/emoji-18.0/source.json), and
  [Hibr UI snapshot](../assets/fonts/hibr-ui-glyphs.json). The latter is
  generated from a Hibr release's wm/glyphs.hibr by
  `tools/fonts/snapshot-hibr-ui.py` (the release and the file's hash
  recorded in it; `hibr_ui_glyphs_gate.sh` checks it against the newest
  Hibr release), not every application.

The tables are generated, not another editable glyph registry:

```sh
# The pinned fontTools 4.60.1 the font builders use (tools/fonts/fonttools.sh)
PYTHONPATH=$(tools/fonts/fonttools.sh) python3 tools/fonts/build-reference.py
PYTHONPATH=$(tools/fonts/fonttools.sh) python3 tools/fonts/build-reference.py --check
ruby tools/tests/font_reference_gate.rb
```

The generator verifies pinned input hashes, and that the glyph stack covers
the full Nerd catalogue and the original icons. Regenerate and commit
derived tables together when canonical assets change. No host fonts, network or running display are
needed. Repository Markdown on [GitHub](https://github.com/osakka/blit) is the
public publication format. Use repository-relative file links within the
guide and GitHub `blob/main` URLs when sharing it externally. Internal Gitea
addresses are for engineering workflow, not public publication. A future
site should consume the same files rather than introduce a parallel catalogue.

## Licences and attribution

Keep [font notices](../assets/fonts/README.md), [Nerd family attribution](../assets/fonts/licenses/nerd-v3.4.0/README.md),
[original-art MIT licence](../assets/fonts/icons/LICENSE.txt), and
[Unicode data licence](../assets/unicode/emoji-18.0/LICENSE.txt) when redistributing
the respective material. Each text font's licence is in `licenses/`. Arabic
Modern is GPLv3+ with the documented font-embedding exception and preferred
source included; Unifont is used under the OFL 1.1.
Typeface, source-art and trademark rights are distinct. Inclusion of a brand
glyph does not grant permission to use its trademark.
