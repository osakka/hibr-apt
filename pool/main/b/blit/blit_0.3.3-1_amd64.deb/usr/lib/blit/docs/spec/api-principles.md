# API and schema principles

The schema is the single source of truth for the public contract. There must
be one semantic implementation behind all supported transports and generated
bindings. A transport adapter, client SDK, or renderer may translate the
contract, but may not redefine it.

## Schema-first workflow

The schema is the source of truth for the public contract:

1. Define or change resources, commands, events, and errors in the schema.
2. Review compatibility, examples, and behavior in documentation.
3. Generate protocol types, validators, and reference material.
4. Implement server behavior and conformance tests.
5. Version the schema and record a decision for breaking changes.

Generated code must not become the canonical place where API behavior is
defined.

## Required contract concepts

The initial schema should eventually cover:

- server identity, API version, and capabilities;
- graphics cards, render capabilities, displays, modes, topology, hotplug, and
  presentation state;
- audio devices, formats, routing, and playback/capture capabilities;
- keyboard, pointer, seat, focus, and input-route resources;
- gamepad devices and raw timestamped button/axis input events;
- terminal sessions, PTY lifecycle, flow control, and process identity;
- canvases, surfaces, layers, and z-order;
- bounded graphic overlays and their composition policy;
- text cells, styles, cursor state, and incremental updates;
- effect definitions, parameters, presets, and effect graphs;
- input devices, focus, routing, and input events;
- frame requests, acknowledgements, timing, and damage;
- bounded binary pixel-frame streaming with explicit frame boundaries,
  back-pressure, and presentation receipts;
- subscriptions, event sequencing, and replay/resynchronization;
- typed errors and diagnostic details;
- authentication, authorization, and client leases.

## Compatibility rules

- Every request, response, event, and error has an explicit version.
- Unknown fields must be safely ignorable where possible.
- Enum evolution must define the unknown-value behavior.
- Resource identifiers are opaque to clients.
- Mutations support idempotency keys when retries could duplicate effects.
- Events carry a sequence or revision so clients can detect gaps.
- Capability discovery precedes use of optional features.
- A schema change is breaking only when an existing valid client can no longer
  safely interpret or complete its operation.

## Transport independence

The schema defines messages and semantics, not sockets, ports, framing, or
serialization libraries. Candidate transports may include a Unix-domain local
transport and a network transport, but those are implementation decisions until
their security and operational requirements are documented.

## Error model

Errors should distinguish at least:

- malformed or schema-invalid requests;
- unsupported capability or effect;
- stale revision or conflicting mutation;
- authorization failure;
- unavailable output or display resource;
- renderer or presentation failure;
- rate, memory, or frame-budget exhaustion.

Each error should include a stable code, human-readable context, and enough
structured detail for a client to recover without parsing prose.

## Determinism and effects

Effects should accept an explicit time/frame context when reproducibility is
important. The schema should distinguish static parameters from runtime inputs
such as elapsed time, frame number, noise seed, and display scale. Presets are
named schema resources rather than undocumented renderer constants.

## Current contract decisions

OpenAPI 3.1 in `openapi/blit-0.1.yaml` is the canonical HTTP contract.
JSON is the request/response encoding, and WebSocket is the streaming
transport described by the `x-blit-stream` extension in that same document.
Terminal text crosses the PTY boundary as UTF-8 and is represented internally
as revisioned cells. Multi-output frame atomicity is defined at the scene
commit boundary; physical scanout timing remains a capability/evidence
question, not an excuse to weaken the state contract. Bitmap assets are
supported only through explicitly bounded overlay/pixel-frame resources.

Future transport or encoding additions must preserve these resource semantics,
be added to the schema and API guide together, and receive an ADR when they
change compatibility or ownership.
