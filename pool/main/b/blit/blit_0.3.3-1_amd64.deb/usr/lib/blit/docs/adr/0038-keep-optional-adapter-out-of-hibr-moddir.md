# ADR 0038: Keep the optional Blit adapter outside Hibr's module directory

Status: accepted; integration-path statement amended by ADR 0069 and ADR0168

## Context

The ordinary Hibr desktop uses `need display` and must select Hibr's native
console provider. Blit's `console-blit` provider is an optional transport
adapter for explicitly controlled standalone/provider sessions. Installing it
in Hibr's module search directory made the provider discoverable during the
ordinary desktop startup. The resulting live desktop attempted to flush
large cell batches through the optional adapter, producing empty HTTP responses,
stale revisions, and a visibly corrupted display.

## Decision

The Debian package installs `console-blit.so` under
`/usr/lib/blit/hibr/console-blit.so`, outside Hibr's module search directory.
The Blit-owned adapter entrypoint loads that file explicitly and loads Hibr's
`pty`, `term`, and `hold` modules from the external Hibr installation.

The canonical native-provider test path remains `/usr/bin/desktop` with
`surface_mode: terminal`; it does not load `console-blit`. The packaged Blit
held-desktop path is now the explicit `/usr/share/blit/hibr/blit-session.hibr`
entrypoint, which loads the adapter by absolute path as specified by ADR 0069.
The current held-desktop path is native terminal-provider (ADR0168); the
API adapter is opt-in only. Earlier API-provider integration statements above
are historical, not instructions to inject it into ordinary child shells.
Hibr source and installed Hibr modules remain outside Blit's ownership
boundary.

## Consequences

This removes provider-name collision from the normal desktop path. Provider
tests must invoke the Blit entrypoint explicitly and must verify its adapter
ABI against the exact Hibr checkout. Package tests must assert that the
optional adapter is not installed below `/usr/lib/hibr`.
