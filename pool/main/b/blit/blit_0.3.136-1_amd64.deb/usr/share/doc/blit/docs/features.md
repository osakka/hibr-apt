# Blit features

Everything Blit does, in one place. Each row says when it arrived, which
decision record explains it (`docs/adr/NNNN-*.md`), and how far it has been
proved:

- **Used** — running on the owner's machine and seen working there.
- **Tested** — covered by the automated suites (`tools/run-gates.sh`, or
  the release build's own gates in `tools/release/build-release.sh`), not
  yet confirmed on real hardware.
- **Hardware pending** — tested, and waiting for a device we do not have
  to hand (stated in the row).
- **In development** — partly built and gated, not released or not yet
  complete (the row says what exists and what does not).

The [verification ledger](verification-status.md) has the evidence for each
release. What is not here yet is in the [roadmap](roadmap.md).

## Displays

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Drives monitors directly through Linux DRM/KMS: no X11, Wayland or SDL | 0.1 (only path since 0.2.22) | 0004, 0184 | Used |
| Frames composed on the GPU with OpenGL ES (Mesa, loaded at run time); the default since 0.3.11 | 0.2.9 | 0181 | Used |
| The CPU compositor, when chosen | 0.2.9 | 0181 | Used |
| If the GPU cannot be used, the CPU composes instead, with the reason reported | 0.2.9 | 0181 | Used |
| A GPU start that crashes falls back to the CPU for the next start | 0.2.10 | 0181 | Used |
| Only changed areas are recomposed and uploaded | 0.2.11 | 0181 | Used |
| Each monitor refreshes at its own rate, fractional rates kept; nothing is drawn while idle | 0.1.533 | 0006, 0119 | Used |
| Frame timing: compose immediately, or late (just before refresh) for lower latency | 0.2.20 | 0183 | Used |
| Several monitors, each presented independently | 0.1 | 0043, 0131 | Used (two outputs) |
| Monitors plugged in or out while running are picked up | 0.1.544 | 0130 | Hardware pending (a third monitor) |
| Each monitor split into a grid of panes, 1–8 columns × 1–8 rows | 0.1.545 | 0131 | Used |
| A pane with a running program cannot be removed by a layout change | 0.1.545 | 0131 | Tested |
| Text grid centred in each pane, whole rows only | 0.1.536 | 0075, 0123 | Used |
| Display list with modes, size, refresh and connector | 0.1 | 0064 | Used |
| Backlight brightness (laptops with one panel) | 0.1.456 | 0064 | Hardware pending (a laptop panel) |
| Pixel zoom per monitor (100–400% in 25% steps, kept per connector): the whole display magnified, pointer and panel kept normal size | 0.3.26 | 0204 | Tested |
| Screenshots of what is on screen, read back from the GPU | 0.1; GPU 0.2.13 | 0105 | Used |
| Overlays placed by API clients | 0.1 | 0002 | Tested |

## Terminal

The complete list of escape sequences is in the [terminal reference](terminal.md).

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| A terminal session is `running` from its program's start, silent or not, then `stopped` or `failed` (no `starting` until a first byte; #155) | 0.3.99 | — | Tested (`session_lifecycle_gate`: a silent program running at creation and 1.5 s in, a silent `sleep 1` then stopped) |
| Terminal sessions started, placed, resized and stopped through the API, as any local user | 0.1 | 0002, 0010 | Used |
| xterm-compatible emulation: 256 colours and truecolour, attributes, cursor styles, scroll regions, margins | 0.1 | 0004 | Used |
| Terminal fixes: xterm's bright colours, underline styles, colon colours, `CSI 3 J`, margins, four character sets, background-colour erase, window size reports, DECRQM/DECRQSS/DA3 answers | 0.3.12 | — | Tested |
| 1,000 lines of scrollback on the wheel; alternate screen | 0.1 | 0004 | Used |
| Mouse reporting: normal, button and any-motion tracking; SGR and pixel coordinates | 0.1; pixels 0.2.6 | 0029 | Used |
| Bracketed paste, focus events, synchronized output | 0.1 | 0029 | Tested |
| Kitty keyboard protocol (flags 1, 2, 8), including Super | 0.1.585 | 0059, 0169 | Tested |
| Kitty keyboard flag 4, report alternate keys: `CSI key:shifted:base ; mods u`, the shifted key while Shift is held and the base-layout key (the US PC-101 key at the same physical position, from the evdev code), each left out when it equals the key; with a device keymap the key is the layout's and the base the US key | 0.3.61 | 0225 | Tested (`kitty_keyboard_gate`) |
| `pointer_session_scans` in `/v1/diagnostics/runtime` performance: how often the input routes ask which session is under the pointer, held by a gate at once an event however many routes (dragging grew clunky when 0.3.83 asked once a route) | 0.3.96 | 0228 | Tested (`frame_input_gate` scans, shown to fail on the per-route ask) |
| `INPUT keep`: the desktop's shortcuts withheld from program windows (a chord grammar by the US base key; press, repeat and release kept; empty clears; refused whole), `KEYBOARD reserved` (Blit's console switch and stop chord, for the desktop's clash check); X focus left to an X program when no X window is activated (no focus fight with Steam) | 0.3.95 | 0231, 0228 | Tested (`frame_input_gate` keep and reserved, `xwayland_gate` keeper) |
| Arabic (Arabizi) as a keyboard: typed on the US keys and turned into Arabic in programs' text fields by blit-compositor's `zwp_text_input_v3` (preedit while typing, words committed on a space or punctuation, chords and Enter commit first, password fields left alone); the engine hibr-ime's, built in from a pinned tag; offered while its data is installed, and set aside, the rest of the list kept, where it isn't; since 0.3.105 tuned by the person's own layer (`$XDG_CONFIG_HOME/hibr/ime/arabizi`, hibr-ime's Arabizi pane: tashkeel, readings, My Words), from the next word | 0.3.101 | 0233 | Tested (`compositor_gate` ime part with a word saved to the user layer while typing, and the real-Blit switch, `keyboard_settings_gate`, `frame_input_gate` method line, `xwayland_gate`) |
| The Arabizi engine (ADR 0233 phase 1): Latin Arabizi to Arabic, key by key, with tashkeel on request; its dry run `POST /v1/input/arabizi/convert`; rules and word lists from `hibr-ime-arabizi` in `/usr/share/hibr-ime/arabizi` since 0.3.103, in `/usr/share/blit/arabizi` before (word lists CC BY-SA 4.0, credited) | 0.3.100 | 0233 | Tested (`arabizi_gate`: word and line accuracy floors, worst case, tashkeel, 400, 503) |
| Keyboards on the frame channel (`KEYBOARD list`, `KEYBOARD current <n>`; `KEYBOARD item ...`, `KEYBOARD current`, sent on every change) for a desktop without the API token; dead keys and compose sequences in terminals (a compose state per keyboard on the locale's table) | 0.3.94 | 0231 | Tested (`frame_input_gate` keyboards part, `kitty_keyboard_gate` us(intl)) |
| The display's refresh rate on the frame channel (`DISPLAY rate` answered `DISPLAY rate <mHz>`, and sent again on a mode set, a rescan or a move to another display) for a desktop without the API token | 0.3.98 | — | Tested (`frame_input_gate` rates: two displays at 60 and 74.973 Hz, a move told once, EINVAL, opt-in) |
| Keyboards: an ordered list of the system's xkb layouts and the current one (`GET/PUT /v1/input/keyboards`), what the system has (`/v1/input/keyboards/available`), kept in the settings; switching reaches terminals, Wayland and X programs (keymap and modifiers) and the input stream (`keyboard` event); phonetic Arabic typed letter by letter | 0.3.93 | 0231 | Tested (`kitty_keyboard_gate` ara(mac-phonetic), `keyboard_settings_gate` restart, `compositor_gate` switch, `api_schema_gate`) |
| Popups as Firefox draws them: a popup's subsurfaces flattened onto the popup (`WINDOW sub <id> <popup>`), a popup of a popup (a submenu), the pointer hit-testing popups at any depth and their subsurfaces, and a grabbing popup holding the keyboard; with Hibr #528 Firefox's menus and permission panels show | 0.3.92 | 0228 | Tested (`compositor_gate` popup tree, the stand-in's `--popup-tree`) |
| Keyboards from the system's xkb keymap (ADR 0231 step 1): what a key types, its modifiers and its locks come from libxkbcommon's `us` and each keyboard's xkb state, one keymap for terminals, Wayland and X programs; a device's modifier roles are applied as the role's own key; blit-compositor is sent Blit's modifiers (`INPUT modifiers`), so Num Lock at Start and locks reach programs; the per-device `keymap` override removed | 0.3.91 | 0231 | Tested (`kitty_keyboard_gate`, `key_encoding_gate`, `keymap_gate`, `compositor_gate`, `frame_input_gate`, `input_stream_text_gate`) |
| Kitty keyboard flag 16, report associated text (with flag 8): `CSI key ; mods ; text u`, the text the key types on the device's layout (Shift, AltGr, CapsLock; a keypad operator, or its digit with NumLock on) on a press or repeat; none on a release, a Ctrl/Alt/Super chord or a functional key. With flags 2 and 8 a desktop sees a lone Super tap and still every character typed | 0.3.89 | 0059 | Tested (`kitty_keyboard_gate`) |
| Focus reports on input hand-over: the focused session (mode 1004) gets `CSI O` when Blit releases physical input for a VT switch, after the synthetic key and button releases, and `CSI I` when it takes input back | 0.3.61 | 0225 | Tested through the `BLIT_TEST_VT_SIGNALS` hook (`kitty_keyboard_gate`); the real VT path only in the QEMU gate |
| Hyperlinks, notifications, window titles, clipboard writes | 0.1 | — | Tested |
| Pointer shapes set by the program (OSC 22), or hidden | 0.2.8 | — | Tested |
| Pointer lock for games and emulators: raw mouse movement, released on focus loss | 0.2.42 | 0198 | Used |
| Rectangle copy (DECCRA), for solid window moves in Hibr | 0.1.589 | 0175 | Tested |
| Colour emoji sequences laid out as two-cell clusters (opt-in `text_layout: "emoji"`) | 0.1.578 | 0161–0163 | Tested |
| The Glyph Protocol (v1.18), adopted as specified, so programs written for Rio, Ghostty and kitty detect Blit and ask before they print: the support check `s` (answered `fmt=` empty: no registrations accepted), the coverage query `q ; cp=` answered from the cell's own drawing path for the current font, pixel or outline (`status=system` or empty; the registration block U+100000-U+1003FF and Blit's old icon range empty), `r` rejected and `c` of an empty glossary as the specification requires, `grapheme` answered `unsupported`; replies in request order before DA1's, never echoing request bytes, 256 lookups a second per session | 0.3.133 | 0243 | Tested (`glyph_protocol_gate`) |
| Glyph sets by set and name (ADR 0243 step 3, the set level): the font registry declares each names source and derives the sets from it -- `blit` (Blit's 850 catalogue ids, terminal-local, versioned by the catalogue's SHA-256; names it publishes and later drops answer retired) and Nerd Fonts 3.4.0's own 17 `nerd-*` sets (portable) -- and `GET /v1/fonts` (`sets`), `GET /v1/fonts/sets`, a paged `GET /v1/fonts/sets/{set}` and `GET /v1/fonts/sets/{set}/{name}` answer from one table read at start: codepoints, aliases, deprecations, tiles, retired names (410), the names Blit shares with Nerd sets resolved per set; the address grammar checked before any lookup, nothing echoed. Not yet in band (the `names` capability is a draft) | 0.3.134 | 0243 | Tested (`glyph_sets_gate`) |
| Default colours set per session | 0.1 | 0109 | Tested |
| Raw output capture of a session, for diagnosis | 0.2.31 | — | Tested |

## Images

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Kitty graphics protocol: chunked, compressed RGB/RGBA/PNG, placements, layers, deletion | 0.1 | 0005, 0056, 0060, 0084 | Used (Hibr's wallpaper and video) |
| Images scroll with their text | 0.1.491 | 0087 | Tested |
| Kitty images changed in place, redrawing only the changed rectangle | 0.3.1 | 0200 | Tested |
| Kitty replies: `OK`, and an error for every failure; quiet levels respected | 0.3.3; errors 0.3.12 | 0200 | Tested |
| Picture frames by descriptor: a sealed memfd over a local, token-checked socket instead of base64 through the terminal (for video and pages). Local only: a program over ssh or on another machine sends pictures through the terminal | 0.3.17; login sessions 0.3.19 | 0202 | Used (with Hibr 0.99.398) |
| Picture frames by dmabuf (FRM3 on the frame channel; since version 3, today version 5): a GPU producer's buffer imported by the GPU compositor as a texture, no CPU copy or upload; offered only while the GPU compositor composes every output and can import (`OK dmabuf=1`, with the formats and modifiers); RGB (`XRGB8888`, `ARGB8888`, `XBGR8888`, `ABGR8888`; the alpha formats premultiplied), an optional acquire fence waited on by the GPU, `FRAME release` once a newer frame is shown; `ENOTSUP` when any output is composed by the CPU. YUV not yet | 0.3.60 | 0223 | Tested; protocol, import, release, premultiplied alpha and a GPU-rendered frame with its fence checked on screen on an Intel HD 515 test host with a test producer (`frame_dmabuf_live_gate`); blit-compositor forwards programs' dmabufs (0.3.71 on) |
| Pictures bounded by memory, not by count: a session's pictures and placements in tables that grow, up to ceilings of 4096 pictures and 16384 placements (`ENOSPC`, the API 409); a picture budget per session (256 MiB) and across sessions (a quarter of physical memory, at most 2 GiB), settings in MiB, charged by one accounting function for CPU pixels, sixel and Kitty scratch and GPU textures; over a budget, unshown pictures freed least recently shown first, never a shown one (placed, with a held placement, or holding an input route), and nothing freed when that would not make room, else `ENOSPC`; the GPU's picture textures a cache of 512 MiB (a setting), recycled least recently drawn, so nothing on screen is uploaded again; the frame channel's input routes one per picture; `graphics.budget`, `graphics.used` and each session's `graphics_memory` (bytes, frees and refusals by reason) | 0.3.65 | 0226 | Tested (`graphics_memory_gate` on the CPU and GPU compositors: 1000 pictures with 500 placed all drawn and no re-upload, the reported bytes, a session budget and the server budget over two sessions freeing least recently shown first then `ENOSPC`, picture 4097 refused; `graphics_memory_frames_gate`: a routed picture and a held placement kept); not yet run on the owner's machine or 10.52 |
| Input route hold modes (`INPUT hold <image-id> relative|confine`, answered `INPUT ok <image-id>` or `INPUT error <image-id> EINVAL`; any time after `INPUT sock`; takes and gives back no lock): `relative`, the default (under `?7701` the pointer hidden and still, raw relative motion to the route); `confine`, while the session holds `?7701`, the route is live and its picture is drawn on the pointer's output: Blit's pointer stays shown with its shape, moves as an unlocked pointer does, kept inside the picture's topmost drawn rectangle, and the route is sent that point as an absolute position through the usual mapping (no relative motion), so the compositor's pointer and the drawn one are one point; buttons, the wheel and the holder's `?7701` reports as under `relative`; the picture not drawn or the pointer on another output behaves as `relative`; when the lock ends the pointer stays where it was; one function (`frame_input_confined`) decides for both the pointer's visibility and its motion; each route's `hold` in `frames.input` | 0.3.70; `sock` routes only since 0.3.75 | 0225, 0198, 0228 | Tested (`frame_input_gate`: `EINVAL` for an unknown or missing mode and for an image with no route, `INPUT ok` and `hold` for both modes; on a `sock` route, read off the socket, `relative` hiding a still pointer with the raw sum sent, and `confine` showing it, moving it, clamping it at both far corners, the compositor sent the same points as absolute positions and no relative motion, the holder its raw deltas, a click, the picture undrawn falling back to `relative` and drawn again confining, and after `?7701l` the pointer where it was and ordinary absolute motion) |
| One grammar for the frame channel, version 5, a flag day with Hibr 0.99.482: every line about a picture is `<WORD> <verb> <id> [arguments]`, the picture id the third word -- `FRAME release <id> <seq>` and `FRAME error <id> <code>` (were `RELEASE` and `ERROR <id>`), `INPUT sock <id> <path>`, `INPUT ok|error <id>` (were `OK input`, `ERROR INPUT`), `WINDOW ok|error <id>` (were `OK window`, `ERROR WINDOW`); a line about no one picture says 0 there (`FRAME error 0 EINVAL` for a malformed STA1). The hello is version 5 (`v5 <token>`), answered as before (`OK dmabuf=... window=0`); a hello of versions 1 to 4 is refused `ERROR 0 EINVAL`. No compatibility forms: `blit` Breaks `hibr (<< 0.99.482)`. blit-compositor speaks it; the binary FRM1, FRM3 and STA1 messages are unchanged | 0.3.74 | 0202, 0223, 0225, 0228 | Tested (every channel gate on version 5, the version 4 hello refused and the version 4 forms understood by neither producer; Hibr 0.99.482's desktop end to end against the 0.3.74 compositor) |
| Sixel images, up to 8 MiB of data each | 0.1; large 0.3.12 | 0021 | Used |
| Pixel-exact image scaling | 0.1.557 | 0139 | Used |
| Binary WebSocket frame stream for emulators and games | 0.1 | 0013, 0166 | Used |

## Fonts and glyphs

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Text fonts: Hack, IBM 3270, JetBrains Mono NL, Fira Code, IBM Plex Mono | 0.2.36 | 0195 | Tested |
| Pixel font: Terminus 16 (Spleen 16 retired in 0.3.68 for `spleen`) | 0.1; renamed 0.2.35 | 0145, 0194, 0227 | Used |
| Spleen at any size, 8–64 px: one font of the five Spleen 2.2.0 masters (6x12, 8x16, 12x24, 16x32, 32x64), the largest whose height divides the cell height drawn pixel-exact, else the largest below it scaled; `GET /v1/fonts` reports `master` and `master_fit` | 0.3.68 | 0227 | Tested (`spleen_master_gate`: listed once with its masters, none as a font of its own; the master at 12, 16, 24, 32, 48, 64 px crisp and 20, 28, 40 px scaled; at every crisp size the text in the screenshot holds only its two colours, and has in-between coverage when scaled; a saved `blit-spleen16` falls back to the boot font; `outline_catalogue_gate`, `custom_icon_gate`: every Nerd icon and Blit glyph through the stack at 8–64 px) |
| Add your own monospaced TTF/OTF to `/usr/local/lib/blit/fonts/text`: it appears without a restart | 0.2.36 | 0195 | Tested |
| Font size by cell height, 8–64 px, changed live | 0.1.561 | 0144 | Used |
| One glyph stack under every font: Blit icons, Nerd Fonts symbols (10,386), Noto symbols and maths, colour emoji, Arabic, Unifont | 0.2.36 | 0195 | Used |
| Pixel fonts borrow missing glyphs from the stack | 0.2.43 | 0199 | Tested |
| Box drawing, blocks, Braille and Powerline drawn to fit the cell exactly | 0.2.32–0.2.36 | 0164, 0191 | Tested |
| Colour emoji (Noto Color Emoji, Emoji 18.0) | 0.1.574 | 0157–0160 | Used |
| Arabic with shaping, positioned marks and Arabic-Indic digits (cell by cell in Blit Arabic Modern until ADR 0243; as words since, the row below) | 0.1.588 | 0174 | Tested |
| Arabic shaped as words, as a browser does: each run of Hibr's cells is one word in Noto Naskh Arabic, joined, with its tashkeel, drawn into exactly the cells it was given, on the CPU and the GPU, outline and pixel fonts alike; the one Arabic path since ADR 0243 (no `arabic` setting), a run the face cannot shape drawn cell by cell from the glyph stack | 0.3.129 | 0241, 0243 | Tested (`arabic_word_text_gate`, `arabic_word_slice_gate`, `arabic_word_view_gate`, `arabic_backend_gate`, `gles_compose_gate`, `arabic_screen_gate`, `modern_font_api_gate`) |
| Bold keeps a shape that fills its cell (Hack's window buttons were D-shaped): the shape narrowed by a column before the overstrike; text bold as before | 0.3.129 | 0240 | Tested (`bold_shape_gate`) |
| A program keeping the screen awake (a video: `zwp_idle_inhibit_manager_v1`) tells the desktop, `WINDOW inhibit <id> on|off`, for its saver to honour | 0.3.130 | 0229 | Tested (`compositor_gate` inhibit part, `compositor_wire_unit`) |
| Blit's own colour icons: Wi-Fi, battery, volume, power, pen, telephones, the hui badge | 0.1.588–0.2.45 | 0172, 0196, 0197 | Used |
| File-manager icons: 63 kinds, folders in four colourways | 0.3.4–0.3.9 | 0201 | Used |
| Retro Mac-style window chrome glyph sets, Chalk (one colour) and Slate (the cell's own colours since 0.3.39), one per part (title bar, frame, dialog, buttons) so they mix; SGR 51 framed labels and titles | 0.3.36–0.3.39 | 0210, 0211 | Tested |
| Drop shadow under any cell (SGR 66/67), in the cell's underline colour or foreground | 0.3.39 | 0211 | Tested |
| Icon catalogue for applications (`GET /v1/fonts/icons`) | 0.1.588 | 0172 | Used |
| Blit's icons and cell geometry at U+101000-U+101494, out of the range the Glyph Protocol reserved for programs' glyphs (U+100000-U+1003FF): the whole set moved up by 0x1000, ids and catalogue shape unchanged; the old U+100000-U+100494 still draws the same glyphs during the transition (`deprecated_range` in `GET /v1/fonts/icons`) until a later release drops it | 0.3.131 | 0243 | Tested (`icon_transition_gate`) |
| Window frame with its line on the outer edge: one frame set (five cells) and the title bar's end cells, Chalk and Slate, whose stripes run into them; the old frame glyphs and `stripe-first`/`-last` are deprecated in the catalogue (`deprecated`, `replaced_by`) and still drawn | 0.3.41 | 0214 | Tested |
| Pressed title-bar boxes and a grow box: close, shade and zoom pressed (also hover), and the window's resize corner, normal and pressed, Chalk and Slate (10 glyphs, U+1012BB-1012C4) | 0.3.47 | 0219 | Tested |
| Inactive title-bar end cells: four plain title-end glyphs (the outer line, top line and rule, Slate's bevel, no stripes), Chalk and Slate, for the inactive bar beside the plain `title` cell | 0.3.44 | 0214 | Tested |
| Controls glyph set: a checkbox, a compact two-cell switch and a three-cell capsule switch, in Chalk, Slate and the capsule's own pens | 0.3.40 | 0212 | Tested |
| Graphics ledger (`GET /v1/diagnostics/graphics-ledger`) and blink counters: a picture that vanishes from presented frames and returns is counted; pictures deleted inside a synchronized update stay until it ends, so a whole-output redraw shows no hole | 0.3.42 | 0213 | Tested |
| A fitted icon or symbol is never trimmed at any font size, 8 to 64 px; the Wi-Fi and volume icons are fitted by their drawn layers; a spanning icon's halves join to the pixel | 0.3.43 | 0215 | Tested |
| A catalogue a client can map: structured pen roles (part, cells, background, foreground, SGR 58) on every cell-geometry glyph; a revision, an ETag and `If-None-Match`; SGR capability flags (`sgr-framed`, `sgr-framed-bar`, `sgr-shadow`) in `GET /v1/server` | 0.3.40 | 0212 | Tested |

The [font reference](font-reference.md) lists every glyph and icon codepoint.

## Input

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Keyboards, mice and touchpads found automatically, including when plugged in | 0.1.239 | 0011, 0064 | Used |
| Which device types into which session, chosen per device | 0.1 | 0022 | Used |
| Keyboard repeat rate and delay, Caps/Num Lock at start, key remapping, layout per device | 0.1.453 | 0067 | Used |
| Pointer speed, acceleration, natural scrolling, left-handed buttons, scroll step | 0.1.454 | 0067 | Used |
| Middle-button emulation | 0.1.492 | 0088 | Tested |
| Touchpad: move, two-finger scroll, click | 0.2.2 | — | Used |
| Touchpad: tap to click, tap and drag, ignored while typing | 0.2.3, 0.2.34 | 0193 | Hardware pending (the HP Chromebook) |
| Pointer appearance: three shapes, four palettes, 24–64 px, shadow | 0.1.550 | 0133 | Used |
| Shake to find: shaking the mouse grows the pointer, the harder the bigger, easing back as it calms; on by default, the most (64–256 px), sensitivity (1–10) and, since 0.3.104, the time to shrink back (150–3000 ms) set in `document.pointer`; a sweep, a drag or a warp do not grow it; nothing spent at rest | 0.3.102 | 0234 | Tested (`pointer_shake_gate`, `pointer_settings_gate` shake verdict; not yet the owner's hand) |
| The busy pointer: a program in a window that stops answering (no pong to blit-compositor's ping within `busy_after_ms`, default 2 s) shows a spinning ring of spokes over its windows until it answers, and the desktop is told `WINDOW busy <id> on|off` (Hibr: "(not responding)", Force Quit); `wait`/`progress` asked by OSC 22 spin too; on/off, the threshold and the spin speed in `document.pointer` and the Blit Mouse pane; never for a locked or confined window or an X program | 0.3.106 | 0235 | Tested (`compositor_gate` busy part with a hung stand-in, `frame_input_gate` `INPUT busy` live, `pointer_shape_gate` spin pixels and idle; not yet the owner's machine) |
| A mouse's further buttons (back, forward and the two more: X's 8 to 11, BTN_SIDE to BTN_BACK) reach programs in windows (`INPUT btn`) and the input stream; Blit dropped them before. The desktop keeps a button chord as a shortcut with `INPUT keep` (`button8`, `super-button9`, `ctrl-button2`; Hibr #540), kept from programs and reported to its terminal as xterm's 128 to 131 -- only kept ones, so a terminal never misreads one | 0.3.107 | 0231 | Tested (`frame_input_gate`: 8 and 9 to a route by index and by evdev code, kept chords to no route and to the desktop as 128/129, unkept to no terminal, 4-7 and bad names refused) |
| A sixel is paint: a character written into a cell (the same one again included) or an erase takes the place of the sixel's pixels there, as on every sixel terminal; cells not written over keep it (Gitea #85) | 0.3.108 | — | Tested (`sixel_paint_gate`, native and gles; fails on 0.3.107) |
| Arabizi cycle or teach in programs' text fields (hibr-ime 0.1.5, IME_API 3): the desktop's Shortcuts set a cycle, a back and a teach key (`INPUT imekeys`), which reach the compositor as actions in key order (`INPUT ime`); cycle steps the word being typed through its spellings and the one picked is remembered in My Words; teach opens the desktop's box on it (`WINDOW teach` / `teachdone`); with nothing typed the key is the program's; the person's rules re-read in place in under a millisecond | 0.3.109 | 0233 | Tested (`compositor_gate` ime part with ASan/UBSan: cycle, kept in the layer, plain key, teach commit and cancel; `frame_input_gate` imekeys in order; `compositor_wire_unit`) |
| A program's windows keep updating across a display change: Blit refuses dmabuf frames `ENOTSUP` for a moment while it rebuilds its outputs, and blit-compositor now keeps each window's newest frame (a GPU's tiled one cannot be copied) and tries `FRM3` again at 250 ms, doubling to 4 s, instead of copying for good and dropping what it could not copy (Gitea #156: Steam Big Picture, Planetbase and a fullscreen game froze; 1.09 million frames logged as not shown). Logged once when the refusals begin and once when they end | 0.3.110 | 0223 | Tested (`compositor_gate` dmabuf retry part: a tiled stand-in refused, kept, tried at 250 ms and 500 ms, then taken; fails on 0.3.109) |
| A full session table is refused before anything is started: `503 session_limit`, saying how many of the 16 sessions have ended (an ended session keeps its slot, and its output stays readable, until it is deleted). Up to 0.3.110 the command was started, ended again, and the answer blamed the command, the surface or the PTY (Gitea #157) | 0.3.111 | — | Tested (`session_limit_gate`: 16 ended sessions, the 17th refused and not run, a delete frees a slot; fails on 0.3.110) |
| blit-compositor's log is capped: past 16 MiB it becomes `<path>.1`, replacing the one before, and a new one starts with a line saying where the old lines are, at most 32 MiB for both (Gitea #156: a flood had grown it to 155 MB) | 0.3.111 | 0223 | Tested (`compositor_log_cap_gate`: a small log appended to, a 17 MiB one rotated; fails on 0.3.109) |
| Icons over several rows (the catalogue's `rows`/`row`, the icon font's BLrw table): the now-playing discs at four cells by two rows, fitted to both rows and joined without a seam | 0.3.127 | 0237 | Tested (custom_icon_gate whole-icon ink and colour at 57 sizes; icon_clip_gate rows) |
| Keys for a player (or any program): one-row raised and pressed keys -- the ends as cell glyphs in the cell's pens, the bevel across the icon cells as SGR 51:6/51:7, a pressed icon 1 px lower; the theme picks face, light and dark | 0.3.127 | 0237 | Tested (`window_style_gate`, CPU and GLES) |
| A Kitty placement at an exact pixel size, `W=` and `T=` (a Blit extension beside `c`/`r`), so the desktop draws a program's scaled subsurface exactly | 0.3.127 | 0228 | Tested (`kitty_placement_gate`: 13x7 px of green at a sub-cell offset, in the diagnostics; W without T, W/T with c, W past 16384 refused; fails on 0.3.126) |
| Player glyphs (huiamp): LCD digits big and small with faint unlit segments, LED meters, sliders and faders as cell geometry in the text colour; transport buttons in one and two cells; CD, record and cassette in eight turning frames | 0.3.126 | 0237 | Tested (`player_glyph_gate` at every cell size; custom_icon_gate, icon_clip_gate, catalogue_fields_gate, blit_icons_rebuild_gate) |
| Two more slider styles for a Slider Style choice (Hibr): circle, a round knob on a thin line (`slider-circle-*`, `fader-circle-*`, U+101495-10149E), and groove, a hollow channel with a square thumb (`slider-groove-*`, `fader-groove-*`, U+10149F-1014A8); each a slider's and a fader's five pieces at a base codepoint plus 0-4 (cap, track, track-filled, knob, cap), in the same order as the current style's, so a program swaps the base; the knob's cell holds the knob alone. The icons' old range now ends at U+100494, the last glyph that moved (`deprecated_range` `to`), so old U+100495 never draws a slider piece | 0.3.136 | 0237, 0243 | Tested (`player_glyph_gate` at every cell size: joined tracks, the knob alone, centre lines within half a pixel of the current style's; `icon_transition_gate`: nothing past U+100494 maps) |
| A display's mode chosen through the API (`configuration.mode`: a listed mode, `auto`), tried and reverted by itself unless kept within 15 s, saved when kept and used at start in one modeset; the display keeps its place, its panes and sessions follow as on a replug, zoom stays over it | 0.3.125 | 0236 | Tested (`display_mode_gate` on the DRM mock, CPU and GLES: trial, revert, keep, a mode the monitor refuses, restart, auto). Live: the owner's to try |
| A start that hangs opening the display device or setting up its outputs is followed by one that serves the API with no displays and says why, so the box stays reachable; the restart after starts the displays again (a GPU-start hang keeps its CPU fallback) | 0.3.124 | 0153 | Tested (`gles_compositor_gate` cases 7 and 8: test-only hangs in each phase, the marker naming it, API-only next with the reason, displays after) |
| blit-compositor never writes its log from its loop: a thread does, so a disk that stalls (the owner's USB drive took 8-10 s a write) holds the log back, not the programs' frames and input; past 256 KiB waiting, lines are dropped, counted and said (Gitea #158). blit-server's last loop write, the GPU guard marker's removal, moved to its settings writer | 0.3.116 | 0223 | Tested (`compositor_gate` log stall: a log pipe nobody reads, 10000 lines, the window still opens and draws, every line written or counted; fails on 0.3.115) |
| The busy pointer only for a program that really stops answering: each window is pinged on the `xdg_wm_base` it was made from, not the program's newest binding (Firefox binds a second one it reads only now and then, and a working Firefox was shown busy for minutes); the log names the program, how long it went unanswered and what ended it | 0.3.112 | 0235 | Tested (`compositor_gate` busy second-binding part, with ASan/UBSan; fails on 0.3.111) |
| The busy pointer is a colour wheel by default: Blit's own disc of bright colours that turn, in 36 steps a turn, inside a thin dark rim, at the pointer's size and shake; the ring of spokes stays a choice (`pointer.busy_style`, Blit Mouse's Busy Pointer Style) | 0.3.113 | 0235 | Tested (`pointer_art_gate`: colours round the wheel, a spin keeps alpha and rim, turns clockwise, 36 distinct phases, no libm; `pointer_appearance_gate`, `pointer_shape_gate`) |
| Files dropped from the desktop onto a program window reach the program: `CLIP drop` enters its surface with the types offered, a motion at the drop point until it answers, its reads (before the drop too) answered by the desktop through `CLIP read`, and `CLIP dropped taken\|refused` its own answer (Wayland programs; X programs since 0.3.117) | 0.3.114 | 0229 | Tested (`compositor_gate` drop part with ASan/UBSan; a real GTK3 window received the file; Firefox read and took the drop) |
| A program's own drag icon reaches the desktop while it drags out (`WINDOW dragicon`), every buffer kind, scaled to at most 256 px a side; Wayland start_drag icons and X programs' _NET_WM_WINDOW_TYPE_DND windows | 0.3.123 | 0229 | Tested (`compositor_gate` and `xwayland_gate` dragout parts; real GTK3, Wayland and X) |
| A program drags files out to the desktop or another program window: `CLIP dragout o<n>` to the desktop, which runs the drag; reads from the program's source; `CLIP dragend` ends it as copy, move or cancelled (Wayland programs; X programs since 0.3.121, through an XDND drop window; onto X windows relayed since 0.3.122) | 0.3.119 | 0229 | Tested (`compositor_gate` dragout part; `xwayland_gate` dragout part; real GTK3 drag sources, Wayland and X) |
| While a drag from the desktop is over a program window, the program's answer reaches the desktop (`CLIP drag`/`CLIP leave` in, `CLIP hover copy\|none` out) for its drag pointer; the drop over it is at once (Wayland and X programs) | 0.3.118 | 0229 | Tested (`compositor_gate` and `xwayland_gate` hover cases; a real GTK3 window) |
| Files dropped onto an X program's window reach it (XDND: Steam, Wine and other X programs): the compositor is the drag's source; a window not XdndAware is refused at once | 0.3.117 | 0229 | Tested (`xwayland_gate` drop part with ASan/UBSan in the release environment; a real GTK3 window under Xwayland received two drops) |
| A dropped file reaches a program that reads only when an event comes (mpv): the compositor relays the read and ends the drag (`leave`) once the data is in the program's pipe; mpv no longer aborts on a second drop | 0.3.116 | 0229 | Tested (`compositor_gate` lazy-reader drop: two drops taken at once; fails on 0.3.115; mpv 0.40 opened two dropped files in a row) |
| Programs that crop or scale (wp_viewporter, buffer scale) are shown that way: `WINDOW view` tells the desktop the buffer rectangle and the size, and input, subsurfaces and popups use the shown size -- mpv's video subsurface, HiDPI and scaled programs, Xwayland's resolution emulation; drag icons cropped and scaled too | 0.3.124 | 0228 | Tested (`compositor_gate` viewport part: crop+scale, buffer scale 2, back to pixels, a scaled subsurface placed at its shown size and the pointer reaching its scaled part; scaled drag icons, shm and dmabuf; with ASan/UBSan). Hibr draws it from its side (Gitea #159) |
| `wp_viewporter` for programs: mpv (and other programs that need it) runs its own Wayland video output instead of its slow SDL fallback, and takes dropped files; a viewport its buffer's size is shown as is, one that would crop or scale is shown unscaled and said once | 0.3.115 | 0228 | Tested (`compositor_gate` viewport part with ASan/UBSan; real mpv runs vo/gpu and opened a dropped file) |
| Gamepads: discovery, dead zone, inverted axes | 0.1.454 | 0013 | Hardware pending (a gamepad) |
| Ctrl+Alt+Fn switches virtual console; the console is restored if Blit stops | 0.1.587 | 0170 | Used |
| Ctrl+Alt+Backspace stops Blit; can be changed or turned off | 0.1.461 | — | Used |
| Input injected through the API, including relative pointer movement | 0.1 | 0028 | Used |

## Sound and power

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Sound devices listed, default playback and capture device chosen | 0.1.451 | 0064 | Used |
| Each card's volume, mute and mixer controls | 0.1.455 | — | Used |
| Default sound device passed to every session (`ALSA_CARD` and friends) | 0.1.451 | — | Used |

## Effects

Per pane, saved with the settings, changed live from the Blit Effects pane.

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Rounded corners, scanlines | 0.2.27 | 0186 | Tested |
| Screen curvature and glow (GPU only) | 0.2.28 | 0187 | Used |
| RGB shift | 0.2.30 | 0187 | Tested |
| Hum bar (animated only while on) | 0.2.31 | 0188 | Used |
| Animated effects follow each display's refresh (`effects_animation_hz` `"auto"`, the default), or a ceiling of 10–240 Hz met by ticking every Nth vblank (50 on 60 Hz is 30), never above the display's refresh; ticks still only fill gaps between real frames | 0.3.67 | 0188 | Tested (`presentation_effects_gate`: auto at the DRM mock's 60 Hz, 30 and 10 as set, 50 as 30 and 25 as 20, 240 clamped to 60, measured rates, settings round trip and refusals, `fills_gaps_only` under auto; `tube_effects_gate`, `zoomed_effects_gate`, `burn_in_gate`: the clock at the display's rate; `api_schema_gate`: the schema); CPU and power cost of 60 against 30 Hz not yet measured on real hardware |
| Flicker, horizontal sync and jitter | 0.2.32 | 0190 | Tested |
| Every effect drawn on a zoomed display, the 100% picture enlarged | 0.3.30 | 0204 | Tested |
| Static noise, chroma with a phosphor colour, brightness and contrast | 0.3.32 | 0207 | Used (cost measured on the mini PC) |
| Burn-in: what was lit fades out over 0.16–1.6 s, frames only while a trail fades | 0.3.33 | 0208 | Used (cost measured on the mini PC) |
| CRT mask at the panel's own pixels: aperture grille, slot mask or shadow mask, brightness kept | 0.3.35 | 0209 | Tested |
| A pane says whether anything is shown in it (`has_view`), so effects set on an empty pane are explained | 0.3.34 | — | Used |
| Master switch and per-pane switch | 0.2.28 | 0187 | Tested |
| The pointer still lands on the right cell through curvature | 0.2.28 | 0187 | Tested |

## Hibr desktop

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Hibr's login screen on a chosen pane | 0.1.485 | 0083, 0124 | Used |
| The login is a local seat session (`LG_SEAT`/`LG_VTNR`) | 0.2.7 | — | Tested |
| Signing in hands the session to the user, with their identity | 0.1.538 | 0125 | Used |
| One Hibr desktop, joined by other displays as independent viewports | 0.1.540 | 0127 | Used |
| Other displays started and placed from saved settings | 0.1.542 | 0128 | Used |
| Control Panel panes **Blit**, **Blit Mouse**, **Blit Keyboard** and **Blit Effects** (shipped with Hibr's apps): zoom and effect sliders, the panel's switches, restart after update, the keyboard list | pane 0.1.0–0.1.37 | — | Used |
| Restart Blit and the Ctrl+Alt+Backspace switch from the Control Panel | pane 0.1.19 | — | Used |

[Hibr integration](integration-hibr.md) explains the contract.

## API

HTTP and WebSocket, described in full by the
[OpenAPI document](../openapi/blit-0.1.yaml) (54 paths) and the
[API guide](api.md).

| Group | Endpoints |
| --- | --- |
| Identity | `/v1/version`, `/v1/server` |
| Hardware | `/v1/graphics`, `/v1/displays`, `/v1/audio`, `/v1/audio/cards` |
| Layout and fonts | `/v1/topology`, `/v1/fonts`, `/v1/fonts/icons` |
| Settings | `/v1/settings` — one saved document, protected by revision |
| Sessions | `/v1/terminal-sessions` and their `input`, `graphics`, `output-capture`, `hibr-owner` |
| Surfaces | `/v1/surfaces/{id}/cells`, `summary`, `scrollback`; `/v1/frames` |
| Input | `/v1/input/devices`, `/v1/input/routes`, `/v1/input/inject`, `/v1/input/keymap`, `/v1/input/keyboards` and `available`, `/v1/input/arabizi/convert` |
| Hibr | `/v1/login`, `/v1/auxiliary-displays` |
| Effects and overlays | `/v1/effects`, `/v1/overlays` |
| Diagnostics | `/v1/diagnostics` and `runtime`, `console`, `processes`, `observation`, `trace`, `graphics-ledger`, `screenshots` |
| Control | `/v1/control/shutdown`, `restart`, `shutdown-key`, `update` and its `status`, `cancel`, `reset` |
| Events | `/v1/stream` — WebSocket: input, output, surface and frame events, pixel frames, with replay |

Errors are `application/problem+json` with stable codes.

## Security

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Bearer token on every request; generated at install | 0.1 | 0065 | Used |
| Without a token, listens on 127.0.0.1 only, and refuses the network unless told otherwise | 0.1 | 0065 | Used |
| Separate token for installing updates | 0.1 | 0008 | Used |
| Allow-list of the commands sessions may run | 0.1 | 0065 | Tested |
| Unprivileged profile: run as user `blit` with a systemd drop-in | 0.1 | 0065 | Tested |
| Every session child gets `BLIT_API_TOKEN` (ADR 0055), except a login manager's in a Hibr join; a client sets it empty in `environment` to opt a child out. Native child shells do not inherit the optional API provider (ADR 0168) | 0.1.584 | 0055, 0168 | Tested (`network_auth_gate.sh`, `native_child_provider_gate.rb`) |

## Updates and packaging

| Feature | Since | ADR | Status |
| --- | --- | --- | --- |
| Install a new package through the API; a separate root helper checks and installs it | 0.1.232 | 0008 | Used |
| An API update installs blit and blit-compositor together, at one version, in one `dpkg --install`; the helper refuses blit alone where blit-compositor is installed, never adds blit-compositor where it is not, accepts only files from its staging directory, and removes them after answering (`X-Blit-Packages`) | 0.3.97 | 0232 | Tested (`update_pair_gate`: real helper and dpkg, nine cases (sixteen from 0.3.133); `update_restart_gate`: the split upload; `update_install_live_gate`: the server serves throughout an install) |
| Only a signed release is installed through the API: releases are signed with a Blit Ed25519 key (`tools/release/keygen`, `tools/release/sign-release.sh`; Monocypher 4.0.3, pinned), `blit` installs the public keys in `/usr/lib/blit/release-keys`, and the helper verifies the signature (`X-Blit-Signature`) over each package's Version and SHA-256 before installing, refusing anything unsigned, signed by another key or for other packages, and any `blit` older than 0.3.133; keys rotate by adding the next one in a release and revoke by removing one (security review SR-2) | 0.3.133 | 0232 | Tested (`release_signature_gate`: RFC 8032 vectors and refusals, `blit-sign`, the helper's refusals; a scratch-root lab of the bootstrap and the server-to-helper chain). `update_pair_gate`'s seven signature cases and `package_artifact_gate`'s key checks first run in the 0.3.133 release build |
| Settings, devices and the shutdown chord survive updates | 0.1.451 | 0067 | Used |
| Restart in place through the API, without a reboot | 0.1.451 | — | Used |
| After an `apt upgrade`, Blit restarts itself at the login screen when nobody is signed in (or only reports it: `server.restart_after_update`) | 0.3.27 | 0205 | Used |
| The running Hibr's release and module ABI are checked again whenever Hibr is upgraded underneath Blit | 0.3.32 | 0094 | Used |
| Built against Hibr's module ABI 17 | 0.3.31 | 0094 | Used |
| Debian package on Hibr's apt repository, with a release receipt per version | 0.2.2 | 0091 | Used |
| Manual pages: `blit(8)`, `blit.env(5)`, `blit-update-helper(8)` | 0.3.10 | — | Tested |
| `blit-compositor`, Blit's own Wayland compositor for programs (ADR 0228 phase 1, milestone A): a program beside blit-server, one per desktop session, that composites nothing; it says hello on the frame channel (then version 4; version 5 alone since 0.3.74), listens on `$XDG_RUNTIME_DIR/blit-<n>`, says `WINDOW display <name>`, and turns each `xdg_toplevel` and `xdg_popup` into a picture: `WINDOW new`, `title`, `appid`, `limits`, `fullscreen`, `popup`, `decor` (server-side by `zxdg_decoration_manager_v1`) and `gone` out, the desktop's `WINDOW size` (configured exactly, `0 0` the program's choice) and `WINDOW close` in; every `wl_shm` buffer one sealed FRM1 frame, released and its frame callbacks answered when sent; `wl_compositor`, `wl_subcompositor` (accepted, not composited; subsurfaces are pictures since 0.3.74), `wl_shm`, `wl_output`, `wl_seat` (advertised; input is milestone B) and `xdg_wm_base`, at the ADR's versions bounded by the build host's protocol XML. blit-server answers a version 4 hello as version 3's plus ` window=0` and every `WINDOW` line `ERROR WINDOW <id> ENOTSUP`. Not yet: dmabuf frames, input and the keymap, presentation timing, packaging | 0.3.71 | 0228 | Used (`compositor_gate`: against a fake desktop with the in-repo stand-in client, the lines, frames of exactly 320x200 and 500x300 and the program's own size for `0 0`, pixel for pixel, a popup at its offset closed by `popup_done`, a killed client's window `gone`, the seat and output a client binds, close then `gone`; Blit's `window=0` and `ENOTSUP`; the same under AddressSanitizer and UBSan). Its "not yet" list -- dmabuf frames, input and the keymap, packaging -- shipped in 0.3.72-0.3.74 (rows below) |
| `blit-compositor` milestone C (ADR 0228 phase 1): `zwp_pointer_constraints_v1` asked of the desktop -- `lock_pointer`/`confine_pointer` send `WINDOW lock <id> relative|confine`, the desktop's `WINDOW lock <id> on|off` sends locked/confined and unlocked/unconfined, a constraint pending until `on`, a oneshot defunct after `off`, a persistent one waiting for the next `on`, its destroy or its window gone `WINDOW lock <id> off`, no absolute motion while locked; Blit's `INPUT member <popup> <top-level> <x> <y>` (a popup's picture in its top-level's route, the pointer over it mapped into the top-level's pixels, ending with its picture; `members` and `over` in `frames.input`); key repeat from Blit's keyboard settings (`X-Blit-Repeat-Rate`/`-Delay` on `GET /v1/input/keymap`, 200 and 304, sent as `wl_keyboard.repeat_info`); the keymap re-read only on Blit's `INPUT keymap <id> <revision>` notice (a keyboard configured, plugged or gone, or a key from another keyboard, before that key; bounded 250 ms read); the default keymap the keyboard whose key came last; the `blit-compositor` package (Depends `blit (= version)`, libc6, libwayland-server0, libxkbcommon0 and, since the X window manager (0.3.78), libxcb1 with its composite, xfixes, res and randr libraries; Recommends xwayland; `blit` Suggests it; no build path, reproducible) | 0.3.72 | 0228 | Used (`compositor_gate`: the lock part with the stand-in's `--lock` against a fake desktop, and end to end with a real Blit: the pointer over a member picture reaching the popup surface, Blit's repeat, a PATCH while live reaching the client, a key from a second keyboard bringing its keymap and repeat before the key; `frame_input_gate` sock: `INPUT member` answers and mapping, the notice at live; `keymap_gate`: repeat headers, the last key's keyboard; the package built twice to one sha256; not yet the owner's live check on the mini PC) |
| `blit-compositor`: programs survive a desktop restart (ADR 0228; `docs/api.md`, agreed with Hibr) -- when the frame channel closes it keeps every program, window, the Wayland and input sockets and each window's newest frame (wl_shm copied, dmabuf held, older buffers given back at once), answers frame callbacks at the output refresh, and dials the same socket and token again (50 ms doubling to 1 s, at most 60 s, never blocking) until a desktop answers `window=1`; then `WINDOW display`, every window again with its id and last state (`new`, hints, `INPUT sock`, `hide`, popups), the newest frames and `WINDOW lock`, configuring nothing until the new `WINDOW size`; no desktop back: status 1; `WINDOW quit 0`: ends at once, status 0; `--display <name>` (refused, status 2, when in use or invalid) | 0.3.73 | 0228 | Used (`compositor_gate` restart part against a fake desktop, also under ASan/UBSan: an shm and a dmabuf program drawing through the outage, a program started meanwhile, all announced again with their newest frames and a pending pointer lock on the same socket, then sized; quit; no desktop back after a shortened bound; `--display` refused; `compositor_wire_unit` `WINDOW quit`; not yet Hibr's side or a live restart) |
| `blit-compositor`, live fixes from the owner's first checks: a toplevel's initial commit answered with a configure at once (the desktop's size, else 0x0), as xdg-shell requires and vkcube relies on; the keymap on the input route itself (`INPUT keymap <id> <revision> <size> <rate> <delay>` with a sealed memfd, the bytes `GET /v1/input/keymap` serves), so the compositor needs no API port or token; an input socket per toplevel (`<display>-input-<id>`), so the desktop's own picture id on Blit's lines no longer drops them; POST /v1/terminal-sessions arguments and environment bounded by the request, not 255 bytes each (`invalid_session_strings`) | 0.3.73; the socket per window 0.3.74 | 0228, 0229 | Tested (`compositor_gate` with ASan/UBSan, the gate relaying under Hibr-sized ids; `frame_input_gate`: the memfd sealed and byte-for-byte the API's keymap; `terminal_conformance`; vkcube drawing on the owner's mini PC) |
| `blit-compositor`, programs as whole windows (ADR 0229, agreed with Hibr 0.99.482): subsurfaces as pictures of their own (`WINDOW sub <id> <parent> <x> <y> <w> <h> above|below`, both wl_subsurface modes, input regions deciding the pointer); `WINDOW geometry` (a client-side frame's window inside its buffer); `WINDOW move`, `resize` and `menu` from a program's own title bar, only with a press's serial; tiled states; the clipboard and the primary selection bridged to Hibr's clipboard (`CLIP offer/read/clear`, one text type, pipes passed with the line, no bytes kept, secrets by `x-kde-passwordManagerHint` kept out of history and cleared both ways) | 0.3.74 | 0228, 0229 | Tested (`compositor_gate` with ASan/UBSan: `--sub`, `--csd`, `--clip` and a restart; Hibr's native suite through the real desktop against the same build; not yet Firefox on the owner's machine) |
| `blit-compositor`, X programs, milestone A (ADR 0228 phase 2; `docs/api.md`, "X programs"): Xwayland 23.1 or later started with the compositor on the first free X display (`-listenfd`, `-rootless`, `-wm`, `WAYLAND_SOCKET`; refused older, restarted when it dies, given up after three quick deaths, ended with the compositor and its sockets and lock removed), the compositor its X window manager on libxcb (Composite redirect, the WM check window, `WM_STATE`), X windows associated by `xwayland_shell_v1` (`set_serial` and the `WL_SURFACE_SERIAL` client message, either order), each X top-level a window on the same lines as a Wayland one (`new`, `title` from `_NET_WM_NAME`/`WM_NAME`, `appid` from `WM_CLASS`, `decor server`, frames, `INPUT sock`; `WINDOW size` resizes it and gives it X focus, `WINDOW close` sends `WM_DELETE_WINDOW`); `WINDOW display <name> <x-display>`; per X window, commit to frame sent over its first 60 frames in the log. Milestone C (0.3.81): override-redirect menus and tooltips as popups (moved with their program from 0.3.82), `WM_TRANSIENT_FOR` parents, `WM_NORMAL_HINTS` limits, `_NET_WM_STATE` full screen and maximize, `_NET_WM_MOVERESIZE`, minimize, `_MOTIF_WM_HINTS` decor (0.3.80), X cursors by name; `--x11 on|off` (0.3.81). Milestone D (0.3.84): CLIPBOARD and PRIMARY onto the one clipboard both ways, INCR, the Vault's hint, deadlines on every transfer | 0.3.78 | 0228 | Used (`xwayland_gate` in the build environment against Xwayland 24.1, tcc and ASan/UBSan; xterm and Steam on the owner's machines) |
| One copy of the documentation, and FreeMono's source in its own small package `blit-font-sources` (suggested, not installed by default): the package is 17.2 MB, down from 24.6 MB. The sources package went with the face it carried (ADR 0243) | 0.3.45 | 0217 | Tested |
| The terminal answers XTGETTCAP for `sgr-framed`, `sgr-framed-bar` and `sgr-shadow` (booleans), so a client that holds only the terminal can detect Blit's SGR extensions | 0.3.46 | - | Tested |
| `fonts.hinting` (`full`, `light`, `none`; default `full`) sets the FreeType hinting of text glyphs through `PUT /v1/fonts` and the settings document; fitted icons ignore it | 0.3.47 | 0218 | Tested |
| Blit's colour icons can be drawn as a monochrome shape that says state (battery level, charging, mains, signal, volume) by shape, in black, white or the cell's foreground; 0.3.48 chose this with the global `fonts.icon_colour` setting, which 0.3.49 replaced with the per-cell icon pen | 0.3.48 | 0220, 0221 | Tested |
| The icon pen is per cell: SGR 68:v (1 auto, 2 black, 3 white), ended by SGR 69, so a menu bar draws its icons monochrome while the desktop and file manager beside it keep them in colour; a change is cell damage only (no glyph-cache rebuild, no reflow); `style.icon_pen` in the cells API, `sgr-icon-pen` in the server capabilities and XTGETTCAP, reported by DECRQSS | 0.3.49 | 0221 | Tested |
| The hui badge is a solid teal disc with white letters (its monochrome shape unchanged: the disc with the letters cut out); a new hui mark, the H-U-i monogram in teal without a disc, two columns (`hui-mark-left` + `-right`, U+1012C5-1012C6), its monochrome shape its own outline | 0.3.51 | 0197, 0220, 0221 | Tested |
| Two wiretap icons for Hibr's network monitor and firewall, a water tap in water blue (#2e8fe0), two columns each: on, with a drop under the spout (`wiretap-left` + `-right`, U+1012C7-1012C8), and off, without it (`wiretap-off-left` + `-right`, U+1012C9-1012CA); each monochrome shape is its own outline, and on and off differ by shape (`font_icon_shape_gate`) | 0.3.52 | 0197, 0220, 0221 | Tested |
| The wiretap icons in one column, a bolder tap in the same water blue: on, with the drop (`wiretap-1`, U+1012CB), and off, without it (`wiretap-1-off`, U+1012CC), from one drawing whose drop is a level (clear when off, so both states sit in one box and the tap does not move); the monochrome off shape has no drop, and on and off differ by shape (`font_icon_shape_gate`) | 0.3.53 | 0220, 0221 | Tested |
| A minimise box for the title bar, Chalk and Slate, normal and pressed (also hover): a short bar along the bottom of the box, apart from shade's bar across the middle and zoom's square (4 glyphs, U+1012CD-1012D0: `chalk-minimise`, `-pressed`, `slate-light-minimise`, `-pressed`) | 0.3.54 | 0222 | Tested |
| Wi-Fi as a fan, one column: `wifi-signal-1` to `-4` (U+1012D1-1012D4), a dot and three arcs lit in teal up to the level, the rest in the bars' inactive slate, and `wifi-off` (U+1012D5), the fan unlit with a red cross (monochrome: the cross alone); every level differs by shape (`font_icon_shape_gate`). The four bars are the mobile signal: `cellular-1` to `-4` (U+1012D6-1012D9), and `wifi-1` to `-4` are deprecated, `replaced_by` the cellular ids, still drawn | 0.3.55 | 0214, 0220 | Tested |
| Wi-Fi and volume in two columns, beside the one-column forms (unchanged): `wifi-signal-wide-1` to `-4` and `wifi-off-wide` (U+1012DA-1012E3) and `volume-wide-0` (muted) to `-3` (U+1012E4-1012EB), each `-left` + `-right`; the same drawings as `wifi-signal-N`, `wifi-off` and `volume-N`, about twice the size, every level in one place; each level differs by shape across the whole badge (`font_icon_shape_gate`) | 0.3.56 | 0197, 0220 | Tested |
| The classic desk telephone in two columns, beside the one-column form (unchanged): `phone-classic-wide-off`, `-wait`, `-on` and `-ring` (U+1012EC-1012F3), each `-left` + `-right`; the same drawings as `phone-classic-off` to `-ring`, about twice the size; each state differs by shape across the whole badge (`font_icon_shape_gate`) | 0.3.57 | 0197, 0220 | Tested |
| The battery lying on its side in two columns, beside the upright one-column battery (unchanged): `battery-wide-0` to `-4` (U+1012F4-1012FD), `battery-wide-0-charging` to `-4-charging` (U+1012FE-101307) and `battery-wide-ac` (U+101308-101309), each `-left` + `-right`; four segments left to right, the charging bolt with a dark edge (legible on light and dark bars and over the green); monochrome: the body and the lit segments, the bolt and the plug cut out; each state differs by shape across the whole badge (`font_icon_shape_gate`) | 0.3.58 | 0196, 0197, 0220 | Tested |
| A full-screen box and a sticky box for the title bar, Chalk and Slate: full screen normal and pressed (also hover), four corner brackets in the box; sticky normal, pressed and on (the window is sticky), a pin, bold when on; pressed as ADR 0219's boxes; each mark apart from close, minimise, shade and zoom (10 glyphs, U+10130A-101313: `chalk-fullscreen`, `-pressed`, `slate-light-fullscreen`, `-pressed`, `chalk-sticky`, `-pressed`, `-on`, `slate-light-sticky`, `-pressed`, `-on`) | 0.3.59 | 0224 | Tested |
| The status icons' greys are one, #7d8796, legible on light and dark bars (at least 3:1 on #ececf0 and #24242a): the battery, volume and Wi-Fi/cellular bodies (were #c9d1d9) and their unlit parts (were #3e526b); only the colour changed, no shape | 0.3.56 | 0220 | Tested |
| Builds on any current Linux distribution from the system's own development packages, found through `pkg-config` with minimum versions (libdrm 2.4.114, FreeType 2.12.1, HarfBuzz 6.0.0, zlib 1.2.13, wayland 1.21.0, xkbcommon 1.5.0, wayland-protocols 1.32, libxcb 1.15 (xcb, composite, xfixes, res, randr); EGL, GLES and GBM headers only): `tools/build-flags.sh`, the one place the build, every gate and every tool ask, refuses a missing or too-old module by name; `PKG_CONFIG_PATH` the one override; the hand-built `build/deps/prefix`, the Debian library paths and the `BLIT_FREETYPE_*`/`BLIT_HARFBUZZ_LIBRARY` variables retired; the package names for Debian/Ubuntu, Fedora and Arch in docs/toolchain.md. `.deb` packages today, rpm and Arch later | 0.3.76 | 0230 | Tested |
| `blit --version` and `blit --help` | 0.3.20 | — | Tested |

## Diagnostics

| Feature | Since | Status |
| --- | --- | --- |
| Runtime counters: frames, flips, missed refreshes, GPU time, per-output phases, when after the vblank each flip was submitted | 0.1; GPU time 0.2.16; submit phase 0.3.14 | Used |
| Event log, correlated trace, observation snapshot, process view | 0.1; processes 0.2.17 | Used |
| Console watchdog: restores the screen and reports where the loop stalled | 0.1.587; report 0.2.26 | Used |
| Screenshots and session output capture | 0.1; capture 0.2.31 | Used |
| Performance panel: per display, what it drew, why, its times, pictures and a frame-time graph; Blit-wide loop, input, glyphs and errors once; Hibr's STA1 lines; translucent by `hud.opacity` (0.3.25); both compositors; `hud` setting, `BLIT_HUD` | 0.3.22 | Tested |
| Glyph cache hits and misses; desktop CPU over the desktop's whole process tree | 0.3.22 | Tested |

## Retired

Gone on purpose, so nothing should rely on them:

- **`blit-gamescope` and the libei input path** (0.3.75, ADR 0228), by the
  owner's decision: the bridge that showed games and Steam in a window
  through a headless gamescope, its package, the `INPUT eis` route to a
  compositor's EIS socket (libei, loaded at run time) and, with it,
  `frames.input`'s `backend` and `region`. The `blit` package Breaks
  `blit-gamescope` and `steamer` (the Steam launcher app, retired with
  it), so an upgrade removes both. Programs in windows go through
  `blit-compositor` and its `INPUT sock` routes; Steam and other X11
  programs run under Xwayland since 0.3.78 (ADR 0228 phase 2).
- **SDL renderer** (0.2.22, ADR 0184), and with it presentation trials,
  `server.renderer`, `BLIT_RENDERER` and display rotation (its last
  plumbing removed in 0.3.16; `rotation` other than 0 is refused).
- **Global scanlines** (`PUT /v1/effects`), replaced by per-pane effects (0.2.27).
- **Built-in Retro/Modern fonts** and the console profiles (0.2.35, 0.2.36),
  and Iosevka (0.2.37).
- **Blit Arabic Modern** (ADR 0243), the per-cell Arabic companion derived
  from GNU FreeMono, with the `arabic` font setting (`naskh` or `modern`,
  0.3.129-0.3.130) and the `blit-font-sources` package. Arabic is shaped as
  words in Noto Naskh Arabic alone; `active.arabic` is now that face's
  report and `active.arabic_companion` is gone. A stored `font.arabic` is
  ignored. `blit` declares no relation to `blit-font-sources`, so a host
  that installed it keeps it until it is removed (`apt purge
  blit-font-sources`): it is a source archive under `/usr/share/doc`, and
  a Breaks would make the updater's `dpkg --install` refuse the update.
- **Large telephone icons** U+101023–101032 (0.3.5), and the blue, green and
  amber slots of non-folder file icons (0.3.9). Retired codepoints are
  never reused.
