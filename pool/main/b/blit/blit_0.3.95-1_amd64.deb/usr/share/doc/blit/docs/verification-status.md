# Verification status

A ledger, newest first: each entry records what was true and what was tested
at that release, and is not revised afterwards. Older entries describe Blit as
it was then. In particular SDL (and with it SDL's KMSDRM driver, its renderers
and its rotation) was removed in 0.2.22 (ADR 0184), so entries before that
mention an SDL backend that no longer exists. Blit today presents only through
Linux DRM/KMS, composing frames on the GPU with OpenGL ES (Mesa, loaded at run
time) or on the CPU, with no X11, Wayland or SDL underneath. For current facts
read the README, `docs/architecture.md`, `docs/features.md` and `docs/api.md`.

## 2026-11-12: 0.3.94 keyboards on the frame channel; dead keys and compose (ADR 0231 step 3)

- **Keyboards for a desktop without the API token:** `KEYBOARD list`
  and `KEYBOARD current <n>` on the frame channel; Blit answers with the
  list (`KEYBOARD item ...`, `KEYBOARD current <n>`) and sends it again
  on every change; opt-in. For Hibr's switcher (#529).
- **Dead keys and compose** in terminals: a compose state per keyboard
  on the locale's table (libx11-data, now a dependency; the mini PC has
  it, checked before the deploy).
- **Suites:** the build environment, the tagged commit: `compositor_gate`,
  `xwayland_gate` (ASan/UBSan), `package_artifact_gate`. This host:
  `frame_input_gate` (its keyboards part), `kitty_keyboard_gate` 63
  cases (us(intl) dead acute), `keyboard_settings_gate` (six keyboards);
  gcc no new warnings; `all` 188 pass, 12 skip; `renderer` 82 pass;
  `renderer-gles` 61 pass and `burn_in_gate` counted 26 animation frames
  for its 1.6 s fade once (the Blit pane's gates ran alongside it, adding
  load), then passed 3 of 3 alone.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-12: 0.3.93 keyboards: the system's layouts in a list, switched live (ADR 0231 step 2)

- **Keyboards:** `GET/PUT /v1/input/keyboards` (an ordered list of xkb
  layouts and variants with the system's names, and the current one) and
  `/v1/input/keyboards/available[?layout=]` (what xkeyboard-config has).
  A switch reaches terminals, Wayland and X programs (keymap and Blit's
  modifiers, locks kept) and the input stream (`keyboard` event); the list
  is kept in the settings document. Phonetic Arabic types letter by
  letter; Ctrl+C stays 0x03 by the base key.
- **Suites:** the build environment, the tagged commit: `compositor_gate`
  (a switch to Arabic and back reaching the client) and `xwayland_gate`,
  both ASan/UBSan; `package_artifact_gate`. This host: `kitty_keyboard_gate`
  61 cases, `keyboard_settings_gate` (kept across a restart, an unknown
  layout 422), `api_schema_gate` (53 paths); gcc `-Wall -Wextra` no new
  warnings; `all` 188 pass, 12 skip; `renderer` 82 pass;
  `renderer-gles` 62 pass. The Blit pane's four gates against this
  server.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-12: 0.3.92 Firefox's menus: a popup's subsurfaces, popups of popups, the grab

- **Compositor:** a popup's subsurfaces are flattened onto the popup
  (`WINDOW sub <id> <popup>`): Firefox draws a menu's contents in one, and
  the owner's log showed "a popup's, not shown in this release" for every
  menu opened. Popups of popups (submenus) are hit-tested at any depth, a
  popup's subsurfaces in the popup, and a grabbing popup has the keyboard.
  Hibr places them (#528).
- **Suites:** the build environment, the tagged commit: `compositor_gate`
  (its new popup tree: the lines, the frames, the pointer on the contents
  and the submenu, a key to the grabbing submenu) and `xwayland_gate`,
  both ASan/UBSan; `package_artifact_gate`. This host: gcc `-Wall -Wextra`
  clean on the compositor; `all` 187 pass, 12 skip, and
  `under_text_picture_gate` timed out once under parallel load (passed 3
  of 3 alone; the server is unchanged in this release; filed); `renderer`
  82 pass; `renderer-gles` 62 pass.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-12: 0.3.91 keyboards from the system's xkb keymap; Blit's modifiers reach programs (ADR 0231 step 1)

- **Keyboard:** what a key types, its modifiers and its locks come from
  libxkbcommon: the system's xkeyboard-config `us`, one keymap for every
  keyboard, an xkb state per keyboard. The same keymap goes to
  blit-compositor and its Wayland and X programs, and Blit's modifiers
  go with it (`INPUT modifiers`): Num Lock at Start and a lock across a
  keymap change now reach programs. Device roles are applied as the
  role's own key. Changes a US typist sees: the ISO key beside Left
  Shift types `<` and `>`, Right Alt is Alt, a lock goes off at the
  release of its unlocking press. The per-device `keymap` override is
  removed; a stored one is dropped as the settings are read.
- **Suites:** the build environment, the tagged commit: `compositor_gate`
  and `xwayland_gate` (ASan/UBSan), `package_artifact_gate`. This host:
  `kitty_keyboard_gate`, `key_encoding_gate`, `keymap_gate`,
  `input_stream_text_gate`, `keyboard_settings_gate`, `frame_input_gate`;
  gcc `-Wall -Wextra` no new warnings; `all` 188 pass, 12 skip;
  `renderer` 82 pass; `renderer-gles` 61 pass and `zoomed_effects_gate`
  failed once (its static-noise check, two screenshots 0.15 s apart under
  parallel load: a test-timing fault, filed), then passed 3 of 3 alone.
  The mini PC has libxkbcommon0 1.7.0 and xkb-data 2.42 (checked before
  the deploy).
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-12: 0.3.90 a keyboard's repeat period is state; a configuration sent back as read is accepted

- **Input devices:** `repeat_period_ms`, the period the kernel holds, is
  reported in the device's `state`, not its `configuration`. A
  configuration holds only what may be written, as Blit refuses
  against; carrying the period, a configuration sent back as read had
  the device's whole entry refused, and a settings document saved by
  the Blit control panel lost every keyboard setting while the PUT
  answered 200 (found writing the Blit Keyboard pane, pane 0.1.30).
- **Suites:** the build environment, the tagged commit: `compositor_gate`,
  `xwayland_gate` (ASan/UBSan), `package_artifact_gate`. This host:
  `keyboard_settings_gate` (the period from state, configuration without
  it, a configuration sent back as read answered 200); `all` 188 pass,
  12 skip; `renderer` 82 pass; `renderer-gles` 62 pass;
  `api_schema_gate`, `documentation_gate`. The Blit pane's
  `blit_keyboard_gate`, `blit_mouse_gate`, `blit_panel_gate` and
  `blit_ui_gate` against this server.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-12: 0.3.89 kitty keyboard flag 16, the text a key types

- **Keyboard:** kitty flag 16, report associated text (with flag 8): a
  press or repeat that types text carries it as a third field of code
  points (`CSI 223;1;92u`, AltGr on a layout keymap typing a backslash),
  the text `evdev_key_character` gives the legacy encoder, and a keypad
  key's operator, or its digit with NumLock on. A release, a chord with
  Ctrl, Alt or Super, a functional key and control characters carry none.
  `supported_flags` is 31 in the API and the schema. The desktop needs
  flags 8 and 2 to see a lone Super tap for the start menu (Hibr #516);
  with 16 it still reads every character typed.
- **Suites:** the build environment, the tagged commit: `compositor_gate`,
  `xwayland_gate`, both with ASan/UBSan; `package_artifact_gate`. This
  host: `kitty_keyboard_gate` 58 cases (9 new); gcc `-Wall -Wextra` no new
  warnings; `all` 187 pass, 12 skip, `terminal_conformance` failed on its
  old expectation that 16 is masked, then passed (275 cases) after its
  query test was updated (test file only, no `src` change); `renderer` 82
  pass, `renderer-gles` 62 pass; `api_schema_gate`, `documentation_gate`.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-12: 0.3.88 the desktop's displays, X's layout and primary (Hibr #514)

- **Displays:** `WINDOW layout <name> <x> <y> <w> <h> <mHz>` and `WINDOW
  layout end` give one `wl_output` per display at its place (with
  `zxdg_output_manager_v1`); `WINDOW output` takes the display's name, so
  two displays of one mode are told apart. X's layout mirrors the
  displays: the root is their union, an X window stays inside its display
  and follows it, a full-screen one goes to its display's origin.
  `WINDOW primary <name>` is X's RandR primary (re-set after Xwayland
  restarts), so games size themselves to the display the desktop's Full
  Screen On setting names (Hibr 0.99.497). A desktop that sends no layout
  gets the earlier behaviour.
- **Suites:** the build environment, the tagged commit: `compositor_gate`
  (layout, named output), `xwayland_gate` (RandR monitors and primary,
  placement, full screen, displays swapped, restart), both with ASan/UBSan;
  gcc `-Wall -Wextra` clean; `package_artifact_gate`. This host: `all` 187
  pass, 13 skip (`compositor_gate` skipped for the missing
  libxcb-randr0-dev, installed after; it then passed here), `renderer` 82
  pass, `renderer-gles` 62 pass; `documentation_gate`.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-12: 0.3.87 the system linker links; Blit's crash backtrace

- **Hardening:** tcc compiles, the system linker links (`tools/tcc-link.sh`):
  every program and the Hibr adapter declares a stack that is not
  executable, the programs have RELRO. Before, `blit-server`'s thread
  stacks were `rwxp` and a gcc-built process on glibc 2.41 could not load
  `console-blit.so` (Hibr's shell is moving to a non-executable stack, ADR
  0055 there). tcc's `-bt` backtraces are replaced by `src/blit_crash.h`:
  frames to standard error and `addr2line` for function, file and line.
- **An unchanged `WINDOW size`** no longer reconfigures the program.
- **Gates:** `tcc_fault_trace_gate` (Blit's handler, built as Blit is: RW
  stack, RELRO, SIGSEGV, addr2line naming a static function and its caller
  with file and line); `package_artifact_gate` checks every shipped ELF
  file; `compositor_gate`'s nudges are new sizes, and its count of the
  popup's last frame callback accepts the race it lost about one run in six
  (all six frames presented).
- **Suites:** the build environment, 7f9ab08: `compositor_gate` (four
  runs), `xwayland_gate`, ASan/UBSan, gcc `-Wall -Wextra` clean,
  `package_artifact_gate`. This host, rebuilt: `all` 188 pass, 12 skip, 0
  fail; `renderer` 82 pass, 1 skip; `renderer-gles` 62 pass;
  `documentation_gate`. Two checkouts gave byte-identical packages (blit
  6f6a8fa7..., blit-compositor 80c1e112...). An earlier full run's
  `kms_frame_timing_gate` failed under the run's parallel load and passed
  alone three times (60/60).
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.86 programs ask the desktop for focus

- **`WINDOW activate <id> x-focus|x-active|xdg-activation`:** a program's
  request for focus goes to the desktop, which grants it with `activated`
  or refuses (its focus-stealing setting, Hibr #507). X's focus follows the
  desktop's activated window: a program that takes it uninvited (Steam
  from its own game, on the owner's mini PC) has it put back and asks.
  `xdg_activation_v1` offered (tokens once, 30 s). Menus in their grab, and
  a program's answer to WM_TAKE_FOCUS within 1 s, keep focus.
- **Suites:** the build environment, 41dd199: `xwayland_gate` (a thief put
  back x3 with one ask, grants, _NET_ACTIVE_WINDOW, a focused menu) and
  `compositor_gate` (tokens: bad, used, valid), both with ASan/UBSan; gcc
  `-Wall -Wextra` clean; `package_artifact_gate`. This host, rebuilt: `all`
  188 pass, 12 skip, 0 fail; `renderer` 82 pass, 1 skip; `renderer-gles`
  62 pass; `documentation_gate`.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.85 the pointer's session once per event

- **Fix (a 0.3.83 regression):** the session under the pointer was looked
  up once per input route, every route of every channel, on every mouse
  motion, button and wheel notch; a desktop gives each display's session a
  route to every window, so moving the mouse cost Blit time per route (the
  owner saw Blit's CPU rise while moving windows). Each event asks once.
- **Suites:** the build environment, 831a15f: `compositor_gate`,
  `xwayland_gate`, ASan/UBSan, `package_artifact_gate`. This host, rebuilt:
  `all` 188 pass, 12 skip, 0 fail (`frame_input_gate`'s three modes);
  `renderer` 82 pass, 1 skip; `renderer-gles` 62 pass;
  `documentation_gate`.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.84 X copy and paste (ADR 0228 phase 2, milestone D)

- **X selections:** CLIPBOARD and PRIMARY onto the one clipboard, both
  ways, on the existing `CLIP` lines: an X program is one more owner and
  reader. Text targets mapped (UTF8_STRING first, STRING as Latin-1),
  INCR at 64 KiB both ways, the Vault's `x-kde-passwordManagerHint` kept
  both ways and the X selection given up at the desktop's `CLIP clear`,
  3 s deadlines on every transfer, ownership only while an X window has
  the keyboard (as wlroots). Open: a `CLIP read` pipe cut short carries
  no error (a wire change).
- **Suites:** the build environment, 1cbbd2c: `xwayland_gate` (selections
  byte for byte, 700001-byte INCR both ways, secret, stalls, quick
  ownerships, another X client, Xwayland restart) and `compositor_gate`,
  both with ASan/UBSan; gcc `-Wall -Wextra` clean; `package_artifact_gate`.
  This host, rebuilt: `all` 188 pass, 12 skip, 0 fail; `renderer` 82
  pass, 1 skip; `renderer-gles` 62 pass; `documentation_gate`.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.83 a closing window releases its keys; the pointer where it is

- **Stuck keys:** the focused surface going now takes the keyboard away as
  any focus change does (keys released, modifiers cleared, leave). On the
  owner's mini PC every xterm closed within 20 ms after one was ended with
  Ctrl-D: Xwayland kept Ctrl+D pressed and auto-repeated it (traced with
  strace on the machine). `compositor_gate` (`--gone-on-ctrl-d`) failed
  before the fix.
- **Pointer routing:** keys to the focused session's route, the pointer
  (motion, presses, the wheel) to the route in the session under it, a
  release to the route its press went through; `frames.input` says
  `pointer.here`. Firefox raised from a menu on one display and shown on
  the other took no pointer (traced on the mini PC). `frame_input_gate`'s
  new two-display mode failed before the fix.
- **Suites:** the build environment, 7901992: `compositor_gate`,
  `xwayland_gate`, ASan/UBSan, `package_artifact_gate`. This host, rebuilt:
  `all` 188 pass, 12 skip, 0 fail; `renderer` 82 pass, 1 skip;
  `renderer-gles` 62 pass; `documentation_gate`. (A first host run was
  stopped: the server was rebuilt under it for the routing change.)
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.82 a popup its program moves follows

- **Popups that move:** `xdg_popup.reposition` and an X menu its program
  moves are `WINDOW popup` again at the new offset; Hibr's frames module
  already took a repeated popup line as a move. Before, both kept their
  first place.
- **Gates:** `compositor_gate` (`wl_standin_client --popup-move`: the line
  again at 22,73, the frame there, the client told repositioned; its
  counts follow the extra frame) and `xwayland_gate` (the stand-in's menu
  moved 20,10: `WINDOW popup 2 1 50 50`, a press there a choice).
- **Suites:** the build environment, 11993a3: `compositor_gate`,
  `xwayland_gate`, ASan/UBSan, `package_artifact_gate`. This host,
  rebuilt: `all` 188 pass, 12 skip, 0 fail; `renderer` 82 pass, 1 skip;
  `renderer-gles` 62 pass; `documentation_gate`.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.81 X programs, milestone C; the X11 switch

- **Milestone C** (ADR 0228 phase 2): X override-redirect windows (menus,
  dropdowns, tooltips) are `WINDOW popup`s of their toplevel;
  `WM_TRANSIENT_FOR` parents; `WM_NORMAL_HINTS` limits; `_NET_WM_STATE`
  full screen and maximize both ways; `_NET_WM_MOVERESIZE` move and
  resize; `WM_CHANGE_STATE` minimize; X stacking under the pointer; X
  cursors by name through Blit's one table (`src/blit_pointer_names.h`).
  Each onto the line its Wayland equivalent produces; no wire additions.
- **`blit-compositor --x11 on|off`**, the desktop's X11 Programs setting
  (Hibr #504); the gates' `BLIT_COMPOSITOR_XWAYLAND=none` is gone.
- **Gate fixes:** `graphics_memory_gate`'s 1-in-50 hang (a FIFO race; 50
  runs in two lanes clean); the shared gate `Server` is ready only when
  its own process answers and stops it on a failed start (the 0.3.81 full
  run met another program on 19663).
- **Suites:** the build environment, e743bbe: `compositor_gate` (with the
  `--x11` checks), `xwayland_gate` (menus, dialogs, hints, states,
  move/resize, minimize, cursors, Motif, `+accessx 1`; median 1.6 ms),
  both with ASan/UBSan, gcc `-Wall -Wextra` clean, `package_artifact_gate`.
  This host (being upgraded to Debian 13 during the run): `all` 187 pass,
  12 skip, 1 fail (`graphics_memory_frames_gate`, the port held by
  another program; fixed in the helper, passing alone, and failing by
  name with the port held); `renderer` 82 pass, 1 skip; `renderer-gles`
  62 pass; `documentation_gate`.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.80 X windows that draw their own frame; releases built on this host

- **Motif decorations:** the X window manager reads `_MOTIF_WM_HINTS`; no
  decorations (Steam) is `WINDOW decor <id> client`, at announce and on
  every change -- the line a Wayland program's client-side decoration
  gives, one rule for every program. `xwayland_gate` toggles it both ways.
- **Build environment:** `tools/build-env` (Debian 13, podman) and
  `tools/release/build-release.sh`. This host's Debian 12 has not built
  blit-compositor since 0.3.76 (wayland-protocols 1.31); 0.3.76-0.3.79
  were built on the owner's desktop and copied back by the owner. With the
  checkout mounted at `/blit` and every staged path's mode and time
  normalized (one checkout's font file was 0664 and another dated 2018),
  the same commit built in two checkouts gave byte-identical packages
  (blit 5ca1aa4f..., blit-compositor 7b75c4c2...); before, the compositor
  already matched the desktop's 0.3.79 bytes.
- **Suites:** the environment, 5d23f3e: `compositor_gate`, `xwayland_gate`
  (Motif both ways, `+accessx 1`, median 1.6 ms) with ASan/UBSan,
  `package_artifact_gate`. This host, rebuilt: `all` 186 pass, 13 skip, 1
  fail -- `graphics_memory_gate` hung (no output for 300 s; the second
  such hang seen, nothing in this release touches it; three runs alone
  pass in 11 s each; under investigation); `renderer` 82 pass, 1 skip;
  `renderer-gles` 62 pass.
- **Published** to hibr-apt from this host (blit, blit-compositor).

## 2026-11-11: 0.3.79 the keymap's indicators (Xwayland crashed 120 s after a key)

- **Fix:** Xwayland died (SIGSEGV at 0x8) about 120 s after the last key
  in any X window -- seen on the owner's HP with Steam open. Debian's
  xwayland-dbgsym 24.1.6-1 put it in AccessXTimeoutExpire ->
  XkbUpdateAllDeviceIndicators -> XkbUpdateLedAutoState: Blit's keymap had
  no indicators, and Xwayland applying a keymap with none frees its
  keyboards' indicator maps (_XkbCopyIndicators) while their LED state
  still points into them. The keymap now names and defines "Caps Lock"
  and "Num Lock", lit while Lock and Num Lock are locked.
- **Gates:** `xkb_keymap_check` requires both indicators (off at first,
  lit by the key carrying the lock's keysym; fails on 0.3.78's keymap);
  `xwayland_gate` runs Xwayland with `+accessx 1` and checks it outlives
  the timeout (on the owner's desktop: passes, and fails with 0.3.78's
  keymap by the same SIGSEGV at 0x8).
- **Suites:** this host, main d730a33 rebuilt: `all` 187 pass, 13 skip, 0
  fail; `renderer` 82 pass, 1 skip; `renderer-gles` 62 pass. The owner's
  Debian 13 desktop, d730a33: `compositor_gate` and `xwayland_gate`
  (median 1.4-1.5 ms) with ASan/UBSan, the packages built there and
  `package_artifact_gate` passing; brought here by scp, checksums
  verified.
- **Published** to hibr-apt (blit, blit-compositor).

## 2026-11-11: 0.3.78 X programs, milestone A (ADR 0228 phase 2)

- **X programs:** `blit-compositor` starts Xwayland (23.1 or later,
  xwayland_shell_v1) and is its window manager on libxcb: an X program's
  window is a Hibr window (title, class, size from the desktop, focus, keys
  and clicks, close by WM_DELETE_WINDOW). `WINDOW display <wayland> <x>`
  names the X display (`-` when X is off); Hibr 0.99.486 exports
  `DISPLAY`. Xwayland is restarted when it dies; three quick deaths turn
  X off with the reason logged. Menus, tooltips, X states and pointer
  shapes, and selections are milestones C and D.
- **Fix:** `zoomed_effects_gate` stops its server before removing its
  directory (a pass could end in ENOENT).
- **Suites:** this host, main 011c130 rebuilt: `all` 186 pass, 13 skip, 1
  fail (`zoomed_effects_gate`'s cleanup race, fixed in 9f0f8f7 and passing
  three runs); `renderer` 82 pass, 1 skip; `renderer-gles` 62 pass, 0
  fail -- the first real GLES run since 0.3.72: 0.3.73-0.3.77's "GLES
  `renderer`" lines were the `renderer` suite, which runs on the CPU
  compositor. The owner's Debian 13 desktop, 9f0f8f7, real Xwayland
  24.1.6: `xwayland_gate` (commit to frame sent, first 60 frames: median
  1.2-1.5 ms) and `compositor_gate`, both with ASan/UBSan; the packages
  built there and `package_artifact_gate` passing; brought here by scp,
  checksums verified.
- **Published** to hibr-apt (blit, blit-compositor).

## 2026-11-10: 0.3.77 input routes per session; the global menu's wire (ADR 0229)

- **Fix (a 0.3.76 regression):** one route per compositor window socket
  per session, not across sessions. Hibr gives each display's session its
  own route to a window (the session with the pointer or keyboard
  delivers; a window over a seam takes input on both halves); 0.3.76 let
  the last display asked win, so Firefox drawn on HDMI had its only route
  on DP's session. A route in another session to the same socket now
  stands.
- **The global menu, Blit's side:** `WINDOW appmenu <id> <service> <path>`
  from org_kde_kwin_appmenu (`- -` released); Hibr's side is #500.
- **Phase 2 planned** in ADR 0228 (Xwayland, approved by the owner).
- **Suites:** this host, main 6519aae rebuilt: `all` 187 pass, 12 skip, 0
  fail; GLES `renderer` 82 pass, 1 skip, 0 fail; `frame_input_gate` three
  runs. The owner's Debian 13 desktop, 6f8ae85: `compositor_gate` with
  ASan/UBSan (cursor and appmenu cases), the packages built there and
  `package_artifact_gate` passing; brought here by scp, checksums
  verified.
- **Published** to hibr-apt (blit, blit-compositor).

## 2026-11-10: 0.3.76 cursor shapes, one route per window, a portable build (ADR 0229, ADR 0230)

- **Cursor shapes:** programs name their pointer (wp_cursor_shape_v1) and
  Blit's own pointer art draws it (`WINDOW cursor <id> <name>`, OSC 22's
  names; `none` hides; a program's own cursor images are never drawn).
- **Input routes:** one route per compositor window socket (a new one ends
  a route left behind, releasing what it held, `superseded`); each route
  says whether its picture is `present` in its session.
- **WINDOW size:** the state words in any order (the desktop's full screen
  and maximize had been dropped as unknown lines).
- **Build:** dependencies from the system through pkg-config, one place
  (tools/build-flags.sh, ADR 0230), minimums stated; the hand-built
  prefix retired. wayland-protocols >= 1.32 for the compositor: this build
  host (1.31) skips the compositor gate with the reason, and this release's
  packages were built on the owner's Debian 13 desktop.
- **Gates:** every Blit process a gate starts gets a hermetic environment
  (no inherited `BLIT_*`, fake input devices), proved by `gate_env_gate`.
- **Docs:** programs in windows -- what to expect.
- **Suites:** this host, main fae186d rebuilt: `all` 187 pass, 12 skip
  (the compositor gate among them, below its minimum), 0 fail; GLES
  `renderer` 82 pass, 1 skip, 0 fail. The owner's Debian 13 desktop:
  `compositor_gate` with ASan/UBSan on 0cfa8e1 (the same compositor), and
  the packages built there from 6668e28 with `package_artifact_gate`
  passing; brought here by scp, checksums verified against the desktop's.
- **Published** to hibr-apt (blit, blit-compositor).

## 2026-11-10: 0.3.75 gamescope removed; the compositor is the one path (ADR 0228)

- **Removed, by the owner's decision ("no legacy stuff loose"):**
  blit-gamescope (the bridge, its package and build target), the libei
  input path (`INPUT eis`, now an unknown verb answered `INPUT error 0
  EINVAL`), their gates, ADR 0206 and 0225 (superseded by 0228); steamer
  retired with it. `blit` Breaks `blit-gamescope` and `steamer`; the pool's
  blit-gamescope versions removed in this publish. Steam and X11 programs
  return through phase 2 (Xwayland).
- **Kept, on `INPUT sock` alone:** the routes, members, hold modes,
  release-all, the live rule and the keymap memfd; `frame_input_gate`
  covers on sock every case the stand-in libei did.
- **Gates:** the root gates (auxiliary_native, auxiliary_policy,
  login_desktop_observer, login_identity) keep Blit's state in a directory
  of their own; they had written the build host's /var/lib/blit, whose
  stale GLES start marker turned a later GLES gate's server to the CPU.
- **ADR 0228:** the owner dropped phase 0's latency condition for phase 2.
- **Suites** (main 94172dc, the server rebuilt): `all` 187 pass, 11 skip,
  0 fail; GLES `renderer` 82 pass, 1 skip, 0 fail; `compositor_gate` with
  ASan/UBSan; `frame_input_gate` three runs; `package_artifact_gate`
  passes. Hibr 0.99.483's end to end against this build (keys and pointer
  across a restart, subsurfaces, geometry, clipboard, menu, resize) green
  on its side.
- **Published** to hibr-apt with hibr 0.99.483 in one call that also
  removes blit-gamescope. The owner purges blit-gamescope and gamescope
  once by hand.

## 2026-11-10: 0.3.74 frame channel version 5, and programs as whole windows (ADR 0228, ADR 0229)

- **Version 5, a flag day with Hibr 0.99.482:** one grammar on the frame
  channel, `<WORD> <verb> <id>`; `blit` Breaks `hibr (<< 0.99.482)`, Hibr
  Breaks `blit (<< 0.3.74)`; published together.
- **blit-compositor:** an input socket per window (keys and the pointer had
  been dropped under the desktop's picture ids); subsurfaces as pictures
  (`WINDOW sub`, Firefox's page); `WINDOW geometry`, `move`, `resize`,
  `menu` and tiled states for programs that draw their own frame; the
  clipboard and primary selection bridged to Hibr's (`CLIP`), the Vault's
  secrets kept out of history and cleared both ways. The interop map is
  ADR 0229, agreed with Hibr.
- **Documentation:** README, architecture, roadmap and features brought up
  to the compositor; blit-gamescope marked deprecated (removed in 0.3.75 by
  the owner's decision).
- **Suites** (frame-v5 08d0b74; then documentation only, re-checked by the
  documentation and API schema gates): `all` 188 pass, 12 skip, 0 fail; GLES
  `renderer` 82 pass, 1 skip, 0 fail; `compositor_gate` with ASan/UBSan
  (`--sub`, `--csd`, `--clip`, restarts); `package_artifact_gate` passes.
  Hibr 0.99.482's suites (native, 36 checks, end to end through the real
  desktop against this compositor) green on its side.
- **Published** to hibr-apt with hibr 0.99.482 in one call (blit,
  blit-gamescope, blit-compositor, hibr). Not deployed by Blit: the owner
  upgrades with apt and restarts the desktop.

## 2026-11-10: 0.3.73 programs' windows, live: the first configure and the keymap (ADR 0228 phase 1)

- **The first configure:** a toplevel's initial commit is answered at once
  (the desktop's size, else 0x0) instead of after the desktop's `WINDOW
  size`; live, `vkcube --wsi wayland` died with xdg_surface error 3. A
  program started with no desktop is configured too, and re-announced with
  its frame.
- **The keymap on the route:** `INPUT keymap <id> <revision> <size> <rate>
  <delay>` with a sealed memfd of Blit's keymap (the bytes GET
  /v1/input/keymap serves); the compositor no longer reads Blit's API and
  needs no port or token, which the desktop session does not have.
- **Restart survival** (on main since 0.3.72): programs survive a desktop
  restart, `--display NAME`, `WINDOW quit 0`.
- **Session strings:** arguments and environment of POST
  /v1/terminal-sessions bounded by the request (8192 bytes), not 255 bytes
  each; over 32, an empty name, a name with `=` or a non-string is
  `invalid_session_strings` (was the misleading `session_create_failed`).
- **Suites:** `all` 187 pass, 12 skip, 1 fail (frame_input_gate: a test
  race, the key before `INPUT on` took effect; fixed in the gate and passed
  three runs alone); GLES `renderer` 82 pass, 1 skip, 0 fail;
  `compositor_gate` with ASan/UBSan; `package_artifact_gate` passes (its
  compositor usage line updated for `--display`).
- **Published** to hibr-apt (blit, blit-gamescope, blit-compositor). No
  Breaks on hibr: it installs beside hibr 0.99.481. v5 is now Blit 0.3.74
  with hibr 0.99.482.

## 2026-11-10: 0.3.72 blit-compositor milestone C, and its package (ADR 0228 phase 1)

- **Pointer lock and confine:** `zwp_pointer_constraints_v1` v1, asked of
  the desktop with `WINDOW lock <id> relative|confine|off` and granted with
  `WINDOW lock <id> on|off` (the desktop's gesture rule; oneshot and
  persistent lifetimes; no absolute motion while locked).
- **Popups take input:** `INPUT member` in Blit -- a popup's picture joins
  its top-level's route, its points mapped into the top-level's pixels (may
  be negative), topmost draw wins; both backends; answered as INPUT.
- **Keyboard, one source:** `GET /v1/input/keymap` carries Blit's repeat
  (`X-Blit-Repeat-Rate`/`-Delay`, on 200 and 304); its default is the
  keyboard whose key came last; Blit writes `INPUT keymap <id> <revision>`
  to live sock routes when it changes, and the compositor re-reads only
  then (250 ms bound on loopback).
- **Package `blit-compositor`:** /usr/bin/blit-compositor; Depends blit (=
  0.3.72-1), libwayland-server0, libxkbcommon0; Recommends xwayland; blit
  Suggests it; built without debug info so two builds are byte-identical
  (tcc ignores -ffile-prefix-map).
- **Suites** (on the milestone's tree; the merge added documentation only,
  re-checked by schema, documentation and compositor gates): `all` 188
  pass, 12 skip, 0 fail; GLES `renderer` 82 pass, 1 skip, 0 fail;
  `compositor_gate` with ASan/UBSan; `package_artifact_gate` passes with the
  compositor leg.
- **Published** to hibr-apt (blit, blit-gamescope, blit-compositor). Not
  deployed: neither host reachable from the build machine. Hibr 0.99.481
  (#494, native windows on v4) ships against it; v5 is Blit 0.3.73 with hibr
  0.99.482.

## 2026-11-10: 0.3.71 blit-compositor milestones A and B (ADR 0228 phase 1)

- **blit-compositor**, Blit's own Wayland compositor for programs (built in
  the tree; packaged in milestone C): a frame-channel producer speaking
  hello v4 and the `WINDOW` lines (docs/api.md "Program windows", agreed
  with Hibr); xdg-shell toplevels and popups configured at exactly the
  desktop's `WINDOW size`, so any size and shape is 1:1; wl_shm frames as
  FRM1 and linux-dmabuf v4 frames as FRM3, zero copy, held until `RELEASE`,
  falling back to FRM1 on `ENOTSUP`; frame callbacks and wp_presentation
  paced per output refresh; one wl_output per mode from `WINDOW output`;
  keyboard and pointer from Blit over its own input socket (`INPUT sock`),
  with the xkb keymap from Blit's new `GET /v1/input/keymap`, generated from
  Blit's own keyboard tables; relative pointer. No libei.
- **blit-server:** hello v4 answered `window=0` and `WINDOW` lines
  `ENOTSUP`; `INPUT sock` routes (a second emitter behind the route model);
  `GET /v1/input/keymap`; a picture's `frame_us` and
  `performance.last_inject_us` (phase 0's instrument).
- **Agreed for later:** frame channel v5 (one grammar, the id always third),
  shipped with Hibr 0.99.481 as Blit 0.3.73 with Breaks both ways;
  `WINDOW lock` with the desktop's gesture rule.
- **Gates:** `compositor_gate` (wire unit, desktop, states, pacing, dmabuf,
  Blit, input, ASan and UBSan); `keymap_gate`; `frame_input_gate` sock mode;
  `all` 188 pass, 12 skip, 0 fail; GLES `renderer` 82 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes.
- **Not live yet:** neither host was reachable from the build machine (its
  route to 192.168.10.0/24 was down); published to hibr-apt, not deployed.
  A real GPU dmabuf from a program, vkcube and a GTK app wait for milestone
  C on the mini PC.

## 2026-11-09: 0.3.70 hold modes: confine and relative (ADR 0225)

- **`INPUT hold <id> relative|confine`** on the frame channel; a new route
  is `relative` (as before: hidden pointer, raw deltas). `confine`: while
  the session holds `?7701` and the route is live, Blit's pointer stays
  visible, moves as an unlocked pointer does, is clamped to the picture's
  drawn rectangle, and is sent to the compositor as absolute positions, so
  gamescope's cursor (which its stream does not carry, and which its EIS
  never reports -- read from gamescope 3.16.22's source) and the drawn one
  are one point. An older Blit answers `ERROR INPUT 0 EINVAL`. Routes report
  `hold`. One function (`frame_input_confined`) decides hiding, motion and
  relative flushing; `session_surface_px` is now shared with the hit test.
- **Gates:** `frame_input_gate` (shown, clamped at both corners, absolute
  only, raw deltas still to the holder, buttons, falls back to relative when
  undrawn, released keeps the pointer; relative hidden and still); `all` 186
  pass, 12 skip, 0 fail; GLES `renderer` 82 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes.
- **Deployed:** the mini PC, verified at 21:16:32 -- which restarted Blit
  while the owner was reporting a Steam input failure on hibr 0.99.477 with
  Blit 0.3.69, so that state could not be read. 10.52 is offline (it left
  the network at the 0.3.69 update); not deployed there.

## 2026-11-09: 0.3.69 the input route's last pointer, for diagnosis (ADR 0225)

- **`frames.input.routes[].pointer`:** the last absolute pointer of each
  route -- `surface` (where it was on the session's surface), `draw` (the
  picture's drawn rectangle it was mapped through), `sent` (the position sent
  to the compositor), `miss` (`""` once sent, else `other-session`,
  `no-image`, `outside-picture`, `none-yet`). Added for Hibr's report that
  Steam's pointer is wrong after Full Screen, so one reading shows the
  mapping. `frame_input_gate` checks it equals what the compositor received.
- **Suites:** `all` 186 pass, 12 skip, 0 fail; GLES `renderer` 82 pass, 1
  skip, 0 fail; `package_artifact_gate` passes. Published to hibr-apt.
  Deployed and verified on the mini PC (10.54). 10.52 left the network as
  its update finished, as it did for 0.3.65: not yet verified there.

## 2026-11-08: 0.3.68 Spleen, one scalable font of five masters (ADR 0227)

- **`spleen`** is one text font made of the five unmodified Spleen 2.2.0
  OTF masters (6x12, 8x16, 12x24, 16x32, 32x64; BSD-2-Clause; tarball and
  each file pinned in fonts.source.json), in `fonts/text/spleen/`. Each
  master's pixel grid is read from the font itself; `blit_font_master_choose`
  takes the largest master whose height divides the cell height (crisp),
  else the largest smaller one (scaled), else the smallest. At crisp sizes
  each outline is snapped to its design pixels and rendered without the
  hinter, which moved pixels by one (measured); `GET /v1/fonts` reports
  `master` and `master_fit`. The fixed 16 px `blit-spleen16` is retired (a
  saved id falls back to the boot font, no alias).
- **Gates:** `spleen_master_gate` (listed once; crisp at 12, 16, 24, 32, 48,
  64 px with pure on/off pixels; scaled at 20, 28, 40 px; the retired id
  gone); `all` 190 pass, 8 skip, 0 fail; GLES `renderer` 82 pass, 1 skip,
  0 fail; font and schema 56 pass; `package_artifact_gate` passes (masters
  shipped, PSF retired; the .deb grows about 68 KB).
- **Live:** deployed and verified on 10.54 and 10.52. On the mini PC the
  owner's desktop runs Spleen at 24 px, master 12x24, crisp.
- **Mirror:** published to hibr-apt; the public GitHub Pages mirror was still
  serving hibr 0.99.472 at release, so apt clients see it when it syncs.

## 2026-11-08: 0.3.67 animated effects follow each display's refresh (ADR 0188)

- **`effects_animation_hz`** takes `"auto"` (the default) or 10-240. Auto
  ticks each animated output at its own refresh; a number lands on the
  largest whole-vblank rate at or below it, refresh / ceil(refresh /
  setting) (50 on 60 Hz is 30, 120 on 144 Hz is 72), and each output's
  `effects.animation_hz` reports what it keeps. The gap-only rule is
  unchanged: a tick only fills a gap, never inside a quiet window or a Hibr
  barrier, just after a vblank.
- **Measured on 10.52** (Intel HD 515, 60 Hz, the glowing line on one pane,
  15 s each): no animated effect 11 presents/s, 107 ms GPU/s, Blit 7.8% CPU;
  30 Hz 32 presents/s, 316 ms GPU/s, 10.7% CPU; auto 46 presents/s, 482 ms
  GPU/s, 13.3% CPU; no missed deadline in any. **With a 24 fps picture
  playing** (12 s each): 30 Hz 41 presents/s, 9 ticks/s, 1 missed deadline;
  auto 56 presents/s, 26 ticks/s filling the gaps, 0 missed. The cost exists
  only while an animated effect is on. 10.52's settings were restored.
- **Suites:** `all` 186 pass, 12 skip, 0 fail; GLES `renderer` 82 pass, 1
  skip, 0 fail; `package_artifact_gate` passes. Installed on 10.52 for the
  measurement, then released; deployed and verified on 10.54 and 10.52.
- **Also live today** (Hibr 0.99.469, Steam window): after the display
  clients were renewed, 5,606 input events reached gamescope through EIS and
  60,868 frames arrived as dmabuf on the mini PC.

## 2026-11-08: 0.3.66 the blit-gamescope package; GPL-3.0-or-later; the timing lane

- **`blit-gamescope`, its own package** (ADR 0225): /usr/bin/blit-gamescope;
  `Depends: blit (= 0.3.66-1), libc6, libpipewire-0.3-0, libei1, gamescope`
  (Debian 13's `libpipewire-0.3-0t64` provides the old name, checked on the
  mini PC); `blit` only Suggests it, so a plain install carries none of it.
  Built deterministically (two builds, identical sha256) against PipeWire
  1.4.2's headers in build/deps; checked by `package_artifact_gate`.
  Published to hibr-apt beside blit. Steamer will Depend on it (owner).
- **Under `--no-place`** the bridge sends only `INPUT eis`; the desktop's
  focus callback sends `INPUT on`/`off` (Hibr #486 step 4).
- **Licence (owner):** Blit is GPL-3.0-or-later. LICENSE, COPYING, a
  copyright file in the blit and blit-gamescope packages; fonts and icon
  artwork keep their own licences, the Hibr adapter Hibr's LGPL-3.0-or-later.
- **Timing lane:** six gates that count frames, ticks or waits against the
  clock moved to `run_serial_gate` (burn_in, mask, performance_panel,
  tube_effects, zoomed_effects, settings_writer); they had failed one at a
  time under parallel load (Gitea #153 closed; #154 closed the same day).
- **Suites:** `all` 186 pass, 12 skip, 0 fail; GLES `renderer` 82 pass, 1
  skip, 0 fail with the new lanes (the run before them failed
  `performance_panel` once, passing 3 of 3 alone); `package_artifact_gate`
  passes with all three packages. Deployed and verified on 10.54 and 10.52.

## 2026-11-08: 0.3.65 pictures bounded by memory, not by count (ADR 0226 phase 1)

- **Growable picture and placement tables** replace the fixed 16 pictures
  and 8 placements per session; ceilings 4096 pictures and 16384 placements
  per session guard against a runaway program (`ENOSPC`). Pictures are
  records allocated one by one and kept until the session ends, so pointers
  held across calls stay valid. Frame-channel input routes follow pictures.
- **Memory budgets** through one accounting function: 256 MiB per session,
  a quarter of physical memory up to 2 GiB across the server, 512 MiB of
  GPU textures; all settings. Under pressure Blit frees unshown pictures,
  least recently shown first, and refuses once only shown ones remain
  (nothing is freed for nothing). Shown means placed and not deleted, a
  placement held for the next frame, or an input route.
- **The GPU texture cache is bounded by bytes**, not 32 slots: nothing on
  screen is re-uploaded. An idle session is 39,848 bytes, was 53,432.
- **Gates:** `graphics_memory_gate` (1000 pictures, 500 placed, all drawn,
  uploads flat on GLES; budget frees in least-recently-shown order 1,3,4,2;
  server budget across sessions; picture 4097 refused) and
  `graphics_memory_frames_gate` (a route keeps its picture under pressure).
- **Suites:** `all` 185 pass, 12 skip, 1 fail (`hibr_split_capture_gate`
  on one missed presentation deadline on the mock, its third time; the gate
  now reports mock timing instead of failing on it, Gitea #154 closed, and
  passes); GLES `renderer` 82 pass, 1 skip, 0 fail on a quiet machine (a run
  while the split gate ran alongside failed `presentation_effects` at 14.6
  animation frames a second against 15). `package_artifact_gate` passes.
- **Deployed:** the mini PC verified (and the owner returned to the login
  screen: an update restarts Blit; the held desktop resumes on login). 10.52
  left the network as the update finished, so the helper could not confirm;
  it came back without a reboot (up 18 hours) running 0.3.65.
- **Not yet:** 500 thumbnails measured on 10.52's GPU (decides the atlas),
  dmabuf pictures under the budgets, the texture budget under real pressure.

## 2026-11-08: 0.3.64 input routes per picture; the bridge's --no-place (ADR 0225)

- **INPUT per image** (`docs/api.md`): `INPUT eis <path> <id>`, `INPUT on
  <id>`, `INPUT off <id>`, answered `OK input <id>` / `ERROR INPUT <id>
  <code>`. One connection carries the routes of several pictures (Hibr
  multiplexes every picture of a display over one connection, #486); at most
  one route is on per session, and turning one on releases what another
  held first; a compositor going ends only its route.
- **`blit-gamescope --no-place`** for phase 2: the console places the
  picture, so the bridge writes no Kitty placement and no terminal set-up.
- **Agreed with Hibr:** a game picture keeps one image id and one placement
  for its life; moving, raising and resizing re-place it in place, so held
  keys survive a window drag.
- **Gated against a stand-in libei** (`frame_input_gate`: two routes on one
  connection, the one-on rule within and across connections, release order,
  late ENOENT and delete per route); the libeis gate still waits for a host.
- **Suites:** `all` 184 pass, 12 skip, 0 fail; GLES `renderer` 81 pass, 1
  skip, 0 fail on a quiet machine. Two earlier GLES runs failed
  `presentation_effects` (12.1–12.4 animation frames a second against a 15
  floor) and once `burn_in`, both while another build held the 4-core
  machine at load 10; the effects gate passed 4 of 4 alone at load 3.
  `package_artifact_gate` passes. Deployed and verified on 10.54 and 10.52.

## 2026-11-07: 0.3.63 the pointer in gamescope's space; the bridge never captures (ADR 0225)

- **Live test of 0.3.62 on the mini PC** (owner at the keyboard, vkcube
  through `blit-gamescope` in the DP-1 top pane, Hibr's join detached and
  reattached afterwards): keys reached the game (Space paused vkcube, Escape
  closed it; 978 events sent through EIS); dmabuf frames at about 60 fps, none
  dropped. Two faults: the bridge captured the mouse on any click, and a bare
  Blit pane has no release key, so the owner was stuck until Escape closed the
  game; and gamescope's EIS region is INT32_MAX square (its source: the
  absolute position goes straight to `wlserver_mousewarp` in its output's
  pixels), so 0.3.62 scaled the pointer to 2^31.
- **Fixes:** Blit treats an unbounded region as none and maps the pointer to
  the frame; the bridge never captures (capture is the desktop's, with its
  Release Pointer), turns on no mouse modes, and no longer asks gamescope to
  shrink its stream, so the frame always is gamescope's output and pointer
  space and Blit scales; a late `ERROR INPUT ENOENT` is logged as the
  compositor going. The mouse in a game is not yet verified live.
- **Suites, full set:** `all` 184 pass, 12 skip, 0 fail (a first run failed
  `hibr_split_capture_gate` on one missed presentation deadline, passing 3 of
  3 alone and in the rerun; Gitea #154); GLES `renderer` 81 pass, 1 skip,
  0 fail; `package_artifact_gate` passes. Deployed and verified on 10.54 and
  10.52.

## 2026-11-07: 0.3.62 input to a compositor's EIS socket (ADR 0225, Blit's half)

- **The frame channel's INPUT request** (`docs/api.md`): a version-3 client
  names a compositor's EIS socket and an image (`INPUT eis <path> <id>`), then
  says `INPUT on`/`off` as its window gains and loses the keyboard. Blit loads
  libei at run time, connects only to a socket owned by the client's uid
  (checked again by `SO_PEERCRED` on the connected socket), and, while the
  route is on, its session focused and the console Blit's, sends evdev key
  press and release (no repeats), buttons, scroll, the absolute pointer over
  the picture's drawn rectangle mapped into the compositor's pointer region,
  and relative motion under pointer lock. Every end of the route releases what
  was pressed through it; a compositor that refuses or goes is reported
  `ERROR INPUT ENOENT` on the channel. Sessions report `frames.input`.
- **The `blit-gamescope` bridge** (phase 1, frames; ADR 0225) is in the tree,
  not yet packaged.
- **Gated against a stand-in libei only** (`frame_input_gate`): request
  answers, states, key order, release on every end, absolute mapping into an
  880x440 region at two placements and after a resize, relative motion, the
  compositor dropped. `frame_input_eis_gate` (a real libeis receiver) has not
  run: no host has both libeis and a build toolchain. The real check is the
  live test with gamescope on the mini PC.
- **Suites, full set:** `all` 184 pass, 12 skip, 0 fail (a first run failed
  `mask_gate` once on an idle-frame count, passing 3 of 3 alone and in the
  rerun; Gitea #153); GLES `renderer` 81 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes. Deployed and verified on 10.54 and 10.52.

## 2026-11-07: 0.3.61 Kitty flag 4 and focus reports on input hand-over (ADR 0225)

- **Kitty keyboard flag 4 (report alternate keys):** `CSI key:shifted:base ;
  mods u`, the base key being the US PC-101 key at the same physical position
  (from the evdev code); supported flags are now 15. With a device keymap the
  key is the layout's and the base the US key.
- **Focus reports on input hand-over:** a session with mode 1004 gets `CSI O`
  when Blit releases physical input for a VT switch, after the synthetic key
  and button releases, and `CSI I` when it takes input back. Hibr 0.99.466
  builds key phases for desktop apps (Boxer) on these (hibr #315/#485).
- **Not gated:** the order of the focus-out after the synthetic releases on
  the real VT path is read from the code; the gate drives it through the
  `BLIT_TEST_VT_SIGNALS` hook, and only the QEMU gate runs a real VT switch.
- **Suites, full set:** `all` 182 pass, 11 skip, 0 fail; GLES `renderer` 81
  pass, 1 skip, 0 fail; `package_artifact_gate` passes. Deployed and
  verified on the mini PC (10.54) and 10.52.

## 2026-11-07: 0.3.60 frames by dmabuf (ADR 0223, Blit's half)

- **Version 3 of the frame channel:** a program in a Blit session can hand
  Blit a picture already in GPU memory (`FRM3`, plane fds and an optional
  acquire fence by `SCM_RIGHTS`); the GPU compositor imports it
  (`EGL_LINUX_DMA_BUF_EXT`) and draws it with no copy and no upload; Blit
  answers `RELEASE <id> <seq>` when it is done with a buffer. Offered in the
  hello (`OK dmabuf=1 fence=<0|1> formats=...`) only while the GPU composes
  every output; otherwise `dmabuf=0`, every v3 frame `ENOTSUP`, and live
  buffers released. Formats XR24, AR24, XB24, AB24 with the modifiers EGL
  lists; AR24/AB24 are premultiplied. YUV is not done.
- **On real hardware, 10.52 (Intel HD 515, Mesa 25.0.7)**, through the system
  Blit with a scratch build of this code (`frame_dmabuf_live_gate`): 90 frames
  imported and drawn, all released in order, `upload_bytes_delta=0`; a 50%
  alpha AR24 frame blended as premultiplied (131072 of 131072 pixels as
  expected); a frame rendered by the host's GPU sent with its
  `EGL_ANDROID_native_fence_sync` fence drew both halves after the GPU wait
  (`fences_waited` +1). Not tested on hardware: the GPU-to-CPU fallback (gated
  with the DRM mock, mixed CPU and GPU outputs), a long-pending fence, YUV.
- **ADR 0223 stays proposed** until a real producer (the Browser, or the
  gamescope bridge of ADR 0225) is measured on the owner's machine.
- **Suites, full set:** `all` 182 pass, 11 skip, 0 fail (JOBS=2); GLES
  `renderer` 81 pass, 1 skip, 0 fail; `package_artifact_gate` passes. The
  implementing agent saw `hibr_split_capture_gate` fail once in its own run
  (passed 3 of 3 alone, and here).

## 2026-11-07: 0.3.59 Full Screen and Sticky boxes, Flat and Embossed

- **Ten window glyphs** (ADR 0224), asked for by the owner through Hibr #484:
  `chalk-fullscreen` U+10030A, `-pressed` U+10030B; `slate-light-fullscreen`
  U+10030C, `-pressed` U+10030D; `chalk-sticky` U+10030E, `-pressed` U+10030F,
  `-on` U+100310; `slate-light-sticky` U+100311, `-pressed` U+100312, `-on`
  U+100313. Next free is U+100314.
- **The marks**, chosen by the owner from real-server renders of two
  candidates: Full Screen is four corner brackets, Sticky a pin (a 3x3 head on
  a 2 px stem). Pressed forms follow ADR 0219; sticky-on is the unpressed box
  with the mark drawn bold.
- **Gates:** `window_glyph_gate` (literal drawings and per-size rules, failing
  on the other candidate's geometry), `window_style_gate`,
  `glyph_edge_sweep_gate` (CPU and GLES), `icon_clip_gate`,
  `control_glyph_gate`, `catalogue_fields_gate`.
- **Suites, full set** (this changes `src/blit_window_glyphs.h`): `all` 181
  pass, 10 skip, 0 fail (JOBS=2). GLES `renderer` 80 pass, 1 skip, 1 fail:
  `presentation_effects_gate` measured 30 animation frames in 2.13 s, 14.1/s
  against its floor of 15/s at 30 Hz, on the software GPU of the test machine
  at load 3.3; it passed 3 of 3 alone straight after, and this release changes
  only window-glyph tables. The owner's machine holds the rate with headroom
  (issue #152). `package_artifact_gate` passes.

## 2026-11-07: 0.3.58 the battery lying in two columns

- **Horizontal two-column battery**, alongside the upright one-column ones
  (unchanged): `battery-wide-0..4` U+1002F4-1002FD, `battery-wide-0..4-charging`
  U+1002FE-100307, `battery-wide-ac` U+100308-100309; next free U+10030A.
  Sources `battery-wide.svg`, `battery-wide-charging.svg`, `battery-wide-ac.svg`.
  At 22 px the ink is 18 by 11 px against 8 by 13 for one column.
- **Monochrome by shape** (ADR 0220/0221): levels are the body and lit segments;
  charging cuts the bolt out (`data-mono="knockout"`); ac is the solid body with
  the plug cut out. `font_icon_shape_gate`: levels 17.1% to 65.4%, charging
  20.5% to 66.5%, drain against charge 31.7% to 49.5%, ac against all 18.5% to
  60.9% at 22 px (minimum 15%); 15.9% or more at 16 px (minimum 10%).
- **The bolt has a dark edge** (#24242a): measured in the render the bolt's
  boundary is 4.6 to 6.1:1 at 22 px and 3.1 to 4.4:1 at 16 px on both bars,
  where the yellow alone was 1.2:1 on the light bar. The one-column charging
  battery keeps its bolt, since an edge would change its monochrome shape.
- Shown to and approved by the owner from real-server renders. Charging at
  levels 3 and 4 in the pens, at 16 px, is the hardest to read.
- **Icon font** 333,552 to 351,540 bytes; rebuilt byte-for-byte first, no
  existing glyph changed.
- **Suites, glyph-only set** (no `src/` change since 0.3.57): `font` and
  `schema` 56 pass, 0 fail; GLES `renderer` 81 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes.

## 2026-11-07: 0.3.57 the classic telephone in two columns

- **Two-column classic telephone** for longwire's Classic phone style,
  alongside the one-column ids (unchanged): `phone-classic-wide-off`
  U+1002EC-1002ED, `-wait` U+1002EE-1002EF, `-on` U+1002F0-1002F1, `-ring`
  U+1002F2-1002F3, each a `-left`/`-right` pair reusing the one-column drawing.
  Next free is U+1002F4. About 16 by 16 px at 22 px against 9 by 9 for one
  column.
- **States differ by shape** in the black, white and auto pens: 21.8% (on
  against ring) to 59.7% at 22 px, 19.5% to 57.4% at 16 px
  (`font_icon_shape_gate`, minimums 15% and 10%). Shown to and approved by the
  owner from real-server renders; the dashed "wait" reads speckled, as in one
  column.
- **Icon font** 322,932 to 333,552 bytes; rebuilt byte-for-byte first, no
  existing glyph changed.
- **Suites, glyph-only set** (no `src/` change since 0.3.56): `font` and
  `schema` 56 pass, 0 fail; GLES `renderer` 81 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes.

## 2026-11-07: 0.3.56 Wi-Fi and sound in two columns; one grey for the status icons

- **Two-column forms**, alongside the one-column ones (unchanged, nothing
  deprecated): `wifi-signal-wide-1` to `-4` (U+1002DA-1002E1), `wifi-off-wide`
  (U+1002E2-1002E3), `volume-wide-0` muted (U+1002E4-1002E5) and
  `volume-wide-1` to `-3` (U+1002E6-1002EB), each a `-left`/`-right` pair. Next
  free is U+1002EC. They reuse the approved drawings (no new SVGs); a two-column
  icon is fitted by its design box, so every level keeps its place. At 22 px the
  fan is 18 by 15 px against 11 by 9 for one column. Levels differ by shape:
  Wi-Fi 42.9% to 100%, volume 16.7% to 36.8% at 22 px
  (`font_icon_shape_gate`, minimum 15%).
- **One grey, #7d8796,** for the speaker and battery bodies, the unlit arcs,
  bars and battery segments, and the off telephones: 3.08:1 on the light bar
  #ececf0 and 4.25:1 on the dark #24242a. It replaces #c9d1d9 (1.31:1 on the
  light bar) and #3e526b (1.93:1 on the dark). Only colours changed: a
  glyph-by-glyph comparison shows identical outlines, boxes, layers and mono
  shapes. `font_icon_colour_gate`'s default hash is re-pinned for that.
- Shown to and approved by the owner from real-server renders on light and dark
  bars at 22 and 16 px.
- **Suites, glyph-only set** (no `src/` change since 0.3.55): `font` and
  `schema` 56 pass, 0 fail; GLES `renderer` 81 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes.

## 2026-11-06: 0.3.55 Wi-Fi as a fan; the bars become cellular

- **Wi-Fi fan**, one column: `wifi-signal-1` to `-4` (U+1002D1-1002D4), a dot
  and three arcs lit in teal up to the level, the rest in the bars' inactive
  colour; `wifi-off` (U+1002D5), the fan unlit with a red cross. One source,
  `wifi-signal.svg`, so all five states share one box; the cross is a part
  that is never lit in the fan states. Mono shows the lit parts only, and
  `wifi-off` in mono is the cross. The dot is a true circle on the fan's axis
  (within 0.2 px at 22 px; the owner caught it off-centre in the mock-up).
- **The bars are the mobile signal:** `cellular-1` to `-4` (U+1002D6-1002D9)
  draw them. `wifi-1` to `-4` keep their codepoints and pictures, marked
  `deprecated` with `replaced_by` the cellular ids (ADR 0214's fields, now in
  the `FontIcon` schema too); they are drawn until a release retires them.
  `custom_icon_gate` checks `cellular-N` is pixel-identical to `wifi-N`.
- **Levels differ by shape:** 45.8% to 100% of pixels at 22 px between any two
  states (`font_icon_shape_gate`, minimum 15%). Shown to and approved by the
  owner from real-server renders; the owner kept it one column for now: about
  9 px tall at 22 px, a smudge in colour at 16 px. A two-column form is to be
  looked at later if needed.
- **Icon font** 303,760 to 309,348 bytes; rebuilt byte-for-byte first, no
  existing glyph changed.
- **Suites, glyph-only set** (no `src/` change since 0.3.54): `font` and
  `schema` 56 pass, 0 fail. GLES `renderer` 80 pass, 1 skip, 1 fail:
  `presentation_effects_gate` counted 26 animation ticks where it wants 30 in
  what it assumes is 2.0 s, at load about 4.2 with other sessions running; it
  passed 3 of 3 alone straight after. It measures no elapsed time, so the
  failure cannot say why: issue #151. `package_artifact_gate` passes.

## 2026-11-06: 0.3.54 a minimise box, Flat and Embossed

- **Four window glyphs** (ADR 0222): `chalk-minimise` U+1002CD,
  `chalk-minimise-pressed` U+1002CE, `slate-light-minimise` U+1002CF,
  `slate-light-minimise-pressed` U+1002D0. Next free is U+1002D1. Asked for by
  the owner through Hibr, whose window-button list now offers close, zoom,
  minimise and shade, each on or off and on either side.
- **The mark** is a short bar along the bottom of the box (the owner chose it
  over a corner square, from real-server renders of both): 5 px wide on box
  row 8 at 11 by 22, apart from shade's bar across the middle and zoom's square
  at the top left. Pressed forms follow ADR 0219: Chalk solid with the bar cut
  out, Slate the mix pen with an inverted bevel.
- **Gates:** `window_glyph_gate` (literal drawings and per-size rules),
  `window_style_gate`, `glyph_edge_sweep_gate` (CPU and GLES), `icon_clip_gate`
  and `control_glyph_gate`.
- **Suites, full set** (this changes `src/blit_window_glyphs.h`): `all` 181
  pass, 10 skip, 0 fail (JOBS=2); GLES `renderer` 81 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes.

## 2026-11-06: 0.3.53 the wiretap tap in one cell, on and off

- **Two one-column icons** for wiretap's Control Strip module, pane tile and
  window: `wiretap-1` U+1002CB (on, with the drop) and `wiretap-1-off`
  U+1002CC (off). Next free is U+1002CD. One source,
  `assets/fonts/icons/wiretap-1.svg`, the drop a level (`data-level="1"`,
  `data-inactive-fill="#2e8fe000"`), as the battery levels are.
- **Why one source:** a one-column icon is fitted by its layer outlines, so a
  separate drawing without the drop drew the off tap 2 px lower (1 px at 16 px)
  than the on tap. With the drop a clear layer in the off state both share one
  box; the tap's pixels are identical in all 16 compared cells, off shows no
  drop in colour, and its monochrome shape has none.
  `tools/fonts/build-blit-icons.py` now also takes `#rrggbbaa` fills (and still
  rebuilds the previous font byte for byte).
- **On and off differ by shape:** 17.6% of pixels at 22 px, 12.5% at 16 px
  (`font_icon_shape_gate`, minimums 15% and 10%). Shown to and approved by the
  owner from real-server renders; the tap is about 7 by 11 px in an 11 by 22
  cell.
- **Suites, glyph-only set** (no `src/` change since 0.3.52): `font` and
  `schema` 56 pass, 0 fail; GLES `renderer` 81 pass, 1 skip, 0 fail;
  `package_artifact_gate` passes.

## 2026-11-06: 0.3.52 the wiretap tap, on and off

- **Two new two-cell icons** for wiretap (the Hibr network monitor): a water
  tap in #2e8fe0. `wiretap-left` U+1002C7 and `wiretap-right` U+1002C8 is on
  (a drop under the spout); `wiretap-off-left` U+1002C9 and `wiretap-off-right`
  U+1002CA is off (no drop). Next free is U+1002CB. Sources
  `assets/fonts/icons/wiretap.svg` and `wiretap-off.svg`.
- **On and off differ by shape**, so the black, white and auto pens tell them
  apart: 15.4% of pixels at 22 px and 13.3% at 16 px
  (`font_icon_shape_gate`, minimums 15% and 10%; the drop was enlarged only as
  far as that needed). Shown to and approved by the owner from real-server
  renders on light and dark bars at 22 and 16 px.
- **Icon font** grows 1,108 bytes; it was rebuilt byte-for-byte first and no
  existing glyph changed.
- **Suites, glyph-only set** (no `src/` change since 0.3.51; owner-approved
  2026-11-06): `font` and `schema` 56 pass, 0 fail; GLES `renderer` 81 pass,
  1 skip, 0 fail; `package_artifact_gate` passes.

## 2026-11-06: 0.3.51 the hui badge as a solid disc, and a new hui mark

- **hui badge** (`hui-left`, `hui-right`, same ids and codepoints): a solid teal
  disc with white letters in place of the thin ring with near-white letters,
  which the owner found hard to read on a light bar. Its monochrome shape is
  unchanged (the disc with the letters knocked out).
- **hui mark**, new: `hui-mark-left` U+1002C5 and `hui-mark-right` U+1002C6, a
  two-cell H-U-i monogram (an H whose lower half is a U, a dot for the right
  stem's top), for Hibr's Menu Mark choice. Next free is U+1002C7.
- **Shown to and approved by the owner** from real-server renders on light and
  dark bars at 22 and 16 px, in colour and the auto, black and white pens. At
  16 px the badge's letters blur and the mark's crossbar merges into the U;
  both are clear at 22 px.
- **Icon font** grows 400 bytes (301,628 to 302,028). It was first rebuilt
  byte-for-byte from the committed sources, and only the hui glyphs changed.
- **Suites:** `all` 181 pass, 10 skip, 0 fail (JOBS=2); GLES `renderer` 81 pass,
  1 skip, 0 fail; `package_artifact_gate` passes.

## 2026-11-06: 0.3.50 the settings revision moves with the content (issue #150)

- **A false 409 on `PUT /v1/settings`, fixed.** The revision was raised when
  the writer thread put the document on disk, after the coalescing interval,
  so a change made before a client's GET was saved a moment later and the
  revision moved under the client with nothing new to read; its `If-Match`
  failed. `settings_persistence_gate` hit it under load, and the Control Panel
  pane retried around it. The revision now moves when the content changes
  (`settings_mark_dirty`); a save writes the current revision and only
  `storage.saved_revision` catches up. `docs/api.md` says so.
- **Gates:** `settings_persistence_gate` waited for a higher revision as a sign
  of the disk write; it now also waits for `storage.state` clean, and passes.
  Also on main since 0.3.49, tests only: `graphics_blink_gate` reads how long
  a picture was gone from the ledger (issue #149, closed).
- **Suites:** `all` 181 pass, 10 skip, 0 fail (JOBS=2); GLES `renderer` 81 pass,
  1 skip, 0 fail; `package_artifact_gate` passes.

## 2026-11-06: 0.3.49 the icon pen is a cell attribute (SGR 68:v, 69)

- **Per cell, not global** (ADR 0221; replaces the run-time half of ADR 0220):
  `ESC[68:v m` sets the pen for Blit's colour icons in that cell (1 auto, 2
  black, 3 white; 68:0 or a bare 68 is colour), SGR 69 or SGR 0 ends it. The
  owner wants the menu bar in monochrome and the desktop and file manager in
  colour at once; a global setting cannot do that. `fonts.icon_colour` is
  removed. A saved settings document that still carries `font.icon_colour`
  loads as before, the key ignored by the existing reader and dropped on the
  next write (`font_icon_colour_settings_gate`; it fails five checks on 0.3.48).
- **No per-frame cost.** The pen is two attribute bits and part of the glyph
  cache key for Blit icons only; a flip of N icon cells damages exactly those N
  cells, with no reflow and no raster rebuild (`icon_pen_gate`, both
  compositors). Timing suite, 0.3.48 against this build on the same machine:
  `frame_rate_gate` 62.485 Hz against 62.556 Hz; `terminal_soak_gate` 14160
  against 14112 snapshots over 120 s. Run-to-run noise.
- **GLES fix found on the way:** the GLES sprite cache keyed on the scalar only,
  so a black icon would have reused the colour sprite; and it guessed a sprite's
  format from two test renders, which takes premultiplied white for coverage.
  The pen is now in the sprite key, and the sprite asks the raster for its
  format, as the CPU compositor does.
- **Protocol:** capability `sgr-icon-pen` in `GET /v1/server`, XTGETTCAP
  `sgr-icon-pen`, DECRQSS, and `style.icon_pen` in the cells API. A display
  that is not Blit strips it, which draws colour.
- **Suites:** `all` 181 pass, 10 skip, 0 fail (JOBS=2). GLES `renderer`: one run
  failed `graphics_blink_gate` ("no blink counted"); the rerun passed 81, skip
  1, fail 0. That gate failed the same way on 0.3.46 and 0.3.47 builds, and
  passed 15 of 15 runs alone, so it is not this change. Issue #149, since
  fixed in the gate (127ce4d): it assumed its sleeps kept every gap inside the
  detector's 8-frame window, and a slow run went 9 frames (a deletion by ADR
  0213's rule) while a fast one never went absent; it now reads the gap from
  the ledger. My earlier ledger note called it load-sensitive; that was wrong.
  `package_artifact_gate` passes.

## 2026-11-06: 0.3.48 Blit icons in colour, black, white or auto, drawn so a state shows by shape

- **`fonts.icon_colour`** (`colour`, `black`, `white`, `auto`; ADR 0220) draws
  Blit's colour icons in their own colours (the default, byte-identical to
  before for the icons not edited), solid black, solid white, or `auto`: the
  cell's foreground, with knock-outs showing the cell's background, so a Blit
  icon behaves like the text and Nerd glyphs beside it in a bar. It touches only
  Blit's colour icons, not the window glyphs, controls, text or emoji.
- **The monochrome shape is decided when the icon font is built, from the SVG.**
  A first pass tinted the colour raster at run time and gave every level of a
  family the same silhouette (battery levels 0.0% apart, draining against
  charging 1.3%, Wi-Fi and volume levels 0.0%): the owner could not tell plugged
  in from draining. Now each icon's `.mono` glyph is its active paths minus any
  path marked `data-mono="knockout"`; inactive paths are omitted. The Wi-Fi,
  volume and battery SVGs were adjusted, with a larger bolt and a plug.
- **`font_icon_shape_gate`** compares every pair in each state family in the
  black pen: at least 15% of pixels differ at 22 px and 10% at 16 px. Lowest at
  22 px: 15.0% (plugged in vs fully charging); battery levels 20.7% to 57.3%,
  charging levels 17.7% to 62.0%, draining vs charging 24.1% to 34.0%, Wi-Fi
  48.6% to 90.9%, volume 20.0% to 44.2%. At 16 px the lowest is 26.1%. Against the
  first-pass build the same gate fails 78 pairs. The icon font grows by 2,568
  bytes (299,060 to 301,628).
- **Shown to the owner** from real-server renders at 22 and 16 px on light and
  dark bars, in colour, black, white and auto; approved. Known weak spots:
  charging levels are subtle by eye (the bolt dominates), plugged in vs fully
  charging sits at the 15% line, and Wi-Fi level 1 is a single small bar.
- **Suites:** `all` 180 pass, 10 skip, 0 fail (JOBS=2); GLES `renderer` 80 pass,
  1 skip, 0 fail; `package_artifact_gate` passes (reproducibility skipped).

## 2026-11-06: 0.3.47 font hinting setting, pressed boxes and a grow box, a faster gate runner

- **`fonts.hinting`** (`full`, `light`, `none`; ADR 0218) chooses the FreeType
  hinting for text glyphs. The default `full` is what text used before, and
  `font_hinting_gate` pins its raster hash from the pre-change code, so default
  output is unchanged. Fitted icons, shaped Arabic and colour emoji ignore it.
  `GET/PUT /v1/fonts` reports and takes it, the settings document stores it, a
  bad value is a 400, and it survives a restart.
- **Pressed title-bar boxes and a grow corner** (ADR 0219; the pressed look is
  also the hover look): ten glyphs, U+1002BB-1002C4, in Chalk and Slate, shown to
  and approved by the owner from real-server renders. Details in the entry below.
- **A measured, bounded, parallel gate runner** (ADR 0216) is merged:
  per-gate timing, timeouts, port offsets and a serial timing lane. `all` takes
  about 10 to 11 minutes at 4 jobs against 23 serially. `emoji_presentation_gate`
  now has a 600 s limit: it is CPU-bound at 170 to 235 s alone and passed 300 s
  when several gates shared the machine.
- **Suites** on the merged tree at JOBS=2: `all` 177 pass, 10 skip, 0 fail;
  GLES `renderer` 80 pass, 1 skip, 0 fail; `package_artifact_gate` passes
  (reproducibility check skipped). Earlier runs on the same code, with other
  sessions' gates and desktops loading the machine, failed `emoji_presentation_gate`
  on the old 300 s limit and `graphics_blink_gate` on GLES; the latter also
  failed on the 0.3.46 build under that load and passes alone (13 s), so it is
  sensitive to load, not to this change. No retry was added.

## 2026-11-06: pressed title-bar boxes and a grow box (ADR 0219, 0.3.47)

- **Ten glyphs**, U+1002BB-1002C4 (next free U+1002C5), five a set, Chalk's then
  Slate's: `close-pressed`, `shade-pressed`, `zoom-pressed`, `grow`,
  `grow-pressed` (ids `chalk-...` and `slate-light-...`). Hover draws the pressed
  glyph. The grow cell is the window's bottom-right frame cell, its right and
  bottom lines the box's own edges, a `/` hatch with a 4 px period inside.
- **Checks:** `window_glyph_gate` holds all ten pixel for pixel to the design
  script at twelve cell sizes, to written-out drawings at 11x22, and by rule at
  every size (pressed Chalk is the solid box with its mark cleared; pressed
  Slate uses only the three role pens; the grow box's edges are the frame's
  line pixels). `window_style_gate` draws them through the compositor;
  `glyph_edge_sweep_gate`, `icon_clip_gate`, `control_glyph_gate` and
  `catalogue_fields_gate` cover edges, clipping, the next free codepoint and the
  catalogue fields. Not a release: no version bump or receipt here.

## 2026-11-05: 0.3.46 XTGETTCAP answers the SGR extension names

- **`DCS + q` now answers `sgr-framed`, `sgr-framed-bar` and `sgr-shadow`**
  (hibr#476), the names `GET /v1/server` lists in `capabilities`, so a client
  that holds the terminal and not the HTTP API can ask the terminal itself.
  Each is a boolean: a name Blit has is answered `DCS 1 + r <hex name> ST` with
  no value; any other name is still refused `DCS 0 + r <hex name> ST`. `CSI > q`
  already answers `Blit(<version>)`. Documented in `docs/terminal.md`.
- **Checks:** `terminal_conformance` has one case per name asserting the exact
  reply bytes. Suites `all` (174 pass, 10 skip, 0 fail) and GLES `renderer`
  (80 pass, 1 skip, 0 fail) passed; `package_artifact_gate` passes on the
  package (reproducibility check skipped).

## 2026-11-05: 0.3.45 a smaller package: one copy of the documentation, font sources in their own package

- **The Blit package is 17.2 MB, down from 24.6 MB** (installed file bytes
  40.8 MB, down from 51.2 MB) (ADR 0217), with no change in behaviour.
  (1) The documentation was copied to `usr/lib/blit/docs` as well as
  `usr/share/doc/blit/docs` (3.8 MB each); nothing reads the first (checked
  in Blit's source and read-only in Hibr and the apps) and only the package
  gate compared the two, so the second copy is gone, not linked: dpkg
  removes the old directory on upgrade where it cannot replace a directory
  with a symlink. (2) `usr/lib/blit/fonts/sources/freefont-src-20120503.tar.gz`
  (6.2 MB), the preferred-form source of GNU FreeMono from which Blit Arabic
  Modern is derived (GPLv3-or-later with the font exception), is now in its
  own `blit-font-sources_20120503-1_all.deb` (6.5 MB, `Architecture: all`,
  version the upstream's, published only when its content changes), which
  `blit` Suggests; `usr/lib/blit/fonts/FreeMono-SOURCE.txt` in the main package
  says where the source is (the package, the ftp.gnu.org URL, the sha256),
  so the source offer stays with the binary. The build refuses a tarball whose
  sha256 differs from `arabic-fonts.source.json`.
- **Checks:** `package_artifact_gate` now fails on a shipped `fonts/sources`
  or `usr/lib/blit/docs`, a missing `FreeMono-SOURCE.txt` or Suggests, and,
  with the sources package beside it, checks `Architecture: all`, the version,
  the file set and the tarball's sha256; it fails on the 0.3.42 package.
  `documentation_gate`, `font_assets_gate` and `arabic_raster_gate` pass.
  A real `dpkg --root` install of 0.3.42 and then the new packages in a scratch
  root removed `usr/lib/blit/docs` and `fonts/sources` and changed nothing
  else (the postinst needs root, `systemctl` and `adduser`, so it failed in
  that unprivileged run, as expected).
- **Suites:** this change touches packaging only, with no source change since
  0.3.44 (all 178 and renderer 80 passed there); the full matrix was not
  rerun. Run here: the gates above, individually.

## 2026-11-05: 0.3.44 plain title-bar end cells for the inactive bar

- **Four glyphs** (ADR 0214, revised): `chalk-title-end-plain-left/right`
  (U+1002B7-B8) and `slate-light-title-end-plain-left/right` (U+1002B9-BA;
  next free U+1002BB). Each is the existing title-end cell without stripes: the
  outer line, the bar's top line and rule, Slate's bevel rows, the bar
  background. Away from the outer line it is pixel-identical to the plain
  `title` cell, so an inactive title row (end, title cells, end) has no notch
  in the top line or rule. Pens as the title ends (bg the bar, fg the ink,
  Slate: SGR 58 the highlight). Set, part, cells and pen roles in the
  catalogue as for the other frame cells; the catalogue has 105 entries.
- **Gates**, all failing on 0.3.42: `window_glyph_gate` (83 glyphs at 12
  sizes: each plain cell matches the design, equals the `title` cell away
  from the outer line, the seam with it, the 11x22 pixels by hand),
  `window_style_gate` (a real server on both compositors draws all 13 frame
  glyphs and an inactive Chalk and an inactive Slate window; every cell
  against the design, no pixel in the bar but the bar colour),
  `font_reference_gate`, `custom_icon_gate`, `documentation_gate`.
- **Suites:** all 178 pass (6 skip), renderer on GLES 80 pass (1 skip); no
  failures. (Another agent's timed `all` ran at the same time on this host.
  The standalone font suite was not run: `all` contains it.)

## 2026-11-05: 0.3.43 a fitted glyph is never trimmed (the Wi-Fi and volume icons)

- **Root cause** (ADR 0215), found by a sweep of every catalogue icon and the
  symbol classes at 8-64 px: `draw_fitted` fitted a colour glyph from its
  base glyph's outline, but a layered (COLR) glyph is drawn from its layers.
  For `wifi-1` the base box is x[30,131] and the layer union x[30,536], so
  the composite landed about 40% past the right edge at every size, the
  owner's 11x22 included. Beyond that, a hinted render differed from the
  unhinted prediction by about a pixel and the trim loop discarded the
  overhang silently, and percentage margins left under 1 px per side at small
  cells (Nerd icons up to 19 px). Spanning icons did not clip at the owner's
  sizes (the `fit*one > w` theory refuted by measurement); their halves
  disagreed by 1 px in 60-95% of icons because each half was hinted and
  phased separately.
- **Fix:** a colour glyph is fitted by the union of its layers; non-spanning
  fitted glyphs use `FT_LOAD_TARGET_LIGHT`; spanning icons use
  `FT_LOAD_NO_HINTING` at a scale where one advance is a whole number of 26.6
  steps, from a grid origin, so both halves share a phase and join; the
  bitmap is measured after the render (re-fitted smaller up to 3 times,
  slid in by whole pixels if askew, never for a spanning part), and a glyph
  that still does not fit falls back visibly, never trimmed silently. At
  11x22 the Wi-Fi and volume icons change completely (now whole), and the
  file-manager icons soften slightly; Bluetooth, battery and symbols are
  near-identical (before/after sheets at 11x22, 14x28, 20x40).
- **Gates:** `icon_clip_gate` (about 800,000 glyph renders at 3 fonts, and
  10,134,890 at all 7 fonts, stride 8: ink whole, no fallback, spanning
  halves identical, full-cell glyphs reach their edges) fails on 0.3.42
  (about 16,000 glyph-sizes) and passes; `glyph_edge_sweep_gate` runs the
  real server on both compositors at 22-64 px over blocks, box lines,
  powerline, the Chalk and Slate window boxes and a few symbols and checks
  every cell pixel against the production raster's coverage (4.58 million
  pixels, no clip). Blit's drawing does not clip window buttons or cells; a
  clip seen at 40+ is not in the raster or the compositor's cell drawing.
- **Suites:** font 43/43, renderer on GLES 80 pass (1 skip), all 177 pass
  (6 skip) + 1 failure: `hibr_split_capture_gate` ("capture failed pid ...
  exit 1") while three other suites were running on this host; alone it
  passed 3 of 3 afterwards.

## 2026-11-05: 0.3.42 a picture deleted inside a synchronized update stays drawn; the graphics ledger

- **The owner's blink on entering full screen was Blit's** (ADR 0213).
  Hibr sends each frame as one `CSI ?2026h` update: `a=d,d=I` of the old
  wallpaper, then `a=T` of a new image id in 4096-byte chunks (`m=1`).
  Blit holds a synchronized view by skipping it in both compositors, except
  on a whole-output redraw, which drew every view from live state, where
  the old picture was already freed and the new one incomplete: a hole for
  a frame. A whole-output redraw follows a change in the number of views,
  a pane origin moving, or overlays and effects changing, and a full-screen
  transition makes a burst of them over 2-3 s: the 5-6 blinks. In steady
  state nothing redraws the whole output, so only the transition blinked.
  The frame barrier is not the cause (it only decides whether an output
  renders; its holds and timeouts are now counted). **Fix:** inside a 2026
  update a capital-letter delete (`d=I`, `d=A`) of a complete image that is
  drawn now keeps its pixels and placements as a retired image the program
  cannot find, so any redraw still draws it; it is freed when the update
  ends (2026 off, a reset, `ESC c`), with ledger reason `delete-d=I,held`.
  A full image store gives up retired images first; an API graphics reset
  frees them at once.
- **A graphics ledger and counters** make any flicker measurable
  afterwards: `GET /v1/diagnostics/graphics-ledger?since=&limit=` (a
  512-entry ring, never shared with the trace; transmit, place, delete,
  free, reset, blink and barrier events with the output's presented-frame
  number, ids, rectangle, bytes and reason; a cursor, `lost` and per-output
  `present_frames`), and cumulative counters in `/v1/diagnostics/runtime`
  `performance`: placements, deletes, images freed, upload bytes, full
  repaints, blink frames and events, barrier holds and timeouts,
  synchronized live draws. A blink: a picture in the previous presented
  frame is absent from this one and the same id, or a covering successor, is
  drawn again within 8 presented frames.
- **`graphics_blink_gate`** (renderer suite, both compositors): a split
  replace blinks and the ledger shows delete, frames, place; an atomic
  replace and Hibr's real sequence in a 2026 batch, slowly and with views
  appearing mid-batch, do not. On 0.3.41 it fails with 1 blink event, 6
  blink frames and 6 synchronized live draws.
- **Suites:** font 42/42, all 176 pass (6 skip), renderer on GLES 79 pass
  (1 skip); no failures. The agent's earlier `all` run was stopped by hand
  on a hung `output_occupancy_gate` (it passes alone in 69 s; the hang was
  contention between concurrent suites).

## 2026-11-05: 0.3.41 one frame, its line on the outer edge; title-bar end cells

- **One window frame, line on the outermost edge** (ADR 0214, owner's
  decision). Chalk's and Slate's frames were identical, so there is one
  set: `frame-left`, `-right`, `-bottom-left`, `-bottom`, `-bottom-right`
  (U+1002AE-U+1002B2, `set: frame`, coverage in the foreground). The line
  is on the outer edge of its cell (left edge of the left cell, right edge
  of the right, bottom edge of the bottom row); the rest of the cell is
  transparent, so the cell's background, the window face, is the padding.
  The shadow goes in the cells beyond, with `ESC[66:kind:width:0m`.
- **Title-bar end cells** belong to the title bar styles:
  `chalk-title-end-left/right` (U+1002B3-B4) and
  `slate-light-title-end-left/right` (U+1002B5-B6) carry the outer line,
  the bar's top line and rule, Slate's bevel rows and the stripes, which
  run into the cell and stop 2 px clear of the outer line. The old
  stripe-first/-last (inset from a frame line) are redundant.
- **Deprecation, not removal:** the current `chalk-` and `slate-light-`
  frame glyphs (7 each) and stripe-first/-last (18 entries) carry
  `deprecated` and `replaced_by` in the catalogue (typed in OpenAPI,
  checked by `catalogue_fields_gate`) and draw exactly as before, so an
  installed Hibr keeps working until it moves. A later release retires
  them.
- **Gates**, all failing on 0.3.40: `window_glyph_gate` (the nine glyphs
  against the design at 12 sizes, the line on the outermost edge and no
  other ink, seamless stripe joins, the stripe clearance),
  `window_style_gate` (a real server, both compositors: a Slate window with
  a 1 px and a Chalk window with a 2 px shadow, every pixel),
  `catalogue_fields_gate`, `font_reference_gate`, `custom_icon_gate`,
  `documentation_gate`, `api_schema_gate`.
- **Suites:** font 42/42, all 174 pass + 1 timing failure
  (`frame_rate_gate`, which fails under concurrent suites and passed twice
  alone at 62.5 Hz), renderer on GLES 78 pass (1 skip).

## 2026-11-05: 0.3.40 controls glyphs; a catalogue programs can map from

- **Controls glyphs** (ADR 0212), U+10029A-U+1002AD (next free U+1002AE):
  a checkbox (off, checked, mixed) and a two-cell switch in Chalk
  (coverage, the cell's foreground) and Slate (role art from the cell's
  pens), and the Capsule switch, three cells, in one set: its track is the
  cell's foreground (the application picks green or grey), its knob the
  underline colour, its smoothed edge the mean of foreground and
  background. Boxes use the window boxes' helper, so a checkbox lands on
  the same rows at every size. `control_glyph_gate` (every glyph at 12 cell
  sizes against the design) and `control_style_gate` (a real server on both
  compositors; the capsule drawn in green and grey on light and dark
  panels) fail on 0.3.39 ("U+10029A is not a whole coverage cell").
- **A catalogue programs can map from.** Every `cell_geometry` entry (92) has
  structured pen roles, generated from the same tables as the glyphs:
  `part`, `cells` (span and position), `background`, `foreground`, `line`,
  typed in OpenAPI and checked by `catalogue_fields_gate` (the design
  scripts' `--check`). `GET /v1/fonts/icons` carries a `revision` (the
  SHA-256 of the catalogue file as packaged, computed by a new
  `blit_sha256.h`, checked against Ruby's across the padding boundaries)
  and the same value as its `ETag`; `If-None-Match` gets 304; the response
  is `Cache-Control: no-cache`. `GET /v1/server` capabilities list
  `sgr-framed`, `sgr-framed-bar` and `sgr-shadow`, so a client switches
  features on a flag, not a version. The catalogue is 60.9 KB of the 256 KiB
  cap, which the gate enforces.
- **Suites:** font 42/42, all 175 pass (6 skip), renderer on GLES 78 pass
  (1 skip); no failures. One run of "all" failed
  `settings_persistence_gate` once under load; alone it passed 3 of 3 on
  this build and on 0.3.39, and the rerun of "all" passed.

## 2026-11-05: 0.3.39 Slate from the cell's colours; the shadow attribute

- **Slate takes its colours from the cell** (ADR 0211, owner's decision).
  Role art resolved per cell on both compositors: BG the cell background,
  FG its foreground, LINE the underline colour (SGR 58, white if unset),
  MIX the average of FG and BG. One function resolves the pens. Hibr's
  Pewter scheme reproduces the approved look (only the MIX pixels differ
  from 0.3.38's Slate light: 582 pixels of the glyph set, held by a
  fixture of 0.3.38's own drawing). A dark scheme makes Slate dark; the
  Slate dark glyph set U+100277-U+100299 is retired, never reused. The
  dialog's frame cells keep the wallpaper and its margin and gap and the
  buttons' faces are painted with LINE, so no halo or square corners.
  SGR 51:2 draws the bar rows from the same pens, and 51:4 is an alias.
- **The shadow is a cell attribute Blit draws**: `ESC[66:kind:width:inset m`,
  ended by `ESC[67m`. Kinds 1 right, 2 right-start, 3 under, 4 under-start,
  5 corner; width 1 or 2 px; inset 1 (on a Blit frame glyph) or 0 (beyond
  a box-drawing frame). It uses the underline colour or the foreground and
  is drawn before the glyph, so Frame and Shadow combine freely. Cell
  attributes are now 32 bits through the cell, scrollback, alternate
  screen, DECCRA/DECCARA and the compositors (about 320 KiB more per
  surface). DECRQSS and the cells API (`style.shadow`) report it. Gated on
  both compositors: all 20 kind, width and inset combinations pixel for
  pixel, the colour, a glyph over a shadow, SGR 67 and SGR 0.
  `window_style_gate` fails on 0.3.38 ("does not hold SGR 66").
- **Suites:** font 40/40, all 172 pass (6 skip), renderer on GLES 77
  pass (1 skip); no failures.

## 2026-11-04: 0.3.38 no shadow in the frame glyphs

- **The frame, note-frame and dialog glyphs draw no shadow** (ADR 0210
  revised, owner's direction). Each appearance setting draws only its own
  part, and Hibr's Shadow setting owns the shadow. In all three sets the
  frame pieces draw only their 1 px line, and the dialog pieces their four
  border layers. frame-right-top draws as frame-right, frame-bottom-first
  as frame-bottom, and frame-bottom-right as its corner pixel; the code
  points are kept. The shadow constants and Slate's shadow role are
  removed, not left dead. `window_glyph_gate` checks that every frame and
  dialog piece inks exactly its line(s) and nothing else, at 12 sizes in
  all three sets. Against 0.3.37's drawing it fails ("frame-right-top:
  no line against the content, or a shadow beside it").
- **Suites:** font 40/40, renderer on GLES 77 pass (1 skip), all 172 pass
  (6 skip; run with the Hibr headers); no failures.

## 2026-11-04: 0.3.37 SGR 51:5, the rule under a note's strip

- **`51:5`** draws a rule along the cell's bottom edge only (1 px, in
  the underline colour or the foreground): the line under a note's strip,
  which 0.3.36 left undrawn. Plain 51 there would double the frame-top
  line above it. The framing kinds are now one 3-bit field beside the
  FRAMED bit, mapped to the sub-parameters in one table, so the parser,
  DECRQSS, the cells API (`framed: "rule"`) and both compositors read the
  same values. An unknown sub-parameter is plain 51 (ADR 0210 revised).
  `terminal_conformance` (framed-rule-sgr, decrqss-sgr-framed-rule) and
  `window_style_gate` (the bottom line only, native and GLES) cover it.
  On 0.3.36, 51:5 reads as plain 51: the cell reports thin and draws top
  and bottom.
- **Suites:** font 40/40, all 172 pass (6 skip), renderer on GLES 77 pass
  (1 skip); no failures.

## 2026-11-03: 0.3.36 window chrome glyphs (Chalk and Slate) and framed text

- **105 window-chrome glyphs** (ADR 0210), U+100231-U+100299, in three
  sets of 35 in one order: Chalk (one colour, the cell's foreground),
  Slate light and Slate dark (their own colours). Pieces: title bar
  stripes and ends, close, shade and zoom boxes, frame and drop shadow,
  note frame and close box, the dialog's double border, button caps.
  They are drawn as cell geometry in the shared raster, so lines reach the
  cell edge, from one table, `src/blit_window_glyphs.h`. The design script
  and the gates read it, and every length is a constant there. Each
  pixel is set or transparent; transparent pixels show the cell's
  background, the wallpaper under a held desktop. Hibr picks the sets
  per part (Frame, Title Bar, Buttons), so they mix; there is no bundled
  window style. Lines stay 1 px at any cell size, and boxes and stripes
  scale with the cell.
- **SGR 51 framed** (and 54 to end it): a line along each cell's top and
  bottom, in the underline colour or the foreground. Blit extensions:
  `51:3` is the thick default-button ring (`BLIT_WINDOW_THICK_RING`, the
  same constant the caps use); `51:2` and `51:4` are the Slate light and
  dark title-bar rows, so the bar's bevel runs under the title text. One
  band function in the header feeds both compositors. ECMA-48's framed is
  four-sided; Blit's deviates and says so. DECRQSS and the cells API
  (`style.framed`) report it.
- **Gates:** `window_glyph_gate` checks every glyph against the design at
  12 cell sizes, Chalk coverage and Slate colour order, the approved 11x22
  pixels, seams at every size, and contrast on the dark set.
  `window_style_gate` uses a real server on both compositors and checks
  the 25,410 pixels of the 105 cells, SGR 51 and its variants, and cap +
  label + cap as one outline. `terminal_conformance` gains the framed
  cases. They fail on 0.3.35 ("the surface does not hold SGR 51",
  framed-sgr) and without the raster branch.
- **Suites:** font 40/40, all 172 pass (6 skip), renderer on GLES 77
  pass (1 skip); no failures.

## 2026-11-03: 0.3.35 CRT mask; documentation brought up to date

- **CRT mask** (ADR 0209): `mask {amount}` and `mask_type {kind}`
  (0 aperture grille, 1 slot mask, 2 shadow mask). It sits at the
  panel's physical pixels, counted from the frame's corner: it belongs to
  the glass, so it does not grow with zoom and stays still under
  curvature, sync and jitter. Each pixel passes its own channel and
  attenuates the others by the strength, scaled by the inverse of the
  mask's mean transmission, so an unclipped colour keeps its average
  light. It sits after the colour controls and before corners and the
  glass scanlines. Unset, it is byte-identical. `mask_gate` checks
  1,105,920 pixels against the C rule. It fails on 0.3.34 and on four
  mutants: logical pixels, no compensation, no step, and the mask before
  the colour controls.
- **Documentation:**
  - `docs/features.md` lists the effects from 0.3.30 to 0.3.35, restart
    after update, the Hibr identity refresh, ABI 17, `has_view`, and
    Control Panel panes up to 0.1.27, and corrects the zoom range;
  - the README names every effect;
  - `blit(8)` lists zoom, the panel and restart after update among saved
    settings, and gains a paragraph on effects and `has_view`.
  `documentation_gate` passes.
- **Suites:** font 39/39, renderer on GLES 76 pass (1 skip), all 170
  pass (6 skip). A first run of "all" failed `settings_persistence_gate`
  once; alone it passed five times, and the rerun of "all" passed.

## 2026-11-03: 0.3.34 a pane says whether anything is shown in it

- **`has_view`** on each pane of `GET /v1/effects`: whether a session draws
  in it. Effects saved for a pane with no session are kept but draw
  nothing, and nothing said so. On the owner's mini PC the held desktop is
  one session in DP-1 pane 2, so burn-in set on pane 1 never engaged
  (`burn_in_panes` 0) while the API reported it set and available.
  `pane_effects_gate` checks false for both panes before any session, true
  for pane 1 alone after its session, true for both after; it fails on
  0.3.33. The Control Panel's Blit pane 0.1.26 shows "Nothing shown here"
  for such a pane, and burn-in's fade time.
- **Suites:** font 39/39, all 169 pass (6 skip), renderer on GLES 75 pass
  (1 skip); no failures.

## 2026-11-03: 0.3.33 burn-in

- **Burn-in** (ADR 0208): `burn_in {amount}`, phosphor persistence. Each
  burning pane keeps one RGBA8 history texture in logical scene
  coordinates. Before the scene is recomposed the history fades by whole
  levels (linear, as cool-retro-term: gone 0.16 s + 1.44 s x amount/100
  after a change, the remainder carried so the speed does not depend on
  the frame rate); after it, a max blend keeps the brighter of history and
  scene. The pass reads max(scene, history) at every sample, so the trail
  is warped, shifted and tinted like the content; glow is still built from
  the scene. The frame clock runs only while a trail is fading. A history
  is keyed by its pane's logical rectangle and freed when no pane claims it
  (off, resize, layout change); a new one starts as a copy of the scene.
  Without `GL_EXT_blend_minmax` only burn-in is unavailable (`no blend
  minmax`); on the CPU compositor it is kept and reported `cpu compositor`.
  Off: no texture, no draw, byte-identical (zoomed gate's 100% capture).
  `burn_in_gate` checks the fade against the C rule, black by 1.6 s, the
  clock stopping after, amount 30 gone by 0.59 s, layout reset, zoomed 2x2,
  off and pane isolation. It fails on 0.3.32 and on three mutants (shader
  not reading history; clock not extended; fade after recompose).
  GPU memory: 4 bytes per logical pixel per burning pane.
- **Suites:** font 39/39, all 169 pass (6 skip), renderer on GLES 75 pass
  (1 skip); no failures.

## 2026-11-03: 0.3.32 tube colour and static noise; Hibr identity follows the disk

- **Five presentation effects** (ADR 0207): `static_noise` (animated grain,
  frame clock), `chroma` (towards monochrome in the phosphor colour),
  `phosphor` (0xRRGGBB, 0 is white; acts only through chroma), `brightness`
  and `contrast` (-100..100, 0 is off; the registry gains a `minimum`,
  reported in `available[]`). The formulas live once in `blit_effects.h`
  and the shader mirrors them; they run in the present pass after glow,
  the hum bar and flicker, so the light the pass adds is tinted too. On the
  CPU compositor they are kept and reported `cpu compositor`. Zoomed
  displays draw them (ADR 0204). With none set the frame is unchanged:
  the zoomed gate's 100% capture is byte-identical to 0.3.31.
  `tube_effects_gate` checks 860,160 pixels over 7 sets against the C rule
  (within 1). It fails on 0.3.31 (no registry row), and with the chroma or
  noise step removed from the shader (122,880 pixels off; one grain level).
  GPU cost on the Radeon is still to measure.
- **Hibr's identity follows the Hibr on disk** (ADR 0094 revised). The
  probe ran once at start, so after an `apt upgrade` of Hibr from ABI 16
  to 17 the mini PC kept reporting the replaced 0.99.427 as incompatible.
  Blit now stats the configured Hibr every 5 s and probes again only when
  it changed. `hibr_identity_refresh_gate` fails on 0.3.31 (still the old
  identity 12 s after the replacement) and passes.
- **Suites:** font 39/39, renderer on GLES 74 pass (1 skip), all 168 pass
  (6 skip). A first run of "all" failed `frame_rate_gate` (full-scene render
  over budget) while another gate ran on this host; alone it passed twice
  (62.5 Hz, worst frame 5-11 ms of 20) and the rerun of "all" passed.

## 2026-11-03: 0.3.31 built against Hibr 0.99.430 (module ABI 17)

- **Hibr 0.99.430 moved its module ABI from 16 to 17** (`struct ent` and
  `struct var` shrink to 56 bytes). The pins move with it:
  `packaging/HIBR_VERSION` 0.99.430 and `packaging/HIBR_ABI` 17. The
  optional `console-blit` adapter is compiled against the v0.99.430 header
  (identical to b745f9a's, checked) and the server reports
  `pinned_abi` 17. No Blit code changed; the adapter uses none of the
  changed structures.
- The ABI guard was seen working: before this build host had Hibr 0.99.430,
  `native_child_provider_gate` failed with Hibr refusing the new adapter
  (`console-blit: abi 17, shell expects 16`). With 0.99.430 installed it
  passes.
- No package relation to Hibr is added: the adapter is optional and the
  packaged desktop does not load it, and ADR 0094's runtime ABI check is the
  contract. A host still on ABI 16 logs `hibr_abi_mismatch` until Hibr is
  upgraded.
- **Suites** (against the 0.99.430 header): font 39/39, all 166 pass
  (6 skip), renderer on GLES 73 pass (1 skip); no failures.

## 2026-11-03: 0.3.30 presentation effects on zoomed displays

- **Zoomed displays draw every effect** (ADR 0204 revised). On the GLES
  compositor a display with pixel zoom took the enlargement in place of
  the presentation pass, so curvature, glow, RGB shift, the glowing line,
  flicker, horizontal sync and jitter were not drawn and were reported
  unavailable as `zoomed display`. The presentation program now takes the
  zoom: each physical pixel maps to the logical pixel the zoom program
  would show (the same expression), and every effect is worked out in the
  pane's logical rectangle. The result is the 100% picture enlarged in
  crisp blocks. One entry point, `blit_gles_scene_present(..., zoom)`, draws
  the plain copy 1:1 or zoomed; scanlines and corners under the pass are on
  the glass again when zoomed, and the `zoomed display` reason is gone.
  At 100% the output is byte-identical to 0.3.29.
  `zoomed_effects_gate.rb` (renderer suite): a 200% display must equal the
  100% display enlarged, pixel for pixel, with curvature, RGB shift,
  scanlines and corners, black outside the tube, 2x2 blocks, the glowing
  line ticking and moving, and a click landing where the warp shows it.
  On 0.3.29 it fails (392,068 pixels not the 100% display enlarged).
  The entries for 0.3.26 below describe the earlier decision.
- **Screenshots no longer stall under slow animated frames.** Each pending
  capture forced a frame on every render until answered; when frames took
  longer than their period, a flip was always pending at the check after
  composing, and the client got EOF after 10 s. A capture's request now
  clears once its frame is submitted, and captures whose frame has flipped
  are answered before the next frame is composed. It is still the next
  presented frame. Reproduced on 0.3.29 with a zoom cycle and effects on
  llvmpipe; the new gate depends on it.
- **Suites:** font 39/39, all 166 pass (6 skip), renderer on GLES 73 pass
  (1 skip); no failures.

## 2026-11-01: 0.3.29 erased cells repaint; translucent overlays; tidy-up

- **Erased cells never repainted** (the owner's wallpaper showing beside
  Boxer's full screen, twice, cleared each time by a full repaint).
  `terminal_erase_cell` wrote the erase background without damaging the
  cell; `terminal_clear_cell` damages only cells that weren't blank. So
  erasing blank default-background cells to an explicit colour (ED, EL or
  ECH with a background set, as Boxer's Full Screen Border and Hibr's
  windows do) changed the model and not the screen: the floor, or a
  picture under the text, stayed visible over cells the model holds
  opaque. The cell is now damaged when its erase colour is written.
  `under_text_picture_gate.rb` (both compositors) fails without the fix
  (784,638 wrong pixels) and passes with it. It covers delete and re-place,
  replace in place, and synchronized output; erased-to-default cells still
  show the picture.
- **Translucent overlays darkened on the CPU compositor:** blended into the
  scene on every frame, converging to the overlay colour (147,109,80 →
  253,126,0 after 12 frames). They now use the panel's kept-copy store
  (ADR 0203), and `blend_rect` rounds like GLES.
  `overlay_translucency_gate.rb` gives the exact blend with no drift on
  both compositors.
- **Kitty deletes observable:** every session's `graphics_diagnostics` is
  always present, with deletes counted by `d=` kind and images freed. Each
  delete and each image freed for any reason (delete, eviction,
  frame-abandoned and the rest) is a trace event with session, id and
  reason. `kitty_delete_gate.rb`. (Prompted by the HDMI wallpaper vanishing
  while Hibr believed it placed; Hibr found the cause in hold, fixed in
  0.99.418.)
- **OSC 4** palette queries answered with the colour each index paints
  (a set is ignored: Blit has no per-session palette).
- **Overlay DELETE** takes the `overlay-N` id that create and list return.
  The bare number is no longer accepted.
- **Zoom-related fields:** `/v1/diagnostics` per output: `viewport_*` is
  the logical size and `scale_*` is zoom/100. `render_*` is now the mode
  (the framebuffer).
- **Live gates** send the bearer token when `BLIT_AUTH_TOKEN` is set. The
  kitty-limits probe is sized from the real image limit.
  `font_fallback_gate` runs in the font suite. The OpenAPI has the stream's
  `pixel_frame_end` and `pixel_frame_hide`, and api_schema_gate now
  requires a schema for every stream message the server parses.
- **Suites:** font 39/39, all 165 pass (6 skip), renderer on GLES 72 pass
  (1 skip); no failures.

## 2026-11-01: 0.3.28 a pointer lock can't outlive the desktop's release

- **The incident.** On the owner's mini PC, Boxer, full screen on the HDMI
  view, held the pointer lock (ADR 0198). The owner pressed the desktop's
  Release Pointer, and afterwards raw motion reports
  (`ESC [ < 35 ; -5 ; -5 M`, signed deltas, which Blit sends only to a
  locked session) were typed into the focused terminal and shown as
  notifications. It started again after a reboot. The machine had to be
  restarted.
- **Blit's hole.** A Hibr desktop is several Blit sessions, one per view.
  Only the session holding the lock could give it back. "Focus moved away"
  can't happen while the pointer is still, and the stall check saw a
  program reading normally. A give-back on another view, which is where
  the desktop's key goes, ended nothing.
- **Fixed:** `?7701l` from any view of the same desktop (the frame barrier's
  membership) releases the lock wherever that desktop holds it, with the
  usual unasked notice. Every engage and release is a journal line
  (`blit: pointer lock engaged|released: session=… display=… reason=…`) and
  a trace event. `performance.pointer_lock_engages` and
  `pointer_lock_released.{program,desktop_view,focus,stall,reset,exit}`
  count them. (`pointer_lock_releases` counted only Blit's own take-backs,
  so on the night it read 0 and couldn't say whether a give-back had
  arrived.)
- **Gate:** `pointer_lock_desktop_gate.rb` (in the suite with
  pointer_lock_gate) fails without the fix ("timed out waiting for the
  desktop-view release") and passes with it.
- **Not Blit's:** the desktop turning unrouted mouse reports into
  keystrokes, and a restored session re-taking the lock without a click.
  Hibr and Boxer are fixing those (Boxer 1.33: release on game end and
  close, and no lock from restored state).
- **Also from this release's investigation:** the stale right-edge strip
  under Boxer full screen on HDMI (a full repaint cleared it) isn't from
  the displacing effects, which the GPU path recomputes every frame;
  reproductions of that theory were all clean. Cause still open.
- **Suites:** font 38/38, full 161/161 (6 skips), GLES renderer 69/69 (1 skip).

## 2026-11-01: 0.3.27 restart after an update; zoom in 25 % steps, kept per connector

- **Restart after an update (ADR 0205, accepted).** An `apt upgrade` used to
  leave the old Blit running: on 10.52, 0.3.25 was installed at 13:23 while
  0.3.24 ran for hours. The postinst still never restarts Blit, because the
  upgrade usually runs in a terminal inside it.
  - **Detection:** every 5 s Blit reads `/usr/lib/blit/VERSION` (now in the
    package, and checked by the package gate) and notices that its
    executable has been replaced.
  - **The setting:** `server.restart_after_update`, `at-login-screen`
    (default) or `manual`.
  - **The safe moment:** the login manager's session is running, nobody is
    signed in (identity waiting), no other session is running, there has
    been no input for 10 s and no API update is in progress. At most one
    restart per installed version.
  - **Reporting:** `/v1/diagnostics` `update`, with `running_version`,
    `installed_version`, `executable_replaced`, `restart_pending`, the
    policy and `waiting_for`; one line on the performance panel.

  `POST /v1/control/restart` now runs the replaced binary at the same path,
  not the fallback. `restart_after_update_gate.rb` (lifecycle, sudo) works
  on a mock install root:
  - signed in: holds 15 s;
  - manual: holds, and the panel says "restart to apply";
  - at the login screen with a session and input: waits, then restarts
    once 10 s after the last input and comes back as the new version with
    nothing pending;
  - a VERSION the binary doesn't carry: exactly one restart.

  Control Panel pane 0.1.24 has the choice and an "Update waiting" row.
- **Zoom (ADR 0204):**
  - It is kept under the connector name (`DP-1`), not the display name
    ("KMS connector 93"). An entry under the old name is read and dropped on
    the next save (#103 for zoom).
  - It takes any 25 % step from 100 to 400, for the Control Panel's slider
    (pane 0.1.24); display_zoom_gate checks 225 against the formula on both
    compositors.
- **Also seen on hardware this release:** YouTube 3.22 pinned Hibr's
  desktop at ~100 % CPU on both machines, all of it user time
  (utime +295 ticks in 3 s on 10.52, every syscall sample "running"). It was
  rolled back as 3.23.
- **Suites:** font 38/38, full 160/160 (6 skips), GLES renderer 68/68 (1 skip).

## 2026-11-01: 0.3.26 pixel zoom per display (ADR 0204)

- **What:** the owner asked for a zoom per monitor that is not the font
  size, and chose pixel zoom over a crisp one. `PATCH /v1/displays/{id}`
  takes `zoom` (100, 125, 150, 175, 200, 250, 300 or 400), saved per
  connector. The display's logical size is mode × 100 / zoom. Panes,
  grids, pictures, the winsize (columns × the unchanged cell), hit testing
  and pointer position follow it, and Blit enlarges the image nearest-
  neighbour: physical (x, y) shows logical (x·100/zoom, y·100/zoom), with
  the last row and column clamped. The pointer and the performance panel
  aren't enlarged; relative motion stays physical; screenshots are
  physical. Hibr reviewed the design (the logical winsize is theirs).
- **Effects:** curvature, glow and the other presentation effects aren't
  drawn on a zoomed GLES display (reported "zoomed display"). Pane effects
  and scanlines are drawn into the logical scene and enlarged.
- **Found and fixed while gating:** on a zoomed GLES display, scanlines
  under curvature and the corners under horizontal sync or jitter were
  drawn by nothing. The scene left them to the presentation pass, which
  zoom skips.
- **Gate:** `display_zoom_gate.rb` (renderer suite, both compositors), on
  two mock outputs, display-1 1021×769, sized so the clamp shows real
  cells:
  - at 100, 200, 150 and 175 % every physical pixel matches the formula
    computed from a known pattern (5,496,043 pixels, identical on CPU and
    GLES), and the logical bounds, grid and session winsize follow;
  - an absolute pointer move reads logical, a relative 40,20 moves 20,10
    logical at 200 %;
  - the pointer art and the panel are unenlarged, with no residue after
    they leave;
  - scanlines under curvature are enlarged;
  - display-2 is untouched;
  - back to 100 % is byte-identical.

  `display_device_api_gate` covers the capability, configuration,
  refusals, halved bounds, persistence across a restart, and clearing at
  100.
- **Cost (CPU, 1024×768 mock at 200 %):** enlarging one changed cell takes
  about 3 µs; a full-frame enlargement 1.2 ms. A full repaint draws faster
  zoomed (2.6–2.9 ms against 5.5–6.4) because there are fewer cells. GLES
  was measured only on llvmpipe, too noisy to quote.
- **Not gated:** a hotplug rescan keeping the zoom (the code carries it),
  and the pane grid after a boot with a saved zoom.
- **Suites:** font 38/38; full 156/158 (6 skips) and GLES renderer 66/67 (1 skip). `display_settings_gate` failed in both: it expected a display with no backlight to have an empty configuration, and every KMS display now has `zoom`. The gate now expects `{zoom: 100}` and passes on both compositors. `frame_rate_gate` failed once under the full run and passed 3/3 alone.

## 2026-11-01: 0.3.25 a translucent performance panel

- `hud.opacity` (10–100, default 100): the panel's background and graph
  fill blend over what's under them; text, border, bars and the limit line
  stay opaque. Both compositors use the same integer blend,
  `(src·a + dst·(255−a) + 127) / 255` with `a = opacity·255/100`, and
  match to the pixel.
- **No build-up on the CPU compositor.** The panel is blended into the
  scene buffer. So while it is translucent, each output keeps a copy of the
  scene under it, taken after the panes and before overlays and the panel,
  and puts it back before the next partial repaint, as the pointer's
  background is. The copy is dropped on full redraws, GPU frames and VT
  suspend. Opacity 100 keeps the old opaque path.
- **Cost:** the panel build is unchanged (mean 0.07–0.10 ms). On the CPU
  compositor a translucent 390×260 panel costs about 0.3 ms more per
  present (table blend 0.58 ms against the opaque copy's 0.32); the GLES
  quad costs nothing extra.
- **Gate:** `performance_panel_gate` covers:
  - opacity 50 over a pane of a known colour: the exact blend in the
    padding and in a graph gap, on both compositors;
  - three repaints under the panel, the pointer across it and several
    panel updates, after which the pixels are byte-identical (without the
    restore, the CPU background had crept from (28,53,90) to (18,21,29));
  - opacity 100 opaque again;
  - 9, 101 and "50" refused.
- **Control Panel pane 0.1.21–0.1.22:** the corner and Hibr-section rows
  never reached Blit in 0.1.20 (see hibr-apps docs/blit.md); fixed, and
  `blit_panel_gate` now drives all four panel rows, Panel opacity included,
  against this server and checks what it saved. `blit_ui_gate` and
  `blit_mouse_gate` pass.
- GLES exactness is shown on llvmpipe; radeonsi is untested.
- **Suites:** font 38/38; full 157/158 (6 skips), the failure `settings_persistence_gate` (known intermittent), then 3/3 alone; GLES renderer 67/67 (1 skip).

## 2026-11-01: 0.3.24 the panel's why line names text

- The owner asked for "other" to read "text". Most of "other" was text,
  but not all of it, so text is now counted as a reason of its own rather
  than renamed:
  - a frame whose cells changed short of a full redraw counts as
    `text_frames` per output, and as `why_hz.text` in `recent`;
  - "other" stays for the rest, such as a full redraw or a capture, and is
    shown only when nonzero.
- Seen live on 0.3.23 with Hibr 0.99.407 (held desktop, YouTube): the
  panel's hibr section carried the desktop's eight lines, also in each
  session's `status` (about 0.4 s old). display-93 drew 40/s: effects 17,
  video 10, pointer 11, other 2. Mean panel update 0.31 ms with the hibr
  section, 0.16 ms without.
- **Suites:** font 38/38, full 158/158 (6 skips), GLES renderer 67/67 (1 skip).

## 2026-11-01: 0.3.23 the performance panel, made readable and cheaper

- **The owner's reading of 0.3.22 live:** "fps 60" while a 9 fps video
  played, "kitty 0/s sixel 0/s", "render 20.7/0.8", "late flips 14284",
  "input 0.0 ms", identical numbers on both panels, a graph covering
  only two-thirds of the panel, and a renderer name too long to fit.
  Every complaint was right:
  - most lines were global;
  - the timings mixed last values with windowed maxima;
  - the counts were totals since start;
  - the panel grew wider than its 60 bars.
- **Now per display**, at most 47 columns:
  - `draws` (this output's presents per second, without `hud_frames`), and
    `late`/`missed` per second;
  - `why`, splitting the draws into effects, video, pointer and other;
  - `draw` and `flip`, each as now with the max over 10 s;
  - `gpu` (the renderer shortened), or `cpu` and why;
  - `video`, frames by descriptor and Kitty/Sixel per second for this
    display's sessions;
  - a 60 s graph across the full width, newest on the right.

  The Blit-wide block (loop, input `idle` or times, glyph hit %, errors in
  10 s) shows once, on the first panel. Every line is also in
  `/v1/diagnostics`: per output `recent`, `picture_frames`,
  `pointer_frames`; `hud.recent`.
- **Cost:** only changed lines and the graph are redrawn, and GLES uploads
  only the changed rows. Mean update 0.089 ms (CPU) and 0.083 ms (GLES),
  against 0.33/0.38 ms; on the owner's two displays 0.65 ms mean before,
  to be measured.
- **Gates:**
  - `performance_panel_gate` checks the draws, why, video and gpu lines
    against the API in the same response, the 47-column limit, a graph
    spanning the width, and an idle `draws 0/s` / `why nothing drawn`.
  - `frame_descriptor_gate` sends 30 descriptor frames and checks the
    panel's why/video lines against the API.
- **Suites:** font 38/38, full 158/158 (6 skips), GLES renderer 67/67 (1 skip).

## 2026-11-01: 0.3.22 the performance panel (ADR 0203)

- **What:** a "stats for nerds" panel drawn by Blit over everything, asked
  for by the owner and designed with the Hibr maintainers (ADR 0203,
  accepted). The panel shows:
  - fps against the refresh rate, and the mode;
  - missed deadlines and late flips;
  - the compositor and why, and the renderer;
  - render, present, loop-gap and input times;
  - Kitty, Sixel and descriptor-frame rates, and refusals;
  - errors, and glyph-cache hits and misses;
  - a 60 s graph of each second's worst present time;
  - a Hibr section from the lines Hibr sends.

  It is the `hud` object in the settings document (`BLIT_HUD=1` at start)
  and a switch in the Control Panel's Blit pane (pane 0.1.20).
- **Light by construction:**
  - It updates at `hud.hz` (default 2); only while on does it ever wake the
    loop.
  - It is an opaque bitmap in the boot PSF, copied after the overlays in
    the CPU compositor and one texture quad in GLES.
  - Panel-only presents are counted as `hud_frames` and kept out of
    `frame_rate_hz`.
  - Measured: mean update 0.33 ms (CPU) and 0.38 ms (GLES), with a worst
    of 0.56 ms; over an idle 5 s at 2 Hz, 10 presents, all `hud_frames`.
- **Frame socket version 2** (ADR 0202): `HUD1 on|off` to version 2
  clients only, and `STA1` status lines from them. The count is
  little-endian and only a check against the newlines; up to 8 lines of up
  to 64 bytes. They are shown for 5 s and exposed as the session's
  `status`.
- **Counters made true:**
  - `desktop_cpu_ms` now sums the desktop owner's process tree. It followed
    the login wrapper and read 0, while `desktop:desktop` used 30%.
  - `glyph_cache_hits`/`misses` are counted for the first time.
- **Gates:**
  - `performance_panel_gate.rb` (renderer suite, both compositors):
    - off: absent;
    - on: the heading and compositor lines match the PSF pixel for pixel,
      with the exact border and background;
    - idle presents within budget;
    - off again: the region repainted byte-identically.
  - `frame_descriptor_gate` gains version 2: HUD1 on, off, after OK and
    steady across unrelated settings writes; never to version 1. STA1 is
    accepted and shown, and refused for v1, 9 lines, 65 bytes, a count
    mismatch, no newline, a control character, count 0 and an attached
    descriptor. Lines expire after 5 s.
- **Control Panel pane 0.1.20 (hibr-apps):** `blit_panel_gate`,
  `blit_ui_gate` and `blit_mouse_gate` pass against this server. The UI
  gate failed once ("hold: no such session" before the pane loaded) and
  passed twice after.
- **Not yet seen on hardware**, nor with a real Hibr version 2 client.
- **Suites:** font 38/38. The full suite was 157/158 (6 skips) and GLES
  renderer 66/67: both failed only `surface_damage_gate`, which no longer
  compiled (`record_kms_frame_submission` gained the panel-only mask). The
  gate now passes the mask and adds two cases: a panel-only present counts
  as a present and not a frame, while a frame that also updates the panel
  is still a frame. It then passes on both compositors.

## 2026-10-31: 0.3.21 dead diagnostics removed; "delete all" frees descriptor images

- **Dead diagnostics**, found by the documentation sweep. Leftovers of the
  SDL renderer (ADR 0184), reported but never true:
  - `performance.pointer_cache_hits`/`misses`: always 0, nothing counted
    them. Removed from the runtime JSON and the OpenAPI.
  - `tools/diagnostics/verify-live-physical.sh` failed on a render-path
    `graphics_changed=1` the server never emits; the check is gone.
  - `tools/diagnostics/analyze-experience.py` counted
    `graphics_texture_uploads`, which does not exist, so graphics work never
    counted as activity. It now uses `graphics_payloads` plus
    `pixel_frames_accepted`.
- **`frame_descriptor_gate`** gains the case Hibr's restart wipe relies on
  (Hibr 0.99.400): `a=d,d=A` frees every image, descriptor-made ones
  included, even one never placed, and its id then gets `ENOENT`.
- Roadmap: Super as a drag modifier points at Hibr #415. Blit's half
  (ADR 0169) is done.
- **Suites:** font 38/38; full 156/157 (6 skips), the failure `frame_rate_gate` (a full-scene render over its 20 ms budget under the full run), then 3/3 alone (worst render 3.9–5.5 ms); GLES renderer 66/66 (1 skip).

## 2026-10-31: documentation sweep (after 0.3.20, no release)

Every document checked against the code, not against other documents.
191 files; documentation, API schema and schema-suite gates pass.

- **ADRs:** one status line each, in six forms now defined in the ADR
  index. 12 records retired, 16 superseded (six by ADR 0184, as its
  header says), 40 marked `in use since` from a `Used` features row
  or a ledger entry, the rest `accepted`; 0180 stays `proposed`. 0190 and
  0193 moved from proposed to accepted (shipped). 0202 now supersedes 0182.
- **A stripped space before numbers** ("in0.1.545", "ADR0169",
  "issue101") restored at about 550 places; identifiers such as `card0`
  and `base64` left alone.
- **API guide and OpenAPI:** endpoint methods corrected (hibr-owner is
  POST only, inject POST only, update upload PUT); problem codes and 429s
  that the server never sends replaced with the real ones; the runbook's
  jq keys made real; settings keys completed. Many response schemas were
  missing keys the server sends (`frames`, `flip.submit_phase_ms`,
  `compositor`, `server_version` and others) and now carry them.
- **Hibr integration guide** rewritten (513 → about 290 lines): QEMU- and
  adapter-era text cut; join input goes to each client's own PTY (ADR
  0127), the login desktop's role is `primary` once associated.
- **Diagnostics guide:** render_path, evdev and loop-gap field names made
  real. **Font reference:** the glyph stack order is the code's.
- **Testing and workflow guides:** the service runs as root (the
  unprivileged profile is an example drop-in); an unauthenticated network
  bind exits 3; the release flow written in order; the hotplug monitor is a
  netlink thread; the old build-from-scratch gate plan replaced by an
  acceptance table.
- **blit(8):** five production settings moved out of "Testing".
- **Found, not fixed (code), now on the roadmap:** overlay DELETE ignores
  its own `overlay-N` ids; dead diagnostics counters and tool checks; live
  gates without a bearer token; the kitty-limits probe sized for 8 images;
  `font_fallback_gate.c` in no suite; two stream messages without schema.

## 2026-10-30: 0.3.20 `blit --version` and `blit --help`

- The owner asked how to tell which Blit is running. `blit --version`
  (`-V`) prints `blit <version>`; `blit --help` (`-h`) a short usage that
  points at `blit(8)`; any other non-port argument still exits 2 with the
  usage. `blit(8)` documents both, and notes the running server's version
  is also `BLIT_VERSION` in every session and `/v1/version`.
- `documentation_gate.rb` runs the built server: `--version` must name
  `packaging/VERSION`, and `--help` must point at `blit(8)`.
- **Step 2 of ADR 0202 measured live** (Blit 0.3.19, Hibr 0.99.398, YouTube
  in a window, 60.1 s, after one sign-out and sign-in): each of the three
  displays' sessions accepted 706 frames by descriptor (11.7/s), none
  refused, stale or superseded; `graphics_payloads_kitty` +0, so no picture
  crossed a PTY. Hibr desktop 34.5%, hold 2.9%, Blit 9.6%, against 32.0%,
  25.4% and 25.3% on step 1. Blit drew 80.7 frames/s with 3.5 missed
  deadlines/s. ADR 0202 records it under "Result" and is marked in use.
- **Documentation pass**, each claim checked against the code:
  - ADR 0202: the hello's refusal is `ERROR 0 EACCES` (or `EINVAL`), not
    `ERROR EACCES`; frames are read with `pread`, not mapped; the socket is
    abstract, so it has no file mode (it said 0660, group `blit`); `ENOMEM`
    is a reply; a signed-out sender is refused. It now says the channel is
    local only, and what happens over ssh or from another machine. Its
    verification section says what the gate covers and what it does not
    (the uid rules need root).
  - The API guide, `blit(8)`, the terminal reference and the Hibr
    integration guide state the local-only rule; the integration guide has a
    section on Hibr's two picture paths and how to tell which is in use.
  - `PATCH /v1/displays/{id}` accepts `rotation: 0`; the API guide said
    every rotation was refused. The endpoint summary no longer says
    rotation; the multi-display rotation caveat is gone (nothing rotates).
    The OpenAPI drops `rotation` from the capabilities enum and from the
    bounds text; the settings guide says what the `displays` section keeps.
  - Architecture: the frame socket in the diagram, the parts and security;
    `blit_display_geometry.h` (deleted in 0.3.16) gone from the parts.
  - Roadmap at 0.3.20; #143 and #144 off it, #109 waiting on the owner;
    video and dragging results recorded. Features: descriptor frames `Used`,
    `--version`/`--help`, the submit-phase counters. README: `blit
    --version` for the installed Blit, `/v1/version` for the running one.
- **Suites:** font 38/38, full 157/157 (6 skips), GLES renderer 66/66 (1 skip). After the documentation pass, `documentation_gate` and `api_schema_gate` rerun and pass.

## 2026-10-30: 0.3.19 the frame sender's uid is checked on every frame (ADR 0202)

- **Why:** the Hibr maintainers found the main view (the login session) on
  `t=d`: the login screen starts the user's session from an empty
  environment, so its hold client never saw `BLIT_FRAME_SOCKET`/`TOKEN`.
  Hibr 0.99.398 passes those two, and only those, into the session.
- **Blit's part:** the uid allowed for a login session follows the
  signed-in user, but it was checked only at the hello. Now every frame is
  checked; a connection whose uid is no longer allowed (its user signed
  out) is answered `EACCES` and closed (`frame-peer-signed-out`).
- **Step 1 measured live** (Hibr 0.99.397, whole-frame `a=f` into one id,
  YouTube in a window, 60 s): desktop 69.3% → 32.0%, hold 22.9% → 25.4%,
  Blit 21.4% → 25.3%, with the video at 1221x682 against 924x462 (about
  twice the pixels); 560 partial GPU uploads per output; no `a=T` per frame.
- **Not testable without root:** a second uid. `frame_descriptor_gate`
  still passes on both compositors.
- **Suites:** font 38/38, full 157/157; GLES 66/67, the failure
  `settings_persistence_gate.rb` once in the suite (it passed in the full
  suite and 3/3 alone; nothing here touches settings).

## 2026-10-30: 0.3.18 a placement may arrive before its first frame (ADR 0202)

- **Found by the Hibr maintainers:** inside hold the frame goes to the
  socket and the `a=p` to the PTY, two inputs Blit reads independently, so
  the placement can be read first; Kitty's rule refuses it and it is lost.
- **Fixed:** while a session has a frame connection, an `a=p` that keeps
  the cursor and names no image yet is held for 2 s and placed when that
  id's first frame lands (answered `OK`, or nothing under `q=2`); if none
  comes it is refused `ENOENT`. Other sessions and cursor-moving placements
  keep Kitty's rule.
- **`frame_descriptor_gate`** adds both: an `a=p` before its frame is
  placed when the frame lands; one whose frame never comes is refused
  after 2 s and a later frame finds the image unplaced. Both compositors.
- **Suites:** font 38/38, full 157/157, GLES 66/66.

## 2026-10-30: 0.3.17 picture frames by descriptor; 16 images per session (ADR 0202)

- **Why:** with a YouTube video playing on the owner's machine, Hibr's
  desktop used 69%, hold 23% and Blit 21% of a core, every frame a new
  base64 Kitty image through two PTYs.
- **Blit's half of ADR 0202:** an abstract `SOCK_SEQPACKET` socket per
  server (`@blit-frames-<port>`), told to every session with a random
  `BLIT_FRAME_TOKEN` (`BLIT_SESSION_TOKEN` is start time plus session number
  and not a secret; noted, not changed). A client says hello with the
  token; its uid must be the session's (the signed-in user for a login
  session) or root. A frame is a 48-byte header and one sealed memfd, read
  with `pread` into the session's image. Placement and deletion stay Kitty
  escapes; a descriptor image takes no Kitty pixels and a Kitty image takes
  no frames; a frame after a freeing delete is `ENOENT`; an older sequence
  is dropped; of several frames waiting for one image the newest is applied
  and the rest closed unread. No name from any channel is opened (ADR 0066
  holds, and names 0202 as its second authenticated route).
- **16 images per session**, from 8, asked for by the Hibr maintainers.
- **`frame_descriptor_gate`** (Hibr suite), on both compositors: the token
  is separate and random; a wrong token is refused; a frame before its
  placement is kept and drawn on placement (screenshot); newest wins on
  screen; a stale frame is dropped; an edit writes its rectangle; unsealed,
  short, oversized and unknown-edit frames are refused with their codes;
  Kitty pixels into a descriptor image and a frame into a Kitty image are
  refused; a frame after `a=d,d=I` is `ENOENT`. Not tested: a peer whose
  uid may not send (needs a second uid, so root).
- **Hibr's half** (the console writer, hold passing the descriptor) is in
  progress; until then nothing uses the socket.
- **Suites:** font 38/38, full 157/157, GLES 66/66.

## 2026-10-30: window dragging on the owner's machine, Blit 0.3.16 (#125, #135)

The owner dragged windows for 40 s on the main monitor, between its two
Hibr views, and across to the second monitor and back; read through the
API (presents, flips, `submit_phase_ms`, frame barrier, loop-gap windows).

| | display-93 (1920x2160) | display-102 (2560x1440) |
|---|---|---|
| presents/s | 50.1 | 40.9 |
| missed deadlines | 17 | 14 |
| late flips | 29 / 2,014 (1.4%) | 48 / 1,644 (2.9%) |

- Every late flip was submitted in the last 1–5 ms before its vblank.
- Loop gap per 500 ms window: median 8.6 ms, worst 11.4 ms, none over a
  refresh.
- Frame barrier: 874 armed, 710 released with both views, 165 timeouts.
- Blit 12.7% of a core.
- One monitor alone (40 s earlier): 58.5 presents/s, 0 missed, 0.5% late.
- The owner: "it felt fine". The frame rate follows Hibr's redraws; Blit
  does not limit it.
- The second monitor, switched off and on during the session, was found
  again by hotplug (inventory revision 1 → 2), presented on GLES with its
  Hibr view and wallpaper restored (#100).

## 2026-10-30: 0.3.16 a hung GPU start recovers; rotation plumbing gone; the mock DRM fd is real (#109, #143, #144)

- **#109, a GPU start that hangs.** The console watchdog runs before the
  displays are opened, so a hang there is killed after 10 s and systemd
  starts Blit again; the guard marker, written before the GPU start, sends
  that start to the CPU, and the API comes up. `gles_compositor_gate.rb`
  now proves the chain the test display allows: with a test-only hang
  (`BLIT_TEST_GLES_HANG_MS`, honoured only with `BLIT_TEST_MODE=1`) the
  API is unreachable and the marker is on disk; killed, the next start is
  on the CPU with the reason, and the one after tries the GPU again. The
  watchdog itself is `vt_watchdog_report_gate`. `blit(8)` describes it.
- **#143, rotation.** Always 0 since ADR 0184. Gone: the display field,
  `rotation` in `/v1/topology`, the persisted `displays` entry, the rotate
  helpers and `display_geometry_gate`. Kept: `PATCH` accepts 0, refuses
  other angles with 422 `display_rotation_unsupported` and invalid ones
  with 400.
- **#144, the mock display.** The mock DRM device is now a timerfd,
  readable exactly when a page flip completes (at once, or at its vblank),
  with dumb buffers mapped anonymously; the 1 ms sleep in
  `drmHandleEvent` is gone. Measuring it showed the event loop answering
  a due flip 0.4–21 ms late while a PTY floods it -- true of the old mock
  too, and the next thing to look at under the 0.2 architecture tickets.
- **Fixed on the way:** a flip whose vblank passed between submission and
  the sequence read was left out of `submit_phase_ms`; it is counted in
  the last bucket now.
- **Suites:** font 38/38, full 156/156; GLES 66/67, the failure
  `sync_output_gate.rb` once in the suite (its known llvmpipe flake, noted
  at 0.2.10), then 12 of 12 alone.

## 2026-10-30: 0.3.15 animation frames start just after a vblank

- **What 0.3.14 showed** on the owner's machine (5 minutes after deploy):
  every late flip was submitted 12–16 ms after the previous vblank, none
  earlier. display-93: 1,487 late, by millisecond 12–16: 34, 176, 516, 671,
  90. display-102: 896 late: 2, 19, 174, 591, 110. A flip submitted with
  less than about 3 ms left cannot make that vblank.
- **Most frames there are the panes' animated effects** (all of
  display-102's). Their 30 Hz tick fell wherever the period came round, and
  the loop woke for it only at its next 10 ms poll, so animation frames
  drifted through those last milliseconds.
- **Fixed:** an animation tick is put 0.5 ms after the vblank nearest its
  due time, and the loop wakes for it. A tick on a vblank comes round a
  little under a period after the last animation frame, so the "real frames
  are flowing" test now uses three quarters of a period.
- **Gates:** `surface_damage_gate.c` checks the alignment arithmetic;
  `presentation_effects_gate.rb` still sees 30 Hz with no missed deadlines.
  The mock's GLES path has no page flips, so the live buckets are the
  evidence.
- **Live after** (0.3.15 on the owner's machine, 380 s after deploy):
  display-102, whose frames are all animation: 0 late of 11,400 (0.3.14:
  896, 10.5%), every flip submitted 0–3 ms after its vblank. display-93,
  the game's monitor: 731 late of 12,219 (6.0%; 0.3.14: 14.7%), all still
  submitted 12–16 ms after the vblank -- frames whose content arrived that
  late, which no schedule can save. Missed deadlines: 568 / 477 in 380 s
  (about 1.5 / 1.3 a second, from about 30 before 0.3.13).
- **Suites:** font 38/38, full 156/156, GLES 67/67.

## 2026-10-30: 0.3.14 when late flips were submitted

- **Why:** after 0.3.13 about 14% of flips on both of the owner's monitors
  still land a vblank late, with GPU time per frame only 0.4–1.5 ms, so GPU
  cost is not the cause.
- **New diagnostic:** each output's `flip.submit_phase_ms` counts on-time
  and late flips by how long after the previous vblank they were submitted
  (17 one-millisecond buckets). Late flips at the end of the period were
  submitted too close to the vblank; spread through it, something else
  holds them. Runtime behaviour is unchanged.
- **`kms_frame_timing_gate.rb`** checks every classified flip is in exactly
  one bucket.
- **Suites:** font 38/38, full 156/156, GLES 67/67.

## 2026-10-29: 0.3.13 the Hibr frame barrier stops holding every frame (ADR 0082, revised)

- **Found on the owner's machine.** Both monitors missed about 40% of their
  refresh deadlines. In 30 s of ordinary use, with a game drawing in the
  primary Hibr view: 311 frame barriers armed, 251 with 1 of 3 views dirty,
  254 timeouts, each holding a frame a full refresh; 386 missed deadlines on
  display-93 and 403 on display-102.
- **Fixed:** the barrier groups only one monitor's views, and a view that
  let a barrier time out is not waited for again until it draws again
  (forgiven after 1 s of quiet on that monitor).
- **`hibr_frame_barrier_scope_gate.rb`** (Hibr suite): a quiet view and a
  drawing one on one monitor give 1 timeout in 75 frames (0.3.12: 42); views
  4 ms apart on two monitors open no barrier.
  `hibr_join_frame_barrier_gate.rb` still passes: two quiet views redrawn
  4 ms apart present together.
- **Most of the remaining "misses" were not misses.** A second 30 s sample
  (`tools/probes/frame_barrier_sample.rb`) had only 23 barrier timeouts but
  892 / 879 missed deadlines against 784 / 783 presents: the owner's panes
  run an animated effect at 30 Hz, and on a 60 Hz monitor every animation
  frame was counted as a missed deadline. An animation frame is now due
  when its tick fires. `presentation_effects_gate.rb` checks it: 0.3.12
  counted 109 missed deadlines in 52 animation-only frames; 0.3.13, none.
- **Real late flips remain**: 14,342 of 81,393 flips on display-93 were
  late (17%). That is the next item.
- **Live after** (0.3.13 on the owner's machine, same 30 s probe, ordinary
  use; the workload is the owner's and not identical): missed deadlines
  47 / 207 against 925 / 796 presents (before: 892 / 879 against 784 / 783),
  no barrier armed or timed out (before: 23 timeouts in that sample, 254 in
  the first). Late flips remain about 15% / 11%; `kms_frame_retry` 80 in
  30 s. Those are the next item.
- **Suites:** font 38/38; full 155/156 and GLES 66/67, the failure in both
  `surface_damage_gate.c` still naming the single barrier deadline. Fixed,
  the renderer suite was rerun: CPU 67/67; GLES 66/67, the one failure
  `kms_hotplug_gate.rb` (a CPU-compositor gate) timing out under load, which
  passed alone three times and in the earlier full GLES run.

## 2026-10-29: 0.3.12 terminal fixes from the terminal reference

Writing [the terminal reference](terminal.md) from the code (0.3.10) found
these; each now has a case in `terminal_conformance.rb`.

- **Colours:** bright colours (SGR 90–97, 100–107, palette 8–15) are
  xterm's, not a darkened copy of 0–7.
- **SGR sub-parameters** are parsed as such: underline styles `4:1`–`4:5`
  no longer set bold, dim or blink; `38:2:CS:r:g:b` reads its colour space;
  `CSI ? m` is no longer taken as SGR.
- **`CSI 3 J`** erases the scrollback and leaves the screen.
- **Left/right margins:** line feed, index, next line, reverse index and
  wrapping scroll only inside them; a lone-row scroll outside them does not.
- **Background-colour erase:** a line scrolled in or inserted takes the
  current background, as the `bce` Blit advertises promises.
- **Character sets:** G0–G3 with SS2/SS3 and LS2/LS3; 96-character
  designations no longer print their final byte; C1 DCS is DCS.
- **Replies:** DA3 (`CSI = c`) answers with a unit id; XTVERSION names the
  release (`Blit(0.3.12)`); DECRQM reports modes 69 and 2026; DECRQSS
  reports SGR colours and the exact cursor style; window reports 14, 16 and
  19 (pixel and character sizes) are answered.
- **Mouse mode 9** reports presses only, without modifiers.
- **Sixel** images over 16 KiB decode whole (the string grows to 8 MiB);
  past that one is refused whole and the screen carries on.
- **Kitty:** every failure answers with an error (`EINVAL`, `ENOENT`,
  `ENOSPC`, `EFBIG`, `ENOMEM`) to a request that names its image, honouring
  `q=`; `a=p` and `a=q` need no data section; `a=q` answers for PNG. Hibr
  sends `q=2`, so it sees none of these.
- **Mouse mode 9** has its own case in `mouse_report_gate.rb` (press only,
  no release): it fails on 0.3.11 and passes on 0.3.12.
- **Suites:** font 38/38; full 154/155, the one failure
  `hibr_split_capture_gate.rb` stopping at its server start under suite
  load, then passing alone three times and in a rerun of the Hibr suite
  (15/15); GLES 67/67.

## 2026-10-29: 0.3.11 the GPU compositor is the default (ADR 0181, revised)

- **The owner asked for the GPU by default and the CPU by choice.** With no
  `BLIT_KMS_COMPOSITOR` and no saved `server.kms_compositor`, Blit now
  composes with GLES; `cpu` chooses the CPU. A GPU that cannot start, or
  crashed starting last time, still falls back to the CPU with the reason.
  An unknown value is logged and means the GPU.
- **The owner's machine already had `gles` saved**, so its screen does not
  change; the default matters for new installs and after a settings reset.
- **Gates:** every harness that starts the server now names its compositor
  (`cpu` for the default suites, `gles` for `BLIT_GATE_BACKEND=gles`), so
  the CPU compositor stays covered.
- **Suites:** font 38/38, full 155/155, GLES 67/67.

## 2026-10-29: 0.3.10 documentation rewritten; manual pages

- **New:** [features](features.md) (everything Blit does, with version, ADR
  and how far it is proved), the [terminal reference](terminal.md) (written
  from the code, with its known gaps), a current [roadmap](roadmap.md), and
  manual pages `blit(8)`, `blit.env(5)` and `blit-update-helper(8)`,
  installed under `/usr/share/man`.
- **Rewritten:** the README, the documentation index and the architecture
  page; SDL and release-candidate wording removed from the current guides.
  Eleven working notes from 0.1 and 0.2 moved to `docs/history/`, links
  repaired.
- **The OpenAPI document** now lists the saved settings `kms_compositor`,
  `kms_frame_timing` and `effects_animation_hz`, which the server already
  accepted.
- **Font specimen** (`docs/images/blit-fonts.png`) redrawn by
  `tools/fonts/preview.rb`: the five text fonts, Blit and file icons, Nerd
  glyphs and emoji.
- **`documentation_gate.rb`** (schema suite): every `BLIT_` name the server
  reads or exports is in `blit(8)`, the manual pages format without groff
  warnings, and no relative link in the repository is broken. The package
  gate checks the manual pages and the new documents are in the package.
- **Found, not yet fixed** (roadmap, item 1): sixel streams over 16 KiB are
  cut off; bright colours 90–97 are darker than normal ones; SGR `4:n`
  underline styles leak into other attributes; `CSI 3 J` clears the screen.
  `BLIT_AUTH_TOKEN_FILE`, named in the API guide, was never implemented; the
  guide no longer names it.
- **Pointer lock** (ADR 0198, 0.2.42) is confirmed on the owner's machine:
  the owner reported on 2026-10-28 that locking works, and #139 is closed.
  [Features](features.md) marks it Used on that evidence.
- **Suites:** font 38/38, full 155/155 (with the documentation gate), GLES 67/67.

## 2026-10-29: 0.3.9 non-folder colour slots retired (ADR 0201)

- **Step 3 of the changeover.** Hibr 0.99.385 names non-folder kinds
  without a colour, so their blue, green and amber slots -- 294 codepoints
  in 41 ranges -- are retired: listed in the catalogue, never reused, and
  drawing nothing from Blit's icons. 249 colour originals remain; folders
  keep their four colourways.
- **`custom_icon_gate`** reads the live icons and the retired codepoints
  from the catalogue: every live one draws in colour, every retired one
  draws nothing from the icons, and the distinct drawings differ from 16 px.
  The KMS raster gate samples live classic slots.
- **Suites:** font 38/38, full 154/154, GLES 67/67.

## 2026-10-29: 0.3.8 natural-colour file icons; colourways for folders only (ADR 0201)

- **Fifty-two file kinds have one look each, in their own natural colours.**
  Only folders keep the four colourways. The owner approved a preview.
- **PDF carries a "PDF" label, and three new picture kinds carry JPG, PNG
  or GIF** (U+10022B–100230), from a 3×5 label font in the generator.
- **Every existing codepoint still draws.** A non-folder kind's colour
  slots all show its one drawing until Hibr names it without a colour;
  then the slots are retired. 196 colourway SVGs were removed.
- **`custom_icon_gate`** covers 543 originals, and the distinct drawings
  (one codepoint each, from the catalogue) are distinct from 16 px.
- **Suites:** font 38/38, full 154/154, GLES 67/67.

## 2026-10-29: 0.3.7 thirty-nine more file icon kinds (ADR 0201)

- **Special folders, folder plus a badge:** git, config, local, system,
  desktop, downloads, documents, music, pictures, videos, apps, games.
- **Files:** rc, history, service, key, network, cron, readme, license, log,
  kernel, boot, c, asm, makefile, patch, json, vector, rom, ebook, exe,
  disc, package, library, lock, database; devices usb and share.
- Four colourways each, at U+1000F3–10022A. The owner approved a preview.
  The catalogue limit rises to 256 KiB, since it is now 64.7 KiB.
- **Gates:** `custom_icon_gate` covers 537 originals, and the sixty-three
  file kinds are distinct from 16 px. The API and KMS gates sample the last
  pair.
- **`custom_icon_gate`** now asks for antialiased edges of the set at each
  size, not of every drawing. The USB stick's right half is straight
  rectangles that land exactly on whole pixels at 20 px.
- **Suites:** font 38/38, full 154/154, GLES 67/67.

## 2026-10-29: 0.3.6 twelve more file icon kinds (ADR 0201)

- **Twelve kinds added at U+100093–1000F2,** four colourways each, a kind
  at a time:
  - home: a house with its roof in the primary colour;
  - boxer: a Boxer game without its cover, two boxing gloves;
  - markdown, spreadsheet, diagram, presentation, font, web, terminal,
    settings, bundle (a Hibr bundle) and link.
  The owner asked for them, and saw a preview.
- **Gates:** `custom_icon_gate` covers 225 originals, and the twenty-four
  file kinds are distinct from 16 px. The API and KMS gates sample the last
  pair.
- **Suites:** font 38/38, full 154/154, GLES 67/67.

## 2026-10-29: 0.3.5 the large phone icons retired (ADR 0196)

- **U+100023–100032 removed,** after longwire 0.5.22 and Hibr 0.99.378
  stopped using them, as the owner asked. The catalogue lists the range
  under `retired`, and it is never reused. 129 colour originals remain.
- **`custom_icon_gate`** checks the retired range draws nothing from Blit's
  icons. The API and KMS gates no longer sample it.
- **Suites:** font 38/38, full 154/154, GLES 67/67.

## 2026-10-29: 0.3.4 file-manager icons (ADR 0201, 0197)

- **48 two-column colour icons for Hibr's Files** at U+100033–100092:
  twelve kinds in four colourways, one generator, one drawing per kind,
  with colourways from a primary colour. The owner approved the preview.
- **Spanning icons revised (ADR 0197):** the span is the part's advance,
  not its ink's width, and every spanning icon is fitted by its design box,
  so a family shares one scale and one line. The hui badge is unchanged.
- **Catalogue API limit** raised from 8 KiB to 64 KiB (the catalogue is
  ~17 KiB). **The package gate** checks every icon file in the commit.
- **Gates:** `custom_icon_gate` covers 145 originals, with whole file icons
  distinct from 16 px; the API and KMS gates sample the range.
- **Suites:** font 38/38, full 154/154, GLES 67/67.

## 2026-10-29: 0.3.3 Kitty success replies (ADR 0200)

- **A completed `a=t`, `a=T` or `a=f`, and an `a=p`, are answered
  `i=<id>;OK`** unless `q=` quiets them, as in kitty. The quiet level is the
  opening chunk's. Before this only `a=q` was answered. So Hibr 0.99.376's
  probe for edits (two OKs for i=4202) failed on Blit, and X Screen fell
  back to whole pictures.
- **`kitty_frame_edit_gate`** replays Hibr's probe byte for byte from a
  raw-mode session: two `i=4202;OK`, in order, and silence for a `q=2`
  edit.
- **`kitty_placement_gate`**'s own `a=p` now carries `q=2`. Its OK reply,
  echoed by the gate's shell, had moved the cursor the gate measures.
- **Correction to 0.3.2:** `pane_effects_gate` did fail once more under
  suite load, at 5.17 ms of thread CPU time. Contention inflates CPU time
  too, so 0.3.2's claim that the gate no longer fails under load was
  overstated. The bound is now half a refresh (8.3 ms), the gate's stated
  requirement ("far under a refresh"). Measured alone the cost is about
  3 ms.
- **Suites:** full 153/154 (`pane_effects_gate` at 5.17 ms, before the
  bound change), then `pane_effects_gate` passed 3/3 under eight busy loops
  with the new bound. GLES 67/67.

## 2026-10-29: 0.3.2 Kitty edits redraw only what changed; two load-proof gates

- **A Kitty `a=f` edit damages only the cells its rectangle lands on**
  (ADR 0200). The GPU compositor refreshes only that rectangle of the
  image's texture, using a short edit history on the image, and
  `image_partial_uploads` counts it. Hibr's X Screen saves render work as
  well as bytes.
- **`kitty_frame_edit_gate`:** an 8×8 edit of a 64×64 image damages 1×1
  cell (it was 8×4), and on GLES the partial-upload counter rises.
- **`pane_effects_gate` no longer fails under load.** The CPU effects cost
  was measured on the wall clock, which counted preemption as cost. It is
  now the thread's CPU time, which is what the figure is documented as.
- **`mouse_report_gate` no longer fails under load.** The 1016 sweep was
  allowed 20 reports however long its 40 injections took. It is now held
  to the frames the sweep actually spanned, which is the rule it tests.
- **Both checked under eight busy loops** (load average 8.6 on 4 cores):
  3 of 3 pass each. Before, the sweep sent 30–31 reports there and failed.
- **`presentation_effects_gate` race fixed.** It found the glowing line's
  band in one screenshot and read the pixels of a later one, where the band
  had moved, which failed once in the first GLES run ("light below the
  leading edge"). The band and its pixels now come from the same
  screenshot: 3 of 3 pass on GLES, and it passes on the CPU path.
- **Suites:** full 154/154, GLES 67/67.

## 2026-10-29: 0.3.1 Kitty images change in place (ADR 0200)

- **`a=f,r=1` edits a rectangle of an image already shown** (chunked,
  `o=z`, RGB or RGBA blending by alpha, `X=1` overwrites). It lands when
  its last chunk arrives. This is for Hibr's X Screen, which can now send
  only changed rectangles (hibr #404).
- **`a=t`/`a=T` with a complete image's id replaces its pixels** and keeps
  its placements. It used to be refused, and the refusal dropped the image.
- **`kitty_frame_edit_gate` (new):** exact pixels for each case, the screen
  showing each change, and three refusals that leave the image intact.
- **Suites:** full 154/154, GLES 67/67 (the new gate runs in both).

## 2026-10-28: 0.3.0, the start of the 0.3 series: large, two-column phone icons (ADR 0196, 0197)

- **0.3.0 opens the 0.3 series.** The owner called Blit stable and very
  usable. 0.2 built native KMS, the glyph stack and discovered fonts, the
  Blit icons, and pointer lock. 0.3 continues with point releases.

- **Each phone icon, in both styles and all four states, now also comes as
  a two-column badge:** a left/right pair at U+100023–100032, drawn from
  the same SVG as the one-column icon. longwire's Phone Icon Size picks
  Small (the default) or Large, and Hibr maps the pairs as GL[phoneoff2]
  and so on.
- **Gates:**
  - `custom_icon_gate` covers 49 originals, and no large half repeats
    another.
  - `custom_icon_api_gate` sends the whole range through a PTY, one column
    each, on a 64-column surface.
  - `font_kms_raster_gate` covers the first and last pairs.
- **Rendered** through Blit at 22 px, small and large side by side: each
  large phone is whole and seamless.
- **Suites** (built as 0.2.48, released as 0.3.0 with no code change):
  font 38/38, full 153/153, GLES 66/66.

## 2026-10-28: 0.2.47 the classic telephone icons redrawn (ADR 0196)

- **The owner saw the classic icons broken.** The ringing one's waves
  reached past its view box, so its ink was wider than one icon, and the
  renderer drew it as half of a two-column badge. The other three were too
  fine for 10 px.
- **Redrawn:** thicker lines, a bigger dial, ring marks beside the base,
  and dashes cut evenly along the outline (outer and inset matched point for
  point). The new `tools/fonts/draw-phone-icons.py` draws both sets,
  reproduces the modern set byte for byte, and refuses an icon whose ink is
  wider than its view box.
- **Checked** through Blit at 22 px with JetBrains Mono NL, and at 16 and
  10 px.
- **Suites:** font 38/38, full 153/153, GLES 66/66.

## 2026-10-28: 0.2.46 pointer-lock refusals are counted (ADR 0198)

- **Each session's `mouse_reporting.pointer_lock_refusals`** counts the lock
  requests Blit refused because the session lacked focus or had ended. On
  the owner's machine the lock never engaged, and nothing showed whether
  Hibr had asked or on which session. Hibr had asked on a display it had
  only moved across (fixed in Hibr 0.99.368).
- **`pointer_lock_gate`:** an unfocused request is counted once; an
  engaged session counts none.
- **Suites:** full 153/153, GLES 66/66.

## 2026-10-27: 0.2.45 classic telephone icons (ADR 0196)

- **`phone-classic-off`, `-wait`, `-on` and `-ring`, at U+10001F–100022:**
  a rotary desk phone in longwire's four line states, beside the modern
  handset. The owner chose both, and longwire's Phone Style setting picks
  one.
- **Gates:** `custom_icon_gate` covers 33 originals, each style's four
  states being distinct rasters. The PTY and KMS gates cover the new range.
- **Suites:**
  - font 38/38 and GLES 66/66.
  - Full 152/153: `pane_effects_gate` again went over its 5 ms CPU bound
    under suite load (5.63 ms), and passed 3 of 3 alone. Icons don't touch
    the effects pass.
  - That bound now fails in most full runs on the build host. Making it
    load-independent is open work.

## 2026-10-27: 0.2.44 telephone icons for longwire (ADR 0196)

- **`phone-off`, `phone-wait`, `phone-on` and `phone-ring`, at
  U+10001B–10001E:** colour, one column, for longwire's line state: off,
  connecting, on, and an incoming call. Hibr maps them as GL[phoneoff],
  GL[phonewait], GL[phoneon] and GL[phonering].
- **Gates:** `custom_icon_gate` now covers 29 originals, and the four phone
  states are distinct rasters. `custom_icon_api_gate` and
  `font_kms_raster_gate` cover the new range.
- **Suites:** font 38/38, full 153/153 (the Hibr adapter gates included,
  against v0.99.225), GLES 66/66.

## 2026-10-27: 0.2.43 pixel fonts on the glyph stack (ADR 0199)

- **Blit Terminus 16 and Blit Spleen 16** keep every glyph they have, in
  their own pixels, and take icons, symbols and emoji from the glyph stack,
  fitted to their own H. Wide characters stay with the wide pixel font.
  Only a character no face has shows `?`.
- **`pixel_font_stack_gate` (new),** both fonts at 57 sizes: own glyphs
  declined, borrowed glyphs drawn, wide characters in pixels, a missing
  one declined. Of Hibr's 101 UI glyphs, 74 are each font's own and 27
  come from the stack.
- **Suites:**
  - font 38/38 and GLES 66/66.
  - Full 148/149: `pane_effects_gate` went over its 5 ms CPU effects bound
    (5.45 ms) under suite load. Alone, five runs each: 0.2.43 took
    3.0–3.4 ms and 0.2.42 took 3.3–4.1 ms, so it is not a regression.
  - The four Hibr adapter gates skipped after the build host rebooted,
    because their Hibr checkout was gone. Run against v0.99.225, all pass.

## 2026-10-27: 0.2.42 pointer lock, mode ?7701 (ADR 0198, #139)

- **A focused program can hold the pointer** and read raw mouse counts as
  `CSI < b ; dx ; dy M`, for Boxer's mouse-turning games. The protocol was
  agreed with Hibr (#379) and Boxer (hibr-boxer #1).
- **Released** by the program, on focus moving, the program ending, RIS or
  a soft reset, and when the program leaves input unread for two seconds.
  Blit tells the program each time it takes the lock back itself. There is
  no Blit key: the desktop's Release Pointer shortcut is the one key.
- **`pointer_relative` injection** now moves the pointer with no mouse
  attached, as absolute injection does.
- **`pointer_lock_gate` (new):** query, refusal, a still and hidden
  pointer, exact raw sums, coalescing, buttons, focus-loss release with the
  notice, a silent program release, and a stuck program released.
- **Suites:** full 151/152 at first. `network_auth_gate` failed because
  the two new diagnostics counters weren't listed as required in the
  schema; that is fixed, and it and `api_schema_gate` pass. GLES 66/66,
  including `mouse_report_gate` and the new gate.

## 2026-10-27: 0.2.41 the power icon; the hui badge at 80% of the cell

- **`power` U+10001A:** the power symbol, colour, one column, for Hibr's
  Power item on machines with no battery (ADR 0196).
- **The hui badge** is 80% of the cell's height (18 px at 22 px, was 21),
  centred on the text's cap band and kept inside the cell, as the owner
  chose from a side-by-side render (ADR 0197).
- **Gates:** `custom_icon_gate` covers 25 originals, the seam on visible
  ink, and the badge's full height (not clipped). A 2 px shift of a half
  still fails it, and so does a 2 px vertical shift. The seam test compares
  rows, not pixel values: the two edge columns are neighbours and may
  differ. The first version failed in JetBrains Mono NL at 12 px for that
  reason.
- **Suites:** font 37/37; full 150/151 before that seam-test fix (only
  `custom_icon_gate`), which passes alone and in the font suite after it.
  GLES 64/65: `mouse_report_gate` fails under this build machine's load
  (load average 6–9 on 4 cores). The 0.2.40 build fails it the same way
  (31–32 motion reports in a 40-sample sweep), and it passed at 0.2.39 and
  0.2.40 when the machine was quieter. Not a regression.

## 2026-10-27: 0.2.40 the hui badge, an icon two columns wide (ADR 0197)

- **hui-left U+100018 and hui-right U+100019:** the letters "hui" in a teal
  ring, written side by side, each one column and each drawing its half of
  one badge. No width table changes.
- **Raster:** a Blit icon wider than one icon is fitted across its span,
  95% of the square, and each cell keeps its slice.
- **Gates:** `custom_icon_gate` checks the seam (same inked rows, the ring
  equally far either side) at 57 sizes in every font, and fails on a 2 px
  shift. `custom_icon_api_gate` covers the PTY path.
- **Hibr side (pending):** the blit glyph set, and Pen or hui in the Menu
  Bar control panel.

## 2026-10-27: 0.2.39 children see BLIT_VERSION (ADR 0196)

- **Every session child gets `BLIT_VERSION`,** so Hibr's desktop, which
  keeps no Blit URL or token, can use the 0.2.38 icons on 0.2.38 or later
  and its bars below that.
- **`child_environment_gate` (new, terminal suite):** the child's value
  equals `GET /v1/version`.

## 2026-10-27: 0.2.38 battery and volume icons, one per state (ADR 0196)

- **15 new colour icons** in Blit's icon font, with codepoints agreed with
  Hibr: battery 0–4 (U+100009–10000D), charging 0–4 (U+10000E–100012), on
  mains (U+100013), volume muted and 1–3 (U+100014–100017). The bolt and the
  plug are inside the battery, so one glyph says the whole state.
- **Gates:** `custom_icon_gate` covers 22 originals in every font at 57
  sizes, each level a distinct raster; `custom_icon_api_gate` covers the PTY
  path, one column each, with API parity; `font_kms_raster_gate` covers the
  new range.
- **Suites:** font 37/37, full 150/150, GLES 64/65. The GLES miss was
  `mouse_report_gate` (21 motion reports in a 40-sample sweep, against one a
  frame), which passed twice on rerun. That is a timing flake in code this
  release does not touch.
- **Hibr side (pending):** its Blit glyph set maps battery and volume to
  these, and its menu bar draws one glyph per state.

## 2026-10-27: 0.2.37 Iosevka Term dropped (ADR 0195, as built)

- **Five text fonts ship:** Hack, IBM 3270, JetBrains Mono NL, Fira Code and
  IBM Plex Mono. Iosevka Term was 11.6 MB, about 40% of the package; the
  stack already covers its glyphs and the fixed cell cancels its
  narrowness. Copied into `/usr/local/lib/blit/fonts/text`, it is
  discovered as before.
- **`package_artifact_gate`** now refuses it as a retired file.

## 2026-10-27: 0.2.36 text fonts are discovered; every glyph from one stack (ADR 0195)

- **Six unmodified upstream text fonts ship in `text/`:** Hack 3.003,
  IBM 3270 3.0.1, JetBrains Mono NL 2.304, Fira Code 6.2, IBM Plex Mono 1.1.0
  and Iosevka Term 34.9.1. Any regular monospaced TTF or OTF in a `text/`
  directory is listed by its family name.
- **The glyph stack:** geometry (now including box drawing), Blit's icon
  font, the text font, Nerd Symbols, Noto Symbols 2 / Symbols / Math,
  emoji, one Arabic companion, and Unifont 16. Glyphs are fitted at draw
  time; an overhanging text glyph is shrunk, not dropped.
- **Retired:** the baked Modern, Retro and JetBrainless fonts, their
  generator, and Arabic Retro.
- **Gates:**
  - `outline_catalogue_gate`: 10,386 Nerd codepoints × 57 sizes × 6 fonts,
    0 failures.
  - `custom_icon_gate`: UI glyphs, Blit icons, scripts and ⟶, in every font.
  - `font_discovery_gate` (new): shipped, local, rejected and live removal.
  - `font_assets_gate` (replaces `modern_font_assets_gate`).
  - `font_raster_gate`: box drawing is geometry.
- **Cost on the build machine:** raster open 0.3 → 1.6 ms; first
  icon/symbol render 13 → 19 µs; fallbacks in the sample 12 → 0.
- **Not yet:** the two pixel fonts are not on the stack.

## 2026-10-27: 0.2.35 Blit JetBrainless; the font set is Blit's own (ADR 0194)

- **New font:** `blit-jetbrainless`, JetBrains Mono 2.304 without
  ligatures (OFL, no Reserved Font Name), built by the outline generator
  with the full Nerd catalogue, Blit's icons and 1,535 Noto symbols. It is
  reproducible (`4e95abbf…`), and Modern and Retro still rebuild to their
  shipped hashes. Its cells match Modern's: 11×22 at 22 px, 8×16 at 16 px.
- **Renamed:** `blit-terminus16` and `blit-spleen16`, with their files, and
  `Blit-Unifont16.psf`.
- **Removed:** the six console profiles; `Uni2-Terminus16.psf`, whose
  regeneration now reads Debian's identical copy, pinned by hash; the stale
  `Lat15` from the build bundle; and the unused Hack copy. The emoji audit's
  negative fixture is now Blit Modern.
- **Gates:**
  - `package_artifact_gate` fails if a retired file ships.
  - `font_api_gate` and `settings_persistence_gate` now read the
    repository's fonts; they had relied on the console fonts being installed
    on the build machine.
  - Font suite: 36 pass.
  - Full suite: 148 pass, and the one failure, `settings_persistence`, was
    that reliance; it passes after the fix.
  - GPU suite: 64 pass, and its one failure was the same gate.

## 2026-10-27: 0.2.34 touchpad drag and typing (ADR 0193)

The owner, on an HP Chromebook running Blit from hibr-apt, couldn't tap to
drag a window, or hold the pad with one finger and move with another.
- **A pressed pad follows the finger that moves,** read from the multitouch
  slots, and a pressed pad never scrolls.
- **Tap-and-drag,** on by default with tapping, with a deadline release on
  the loop's wait.
- **Disable-while-typing,** on by default: 500 ms after each key typed,
  modifiers excepted.
- Both new settings are per touchpad, and the Blit Mouse pane gains their
  rows (panel 0.1.18).
- Devices report a `multitouch` capability.

Gates:
- `touchpad_gate` gains the pressed drag, with and without slots; tap-and-
  drag (hold, drag, deadline, double click, late loop, pad press, off); and
  typing.
- `tap_setting_gate` covers both settings.
- The panel's `blit_mouse_gate` checks the rows.
- Full suite: 149 pass. GPU suite: 65 pass.

The mini PC (192.168.10.54) has no touchpad, so acceptance waits for the
owner's HP.

**Measured after hibr 0.99.352 (with 0.2.33):** hold went from 64% to 10% of
a core, and Blit from 4,103 to 35,440 bytes per read, so the transport is
idle. The video still arrives at about 8 frames a second, so the rate is
set upstream, in the browser's page capture. Hibr and the browser session
are following that up.

## 2026-10-26: 0.2.33 video ingest; animation fills gaps only

The owner reported slow YouTube and window moves after turning on the
effects. Measured live, the video reached Blit at about 8 frames a second
whatever the effects, so the effects were not the cause.
- **ADR 0192:** Blit read about 4 KiB of a session's output per loop pass,
  4,103 bytes per read live. It now fills its 64 KiB buffer from what is
  queued. `terminal_ingest_gate` (new) passes at 42,597 bytes per read and
  fails on 0.2.32 at 4,088.
- **Hibr's side:** hold parsed each frame byte by byte, about 150 ms a
  frame. Fixed in Hibr 0.99.352.
- **ADR 0188, amended:** animation ticks fill gaps only. Live, they had
  tripled the presents during video and raised late flips from under 1 a
  second to 4 or 5. `presentation_effects_gate` gains `fills_gaps_only`.
- **Still to come:** the live re-measure once both releases are on the
  owner's machine.

## 2026-10-26: 0.2.32 flicker, horizontal sync and jitter; Braille, blocks and symbols

- **ADR 0191, second half:**
  - Block Elements are cell geometry, so Claude Code's ▐▛███▜▌ logo draws.
  - Both outline profiles gain the symbol blocks they lacked, from pinned
    Noto sources: 1,418 codepoints in Modern, 1,336 in Retro, with no
    existing glyph changed. That covers ⏺ ⎿ ⏵ ✻ ✶ ✳ ✢ ✓ ✗ ⚠ ⋮ ⧉ ※ ⌘ ⌥.
  - The font suite passes (36 gates).

- **ADR 0191, first half: Braille is cell geometry.** btop's graphs showed
  `?`. It sends real Braille, and Blit Modern Nerd has none of the 256. Dots
  are now drawn on the cell grid: 2×4, round, never touching.
  `braille_gate` (new, both compositors, 22 and 16 px) checks 64 dot
  centres against their bits and the gaps between dots. The 0.2.30 binary
  fails it at the first dot.

ADR 0190, the owner's "implement the real ones", read from cool-retro-term's
`terminal_dynamic` shaders: flicker, horizontal sync and jitter.
- Animated presentation effects on ADR 0188's clock, with each frame's
  randomness from its number.
- A pane with sync or jitter has its corners drawn by the presentation pass,
  so they stay still.

Gates:
- `presentation_effects_gate` (gles):
  - flicker is one brightness per frame across the pane, within ±50%, and
    varies;
  - horizontal sync sways some frames and leaves others plain, with the
    corners still;
  - jitter shimmers stripe edges while the mean holds;
  - the noise is deterministic per frame (a C probe).
- `terminal_conformance` expects the nine effects and their classes.
- `pane_effects_gate` (native) trips only its CPU budget at load around 6,
  as the 0.2.30 binary does at the same load.

## 2026-10-26: 0.2.31 glowing line; session output capture; a base64 fix

- **ADR 0188, the glowing line:** the first animated effect, and the frame
  clock behind it.
  - The clock ticks an output only while an animated effect is drawable on
    it and the display is presenting, at `server.effects_animation_hz`
    (10–30, default 30).
  - A tick re-presents through a KMS animation request; it never recomposes.

- `POST/GET/DELETE /v1/terminal-sessions/{id}/output-capture`: a bounded,
  explicitly armed capture of a session's raw PTY output (at most 120 s and
  2 MiB, base64, with timed reads). It was asked for by the Hibr session, to
  see the bytes behind the face-coloured fill that p1 gets when the desktop
  restarts.
- **`base64_encode` padded by the read index, not the group size.** A full
  last group lost its final character, and a single trailing byte got one
  `=` too few. Its only caller until now, the 20-byte WebSocket accept key,
  ends in two bytes, the one case it got right.

Gates:
- `presentation_effects_gate`, the glowing line (gles):
  - the band is one run, about a third of the pane, rising to a leading
    edge that adds up to 51, with nothing below it; it moves down;
  - 30 Hz ticks, with `drawn_cells` 0 and no glow rebuilds;
  - the rate setting (60 refused, 10 Hz honoured);
  - an idle screen presents nothing with the line at 0, its pane switched
    off, or the master switch off.
  On native, a saved line is reported unavailable and costs no frames.
- **The full suites found one real bug.** The per-output diagnostics, longer
  now with the effects fields, overflowed their fixed 4 KB buffer at three
  displays, cutting the JSON mid-entry (`display_layout_gate` and
  `kms_hotplug_gate` failed to parse it). The buffer is now sized for every
  output Blit can have. The other failures were the machine's load (around
  9): `sync_output`, `terminal_conformance`, `mouse_report`, `frame_rate`
  and `terminal_soak` fail the same way with the shipped 0.2.30 binary at
  that load.
- The hum bar ("Hum bar", the owner's name; key `glowing_line`).
- `output_capture_gate` (new): the exact bytes in order, timed reads,
  truncation at `max_bytes`, `DELETE` frees, 400 and 404 refusals.
- The WebSocket gates `stream_replay`, `input_stream_text`,
  `audio_device_api` and `pixel_frame` pass with the corrected encoder.

## 2026-10-26: 0.2.30 settings saves off the main loop; RGB shift

- **ADR 0189.** The owner's 11:23 restart on 0.2.28 was the console
  watchdog. Its report names the main thread in `fsync` (syscall 74), in
  `folio_wait_bit_common`, for 9,070 ms in "input, sessions and API". A
  settings save fsync'd on the main loop during an `apt-get upgrade`.
  - Saves now run on a writer thread. `PUT` and `DELETE /v1/settings` are
    held until their change is durable, then answered with the same receipt.
  - The 0.2.29 font round-trip fix stands as a separate real bug; it was not
    this restart.
- **ADR 0187 addendum: RGB shift**, with an effect `title` column in the
  registry and API.
- **The font cell-fit check** runs before the unchanged-font no-op.

Gates:
- `settings_writer_gate` (new), every save delayed 3 s:
  - the PUT is answered when durable, with a clean receipt;
  - `GET /v1/version` within 34 ms throughout;
  - 122 presents during the save;
  - storage `pending` with the old saved revision;
  - overlapping PUTs both answered;
  - `DELETE` resets after the removal;
  - a failing write answers 503 and recovers.
- `presentation_effects_gate` adds an exact RGB shift case (striped pane,
  2 px samples, more than 1,000 fringed pixels).
- The settings, login, font, display, pointer and effects gates pass.
  `pane_effects_gate`'s CPU-cost budget trips only under the machine's load
  (about 7) and passes when rerun.

## 2026-10-26: 0.2.29 settings writes no longer reflow the panes

Found while tracing the owner's report that Blit restarted once while they
changed curvature on 0.2.28.
- **The bug:** every `PUT /v1/settings` reset to the boot font, then
  re-applied the saved one. Each write was two real font changes: every
  pane's PTY resized to the boot font's grid and back, every Hibr desktop
  repainted twice, and the glyph atlas was rebuilt twice. The live Blit
  Effects pane writes the settings on every slider release.
- On the owner's Radeon a font change is the #146 stall, which the console
  watchdog kills. That is the suspected cause of the restart; the journal is
  asked for to confirm it.
- **The fix:**
  - `settings_reset` no longer installs the boot font.
  - `settings_apply_font` installs, in one step, the document's font, or the
    boot font when the document names none, or names one that is unavailable
    or does not fit.
  - `apply_font_configuration` does nothing when that is already the active
    font.
  - `DELETE /v1/settings` installs the boot font through the same path.
- **Also:**
  - A pane's glow copy is rebuilt only when that pane was redrawn. On the
    owner's display it had been rebuilt on more than half of all frames,
    because a change in either pane rebuilt both.
  - The pointer path reads an output's presentation availability without
    copying its display info.

Gates:
- `presentation_effects_gate` (both compositors): with a saved
  `blit-modern` profile, ten effects writes leave the grid, the font and
  every session's geometry unchanged. The shipped 0.2.28 fails this,
  passing the panes through `12 80` and back to `9 64`. Also, two seconds
  of drawing in pane 2 rebuild nothing for pane 1's glow.
- `settings_persistence_gate`: `DELETE` restores the active boot font, not
  only the document.
- `display_settings`, `font_api`, `font_identity`, `login_policy`,
  `pointer_appearance` and `settings_persistence` pass.
- A 60 s soak on gles, 153 live effects writes with curvature and glow
  flipping and both panes drawing: no failure, worst write 0.26 s, still on
  the GPU.

## 2026-10-26: 0.2.28 curvature, glow and effect switches

ADR 0187 (proposed; accepted once its GPU cost is measured on the owner's
Radeon), the owner's request to continue the effects:
- **Presentation effects,** drawn by the GLES compositor as it presents each
  frame, with a second program used only over panes that have them:
  - Curvature: one registry warp, shared by the shader and pointer input.
  - Glow: a per-pane blurred copy, halved twice, softened with nine taps.
  - On a curved pane, scanlines are drawn on the glass.
  - On the CPU compositor, or without highp, they are kept and reported
    unavailable per pane.
- **Switches,** at the owner's request: `effects.enabled` and a pane's own
  `enabled`. Off keeps the values and takes exactly the no-effects path.
- `GET /v1/effects` reports each effect's class, both switches, and what is
  unavailable. Diagnostics report `present_panes`, `glow_rebuilds` and
  `presentation_unavailable`.

Gates:
- `presentation_effects_gate` (new), on gles:
  - 11,813 warped pixels predicted exactly from a plain capture;
  - glass scanlines drawn once;
  - glow bounded to its pane;
  - pane isolation;
  - SGR mouse reports through the warp;
  - the untouched plain path.
  On both compositors: the switches. On native: CPU unavailability.
- `pane_effects_gate` unchanged and passing on both compositors.
- `terminal_conformance` expects the four effects, their classes and the
  master switch.
- Suites: the native and gles suites ran under a sustained load of about 5.5
  from other sessions.
  - `terminal_conformance`'s failure was the stale expectation above.
  - `pane_effects_gate`'s CPU budget passed on a rerun.
  - `mouse_report_gate` (gles) and `hibr_split_capture_gate` fail the same
    way with the shipped 0.2.27 binary, so they are not this change.
  - `frame_rate_gate` and `terminal_soak_gate` are the known software-GL
    flakes.

## 2026-10-25: 0.2.27 pane effects: rounded corners and scanlines, per pane

ADR 0186, the owner's request for per-pane effects starting with rounded
corners.
- Effects are set per pane in the settings document's `effects`, keyed by
  connector and pane ordinal, applied live and saved. `GET /v1/effects` reports
  them, read-only.
- One registry in `src/blit_effects.h` holds the effects, their bounds and
  their order, and the pixel rule both compositors use.
- Both compositors apply a pane's effects over exactly the rectangle they
  repainted. Effects are idempotent under damage, and the GPU keeps composing
  with them on; the CPU fallback "a display effect is on" is gone.
- The old global scanlines effect (`PUT /v1/effects`) is removed; scanlines are
  now a per-pane effect.
- Each output's render diagnostics report the effects' cost.

Also carries 0.2.26 (the console watchdog's report of where the loop was
stuck), which was not deployed on its own.

Gates:
- `pane_effects_gate` (new), on both compositors: placement, 7,680 pixels
  against the shared rule (exact on the CPU, within 1 on the GPU), no change
  under repeated damage, the GPU composing, cost reported, strict settings,
  read-only endpoint, clamping, and persistence.
- `kms_compose_gate`'s held-frame test carries a pane scanline effect.
  `terminal_conformance` checks the read-only endpoint.
- Native suite: all pass after a typo fix in `terminal_conformance`; the
  terminal suite reran clean on both compositors.
- `BLIT_GATE_BACKEND=gles`: all pass except `terminal_soak_gate`, the known
  software-GL RSS ceiling.

## 2026-10-25: 0.2.26 the console watchdog says where the loop was stuck

Issue #146. On the host, a font-size change from 21 to 22 px twice stalled
the main loop for more than 10 s on the GLES compositor. The console
watchdog SIGKILLed Blit each time. The journal said only "console watchdog
expired". The kernel log was clean, and the stall did not reproduce
locally.

Before it kills, the watchdog now logs:
- the main-loop step the server last named (`blit_vt_phase`), and for how
  long;
- `comm`, `wchan`, `syscall` and the kernel `stack` of every server thread.

The step lives in a page the server shares with the recovery process.
Steps are named for select, KMS flip events, settings flush,
input/sessions/API, and render compose and present.

Gates:
- `vt_watchdog_report_gate` (new): a live process stands in for the stuck
  server; the report names its step and both of its threads with `wchan`.
  As root, `syscall` and `stack` are reported too (checked by hand).
- The native suite.

## 2026-10-25: 0.2.25 an orderly stop is not a GLES crash

The GLES start guard (ADR 0181) leaves `<settings>.gles-starting` until a
GLES start has been healthy for 30 s. It never removed the marker on an
orderly exit. So any update, restart or stop inside those 30 s made the
next start treat GLES as crashed and use the CPU. On the host this
happened today after back-to-back restarts: the Blit panel showed
"Software (CPU); GPU unavailable" with nothing wrong with the GPU.

Every exit path converges at the end of `main`. After the outputs are torn
down, an active guard now removes its marker there. A crash, which never
reaches that point, still leaves the marker and is still skipped once.

Gates:
- `gles_compositor_gate`: a GLES start stopped by SIGTERM inside the hold
  leaves no marker, and the next start runs GLES. Without the fix it fails
  with "an orderly stop left the guard marker".
- The native suite.

## 2026-10-25: 0.2.24 a sign-in at Blit's login screen resumes the desktop without its saver

Issue #145. The owner logged in and was shown Hibr's screen saver on the primary. Hibr's
desktop outlives a Blit restart. Its idle clock ran out while the login
screen was up, and the resume did not say a password had just been given.

Hibr's own `login/start.hibr` exports `HIBR_SIGNEDIN=1` before
`session.hibr --resume`. `dt_autohold` (Hibr 0.99.326) then sends the
desktop `signedin`, which stops the saver, drops the lock and restarts the
idle clock. Blit's login hook (`hibr/blit-login-session.hibr`) replaces
`start.hibr` and did not export it; it now does, for the desktop only.

The host runs Hibr 0.99.341.

Gates:
- `login_identity_gate`:
  - the fake desktop now reports the `HIBR_SIGNEDIN` it receives: `1` for
    a desktop, absent for a shell;
  - without the fix it fails with `0:absent:65534:absent`.
- The auxiliary policy, auxiliary native and login desktop observer gates
  pass, as does the native suite.

## 2026-10-25: 0.2.23 symbols centred in their cell

ADR 0185, the owner's report that window buttons and icons looked clipped
on the right with Modern.
- The shared raster centres each outline glyph's unrounded advance at 26.6
  precision; it used to centre `ceil(advance)`, which put all the slack on
  the right. Blank glyphs skip the clip check.
- The font generator gives the Geometric Shapes block (not its corner
  triangles) the icon fit. Modern and Retro are rebuilt from the pinned
  sources, so only those glyphs change.

Blit's raster at 16x32 and 11x22: `●`, U+F015 and `M` have equal left and
right edge columns.

Gates:
- native suite: 142 pass.
- `BLIT_GATE_BACKEND=gles`: 140 pass, 2 fail, neither caused by this change.
  - `terminal_soak_gate`: the known software-GL RSS ceiling.
  - `frame_rate_gate`: the full-scene render is around its 20 ms budget on
    software GL. Over three alternating runs, it failed twice on 0.2.23
    and twice on 0.2.22.
- The first run failed `outline_catalogue_gate` (`cod-blank` at large
  sizes) and `arabic_raster_gate` (the space), which led to the blank-glyph
  rule; both pass now.

## 2026-10-25: 0.2.22 SDL removed; native KMS is the only presentation path

ADR 0184, the owner's decision. Removed:
- the SDL renderer and compose pass, SDL display discovery, SDL screenshots,
  SDL mouse events and the KMSDRM policy;
- the presentation trial (API route, update-helper commands, recovery);
- `server.renderer`, `BLIT_RENDERER`, and the SDL-only diagnostics fields;
- `libSDL3` from the package, and `vendor/SDL3`.

`display_backend` accepts only `kms`. Display rotation, which only SDL could
draw, is refused (422). blit_server.c is about 4,000 lines shorter.

Gates:
- native suite: all pass after the SDL-only gates were retired and the rest
  ported to the DRM mock;
- `BLIT_GATE_BACKEND=gles`: 140 pass, 2 fail. `hibr_split_capture_gate` (one
  missed deadline at a 31 ms software-GL render) and `terminal_soak_gate`
  (RSS 131,952 KiB against a 131,072 KiB ceiling) fail the same way on the
  pre-removal build (32.7 ms; 132,580 KiB), so they are software-GL limits,
  not regressions.

Also carries 0.2.21 (immediate frame timing by default), which was not
deployed on its own.

## 2026-10-25: 0.2.21 immediate is the default; late flips from the vblank counter

Host A/B on 0.2.20 (owner dragging): late 36 fps with 31 "late" flips at the
capped 8.3 ms lead; immediate preferred by the owner. Most "late" flips were
false: the driver stamps a flip event with the new frame's scanout start,
after the vblank began, and the classifier compared that time with one
period. A flip is now late when it completes two or more vblanks after the
CRTC's vblank number read right after submission (`drmCrtcGetSequence`; time
fallback 1.5 periods). Immediate is the default; late is opt-in (ADR 0183).
The host keeps its saved `kms_frame_timing: immediate`.

## 2026-10-25: 0.2.20 late compose (server.kms_frame_timing)

The owner found drags fast but jumpy. On the host a frame was composed as
soon as the previous flip completed -- right after a vblank -- and waited
~15.7 ms to be shown. Native KMS now composes each output's frame a lead
before its next vblank, predicted from the kernel's vblank timestamps and
the mode's refresh (the measured rate refines it only within 2%). The lead
starts at 4 ms and adapts: +1 ms (to half a refresh) for a late flip or a
compose slot the loop was busy through, -0.25 ms (to 2 ms) per 240 flips on
time. An output asked to render at once (a capture) renders unaligned.
`server.kms_frame_timing` (`late` default, `immediate`) applies live.
`kms_frame_timing_gate` (new; the DRM mock gains a periodic-vblank mode)
switches one server live from late to immediate under continuous output:
locally flip wait 14.7 → 4–7 ms at the same frame rate, 0 late flips, an
invalid value refused. Two defects found on the way and gated: aligning
"now" chased the next slot forever (captures never rendered), and a vblank
count that is not a vblank count set a period of seconds. Native timing,
renderer, schema and terminal suites: 83 pass, 3 skip; GLES renderer suite
passes with the timing gate skipped there (it measures scheduling, which the
surfaceless software rasteriser's readback would dominate).

## 2026-10-25: 0.2.16–0.2.19 where the time goes; damage-limited GPU recompose

The owner found window drags slightly laggy and YouTube choppy on GLES.
0.2.16 adds GPU time per frame (`GL_EXT_disjoint_timer_query`), flip latency
for every output and per-frame quads/draw calls/uploads; 0.2.17 adds `GET
/v1/diagnostics/processes`. On the host during drag + video the GPU
compositor costs at most 2.9 ms CPU and 3.4 ms GPU for 17,052 cells with no
CPU fallbacks; video reaches Blit from WebKit → hibr-wpe → Hibr desktop
(44% of a core) → hold (22%) at ~13 fps with no saturated process (ADR 0182,
proposed; blit #141). 0.2.18 makes Kitty ingest cheaper (string bodies
copied in runs, table base64, json_escape runs): locally 33.7 → 11.0 ms of
CPU per MB of base64; on the host Blit went from 24–42% of a core at 20 MB/s
to 12% at 12 MB/s. A Kitty `t=s` prototype was withdrawn before release: it
contradicts ADR 0066. 0.2.19 recomposes only a changed view's damage on the
GPU, with draw_view's rules (ink widening, region clipping, cursor only
inside the region); `gles_compose_gate` adds four damage frames, Terminus
and the overhanging Modern/Arabic font, including a changed cell outside the
damage that both compositors must leave stale, and fails if the GPU
recomposes the whole view. Renderer, terminal and font suites on the GLES
backend: 111 pass, 1 skip; mouse_report_gate failed once on its
motion-report count under load and passes on rerun on gles and native.

## 2026-10-24: 0.2.15 scaled images on the GPU; sprite atlas follows the font

On the host (0.2.14, owner logged in), ~30% of frames were still CPU
composed with "an image is scaled": the wallpaper. The GPU now samples a
scaled image at s = source + d*k + 0.5/width texels (k = source/destination),
the same texel as the CPU's integer floor(d*k) at any ratio;
`gles_compose_gate` adds scaled RGB and RGBA images at 37x23, 9x41, 200x120
and 13x13 from 16x16 and 12x12, within 1 per channel. The owner reported
title-bar buttons clipped on the right by a few pixels; not reproduced (the
screen was locked): the brackets-style buttons fit their cells in Modern,
and GPU equals CPU for that exact bar against a view's right edge (new
scene). One GPU-only way to get it was closed regardless: the sprite atlas
is now emptied whenever the font's path, cell size, raster or data change,
since a replacement raster can reuse the old one's address. Renderer,
terminal and font suites: gles 112 pass, native 112 pass.

## 2026-10-24: 0.2.14 title-bar corner glyphs U+100007/U+100008 (#140)

For hibr 0.99.316's `bar` frame (Charcoal): two Blit originals, a cell
filled except a quarter-circle cut at its top-left (U+100007) or top-right
(U+100008), radius the cell's shorter side; rounded top corners only, the
bottom square where the bar meets the window. They are cell geometry drawn
by the shared raster, as Powerline separators are, so they fill the cell
edge to edge at every size with no seam against the bar's other cells; no
outline font binary changed. The catalogue's new `cell_geometry` section
lists them (served by `GET /v1/fonts/icons`), its pinned hash is updated,
and `docs/fonts/special.md` is regenerated with fontTools 4.60.1.

`bar_corner_gate`: 57 sizes x 2 profiles, the corner pixel empty, solid
below the arc and along the inner edge (the arc's last top-row pixel is at
least 247/255), exact mirrors, antialiased arc, cached. The KMS and SDL font
raster gates draw both through each compositor (KMS tolerance 0). Font suite
40 pass.

## 2026-10-24: 0.2.13 GPU composition with overhanging fonts

0.2.12 on the host (deployed) composed nothing on the GPU: every frame fell
back with "the font's ink overhangs its cell", because the host's Modern
11x22 font has the Arabic companion attached, which reports overhang.
0.2.13 sizes sprite margins from the font's reported overhang and redraws
glyphs whose ink enters a block cursor in the cursor colour, clipped to it,
as the CPU does. `gles_compose_gate` adds the host's font (Modern 11x22,
colour emoji, Arabic): Latin, bold, italic, a wide emoji, Arabic with a
mark, and a block cursor on overhanging ink. Max difference 2, on one
antialiased bold edge (CPU rounds bold's two strikes separately); the gate
allows 2 inside bold cells only, 1 elsewhere. Renderer, terminal and font
suites: gles 111 pass, native 111 pass.

Host, 0.2.13 (update helper, receipt `releases/0.2.13.yaml`), saved
`kms_compositor: gles`: both outputs `active: gles`, GPU-composed frames
rising, 0 CPU-composed frames. The API screenshot is now the GPU frame read
back before its swap; it shows the login screen and pointer correctly. Same
10 s probe at the login screen: 3.0% of one core (CPU compositor 8.4%,
0.2.11 upload path 10.9%), per-frame work median 0.45 ms with no copy, 0
missed deadlines. Not yet measured: an active desktop, window dragging and
video, which need the owner logged in (ADR 0181 cutover criteria).

## 2026-10-24: 0.2.12 the GPU composes views (ADR 0181 steps 3-4, first cut)

`src/blit_kms_gles.c` composes each output on the GPU in `draw_view`'s
order: default-background floor, under-background images, background runs,
under-text images, glyph sprites with underline and strike, over-text
images, cursor; then the persistent scene, overlays and pointer. Sprites are
rendered by the CPU's own `draw_cell_glyphs` (white over black and over
white), atlased in one 2048x2048 texture; images are textures keyed by image
and pixel generation. Frames with an effect, an overhanging font or a scaled
image fall back to CPU composition plus upload. `/v1/diagnostics` reports
`gpu_composed_frames`, `cpu_composed_frames` and `cpu_reason`.

`gles_compose_gate`: CPU `draw_view` and the GPU compositor agree within 1
per channel on five scenes (Terminus and the wide font; plain, colours,
explicit black, bold, italic, underline, strike, dim, reverse, box drawing,
a wide CJK cell, block/underline/bar cursors; RGB and RGBA images in all
three bands), max difference 1. Two bugs found on the way, both fixed: a new
texture was bound before queued quads were drawn (they sampled it), and the
start guard counted only uploaded frames, so a fully GPU-composed start
would never clear its marker.

`run-gates.sh all`: native 159 pass, 6 skip, 0 fail (after the guard fix);
gles 157 pass, 6 skip, 3 fail before the fix -- the guard gate, plus the two
llvmpipe timing gates (frame_rate 26.7 ms, was 33.9 with uploads).

## 2026-10-24: 0.2.11 GLES uploads changed rows from RAM

First host run of GLES (0.2.10 on 10.54, `server.kms_compositor: gles`):
both outputs `active: gles` on "AMD Radeon Graphics (radeonsi, rembrandt,
LLVM 19.1.7, DRM 3.61) | OpenGL ES 3.2 Mesa 25.0.7"; 577 frames drawn and
flipped on DP-1, 0 missed deadlines, the start guard cleared. But a 10 s
probe at the login screen measured 74.8% of one core against 8.4% on CPU,
and 69 ms per frame in the copy/upload phase against 0.7 ms: the frame was
uploaded from the scanout dumb buffer, whose write-combined mapping is very
slow for the CPU to read. The host was set back to `cpu`.

0.2.11 uploads from the compositor's RAM scene and only the rows that
changed since the last upload (a RAM shadow of it; the texture keeps the
rest). `gles_frame_gate` adds: an unchanged frame uploads 0 rows; changing
the first row, a middle band and the last row uploads exactly 5 and reads
back exact. `compositor.gles_uploaded_rows` reports the count. Renderer and
terminal suites: native 71 pass, gles 71 pass.

Host, 0.2.11 on GLES (deployed through the update helper, receipt
`releases/0.2.11.yaml`), same 10 s probe at the login screen: 10.9% of one
core (CPU compositor 8.4%, 0.2.10 GLES 74.8%), upload phase median 3.9 ms
(0.2.10: 69 ms), 0 missed deadlines, both outputs `active: gles`; DP-1
averaged ~200 uploaded rows a frame for the login animation. Step 2 is
still the CPU frame plus an upload, so it trails the CPU compositor
slightly, as expected; step 3 removes the CPU drawing of text.

## 2026-10-24: 0.2.10 GLES start guard; 0.2.9 deployed on CPU

0.2.9 installed on 10.54 through `tools/deploy/update-live.sh` (receipt
`releases/0.2.9.yaml`, sha256 11d8334b...); `/v1/version` 0.2.9, both
outputs (DP-1, HDMI-A-1) ready on the CPU compositor, login screen running.
GLES was not enabled: a crash in it would restart into the same saved setting
and lock the API out. 0.2.10 adds a start guard (marker beside the settings
document, cleared after 30 s of healthy GLES frames on every GLES output; a
marker found at start forces CPU for that run with the reason, then clears).
`gles_compositor_gate` covers both halves.

`run-gates.sh all` on 0.2.10: native 159 pass, 6 skip, 0 fail; gles 156 pass,
6 skip, 3 fail, all timing under llvmpipe plus per-frame readback (test mode
only): frame_rate (34 ms > 20 ms), hibr_split_capture (analyzer passes every
boundary but "presentation: missed deadlines: 1", 34.6 ms render), and
sync_output, which passed twice when rerun alone. No functional failure.

## 2026-10-24: 0.2.9 ADR 0181 step 2 -- GLES inside native KMS

`src/blit_gles.c` loads Mesa's EGL, GLESv2 and GBM at runtime (no link
dependency; `dlopen` is in glibc here) and draws one textured quad: GBM on
the KMS device for scanout, Mesa's surfaceless platform for tests. The
native backend draws each CPU-composed frame through it and flips the GBM
buffer, holding each buffer until the flip that replaces it completes. Any
EGL/GBM/context failure drops the output to CPU with the reason. Selected by
`document.server.kms_compositor` (`cpu` default, `gles`), which is what makes
it configurable on a host through the API; `/v1/diagnostics` reports each
output's compositor, renderer, reason and GLES frame count.

Evidence: `gles_frame_gate.c` reads a frame back byte for byte at 1024x768,
1920x2160 and a padded pitch on llvmpipe (Mesa 22.3.6) and softpipe (Mesa
26.2.3); swapping red/blue, flipping rows or adding linear filtering each
fail it. `gles_compositor_gate.rb` checks the surfaceless output on GLES,
GBM falling back to CPU with a reason under the DRM mock, and the setting
saved and applied. `BLIT_GATE_BACKEND=gles` runs every gate with frames
drawn by GLES and read back.

`run-gates.sh all`: native 159 pass, 6 skip, 0 fail; SDL 159 pass, 6 skip,
0 fail; gles 158 pass, 6 skip, 1 fail -- frame_rate_gate's 20 ms full-scene
budget, 33.9 ms there, because the gles test mode renders with llvmpipe (GL
on the CPU) and reads every frame back for screenshots. Neither happens on a
host GPU; recorded, the budget is not relaxed.

Not claimed: speed. Step 2 is the CPU frame plus an upload; it cannot be
faster than native CPU. The GBM path is exercised only on a host.

## 2026-10-24: ADR 0181 step 1 -- gates run on the native compositor

The DRM mock (`tools/tests/fixtures/drm_hotplug_mock.c`, LD_PRELOAD) runs the
whole server headless on native direct KMS once its buffer slots fit a real
output (6068ad5). `tools/tests/gate_server.rb` makes that the default display
for gates (`BLIT_GATE_BACKEND=native`; `sdl` keeps SDL's dummy driver until
cutover); `gate_bmp.rb` reads either backend's screenshot. 60 gates migrated
(1219a99). Most had never run against the compositor the host uses.

First native sweep, 18 failures, classified:

| class | gates | outcome |
|---|---|---|
| gate parsed SDL's 24-bit BMP | cell_paint, deferred_damage, display_settings, font_identity, kitty_placement, pointer_geometry, sync_output, wide_glyph, render_state_agreement, sixel_decoder | shared reader; pass |
| gate assumed SDL display naming | auxiliary_native, auxiliary_desktop | compare the connector; pass on both |
| tests SDL itself | display_settings (rotation), pointer_pixel (rotation), observation_api, backend_selection, presentation_provenance, pointer_damage_atomic, pointer_wallpaper_stress | pinned `backend: 'sdl'`; retire at cutover |
| **native bug** | cell_paint: italic drew as plain in 16 px cells | fixed, 3d57095 |
| **native bug** | sync_output: screenshot answered before its flip completed, never said presented | fixed, ac2254d |

Native has no rotation (refused by contract); SDL has. That is a feature gap
for the GLES compositor to close, not a gate to keep.

Result: native `run-gates.sh all` 158 pass, 6 skip, 0 fail; SDL 157 pass,
6 skip, 1 fail -- frame_rate_gate's 20 ms wall-clock budget, which misses
under host load equally on the pre-change and current binaries (A/B, 1 of 3
each).

Rest of step 1 (6b5e432). `sdl_test_profile.rb` and a new `gate_display.sh`
follow the same backend switch: 16 of 18 profile gates and 12 of 14 shell
gates run on native by default. Remaining on SDL, each by design:

| kind | gates | why |
|---|---|---|
| tests SDL itself (pinned, retire at cutover) | 7 server gates above; http_accept_budget, external_pointer_composition; sdl_graphics_cache, sdl_background_batch | SDL traces, caches, rotation, simulated SDL present |
| SDL half of a pair whose native half runs | font_backend_raster (kms mode), arabic_backend (kms mode), graphics_placement_damage (graphics_scene_native) | both halves in the suite |
| SDL-only C harnesses | sdl_kms_policy (2), sdl_output_startup, sdl_glyph_filter | SDL startup and filtering |
| canonical-state C harnesses | emoji_layout, rectangle_copy, surface_damage, presentation_trial_api, graphics_ingestion | test terminal/graphics state; leave SDL with `blit_server.c` |
| GLES suite | 13 gates | SDL's GL path, kept green until cutover |

Final: `run-gates.sh all` native 158 pass, 6 skip, 0 fail; with
`BLIT_GATE_BACKEND=sdl` 158 pass, 6 skip, 0 fail; `gles` 13 pass. The
headless oracle for the GLES compositor is in place.

## 2026-10-24: 0.2.8 pointer shapes and hiding the pointer, OSC 22 (#138, hibr #373)

Hibr's Boxer draws the game's own cursor and Blit drew its pointer on top, so
a game showed two arrows. Blit now implements kitty's OSC 22: set, reset,
push, pop and query, answered in the same pass as DA1, plus `none`, which
hides Blit's pointer. Eight new shapes come from the one vector source --
I-beam, busy, move, the four resizes and not-allowed -- with kitty's CSS names
and the X11 aliases mapped onto them; a name with no art answers `0` and shows
the display's own pointer. A request is honoured only while the pointer is
over its session's surface, and is given back on RIS, a soft reset and the
program exiting. Palette, size and shadow stay the settings API's;
`effective.pointer` is unchanged and `effective.pointer_shown` reports what is
drawn. Direct KMS now repaints fully only when an art change changes the
pointer's size; a same-size swap is incremental.

Evidence, local build on the dummy SDL backend:
- `pointer_shape_gate.rb` PASS: `query=1,1,0,0 hidden=pane_a_only
  text=exact push_pop=wait ris=restored exit=restored`, plus the pane edge
  and the API state. Against the 0.2.7 binary it fails at the first step:
  the query is never answered.
- `pointer_art_gate` covers all 11 shapes (antialias, hotspot, alpha);
  `kms_compose_gate` adds same-size shape swaps, every pixel exact.
- `run-gates.sh all` on the 0.2.8 binary: 158 pass, 6 skip (QEMU, package
  and live-host gates), 0 fail. `hibr_join_frame_barrier_gate` failed once in
  an earlier run; it is flaky on 0.2.7 too (1 of 2 runs failed there).

Not yet: published, run on hardware, or checked from hibr (`hold pointers`
should say `yes` for a Blit display; Boxer should show one arrow).

## 2026-10-23: 0.2.7 a login on a Blit display is a local session (hibr #367)

Hibr's login screen runs on Blit's pty, which tells PAM no seat and no VT, so
logind registered every login on a Blit display as a remote session with no
seat (`loginctl`: `Seat=`, `Remote=yes`, `Type=tty`). WirePlumber then drives
no Bluetooth audio for that user, so a connected headset never became a sound
output; NetworkManager's policy for an active session does not apply, so Wi-Fi
wanted root's password; logind's brightness and power need it too. Blit now
exports the VT it owns as `BLIT_VTNR` to the sessions it starts, and its login
wrapper passes `LG_SEAT=seat0` and `LG_VTNR` to Hibr's login screen, which
hands them to PAM as `XDG_SEAT`/`XDG_VTNR` (Hibr 0.99.305). An older Hibr
ignores them and logs in as before. `login_seat_gate` checks the wrapper both
ways; the export itself needs a real VT, which the dummy backend never owns,
so it is checked on hardware.

## 2026-10-23: 0.2.6 the mouse in pixels, mode 1016 (#137)

A program can ask for SGR-Pixels (DEC 1016): the same SGR report with the
pointer's position in pixels of the surface, one-based and clamped to it,
instead of the cell it is in. DECRQM answers for it, so a program can find
out before asking, and the session's `mouse_reporting` names it. Every
sample moves a pixel, so motion under 1016 is held to one report a frame,
the newest position kept and written by the main loop when it is due (its
own wait clamp, so a pointer that stops is still reported where it
stopped); a click writes any held motion before itself. Cell reports are
unchanged. `mouse_report_gate` checks the answer, a click's exact pixel, a
40-sample sweep (3 reports, the last where the pointer stopped) and the
session field. For hibr #370, which asks for it from the desktop.

## 2026-10-23: 0.2.5 a preferred login pane is waited for before another takes it

Reported by the owner: the primary display changed between logins. With a
preferred login pane set and Fallback `first_available`, a preferred pane
not present the moment the login screen started -- its monitor still
waking, or its connector discovered a beat later than another -- gave the
login screen at once to whichever pane was first, so the primary depended on
discovery order. Now a missing preferred pane is waited for up to 10 s
(`BLIT_LOGIN_PREFERRED_GRACE_US`; logged once as
`login_preferred_pane_waiting`) before the first available takes its place,
retried on the login loop's own 5 s cadence. `wait` and a present preferred
pane are unchanged. `login_policy_gate` checks that the fallback waits, then
falls back after the grace. Not yet observed on the owner's hardware.

## 2026-10-23: 0.2.4 a font change no longer shakes a running desktop (#136)

Every layout resize of a Hibr session -- a font change reflowing the pane,
a new grid -- started the attach repair loop again: up to 32 passes, 250 ms
apart (2 s once a held desktop's processes were found), each pushing the
terminal one row shorter and back. A desktop already running took every
pass as a resize, cleared and repainted, for about eight seconds after each
font change, and a click landing in one was lost. That was the whole of
hibr's flaky Blit UI gate (hibr #362). It was first filed as the font
flipping between two sizes, which was wrong: the 19/20 px alternation in
that trace was the gate's own font writes.

Now a session is *unsettled* only while a startup or attach repair is owed
or running. Once settled, a layout resize that changed the geometry arms
nothing, since TIOCSWINSZ already signalled the program, and one that
changed nothing gets a single pass. A resize during a repair leaves the
running loop to finish its own window rather than restarting it. The
startup and attach sites are unchanged. `GET /v1/terminal-sessions` reports
it as `hibr_attachment.settled`.

The new `layout_reassert_gate` counts the SIGWINCH a Hibr session receives
after two font changes: 2 on this build, 11 on 0.2.3, limit 4. hibr's
`blit_ui_gate` passes 8 of 8, from 4 of 8. Twelve attach, hold, join,
resize and font gates pass, `native_hold_observer` and
`hibr_resume_guard` among them. The full `tools/run-gates.sh all`
passes 152, skips 10, fails 0 (16 minutes), with `layout_reassert_gate`,
`touchpad_gate` and `tap_setting_gate` now in it. Not yet run against the
owner's held desktop on hardware.

## 2026-10-23: 0.2.3 tap to click; 0.2.2 confirmed on the Air's trackpad

The owner reports 0.2.2 on the MacBook Air mid-2012 (bcm5974): the pointer
moves and the pad's own click works. That is the first hardware
confirmation of the touchpad path, which 0.2.2's entry left outstanding.
Tapping did nothing, because 0.2.2 had none.

0.2.3 adds `tap_to_click`, a per-device setting offered only on a device
Blit reads as a touchpad, off by default: a touch that ends within180 ms
having moved less than8 px, the pad never pressed, is a click -- left for
one finger, right for two. Tap-and-drag is not done. `touchpad_gate`
covers it on the recorded sequence (off, left, two-finger right, long,
moved, pressed, a small wobble); the new `tap_setting_gate` covers the API:
offered for a touchpad and not a mouse, 422 on a mouse, 400 for a
non-boolean, kept in the settings document. The seven input gates pass
against this build. Tapping itself is not yet confirmed on the hardware.
The Blit Mouse pane (catalogue 0.1.10) shows a Tap to Click row for a
touchpad.

## 2026-10-23: 0.2.2 touchpad pointer; first package in hibr's apt repository

Source59cdd2c; package identity is in `releases/0.2.2.yaml`. A touchpad
(absolute X/Y, a finger tool and touch, not a gamepad) is now classified as
a pointer: one finger moves, two fingers scroll at24 px a tick, the pad's
own button is left or, with two fingers on it, right. `touchpad_gate`
passes on a recorded MacBook Air mid-2012 (bcm5974) sequence, and the
existing input gates (input_device_api, input_device_config,
pointer_settings, mouse_report, evdev_scan, input_device_route,
pointer_target) pass against this build. Updater and ABI16 adapter hashes
are identical to0.2.1. Not yet run on the physical trackpad: no hardware
or /dev/uinput here, so physical acceptance on the Air remains outstanding.

This is the first Blit package published into hibr's apt repository
(pool/main/b/blit); source, tickets and the Control Panel pane's
catalogue entry are unchanged.

## 2026-10-22: architectural ticket handoff verified (planning only)

Created internal126–135 and refreshed122/125/104/120 current-status bodies,
preserving historical reports and leaving all issues open. Read-back verifies
ten complete descriptions (scope, source pointers, tests/acceptance, boundaries
and prerequisites),24 native Gitea dependency edges and0 unresolved template
placeholders. The dependency index is
[performance architecture handoff](history/performance-architecture-handoff.md);
ADR0180 is proposed, with mechanism/native ownership approval delegated to128.
Full issue work orders remain in Gitea, not a second editable repository copy.

Documentation reference gate and diff checks pass. This cycle changes issues
and documentation only: no runtime/SDL/Hibr edits, deployment, input/session
mutation or live backend/font/layout change. Existing GPU/startup/hotplug/
movement performance gaps remain open; creating a ticket is not implementing
or accepting it. No unrelated backlog issues were closed or reclassified.

## 2026-10-22: authenticated0.2.1 observation; no movement acceptance yet

Association passes3 read-only UID1000/bottom-primary samples; initial inventory
contains one primary/two joins. Screenshot shows desktop wallpaper/YouTube
window.10.103s window:11.56% one server CPU core,1,316 terminal bytes/s,
71 aggregate presentation calls,142 scheduler misses; final phase samples
DP1.285ms draw/40 cells and HDMI23.715ms/2294 cells. Lower traffic and different
content than Matrix prevent any before/after blend speedup attribution. Last
phases can be stale, scheduler misses are not confirmed lost physical frames,
and concurrent association/API reads add overhead. Native KMS/Retro28px/ABI16
unchanged. All three sessions initially retain one image each.

Subsequent inventory revision2 contains only DP-1; HDMI-A-1 binding waits for
its output, with primary/top join still ready. User clarification requested
for monitor disconnect/switch and subjective movement. No live mutations or
Hibr changes were performed. DP image geometry is RGB24/959x532 to1918x1064,
an existing integer-scale fast-path case, not evidence of general-scaler cost.
No runtime fix, physical movement result or performance acceptance claimed.
Evidence paths are recorded in current-state.125/122/104 remain open.

## 2026-10-22: 0.2.1 canary installed; desktop acceptance awaits login

Exact source7ca0dbc/package identity is in `releases/0.2.1.yaml`. Artifact
rebuild is byte-identical. Updater/ABI16 adapter hashes remain identical to
0.2.0/589. Existing API updater verifies live0.2.1; postflight checks version,
API0.1, native KMS, both physical outputs, all three pane grids, exact font
identity/settings hash, clean revision397 and compatible Hibr ABI16. No SSH,
Hibr modification, backend/font/layout change or authentication bypass.

Local receipts:39 font checks pass; combined renderer/GLES74pass/1explicit
VT-kernel skip/0fail; schema and unchanged local frame-rate gate pass. Full
standard-suite/lifecycle soak is not newly rerun or claimed for this arithmetic-
only change.33,654,432 production blend comparisons and0 TCC divisions are
recorded below; local timing gains are not native-frame/desktop acceptance.

Restart replaces PTYs. One bottom-primary login manager is awaiting
authentication and no premature joins are created. User login, association,
physical rendering/input and actual movement/frame-time measurements remain
pending. Pre-update6.194s window (0.2.0):52.37% of one server CPU core,
176 aggregate presentation calls/60 missed deadlines; uncontrolled workload,
not distinct-frame FPS or a fair before/after desktop comparison. Do not compare
that desktop window with new idle login. Logs: `build/tests/blend-package.log`,
`blend-frame-rate.log`, `blend-deploy.log`, `blend-postflight.json`,
`blend-live-before-config.json` and `blend-live-before.json`.0.2.0 and stable589
rollback archives are retained; no stable0.2 tag.125/122/104 remain open.

## 2026-10-22: 0.2.1 exact raster arithmetic, local implementation

ADR0179's production function matches the frozen pre-change oracle in
33,654,432 cases: every alpha/source/background channel combination for
coverage and RGBA, plus100,000 mixed-RGB/high-byte/stride/bounds/unsupported-
format cases. Null inputs retain the original return. RGBA tests deliberately
include channels above alpha, preserving original saturation behaviour rather
than assuming only valid premultiplication. Old source passes equivalence,
but fails the instruction-work requirement with6 TCC divisions; new source
has0. Reference is test-only, not an alternate production implementation.

The5-run alternating process-CPU benchmark (2million pixels) reports reference
versus production medians: transparent43.378/17.897ms, opaque46.968/20.175ms,
mixed42.099/35.413ms. Old-production baseline medians46.100/48.018/45.275ms
were comparable with its reference43.489/47.960/45.009ms. These are local
function timings, not whole-frame improvements, native CPU attribution or
physical input acceptance. The runtime consumer is native KMS; no SDL/GPU
speedup is inferred. Logs: `build/tests/blend-before.log`,
`blend-before-benchmark.log`, `blend-after.log`, `blend-font.log` and
`blend-renderers.log`. New candidate identity is0.2.1; live remains0.2.0 until
separate package/deployment verification. No host or Hibr changes so far.
Full font suite:39pass/0skip/0fail, including all-size presentation and
native/software raster consumers in Modern and Retro. No physical pixel,
input-latency or active-window-drag acceptance follows from those local gates.
Combined renderer/GLES suite:74pass/1explicit VT-kernel skip/0fail. This
includes native mocked-DRM composition, software/GL raster consumers and
graphics/damage/frame-lifecycle invariants, not physical GPU or hotplug acceptance.
Package artifact/rebuild gate passes reproducible=yes for the manifest's exact
0.2.1 archive. Local frame-rate gate passes at60Hz with unchanged20ms budget;
this SDL fixture is not native live cadence or movement acceptance.

## 2026-10-21: 0.2 authenticated association passes; performance not accepted

Read-only native association gate passes3 samples with a verified UID1000
owner, bottom primary and no mutations. Session inventory confirms one
primary and two joins. All retain14x28 cells/Retro28px and compatible ABI16.
Screenshot shows Matrix saver, not active window dragging.10.146s uncontrolled
window:55.05% one server core,96,822 terminal bytes/s,289 aggregate presentation
calls,104 missed deadlines. Last draw samples17.199/20.231ms; last-frame
samples may be stale and are not percentiles. Association/API polling adds
overhead. No fair589 comparison, confirmed movement result or FPS gain claimed.
Font window:0 new rasterizations,61,152 cache bytes. Session inventory:0 images
retained at the sampled instant; lifetime counters still record Kitty traffic.

Native per-pixel raster callback remains unchanged. TCC disassembly confirms
6 coverage-path integer divisions. Exact division-rounding identity tested
for every product0..65025 (65,026 cases) passes, but production blender
equivalence/timing tests and implementation remain future work. No source,
API, host input, settings, font/backend or Hibr changes in this observation.
The15s follow-up included screenshot capture and unconfirmed user activity;
do not use it as a clean drag comparison. Evidence paths and next boundary are
recorded at the top of current-state.125/122 remain open.

## 2026-10-21: 0.2 canary package and live startup, not desktop acceptance

`releases/0.2.0.yaml` records source/docs4013bcd and the exact development
artifact. Package gate with rebuild enabled passes reproducible=yes; pinned
ABI16 native-child-provider gate passes. Timing suite4pass/2explicit live-only
skips/0fail;120-second four-PTY soak10512 snapshots/956 resizes. No thresholds
were relaxed. Exact589 rollback package checksum/manifest also verify.

Existing API updater accepted the candidate and independently reported
server0.2.0 through `/v1/version`. Postflight confirms API0.1, native KMS,
both output identities/modes, three pane grids, saved layout and settings
document hash unchanged, clean revision397. Live Hibr is0.99.285/ABI16,
compatible with the pinned adapter; updater/adapter package hashes match589.
No SSH, Hibr edits or backend/font/layout mutations. Restart replaces PTYs.

One running login manager occupies the saved bottom primary; identity waits
for authentication. Auxiliaries have not been launched before login. User
login, primary/join reattachment, physical pixels/input and matched desktop
performance remain pending. Do not compare pre-update desktop CPU/cadence
with post-update login idle as a speedup, or call this a stable0.2 release.
Preflight, postflight, package/rebuild, timing, deployment, font/baseline
observations and API screenshot are in `build/tests/candidate-0.2-*`.
Pre-update5.108s sample:49.40% one server core,67,781 terminal bytes/s,
141 presentation calls/24 missed deadlines; uncontrolled, not distinct FPS.
Another5.516s font sample on Retro28px sees0 new rasterizations and49,392
cache bytes, so no cache churn was observed in that particular window.
These windows do not identify the expensive function or a Kitty comparison.

## 2026-10-21: 125 protocol-image producer damage, candidate0.2.0 only

ADR0177's extension narrows Kitty completion/deletion and sixel completion
damage while retaining the shared last-composed comparison and renderer
fallbacks. A production-parser regression fails on the prior full-surface
Kitty completion handler. Sixteen added protocol frames pass software SDL
and offscreen OpenGLES2 full-reference pixel comparisons: chunked uploads,
multiple placements, placement-only/data deletion and opaque/transparent
sixel over unchanged wallpaper. Maximum producer damage in these small-image
cases is1 cell rather than480 full-view cells; this is fixture work, not a
real application's damage bound or a physical FPS result. Held pointer,
synchronized and masked attempts retain damage and the prior scene snapshot.
Partial uploads remain invisible. Existing36-step native compositor tests
(only DRM mocked) and deferred-flip tests also pass; do not describe these
as physical native protocol acceptance.

Final direct software/GL fixtures, TCC build and font-reference gate pass.
Valgrind reports0 errors and0 definitely/indirectly/possibly lost bytes on
software/protocol;18,804 bytes in9 library blocks remain reachable. Native
fixture exits with0 allocated blocks and0 errors. Renderer suite:
61pass/1explicit hardware-dependent skip/0fail. GLES suite:13pass/0skip/0fail.
Combined schema/terminal/lifecycle suite:34pass/1explicit missing-pinned-Hibr-
headers skip/0fail. No complete standard-suite or physical acceptance is claimed.
Logs in `build/tests/`: `protocol-damage-software.log`,
`protocol-damage-gl.log`, `protocol-damage-valgrind-final.log`,
`protocol-damage-renderer.log`, `protocol-damage-gles.log` and
`protocol-damage-contract.log`.

Bounded read-only live observation still identifies589/native KMS. Over
5,512ms it reports50.71% of one server CPU core,107,345 terminal bytes/s,
149 presentation calls across two outputs and67 missed deadlines. Last-phase
samples are display-93 (1920x2160):18.109ms draw/0.833ms copy/0.038ms submit
and display-102 (2560x1440):20.595ms draw/0.714ms copy/0.020ms submit,
both around60Hz.
Workload is uncontrolled, samples can repeat stale frames, presentation calls
are not distinct displayed frames, and CPU excludes Hibr/hold/GPU. No causal
attribution, Kitty comparison or candidate live speedup follows from this
window (`protocol-damage-live-observation.json`). No live writes, backend,
session, layout or Hibr changes.125/122 remain open;104 still gates SDL
multi-monitor hotplug parity. Native CPU composition/copying and controlled
candidate video/input acceptance remain outstanding.

## 2026-10-21: 125 linear image ingestion, candidate0.2.0 only

ADR0178 removes redundant ingestion work without changing protocol semantics.
The production TCC fixture measures4,097 strlen calls for a4,096-byte chunk
before the fix and1 afterward; summed logical scan lengths fall from
16,785,409 to4,097 bytes. These are instrumented call/length counts, not
physical memory traffic, elapsed CPU speedup or live FPS. The normal gate
fails against the old decoder. Baseline `--observe` disables performance
assertions and is observation only, regardless of its historical output label.

Final direct software and explicit offscreen OpenGLES2 fixtures pass binary
fragmentation at every split, valid padded endings, whitespace, rejected
inputs, capacity canaries, exact RGB/alpha/pitch, texture reuse and changed
generation submission. Already packed RGBA reaches SDL from its original
buffer; RGB24 still converts exactly. SDL/driver uploads and internal copies
remain: this is not zero-copy rendering. The fixture includes production
functions, not a parallel decoder or uploader.

The renderer suite passes61 checks, skips1 explicitly and fails0; the GLES
suite passes13/13 with0 skips/failures. Software ingestion under
Valgrind reports0 errors and0 definitely/indirectly/possibly lost bytes;
18,804 bytes in9 SDL/library blocks remain reachable. TCC build,
font-reference gate and diff checks pass. Logs: `build/tests/ingestion-before.log`,
`ingestion-after.log`, `ingestion-gl.log`, `ingestion-valgrind.log`,
`ingestion-renderer.log` and `ingestion-gles.log` in the same directory.

No physical-host performance gain, full standard-suite acceptance, new Debian
release or deployment is claimed. Live remains589/native KMS; no Hibr,
settings, session or backend changes.125/122 remain open. Protocol-image
upload/delete damage, native full-output copying and controlled video/input
measurements remain;104 still gates SDL multi-monitor hotplug parity.

## 2026-10-21: 125 retained placement damage, candidate0.2.0 only

ADR0177 establishes one shared comparison of immutable last-composed image
placement descriptors. The new production-command regression failed against
the previous full-surface `a=p` handler, then passed with old/new coverage.
The renderer consumers use prepared damage while preserving unknown-caller
fallback, topology/full redraws and terminal damage accumulation.

`graphics_placement_damage_gate.rb` passes with SDL software and explicit
offscreen OpenGLES2. Each compares36 incremental frames against forced full
redraws with exact pixels, full wallpaper, translucent moving foreground,
stationary overlapping image, z/crop/pixel-generation changes, deletion,
reappearance, fractional-cell and negative positions. SDL whole-renderer
clears stay0 for the incremental steps; image uploads stay unchanged except
the single changed-pixel case. Synchronized and masked-output attempts do
not advance the surface's composed scene snapshot. Native production
composition (only DRM mocked) matches the same36 full-reference cases with
drawn cells strictly below the fixture's480 full-view cells. Explicit
unknown-caller fallback still draws the whole graphics union; pending flips
defer without consuming damage, and retry consumes it.

Existing renderer suite59pass/1skip/0fail, GLES11pass/0fail, and combined
schema/terminal/lifecycle34pass/1skip/0fail pass. The new software/native and
GL fixture invocations above are additional to those receipts; suite hooks
were added afterward. Valgrind on software/protocol and native fixtures:
0 errors,0 definitely/indirectly lost; native exits with0 allocated blocks.
TCC candidate build, font-reference gate and diff checks pass. No new full
standard-suite pass or physical-host performance acceptance is claimed.

Final isolated timing:4pass/2live-only skips/0fail with unchanged limits;
120s/four-session soak performs11,756 snapshots/1,069 resizes. Logs are
`build/tests/scene-renderer.log`, `scene-gles.log`,
`scene-contract-lifecycle.log`, `scene-timing.log`,
`scene-placement-software.log`, `scene-placement-gl.log` and
`scene-valgrind.log`. Earlier0.2 validation gaps remain explicitly recorded.
Final review includes shared scene preparation inside aggregate frame timing
and optional SDL trace timing; backend-only draw phases keep their narrower
scope. No comparison may silently exclude preparation cost. Placement fixtures
and the unchanged local frame-rate gate are rerun for this timing-only change.

Image upload/delete handlers retain conservative full damage; native scanout
copying and SDL changed-image staging are unchanged. Live remains589 with
no backend/layout/session/Hibr changes or SSH.125 remains open for those
remaining stages and controlled video/movement/input-latency measurement.

## 2026-10-21: Kitty architecture audit, no runtime implementation change

Internal125/122; pinned Kitty source and exact local code paths are recorded
in[the investigation](history/kitty-rendering-investigation.md). The bounded local
TCC probe invokes production functions: moving an existing placement preserves
pixel generation but damages all240x135 cells; wallpaper makes native graphics
bounds full-view; production scanout preparation copies16,588,800 bytes.
SDL software resource-policy fixture confirms unchanged images are reused,
not re-uploaded for movement; changed generation causes the next upload.
These are architecture/work-shape observations, not a real-GPU FPS test.

`ruby tools/probes/graphics_work_shape.rb` passes native and shared-protocol/SDL
fixtures; source hashes are included in its JSON. Ruby syntax, documentation
reference gate and diff checks pass. No runtime sources, schemas, font assets,
live settings/backend, Hibr source or sessions were changed. The earlier
0.2 release-validation gaps remain; these probes do not close them.

## 2026-10-21: 0.2 development cache and observation checkpoint

Stablev0.1.589 annotation/target is verified on the public GitHub mirror.
Development packaging/VERSION is0.2.0; TCC builds it successfully. No0.2
release/tag/package deployment is claimed; the live host still reports589.
Internal122/123 and ADR0176 own the[performance programme](history/performance-0.2.md).

Production cache workload: Retro and Modern,11x22px,200 warmed passes;
ASCII19,000 lookups/0 repeats; ASCII+Hibr UI39,200/0 (released code28,800
repeats); same-bucket Latin/Arabic/colour600/0 (released code600 repeats).
Per-run glyph pixel/metric signatures match; CPU time includes signature
checking and is not a live FPS benchmark. The4MiB resident pixel limit stays.

Targeted final-code checks pass: full emoji-presentation corpus at every
size8..64 in both profiles, full5,244-entry cluster corpus per profile,
Arabic16,986 cases per companion, font-raster all57 sizes with five-way
collision/LRU tests, and large64px colour-pressure/recovery in both profiles.
Native-KMS, SDL software and offscreen GL raster fixtures also pass. Shared
cache probe under Valgrind reports0 errors/0 definitely or indirectly lost.
Schema and font-reference gates pass. The new observation sampler fixture
passes exact CPU/counter units, GET-only operations, reset/backend-change
rejection and credential-output checks.

Initial associative code failed a supported emoji lookup at53px because the
larger entry count hit the byte ceiling. Successful-miss budget reclamation
fixes it; all-size presentation and dedicated large-colour pressure checks
were rerun, not waived. Initial parallel GLES run also hit an occupied test
port, and initial standard input-config fixture lost its fabricated event0;
the isolated input-config recheck passes (tracked for investigation in124).
The initial standard run finished142pass/9skip/3fail: presentation above,
input-config, and full-scene timing44.697ms against its unchanged20ms budget.
It ran alongside CPU-heavy raster/GLES checks; that is not a diagnosed cause
of the timing miss. No threshold was relaxed. The nine skips explicitly
include absent Hibr headers, package/live-host gates and QEMU oracles.
Final GLES recheck passes11/11 with no occupied fixture port. These receipts
are not a clean standard-suite run and do not certify release/deployment.
No new live drag/cadence improvement is claimed.

Final isolated timing suite:4pass/2live-only skips/0fail, including the new
sampler fixture, unchanged frame-rate budget and120s/four-session PTY soak
(11,072 snapshots/1,006 resizes). Final input-config recheck also passes.
Final targeted Arabic/cluster/native-KMS/SDL-software/GL checks pass after
byte-budget reclamation was added. All three initial failing gates now pass
their corrected/isolated rechecks, but a new clean full standard-suite run
has not been claimed. Input-fixture intermittency remains tracked in124.

Read-only live589 window:5.091s server uptime delta,9.31% one server core,
36 presentation calls/32 missed deadlines. Native direct-KMS; last sampled
draw17.542ms/copy1.081ms. Workload uncontrolled; phases can repeat stale
frames. The sampler does not measure Hibr/hold or GPU/compositor CPU.
No live settings/backend/session changes, Hibr edits or SSH.

## 2026-10-21:0.1.589 supervised live release receipt

Operator requested releasing589 after its149pass/5skip/0fail standard suite,
11/11 GLES gates and reproducible package acceptance. Existing API updater
accepted the manifest-matching package and verified live version589.
Read-only API command reporting confirms installed server SHA256
86023def38c0186b0b5bb765ecf23fa9574aaca442caa5072c69926a5c4a5960.
Logs: rectangle-589-live-update.log and rectangle-589-live-identity.json.

The complete saved settings document is unchanged, clean revision341:
Retro22px, Arabic Retro/baseline17px, direct KMS, DP-1 split1x2. One primary
bottom-pane login-manager owner is running after restart; auxiliary joins
wait for authentication. Initial diagnostics have no errors/warnings.
No font/backend/layout/Hibr changes or SSH. This verifies installation and
configuration preservation, not physical appearance or solid-drag speed.
Hibr337/Blit120 remain open for the complete negotiated route and end-to-end
acceptance; native DA28 alone is not held-route support.

## 2026-10-21:588 tag and120 candidate589 rectangle-copy checkpoint

Annotated v0.1.588 targets48c5fdf, verified on origin and public GitHub.
The release manifest still names its exact packaged source70999f2, package
and binary SHA256s. Production-path diff from that source to the tagged
commit is empty; subsequent changes through the tag are documentation/tooling.
Live API version was verified588. User's unrelated releases/0.1.554.yaml is
preserved; no tag overwrite or remote configuration change.

Candidate589 corrects the existing DECCRA implementation, not a second escape.
Negative control with the old code fails the combining-count assertion
(`rectangle-copy-before.log`). New direct fixture passes1048 cases, including
immutable-source overlap oracle, all16 attachment slots, style/underline/link
metadata, wide cut/cleanup damage,512x160 limits, defaults/clipping/origin,
byte-fragmented parser and DA1/DECID feature28 (`rectangle-copy-after.log`).
Local30-copy144x38 CPU sample:8.582ms total,0.286ms mean. It excludes input,
parser, hold, painting and scanout and proves no Hibr drag speed.

TCC589 builds. Final const-only qualification rebuild is binary-identical to
the tested binary. Terminal suite5pass/0skip/0fail includes new real PTY/API
metadata and wide-pair checks. Renderer59pass/1skip/0fail; skipped native VT
kernel fixture is not acceptance. GLES11pass/0skip/0fail. Valgrind fixture
1048cases:0errors/0definite/indirect/possible lost bytes;18,804bytes in9
reachable library blocks. Logs: build/tests/rectangle-copy-{build,after,
terminal-suite,renderer-suite,gles-suite,valgrind}.log.

The full standard suite passes149/5skip/0fail (`rectangle-copy-all.log`),
including120s/four-session soak,11272 snapshots and1025 resizes. Skips are
native VT kernel/QEMU fixtures, explicit QEMU Hibr lifecycle, package not
supplied, live multi-display and live screenshot timing. They are not passes.
Candidate589 artifact checks pass, including deterministic rebuild:
package SHA25669ff6b1cfafbd6606a7f7bc9475c626f47e0c4beb58e83c4cf1c26d67854b73e,
server SHA25686023def38c0186b0b5bb765ecf23fa9574aaca442caa5072c69926a5c4a5960;
recorded source/documentation53b0a45. Log rectangle-589-package-artifact.log;
manifest releases/0.1.589.yaml. It is not deployed: no live font/layout/backend/Hibr changes. Hibr337 is the upstream
console/term/hold/desktop integration dependency.120 remains open until
actual through-hold and physical solid-motion acceptance; retained pixel
placements/translucency are not cell-copy capabilities.

Read-only Hibr checkout audit:7dc5f74, clean audited term/gfxask/console-key
files; term/vt.c SHA2566020360b9978d08e4c2f6700a6c0179c848916159119dd1eda0b66211b451ff7.
tm_csiin ignores `$v`, whereas relayed primary DA is passed to the client.
This can expose native DA28 without emulator support, so Hibr337 must
qualify/filter negotiation before enabling the complete route. gfxask's
decoder scans to the final CSI byte, not a fixed11-byte response. These are
local source facts, not installed-host observations; no Hibr edits were made.

## 2026-10-21: public link boundary correction

Verified github.com/osakka/blit exists publicly, public font-reference URL
returns200, and osakka/hibr-apps/blob/main/docs/blit.md returns200. Read-only
git ls-remote confirmed public main exactly matched local9781791 before
this documentation correction. Earlier internal Gitea browser404 results
do not establish any failure of GitHub publication.

Public entry points use GitHub/relative links, with no invented mapping from
internal issue numbers to GitHub issues. font_reference_gate passes and now
rejects internal host URLs in those entry points. Documentation/tooling only;
no runtime/font/backend/remote/Hibr changes.

## 2026-10-21:121 generated font developer reference

`build-reference.py --check` passes against all30 generated Markdown pages
and six-face coverage JSON using pinned fontTools4.60.1. Generation verifies
font/catalogue/corpus SHA256s; both primary faces contain the complete Nerd
and original icon repertoire. An empty-output negative control fails without
creating files, proving missing reference artifacts are not accepted.

`font_reference_gate.rb` passes:10,764 Nerd names/aliases,10,386 distinct
scalars, seven originals with valid supplementary JSON strings,5244 complete
emoji sequences matching corpus order, six native-face hashes/ranges/counts,
all local links. Added to the standard font suite. Asset identity and48-path
schema gates pass. Generated previews use the existing real raster tool;
font artwork and runtime are unchanged. This is documentation correctness,
not another renderer, shaping or physical validation claim. No host writes.
After push, internal Gitea's contents API confirmed the reference on main.
Its internal browser/raw404 results were not a public GitHub test; the
public-address correction above supersedes that publishing concern.
No separate standalone website was created.

## 2026-10-21:119 candidate588 profile activation

Shared-raster gate:16,986 cases per face over8..64px, zero failures;
Latin/Arabic baselines agree at every size. Current overhang counts are
Retro2048 and Modern109; each has2565 mark-difference checks. Unsupported
scalar fallback is explicit, unsupported cluster failure preserves state.
Independent HarfBuzz OT/design-unit whole-word positioning equals separate
visual-cell placement for six captured specimens on both faces
(`arabic_word_gate.py`), not a scanout or arbitrary-script assertion.

The real local PTY/API gate passes24 cases across both profiles at16,17,22px:
original icons plus Arabic marks/digits, contiguous and bytewise UTF-8, exact
presented screenshot equality with direct API writes. The font API gate
checks all57 heights, actual companion identity, missing-asset rollback and
bitmap-null reporting. Logs: build/tests/arabic-activation-{module,api,pty}.log.
Backend fixtures additionally test uncovered-scalar parity and SDL italic
geometry anchored to the original cell. Full arbitrary styled-text pixel
parity and physical typography are not inferred from these checks.

Offscreen GLES:11pass/0skip/0fail (`arabic-activation-gles.log`). Backend
fixtures pass117 scenarios per face/path,702 total, after baseline alignment.
Candidate588 artifact gate passes with reproducible=yes, including exact
source-commit comparison of Arabic faces, manifests, specimens, notices and
the GPL preferred-source archive (`arabic-588-package-artifact.log`).
Source70999f2; package SHA256
`b43b3f993882214f0259d40e342b03f6aad43972fff550722f28856fead46bcd`;
server SHA256
`e574cc31a3c91467aa7545bce57542d5368eabe991c62ed241cbda05c9b7e3e5`.
Standard suite:147pass/5skip/0fail (`arabic-activation-all.log`), including
120s soak with four sessions,11664 snapshots and1060 resizes. Skips:
kernel/QEMU VT, explicit QEMU Hibr lifecycle, package not supplied to the
suite, live multi-display, live screenshot timing. Separate package checks
above resolve artifact acceptance, not the other skipped checks.

Live588 update verified through the supervised API updater. Read-only API
command report confirms exact server and both Arabic asset SHA256s
(`arabic-588-live-identity.json`). Saved document is unchanged, clean
revision335: Retro22px (operator changed it before deployment), direct KMS,
DP-1 split1x2. Active Arabic Retro reports baseline17px. One bottom-pane
login-manager owner; joins wait for authentication. Initial diagnostics have
no errors/warnings. Capture build/tests/blit-0.1.588-login.png shows its idle
animation, not physical Arabic aesthetics or desktop/join acceptance.
Earlier entries retain their historical scope, not current activation behaviour.

## 2026-10-21:119 shared backend overhang/damage fixtures

KMS mock, SDL software and offscreen GLES each pass117 scenarios per face
(Retro/Modern),702 total. Sizes8,9,16,17,22,23,32,48,64 cover movement, erasure,
mark replacement, pane edges, block-cursor/adjacent ink, a negative-z retained
image and deliberate Latin/Arabic/colour cache-slot collisions. Every
incremental frame matches its clean-frame counterpart exactly. The separate
full-raster oracle is exact for KMS, with≤4/channel for SDL overlapping-alpha
composition and exact outside-pane guards. This tolerance is not a relaxation
of any existing font gate. Fixtures call production draw_view/render_outputs,
not a replacement renderer. Logs: build/tests/arabic-overhang-{kms,software,gles}.log.

TCC0.1.588 rebuild passes. Standard `all`:146pass/5skip/0fail, including the
120-second four-session terminal soak (arabic-adapter-all.log). Skips are
native VT kernel/QEMU inputs, explicit QEMU Hibr oracle, absent package,
unset live multi-display and live screenshot checks. They are not passes.
Offscreen GLES suite:11pass/0skip/0fail (arabic-adapter-gles-suite.log).
Final native backend Valgrind runs include117 scenarios per face,0errors,
0definite/indirect/possible lost bytes (arabic-overhang-final-valgrind.log).
Library-reachable allocations remain reported separately, not counted freed.

Two deterministic negative controls fail the same checks: removing ink halos
loses neighbour ink during incremental KMS repaint; a416×208 non-power-of-two
SDL atlas loses an8px glyph pixel. Test-only compile flags reproduce those
conditions; there are no product toggles. Logs: arabic-negative-damage.log and
arabic-negative-atlas.log. SDL now keeps binary-exact UV bounds with correctly
sized tiles; KMS/SDL share write/source halo geometry and clip to the write
region. Cursor repaint includes intersecting neighbouring ink inside its cell.

Companion selection remains disabled in the server. This is not end-to-end
Hibr/PTY, physical scanout, performance or exhaustive Arabic acceptance.
Independent mark/join semantics, mixed-script baseline alignment, styles and missing-coverage behaviour need
review before atomic profile/API integration, package and live validation.
No deployment, Hibr edits, SSH, topology, font or settings writes on10.54;
live version was read-only confirmed587.

## 2026-10-21:119 Arabic companion module, not deployed

ADR0174, source manifest arabic-fonts.source.json and captured Hibr0.99.277 /
ABI16 specimens define the finite acceptance scope. Shared Arabic attachment
uses FreeType outlines and HarfBuzz cell-local mark positioning, preserves
presentation forms, and measures ink offsets rather than clipping overhang.
Server profiles do not attach it: existing KMS/SDL adapters still assume
cell-bounded ink and must gain composition/damage support before enabling it.

Final module gate:16,986 scalar/mark/specimen cases per face at every8..64px
cell height,0failed, including native ink,45 base/mark combinations per size,
all captured word clusters, repeat-key cache hits, bounded cache, failed
attachment/re-attachment and uncovered-scalar output/cache preservation.
Retro839 and Modern910 scalar cases require overhang;2,565 mark comparisons
per face differ from the unmarked base. These counts establish ink/coverage
and mark presence, NOT independent correctness of every GPOS anchor or join.
Log: build/tests/arabic-foundation-final-module.log.

TCC candidate588 rebuild passes (arabic-foundation-tcc.log). Selected schema,
terminal, font and lifecycle suite:67pass/0skip/0fail
(build/tests/arabic-foundation-regression.log). Offscreen OpenGLES2 existing
composition/damage suite:10pass/0skip/0fail (arabic-foundation-gles.log).
These backend regressions use the existing profiles, NOT enabled Arabic.
Final Arabic Valgrind run:0errors,0definite/indirect/possible bytes lost;
18,804bytes/9blocks reachable per process, not reported as freed
(arabic-foundation-final-valgrind.log). Both module fixtures rebuild from
current sources; new experimental attachment is not used by the server.

Both companion files regenerate byte-identically from pinned upstream TTFs.
Negative control: the rejected DejaVu companion fails U+0670 mark/specimen
cases in the same gate (build/tests/arabic-dejavu-negative.log). The earlier
cell-clipped prototype rejected valid source ink; bounds logging identified
negative bearings, top accents and descenders, rather than blaming Hibr.
Real-raster preview docs/images/blit-arabic-candidates.png was generated and
visually inspected; it is not a screenshot from the physical host.

No changes to Hibr, live587, backend/layout/input or saved settings. No new
package/deployment.119/118 remain open. Universal Arabic/Quranic coverage,
backend parity, word-join correctness and operator aesthetic acceptance are
not claimed. Remaining work is in current-state and ADR0174.

## 2026-10-21: final icon/stroke candidate588, Arabic work starts119

Final strengthened UI fixture requires visible ink, not just mappings.
Native fallback source-footprint coverage fixes the reproduced8px blank
U+2500/U+2610; explicit half-block rows including odd heights stay exact.
Selected schema/terminal/font/lifecycle66pass/0skip/0fail; log
build/tests/blit118-final-regression.log. This supersedes the earlier65-gate
run for the stroke change. No deployment or Arabic acceptance is claimed.
Arabic119 audit: both outline faces lack required base letters/digits; Hibr
uni display-order/presentation-form output was read-only verified. Retro and
Modern Arabic face/mark/join evaluation is now the operator's priority.

## 2026-10-21: candidate588 original icons and concrete missing text glyphs

Seven original colour icons:798 size/profile cases, distinct Wi-Fi levels,
partial alpha/premultiplied colour, no foreground tint, themed pen and bounded
cache. Versioned Hibr GL snapshot:101scalars×57sizes×2spans×2profiles=23,028
non-replacement cases (legitimate PSF fallbacks explicitly allowed).
Real local PTY/API fixture:12 cases, bytewise/whole UTF-8, one-cell originals,
exact presented-pixel parity, canonical discovery and missing/oversized503.
Both profiles/native KMS/SDL software/GLES:1710scalar cases each plus existing
2052cluster/cursor cases; guard pixels/tolerances unchanged.

Negative controls: actual587 Modern font fails at U+16D2 before originals;
old shared raster from15e5956 fails to produce colour at U+100000 with the
new assets. Both pass the corrected fixture. Both outline files rebuild
byte-identically. Valgrind:0errors,0definite/indirect/possible loss;
18,804bytes/9blocks still reachable each. Existing Nerd catalogue592,002cases
per face and full5244-entry emoji raster corpus pass at their documented
sizes/spans. Broader selected suite, package and live acceptance are pending;
none of these local checks certifies every application or universal Unicode.
Hibr330 tracks application selection; no Hibr edits. ADR0171/0172 and icon
contract document source of truth and the exact presentation boundary.

## 2026-10-21:118 wide-bitmap colour loss

Expanded native production-compositor gate with real Unifont and U+2615 is
red before ADR0171, green afterward. Modern and Retro native KMS and SDL
software pass all57 sizes, each1311 scalar samples and2052 cluster/cursor
cases; Modern offscreen GLES also passes. Guard pixels/tolerances unchanged.
SDL selection checks a real CJK fallback as well as the corrected colour
choice. TCC server build passes. These are offline rendering tests, not a
physical colour/missing-icon acceptance. Live587/settings remain unchanged.

## 2026-10-21 live587 native VT kernel-state verification

API-only supervised deployment succeeds; installed SHA256
79e706f10673c921a0c5105599c0298f7e092f30da354748b95d7de74fb965e1 matches
the reproducible archive. Native KMS ready,2outputs/3sessions and unchanged
settings/Modern22. Active kernel VT is tty3, previous tty2; API reads K_OFF4,
errno0 and active recovery. Independent pidfd_getfd duplication of the actual
owner's fd confirms4, not586's EIO. No getty on tty3; getty on tty2 stays
separate. Evidence /tmp/blit-rollout587.SKzt0W. No SSH, Hibr edits or manual
desktop/join spawn. Physical operator typing/handover confirmation remains
pending; no live crash, VT switch or destructive test was forced.

## 2026-10-21 candidate587 /117 getty coexistence correction

Source89e54e8; package SHA256
3c294a089495b63e204456a76e8969201c3e8596409ffdc1fdc90cae9d08df9d.
Artifact/provenance and byte-identical rebuild pass. Exact packaged payload
79e706f10673c921a0c5105599c0298f7e092f30da354748b95d7de74fb965e1
passes full expanded VM; /tmp/blit-vt-kernel.HuOiVe/serial.log. Focused
schema/terminal/lifecycle33pass/0skip/0fail. Physical rollout pending here.

586 failed physical acceptance despite the prior getty-free VM pass. Actual
owner fd duplication returns EIO while a new tty2 descriptor reads K_UNICODE;
getty@tty2 restarted after startup. This is recorded in the586 manifest,
current-state and117, not treated as successful isolation. No Hibr changes.

587 reserves a dedicated VT using VT_OPENQRY, global single-owner flock,
bounded activation, previous-VT return and real descriptor/muting health.
Cleanup reopens only the reserved VT if hangup invalidates inherited files.
Final candidate module/full-server VM passes original-login-console
TIOCVHANGUP plus Unicode/text reset without losing own muting, and own-VT
hangup with safe detection/restoration. Existing real key delivery, hotplug,
VT chords, queued-away input rejection, byte-identical scanout, SIGKILL,
stopped-owner watchdog, inherited descriptors and install lease still pass.
Evidence /tmp/blit-vt-kernel.kAxkrF/serial.log. Package/live acceptance pending.
The same expanded fixture is red on the exact586 package payload, after
TIOCVHANGUP and keyboard/display reset of its borrowed console: native owner
still claims active but reports unreadable/unmuted keyboard, matching10.54.
Negative evidence /tmp/blit-vt-kernel.ptvwkj/serial.log.

## 2026-10-21 candidate586 /117 native VT isolation

Source44e3597/package586 artifact gate and byte-identical rebuild pass.
Package SHA2568cbdce7f5442d832f8dc624b70b14a5ed235a9d6c2802c11af07d7af0cca66d8;
exact extracted server3e05a50e2e5b600342f3ca6588f005c827bd0bbae2e9bb74ccdff621fff1475a
passes the complete real-kernel/full-server VM gate again, including install
lease and queued-away input. Evidence /tmp/blit-vt-kernel.yWCkCY/serial.log.
An initial wrong invocation followed the extracted absolute /usr/bin/blit
symlink into the host's old230 binary and failed; it is not acceptance evidence.
The gate now rejects symlink inputs and prints the actual payload checksum.

TCC build and actual Linux6.1.190/QEMU module plus full native server pass.
Module: observed unmuted console leak is the negative control; two keyboards
including hotplug are muted at the VT while still delivering evdev events;
VT release/acquire, normal and SIGKILL restoration, stopped-owner10s watchdog,
inherited recovery descriptors and competing-owner refusal pass. Expanding the
test exposed an inherited-flock restart lockout; explicit unlock is now covered.

Full production server on QEMU Bochs DRM1280x800: physical evdev key reaches
the PTY but not the Linux console; real Ctrl+Alt+Fn leaves/reacquires DRM;
an away key reaches only the other console and is not replayed after queuing
across SIGSTOP/SIGCONT; scanout bytes before/after handover match; API shutdown
restores the keyboard. No ioctl/mock stand-in for this VM result. Evidence:
/tmp/blit-vt-kernel.FHvism/serial.log. Final VM also holds the bounded120s
installation lease longer than10s, then independently verifies the normal
stopped-owner watchdog. Test VM shuts down and exits0.

Broad suite140pass/5skip/0fail (10-second soak, not the120-second default).
It began before the final install-lease addition; the final TCC binary then
passed the real module/full-server VM gate and update_restart_gate explicitly.
Targeted schema/terminal/lifecycle32pass/1skip/0fail; its skip lacked pinned
Hibr headers, while the broad run supplied them and passed provider isolation.
SDL startup cleanup/refusal and console endpoint authentication/readback pass.

Reproduce with tools/tests/native_vt_kernel_gate.sh and BLIT_VT_SERVER_TEST=1,
BLIT_QEMU_KERNEL, static BLIT_QEMU_BUSYBOX and matching BLIT_QEMU_MODULES.
The regular renderer suite skips explicitly when these inputs are absent.
Default kernel path is not assumed to exist. The test executable refuses to
touch a console without the disposable VM's blit_vt_test=1 boot marker.

This is not SDL daemon, physical GPU/multi-monitor VT, gpm isolation, whole
cgroup SIGKILL or kernel/GPU hang acceptance. No live deployment yet; API-only
readback confirms584 on10.54, unmuted VTtty2 and no mirrored desktop files.
117 remains open for the remaining boundaries. ADR0170 records the decision.

## 2026-10-20 candidate585 /116 negotiated keyboard events

Frozen source1206741 passes combined terminal/schema9/0/0. Package585
12d6746d57ae9bbc4b7f7e976575f19af3bcfe16d85d4a8912788a099954ed6d passes
artifact/provenance checks and a byte-identical rebuild. Not deployed;
live API still reports584. Physical and Hibr326 integration remain pending.

Raw-child PTY exact-byte gate passes32 cases: actual query/push/pop/set,
unsupported-bit masking, main/alternate independence, bounded stack, RIS,
lone left/right Super, chords, repeat/releases, lock bits, shifted/control
identity, keypad navigation/numeric distinction, per-keyboard isolation,
Meta remapping, disabled keys, and legacy printable-modifier silence. The
same gate is red on584 (query remains0 after push). WebSocket gate confirms
Super edges and existing UTF-8/AltGr text. Terminal suite4/0/0 (including the
new keyboard gate) and existing keyboard-settings gate pass; OpenAPI gate
passes the supported-mask/stack observation contract. TCC candidate built.
No physical Super or Hibr326 hold/console end-to-end acceptance; no live
deployment. Only flags1/2/8 are supported, not complete Kitty keyboard
protocol coverage. Live584 is preserved. ADR0169 records scope and dependency.

## 2026-10-20:584 target-host provider verification

Package SHA2565df55078bc6eeba2ed6c3da3e1b75d75ddad2077a69258a4ba654527a10d2e7b
byte-identical rebuild and packaged native/API/stale-RC selection pass.
584 API rollout healthy native KMS; settings document unchanged, Retro22
retained from operator preflight. Native login awaiting authentication.
Most and hvi render PRETTY_NAME content from /etc/os-release in isolated80x24
PTYs on10.54 and exit0 (q / :q!), no missing-surface error and empty stderr.
Native console selected despite inherited old RC path; no surface ID needed.
This resolves321 startup/provider failure, not every application's rendering
or performance acceptance. Hibr320 remains upstream-fix pending after traced
SIGTERM->TCSETS->SIGTTOU reproduction without Blit. No Hibr modifications.

## 2026-10-20:320 isolated reproduction and321 candidate584

320: installed Hibr270/ABI16 stock lg_as helper, console open, isolated root
PTY, no Blit. strace confirms watchdog SIGTERM -> inherited terminal TCSETS
-> kernel SIGTTOU/group stop. Live syscall corroboration recorded; all fixture
processes owned/cleaned by isolated transient unit. No Hibr changes or signals
to live stopped children. Upstream fix pending in Hibr320.

321: live583 module inventory has native console sole discoverable provider,
adapter only under Blit-owned directory. Native interactive shell with old
Blit RC reproduces exact missing surface-ID error. Candidate584 RC/provider
gate passes default/native, stale-RC, explicit API and caller-RC tests;
old packaged583 RC fails the same regression. Diagnostic report transport
gate preserves1000 Unicode characters,150 stderr characters, exit7 and removes
its temporary terminal. This is not physical application acceptance yet.

## 2026-10-20 live583 rollout

Reproducible artifact4baf7253764f55cd94b707dea422d2acd321edab3bf7c223d2361e41d74ee96a
installed through API;583 identity and ready DRM/KMS read back. Canonical saved
settings unchanged, Modern16 retained, one primary/two joins verified. Actual
service tmp/retry properties read back through a removed unbound API probe.
Independent systemd User=osakka process lists the same three hold clients,
proving outside-service socket discoverability. Root stopped children persist
and are reported in Hibr320, not fixed. Schema5/0/0, terminal3/0/0, identity,
shutdown/restart and reproducible package gates pass. Browser visual/zoom
acceptance remains pending. No SSH, backend switch or Hibr modifications.

## 2026-10-20 candidate583 service boundary115

Real local systemd socket round-trip passes with shared tmp; private-tmp
negative control hides the socket. Shipped retry values stop a failing
transient unit after3 starts. `systemd-analyze verify` passes. API-created
Hibr probes verify unique0700 session-user-owned log directories and explicit
DT_LOG preservation. Hibr320 tracks stopped login children; no fix claimed
for those. Live582 read-only observation: Modern16, one native UID1000 owner,
three clients. No physical namespace migration/restart acceptance yet.
Candidate583 also passes terminal suite3/0/0, real credential-drop/login
identity rejection/lifecycle tests, and the updated GLES2 pixel-frame gate.

## 2026-10-20 candidate583 destination placement (not deployed)

Production adapter metadata gate passes four cell metrics with independent
2x2 source. Pixel-frame gate is red on582 and green on583: source/destination
independence, quadrant screenshot pixels, odd/even sizes, reuse/grow/shrink,
old-extent erasure, legacy placement and malformed destination rejection.
SDL software and offscreen GLES2 identities checked. Desktop OpenGL failed
initialization here, not verified. Native KMS clipping oracle passes; graphics
reset and OpenAPI contract gates pass. TCC builds server and pinned ABI16
adapter. No live deployment/browser change or end-user acceptance claimed.
Hibr319 owns the requested viewport-sizing policy; Blit111 remains open for
integration/live acceptance. See ADR0166.

This ledger records the latest evidence for the Blit delivery contract. It is
an evidence record, not a claim that the complete product is released.

## 2026-10-20 live font reviews on582 — operator reports

Operator confirms the deployed Spleen16 desktop/input setup is working, then
reports that all look perfect after selecting Modern16. API observations
verify actual Modern profile/native-antialiased/colour support,8x16 cells,
unchanged native DRM/KMS ready health, every existing pane pixel/cell geometry
and exactly one native primary. Two physical outputs/three panes were present.
These are explicit human reports and API invariants, not independent pixel
comparisons or full repertoire/protocol/performance acceptance.

Next selected Retro16 through PUT /v1/fonts: same8x16 cells, native
antialiasing/colour and unchanged backend/panes/primary count. Operator also
reports it is perfect. No size/scale change in these16px comparisons, Hibr
edit, SSH, manual join or server restart. Evidence under /tmp/blit-fontcraft.IHU9AK/:
font-live-baseline.json, font-live-modern-{response,observation}.json and
font-live-retro-{response,observation}.json.107/110 remain open for remaining
coverage; both16px profiles have representative operator acceptance, not
complete glyph/protocol certification.

Next selected Retro17. The local PUT-response formatter had a syntax error;
the mutation was not retried. An authoritative subsequent GET verifies
Retro17,9x17 cells/native antialiasing, native KMS ready, same physical pane
regions and exactly one primary. Every pane's whole-cell counts and centered
integer remainders match its physical region. Observation saved as
font-live-retro17-observation.json. Operator then reports wallpaper absent on
all panes despite correct text/grid.17px wallpaper acceptance fails; correct
API geometry is not proof of correct desktop output.

## 2026-10-20 wallpaper parity114 — fault owner unassigned

Same live582 native KMS, Retro, two outputs/three clients.17px retained-image
counts are0/0/0; pre-change16px counts were1/1/1. Trace includes explicit Kitty
a=d,d=I image deletions followed by capability probes. No rejected payloads.
Restoring16px returns1/1/1; operator confirms wallpaper back on all panes.

A controlled six-second observation at each18/19/20px gives:

| Size | Cell pixels | Final image counts, sessions7/8/9 | Rejections |
| --- | --- | --- | --- |
| 18 | 9x18 | 1/1/1 | 0 |
| 19 | 10x19 | 0/0/0 | 0 |
| 20 | 10x20 | 1/1/1 | 0 |

Returned to16px afterward; final GET confirms1/1/1 again. This separates
height parity from odd width in the tested cases; it is not proof for every
odd/even size. Explicit deletes and absent retained objects point before
final composition, but do not establish Hibr fault: Blit size/query replies
and upstream negotiation remain possible causes. Read-only source inspection
uses Hibr v0.99.270 (local main271 is not the running-version reference).
No Hibr edits, restart, renderer switch or manual joins. Blit114 owns the
investigation until a failing boundary is demonstrated. No even-only font
restriction or silent rounding workaround was introduced.

Evidence: /tmp/blit-fontcraft.IHU9AK/wallpaper-parity.log, wallpaper-17.json,
wallpaper-{17,18,19,20}-trace.json, wallpaper-{18,19,20}-settled.json and
wallpaper-restored16-final.json. A native-KMS17px BMP was captured as
wallpaper-17-display93.bmp; it has not been visually reviewed here (the image
viewer rejects BMP). Do not claim screenshot inspection from that capture.

## 2026-10-20 rollout582: authenticated installation on192.168.10.54

Package/source/documentation identity is releases/0.1.582.yaml (source0d6cc98).
Artifact gate passes with a byte-identical full package rebuild:
SHA01e4346c5f8b73344f68937ad89c4223b1f2aec22a481c6e83afa466f4eaef7f.
The582 server matches the previously frozen TCC binary. Helper/adapter hashes
are unchanged from572. The retained572 package matches its release checksum.
No installed Hibr files were changed; adapter built from pinned225/ABI16.

Before installation, the API reported572, native DRM/KMS ready and cached
runtime Hibr265/ABI16 compatible. A bounded read-only diagnostic PTY checked
installed FreeType>=2.12.1 and HarfBuzz>=6.0.0, exited0 and was deleted; it
was not another Hibr desktop. An earlier oversized diagnostic request failed
400 before creation and was corrected to fit the documented argument bound.

Authenticated update accepted the hash-verified package and completed with
`/v1/version`=0.1.582 and update ready/idle. After observation confirms ready
native KMS, unchanged saved settings document, Spleen16px and both pane pixel
regions/cell grids. Retro/Modern inventory entries are available, not selected.
One1920x2160 physical output,1x2 split; this is not two-monitor acceptance.

Fresh startup reports runtime Hibr270/ABI16 compatible.572's old cached265
probe does not establish when Hibr changed. Later observation shows the lower
login manager awaiting authentication, with no authenticated primary/join;
this is the expected post-restart login boundary. User visual/input acceptance
has been requested, not received at this checkpoint. No live font/size changes,
SSH or manual Hibr joins were performed. No pixel-correctness/FPS claim.

Evidence: /tmp/blit-fontcraft.IHU9AK/rollout-before.json,
rollout-immediately-before.json, rollout-after.json, rollout-final.json,
rollout-host-dependency-preflight.json, rollout-package-gate.log and
rollout-update.log. Network waits in the operator updater are now bounded.
API rollback still depends on a responding management plane; independent
automatic package rollback was not implemented or tested here.

Subsequent rollout-authenticated.json shows a ready native desktop with one
owner and exactly one primary (DP lower pane), plus DP upper and HDMI-A-1
join clients. HDMI appeared after the initial one-output comparison, yielding
two physical outputs/three panes. No manual join was created for this rollout.
This verifies observed ownership/reconciliation, not physical rendering,
mouse/keyboard behavior or measured multi-output performance. Human
visual/input and new-font appearance acceptance still await confirmation.

## 2026-10-20 candidate582: whole-owner resize and PTY transitions

ADR0165. Frozen TCC server SHA
ddb1525c457b83e61a3ceb18903f64da21e31ad5e96279c50497f8fe8c693d26;
fresh rebuild byte-identical. Logs: `/tmp/blit-fontcraft.IHU9AK/582-*`.
The new real local PTY fixture fails on581 at the first resize-cut: a heart
anchor at column3 still claims2 columns after shrinking16 to4. This is a
cell-state defect, not inferred from a photograph (`582-before.log`).

The shared resize function now removes wide anchors whose continuation is
clipped, independently in live/saved alternate buffers. It also clears live
link IDs outside the new grid (previously omitted) and invalidates streaming
cluster extension while preserving the last printable REP value. Whole
overlapping narrow/wide owners survive; no terminal reset/reflow is added.

Real PTY tests use a raw-mode controlled child, independent expected anchor
grids, out-of-band OSC-title completion acknowledgements and exact presented
surface-revision matching. Each resulting BMP equals a positioned-API redraw
of the expected grid, byte-for-byte. Software and GLES each pass324 checks:
two fonts,15/16px, nine sequence families, seven update operations plus shrink
and grow. The old image is captured before each operation. This is PTY/API
pixel parity on presented frames, not an independent raster implementation,
all5244 sequences end to end, Kitty/sixel placement or physical acceptance.

Expanded parser fixture retains all5244 corpus entries under both policies
and contiguous/one-byte feeds; a focused both-buffer resize case additionally
checks attachments/styles/link IDs and non-resurrection after grow/restore.
Valgrind3.19.0:0 errors,0 definitely/indirectly/possibly lost bytes;
18,804 bytes/9 blocks remain reachable (`582-parser-memory-final.log`).
The focused case also uses different narrow/wide occupants in the two
buffers, proving a clipped saved owner does not erase a valid live one or
vice versa. Nonzero foreground/background/underline/link fields are cleared.

Final transition logs: `582-software-ownership-final.log` and
`582-gles-ownership-final.log`; both additionally reject orphan continuations
and owners lacking their second cell. Terminal/schema suite completes8/0/0
(`582-regression.log`). Existing graphics reset and unchanged-image cache
gates pass (`582-graphics-reset.log`, `582-graphics-cache.log`); these are
specific lifecycle/cache checks, not full graphics-placement conformance.
This cycle does not rerun the complete font/renderer/hardware matrix.

The new gate lives in font and explicit GLES suites. Optional
`BLIT_TRANSITION_ARTIFACT_DIR` saves actual/reference BMPs and state JSON on
pixel mismatch; captures are not source assets. No Hibr edits, SSH, package,
live writes or deployment.107/110 remain open for the remaining acceptance.

## 2026-10-20 candidate581: core Powerline geometry

ADR0164. Frozen TCC server SHA
444b79525a1dc49b2e9817d5d33b3dcc1cfbaa5aa0524e947e5af3bf5d8d276a;
fresh rebuild byte-identical. Logs: `/tmp/blit-fontcraft.IHU9AK/581-*`.
The new geometry fixture fails before the production change at8px/U+E0B0:
an entire separator row has no ink (`581-powerline-before.log`). The same
fixture passes after:456 scalar/size/span cases per Modern/Retro profile,
912 combined, checking solid-base opacity, thin endpoints, exact reflection
and vertical symmetry, antialiasing, cache reuse and the4MiB bound.

Core U+E0B0..U+E0B3 coverage is generated once in the shared raster, using
the allocated cell rather than outline cap-height fitting. Font assets,
global metrics, other Nerd outlines and bitmap-only profiles are unchanged.
Backend fixtures include228 additional Powerline bold-overstrike cases per
profile/path at all57 sizes, with exact outside-cell guards. Native compares
exactly; existing SDL2-level per-pass/4-level double-pass tolerance is retained.
No tolerance was raised in this cycle. The general SDL scalar fixture now
checks a one-pixel outside-cell ring as well as the interior.

The selected font/terminal/schema/GLES run reports45 passes, no failures or
skips, then exits143 before the final GLES scene gate; do not claim a
completed full-suite run. A fresh dedicated GLES suite completes9/0/0,
including that last scene gate (`581-gles-final.log`).46 distinct selected
gates therefore have passing evidence across the two runs. The presentation
regression in this cycle uses16px; the full8..64px presentation matrix was
last verified in580, not rerun here. Powerline and backend size tests cover
all57 sizes in this cycle.

The final geometry fixture passes Valgrind3.19.0 for both profiles:0 errors,
0 definitely/indirectly/possibly lost bytes;18,804 bytes/9 blocks remain
reachable per process (`581-memory-final.log`). The production preview was
regenerated and inspected, including separator samples at16/22/30px. It is
an offline raster specimen, not a physical display capture.

This does not certify Powerline Extras, italic overhang, every terminal/
graphics transition or live appearance.107/110 remain open. No SSH, Hibr
edits, package creation, live writes or deployment.

## 2026-10-20 candidate580: Unicode presentation and monochrome emoji

ADR0163. Frozen TCC server SHA
012fa57ca66df1ca5e85a5e405cdc614022517dc9c2fdad6a5e573bbd71c405f;
fresh rebuild byte-identical. Logs: `/tmp/blit-fontcraft.IHU9AK/580-*`.
Pinned official Unicode18.0 properties/standardized variations generate the
lookup header. Shared monochrome Noto Emoji3.002 uses the existing FreeType
coverage/cache/compositor; it is not a silhouette of the colour bitmap.

The presentation fixture passes all371 standard VS15/VS16 pairs and1228
default-emoji scalars at every8..64px height, both owner-supplied spans and
both Modern/Retro profiles. Checks include real ink, no PSF fallback,
premultiplied colour, exact cell bounds, distinct selector cache entries and
the existing4MiB cache bound (`580-presentation.log`). This is raster scope,
not all terminal/graphics/damage or physical-output combinations.

The initial16px fixture caught U+1F41F's hinted one-pixel ink overhang at a
one-column allocation despite a fitting advance. A smaller em is rasterized
until all ink fits; no silent clipping. Both profiles pass the16px presentation
fixture under Valgrind:0 errors,0 definitely/indirectly/possibly lost bytes;
18,804 bytes in9 blocks remain reachable per process. Do not claim all heap
allocations freed.

The catalogue initially failed because its old assertion required U+26A1
(a default-emoji scalar) to remain monochrome. Its format/ink checks now honor
the generated presentation property rather than reading RGBA as coverage.
The corrected catalogue passes592,002 glyph-size samples per profile,
1,184,004 combined, with no fallback/missing ink except intentional cod-blank.
This expectation update does not waive the independent selector tests.

Final font/terminal/schema/GLES run:41pass/0skip/4fail; all four failures were
the extended native/software cluster references omitting text bold's second
overstrike (colour glyphs intentionally skip it). The references now model
that second pass; all six backend/profile fixtures pass isolated reruns
(`580-{native,software,gles,retro-native,retro-software,retro-gles}-final.log`).
Thus45 distinct selected gates have passing final evidence, not a claimed
single uninterrupted45/0/0 run. The earlier long suite was interrupted after
its HarfBuzz gate; it is not counted as a completed suite.

Backend fixtures cover2052 cluster/span/size/cursor-background cases per
profile/path, now including VS15 heart/fish. Native comparison and guards are
exact; SDL retains2-level per-channel single-pass tolerance, with4 for the
two-pass text bold overstrike and exact guard pixels. This explicitly records
SDL8-bit blend quantization rather than claiming bit-identical composition.
Creation/restore and missing colour OR monochrome asset rollback pass for
both profiles.54 real local PTY cases and18 fresh SDL-software BMP comparisons
pass, including VS15's one-/two-column ownership. The suite's presentation
fixture uses16px; its separate full8..64px matrix passed as recorded above.

The regenerated production specimen includes VS15/VS16 pairs and is explicitly
an offline raster image, not physical scanout. No live writes, SSH, Hibr edits,
package creation or deployment.107/110 remain open for full geometry,
terminal/graphics integration and live appearance acceptance.

## 2026-10-20 candidate579: negotiated PTY emoji grouping

ADR0162. Frozen TCC server SHA
f2b0df8462cd988a9b3de78aacc4a93529049116f747df8e7f701b21ccafa313;
fresh rebuild byte-identical. Final terminal/schema8pass/0skip/0fail
(`579-regression-final.log`); expanded emoji_layout, emoji_layout_api and
emoji_pty_api gates also pass:11 distinct focused gates, not the full matrix.
Logs are under `/tmp/blit-fontcraft.IHU9AK/579-*`.

Parser gate checks all5244 corpus entries in scalar/emoji policies with
contiguous and one-byte feeds, exact scalar preservation and cursor advance.
Focused cases: late widening, last-column wrap, bottom scroll, disabled-wrap
and one-column allocation, horizontal margins, insertion before ASCII text,
full-cluster REP, continuation overwrite, erase, alternate restoration, RIS
and control barriers. These are specific tests, not exhaustive VT conformance.

Real HTTP-created local PTYs exercise seven families across omitted/scalar/
emoji policies and contiguous/bytewise emitter writes:42 cases. OS read
boundaries need not match emitter writes; the module gate separately forces
one-byte parser feeds. Fourteen fresh BMP captures match positioned API
rendering byte-for-byte on SDL software/Modern16px. This is fresh-capture
parity, not proof of incremental-damage performance or physical scanout.
Invalid creation policies fail before registration; PATCH policy changes
return400; nested environment keys cannot override the root policy. Existing
positioned API tests remain green after sharing the policy validator.

Full parser/edge fixture under Valgrind3.19.0:0 errors and0 definitely/
indirectly/possibly lost bytes (`579-parser-valgrind.log`).18,804 bytes in9
blocks remain reachable; do not claim all heap blocks freed. No live writes,
Hibr edits, SSH, package or deployment.107/110 remain open for VS15/default
presentation and remaining full backend/terminal/font acceptance.

## 2026-10-20 candidate578: schema-first API grouping, scalar compatibility

ADR0161. TCC server SHA
519e6d4d8677b12c86bc0cb99f125af547bfd1b04991fdb5b4d35f2fea07cb8d;
fresh rebuild byte-identical. Terminal/schema selected suites8pass/0skip/0fail
(`578-ingress-regression.log`); emoji_layout and emoji_layout_api also pass:
ten distinct focused gates. Not a rerun of576's120-gate matrix.

Corpus-derived6157-node trie regenerates byte-identically. C gate checks all
5244 entries in scalar/emoji policy, every scalar preserved in order, grouped
anchor/span and adjacent X placement. Real isolated HTTP gate selects Modern
and tests seven families, width2/continuation ownership, overwrite repair,
default-vs-explicit scalar equivalence and invalid types/values before mutation.
Right-edge wide clusters clip whole; accepted clipped writes may still advance
revision under existing API semantics. No partial-glyph or rejection claim.

This is opt-in API grouping, not PTY grouping, complete presentation policy,
Hibr-provider negotiation, full-corpus backend or physical-display acceptance.
107/110 remain open. No live writes, Hibr changes, SSH or package/deployment.

## 2026-10-20 candidate577: compositor consumption

ADR0160. TCC server SHA
d24c1b4707e05ef8b950203d9a228f26b1802e8517f437d470f77cecebfe0885;
fresh rebuild byte-identical. Ten focused gates pass, no skips/failures:
Modern/Retro font-backend gates for KMS, SDL software and offscreen-OpenGLES2
(six); cell_paint, motion_trail, modern_font_api and kms_compose (four).
Logs `/tmp/blit-fontcraft.IHU9AK/577-*.log`; KMS composition also run directly.
The earlier120-gate result below belongs to576, not this changed server.

Each backend/profile checks1,596 representative cluster cases (seven sequence
families,57 sizes,1/2 spans and two background/cursor cases), alongside1,026
scalar samples. Native KMS tests real draw_view including block-cursor repaint
and exact out-of-cell guards; SDL tests actual atlas/helper/batching output
with normal/cursor-like backgrounds, tolerance2 per RGB channel. Existing
queued collision and native attachment-layout checks remain green. Font API
checks both smooth faces/all57 heights, persistence and failed-change rollback.
KMS composition retains its128-frame full-reference/held-pointer regressions.

No full-corpus backend, complete presentation/width policy, terminal ingress,
physical-display, performance or new-package acceptance is implied.107/110
remain open. No Hibr edits, SSH or live writes. Next: shared API/PTY grouping.

## 2026-10-20 candidate576: shared production colour-cluster raster

ADR0159 /107/110. Frozen TCC server and two fresh rebuilds are byte-identical:
SHA c6599df751a0e0054d60db1f69eb9a3d724ccb067d249fbe8da5148d4333cb17.
Selected font/terminal/renderer/schema/lifecycle/offscreen-GLES run:
120pass/0skip/0fail, `/tmp/blit-fontcraft.IHU9AK/576-verification.log`.
No timing/hardware suite or physical refresh/visual acceptance is implied.
The macro-based header baseline rebuild is byte-identical to the tested server.
Final font-suite rerun24pass/0skip/0fail (`576-font-final.log`) includes the
hardened full-key collision/eviction byte comparison, fresh buffer recovery
after rejected sequences, and injected old-runtime/package-baseline checks.

Internal `blit_raster_get_cluster` shares the existing cache, FreeType colour
face/downsampler and premultiplied compositor. HarfBuzz6.0.0 public headers
are pinned (40 headers plus licence); OS runtime>=6.0.0 is now an explicit
link/package dependency. Tested runtime SHA
1b55afd639cdf32fef66721032a29ee02b9c5af5527845cf53d185bc5413df1a.
An injected old-version-query fixture rejects new colour contexts while
existing bitmap/outline contexts remain usable; it is not an actual old-runtime
loader test. Header hashes and package minimum-version consistency are checked.

Each outline profile passes actual raster tests for all5,244 pinned Emoji18.0
entries at16px with both1/2-column allocations. A colour-only context also
requires every entry to yield a real colour glyph. Seven sequence families
(VS16, keycap, regional flag, skin tone, profession, family, tag flag) pass both
spans at every8..64px height per profile. Tests check ink, dimensions, no
fallback, premultiplied channels and bounded caching. Existing scalar policy
is retained; this does not prove default-emoji/text-selector policy complete.

Both profiles' full corpus/size-family fixtures pass Valgrind3.19.0 with
0 errors and0 definitely/indirectly/possibly lost bytes
(`576-cluster-valgrind.log`). Each retains18,804 reachable bytes in9 blocks.
A separate production-preview run with all reachable stacks enabled traces
all9 to GLib dynamic-library initialization, not Blit raster contexts
(`576-preview-valgrind.log`); do not describe this as all heap blocks freed.

Updated specimen `docs/images/blit-fonts.png` is generated from the production
module, visually inspected and byte-identical to a second generation:
SHA fc443aa14db4572d15685d8c13b7217e16f9c7b0cd7d607a855fad59a646ab45.
It is NOT a live-display screenshot or evidence of terminal cluster support.
PTY/API segmentation, width ownership, renderer consumption and complete
presentation/overwrite/erase/wrap/resize conformance remain pending.107/110
stay open. No Hibr edits, SSH, live writes, Debian artifact or deployment.

## 2026-10-20 candidate575: shared cluster value and native attachment layout

ADR0158 / font107, emoji110, regression113. Frozen TCC server SHA
dac8e240a03dd3a96dba6d038abe7cec50ca0707ae036ece9787fd4622db6132.
Font/terminal/renderer/schema/lifecycle/offscreen-GLES118pass/0skip/0fail;
logs `/tmp/blit-fontcraft.IHU9AK/575-final-verification.log`. Earlier broad
run also118/0/0; final run includes hardened invalid-key checks and explicit
raster-cache collision/column-span regression. No timing/hardware suite or
physical acceptance claim is implied by these selected suites.

New native draw_view fixture fails before the fix at8px/count1: server arrays
have16 attachment slots, reader uses4. One shared bound fixes indexing and
iteration.0/1/5/16 attachments, padded rows/nonzero origins and all57 sizes
compare exact pixels:228 layout cases per Modern/Retro profile. Existing
1026 glyph samples per backend/profile remain green. TCC owned-value gate
round-trips all5244 corpus entries at both owner spans, validates bounds and
atomic rejection, and distinguishes colliding hash keys. It tests storage,
NOT emoji segmentation or shaping. Cache still has128 slots/4MiB pixel limit.

Modern and Retro shared-raster tests under Valgrind3.19.0 report0 errors and
all heap blocks freed, including collision/eviction cases and all57 sizes.
Logs `575-{modern,retro}-valgrind.log` in the same scratch directory.
Additional native-KMS font fixture memory run (`575-kms-valgrind.log`) also
reports0 errors and all heap blocks freed. A fresh575 build and regenerated
specimen were byte-identical to the frozen server and checked-in image.
Full emoji shaping/PTY/API/backend integration remains110. No new shaper
dependency, font-width change, Hibr edit, SSH, live write, package or deploy.

## 2026-10-20 candidate574: complete emoji font-shaping baseline, NOT terminal completion

ADR0157 pins Unicode Emoji18.0 corpus/licence and the single unmodified Noto
Emoji2D2.057 colour asset. HarfBuzz6.0.0 SHA
1b55afd639cdf32fef66721032a29ee02b9c5af5527845cf53d185bc5413df1a
shapes every5,244 corpus entries to one nonzero glyph (3,972 RGI,1,272
qualification variants). The old Noto2.042 has174 RGI failures and10
minimally-qualified failures. New font SHA
15671215ab769fdc7162a045d56fd7d7e477c51b04e6b3c761d914d8fdd6cc44.
Manifest records exact upstream release and OFL hash. Audit output records
scope and identities; --require-complete rejects an ordinary text-font
negative fixture. No HarfBuzz runtime link/dependency was added.

TCC574 build; combined font/schema/lifecycle/GLES54/0/0 before adding the
font-audit runner entry, then final font suite21/0/0 including that audit.
This covers55 distinct gates: font21, schema/lifecycle25, offscreen-GLES9.
The full Nerd catalogue gate still checks1,184,004 glyph/size cases. Shared
colour raster, both native/SDL font adapters, API rollback/persistence and
the regenerated/inspected actual-raster specimen pass with Noto2.057.
Logs: `/tmp/blit-fontcraft.IHU9AK/574-{verification,font-final}.log` and
`574-emoji-audit.json`; re-run through tools/run-gates.sh and the font guide.

These are font-shaping and existing scalar-renderer regressions. Full corpus
colour-cluster raster/terminal acceptance is NOT implemented;107/110 stay
open. No physical acceptance, live deployment, package, browser changes,
Hibr edits or SSH. Execution queue and ticket closure criteria: roadmap.md.

## 2026-10-20 candidate573: offline smooth Retro / full Nerd profiles

ADR0156, tracking107. TCC build573; font/schema/lifecycle44pass/0skip/0fail,
offscreen-GLES9pass/0skip/0fail. Catalogue gate covers10,386 scalars at57
integer sizes for each profile:1,184,004 cases, no fallback or clipped allocation;
all have ink except verified intentionally empty U+EC03 `cod-blank`.
Modern and Retro both independently rebuild byte-identically with pinned
fontTools4.60.1 and source/catalogue hashes from the single provenance manifest.
Modern SHA42457a8ca5eb79fdd888b58bda459d539028cba8bfa84786fa52d68313482cf8;
Retro SHAe7ca66583c2c694be10c8dc9ef85edf12e4598d67b01dac1295151ddfa43b99a.

Both native-KMS/mock, SDL-software and offscreen-GLES composition adapters
check1026 glyph samples per profile/backend at all57 sizes. Exact native
comparison, SDL tolerance2, guard pixels unchanged. Shared module checks
partial alpha, colour/premultiplication, optical bell bound, cache and failures.
Expanded API gate additionally rechecks BOTH Modern/Retro save/restart and
missing-colour rollback, preserving earlier Modern regression coverage.

`ruby tools/fonts/preview.rb` generated and visually inspected an actual-raster
1200x1030 PNG specimen at16/22/30/42px, with48px Nerd and colour-emoji rows.
Logs: `/tmp/blit-fontcraft.IHU9AK/{verification,gles-gates}.log` (scratch,
not durable acceptance artifacts). Re-run commands from the font guide/gate
runner; specimen output is `build/font-preview/blit-fonts.png`.

No live write, SSH, Hibr change, package or deployment. Host remains572.
Not physical-display, hotplug, performance or universal-Unicode acceptance.
Emoji sequences remain issue110; seamless Powerline geometry is not proven.

## 2026-10-20 configuration branch reconciliation: unchanged runtime

Merge13551e4 includes full config-source-108 tip456f354, whose implementation2fb6f7f already
entered main through803728a. Remaining unique content is a historical563
status completion; duplicated release/verification evidence stays single-copy,
and newer results are preserved. Production paths match pre-merge main exactly.
Fresh TCC builds match572 serverfe6041327ebdbd461460c59dff307c283f5af248743ce1e42824533a71b507b1
and helperb0736e2aceb7c77916470e279e7e9219c2219d565a6b6d77a2348f27d6034cf1.
Focused schema/lifecycle25pass/0skip/0fail, including11 provenance/recovery
cases. Historical563 manifest is byte-identical to the branch tip. No host
write/restart/deployment, version change, new physical acceptance or claim that
existing renderer limitations are solved follows from reconciling Git history.
Verified ancestor relationship and unchanged non-documentation tree against
pre-merge281809a. Main pushed atomically with expected-tip-protected deletion
of the old remote branch; local branch retired. Historical ignored worktree
artifacts preserved in detached/locked snapshot; user untracked554 manifest
untouched. Main is the only remaining local/remote development branch.

## 2026-10-20 deployed572: single-output evidence, operator topology change

Byte-identical package SHA256
8b692eee6896c954516822be499d58e77832b2250f8a0e1894d0f20ca2037371;
artifact/manifest and supervised API install/version checks pass. Timed GLES
trial starts from ONE native output, reaches ready SDL/kmsdrm/opengles2/legacy
with ONE output, and restores ready native ONE output with exact saved237.
The operator states the additional display is being used elsewhere for hours.
Do not turn this result into multi-output proof or an enumeration regression.
Read the actual count in all three saved observations, not just startup_pass.

Evidence build/trial572-gles/. Native572 remains live, unchanged saved layout,
Modern22px/bottom primary. Physical two-output validation of ADR0155 remains
pending hardware return. Prior571 two-output fault evidence is unchanged.
Future trial verdicts include explicit topology scope/counts and KMS path.
Schema+lifecycle25pass/0skip/0fail; renderer+GLES67pass/0skip/0fail. Additional
actual-discovery fixture passes default, explicit conflict and other-driver
cases with real SDL hints/mock video identity, verifying before-init ordering
and refusal before enumeration without opening DRM. Not physical parity.

## 2026-10-20 deployed571 / candidate572: symbolized second-output fault

571 byte-reproducible package SHA256
2ff7d37e40cdce7d1f54a19ba6ce2e62b432a73af13f2d41ac026bedb704b866;
artifact/manifest/API install checks pass. Physical GLES still fails but expiry
restores exact native237. Last stage second-output present.begin. Executable
map/file offset and matching remote/local SDL hash resolve RIP to ELF151bc1,
add_plane_property(), pinned SDL_kmsdrmvideo.c:248. Source shows global GBM
guard skips secondary per-display plane setup. No vendor/Hibr modification.

Evidence build/trial571-gles/, build/trial571-journal.txt,
build/trial571-library-sha.txt. ADR0155 chooses the documented legacy hint for
exact pinned SDL; candidate572 real-hint/mocked-identity policy gate passes,
including explicit conflict refusal and other-driver/version scope.
Schema+lifecycle25pass/0skip/0fail; GLES startup-boundary and actual helper
protocol/dispatcher gates pass. Physical acceptance remains pending.

## 2026-10-20 deployed570 / candidate571: fault trace needs executable maps

570 package byte-reproducible, SHA256
ac379c6ce91a37e19f0d9d0a1ae300bf439389a3aec713d2ff8d9b58c4198d05;
artifact/manifest and supervised API install/version checks pass.
GLES physical trial fails once, reports runtime invalid-memory instruction
address, and automatically restores exact native settings237. No reliable
symbol/caller: not proof of any proposed source-level cause. Evidence
build/trial570-gles/ and build/trial570-journal.txt. Frame-rate local gate
passes60.371Hz, max-render16.501ms, zero window missed deadlines; not physical.

571 gated startup stage/executable-map fixture passes (normal/invalid silent,
trial enabled), software and GLES two-output startup boundary gates pass;
GLES also exercised with trial diagnostics enabled. Schema+lifecycle
24pass/0skip/0fail. Physical address symbolization remains pending.

## 2026-10-20 candidate570: fault trace diagnostics

TCC server/helper build. Actual compiler fault gate proves normal exit and
source/function/caller diagnostics for a deliberate subprocess fault; no
bounds instrumentation. Schema+lifecycle23pass/0skip/0fail on the canonical
trace-enabled binary, including restart/shutdown. Override gate verifies
Restart=no during trials; ordinary service policy remains untouched.
API-only journal/scrollback collector works against native569. Physical
fault capture/deployment remains pending at this source checkpoint. No SDL
correctness or unchanged-performance claim follows from debug flags.

## 2026-10-20 deployed569: physical expiry restores native after SDL crash

Source76ddc7f, release manifest7d00015. Rebuilt package byte-identical SHA256
78f7db0c7b46d9675353a8cef9a7b58483c4df75003d11d4482e0041c888b5c0;
artifact/manifest gates and supervised API install/version check pass.
Final schema+lifecycle22pass/0skip/0fail; renderer+GLES67pass/0skip/0fail.
These focused suites do not erase568's earlier timing miss or replace all-suite
physical pixel/cadence validation.

Physical software and opengles2 trials each arm a30s independent lease, lose
API availability, and automatically return ready native KMS with two outputs
and the exact saved document/revision237. Journal shows both SDL windows
created, then SIGSEGV before listener startup (repeated service retries).
This is crash recovery evidence, NOT a successful SDL multi-output result or
proof of the faulting instruction. Local blocked-userspace tests still mock
systemd. Actual kernel/GPU hang recovery is not claimed.

Evidence: build/trial569-software/ and build/trial569-gles/ contain baseline,
lease, timestamped unavailable/restored observations, exact restored settings,
and separate recovery_pass:true / sdl_connected_output_startup_pass:false.
Service journal: build/trial569-startup-journal.txt. API-only oracle:
tools/probes/host_presentation_trial.rb. Live stays native569, bottom primary,
Modern22px. Next isolate SIGSEGV with a pre-listener fault trace, not guesses.

## 2026-10-20 candidate569: presentation recovery fault tests

TCC server/helper build. Actual helper Unix protocol and standalone recovery
entrypoint pass local tests with mocked systemd: unavailable/blocked frontend
is killed, normal restart queued, helper restart restores outstanding trial,
stale IDs do nothing, active recovery excludes updates. Bounded real userspace
command timeout kills/reaps its child. Actual frontend dispatcher passes401
authentication, six400 malformed requests,409 occupied desktop, canonical
snapshot preservation, three read-only mutation refusals, explicit provenance
and suppressed persistence. Root-module gate also covers timer-before-override,
scheduling failure, active conflict, foreign file/symlink preservation and
kill/restart failures retained as active failed state. Schema gate passes46paths.

Schema+lifecycle suite22pass/0skip/0fail. Software startup binding gate passes.
API-only real-host timer canary passes: separate systemd timer/service executes
and cleans up without a Blit restart/config write. Initial operator probe
attempts failed due to the255-byte argument bound and incorrect exited-state
name; fixed to use bounded arguments and actual stopped/failed states.
Canary is scheduling proof, not Blit rollback or physical DRM acceptance.

The fault tests above are not physical systemd/DRM tests. Live567 remains native KMS, bottom
primary login awaiting authentication on the last read-only API check. No
live trial, deployment or physical recovery acceptance is claimed here. Blit109
and104 remain open. Prior568 timing miss below is unchanged/unresolved.

## 2026-10-20 candidate568: SDL creation binding, physical trial held

Source5ee47fa corrects default-display allocation followed by unsupported
KMSDRM window movement. Production initializer test red before (moves2,
bindings0), green after: mocked IDs11/57 correctly requested at creation,
actual software/offscreen GLES renderer identities and dimensions checked,
four injected failure paths preserve diagnostic codes and exact window cleanup.
No vendor/Hibr changes. Mock display identity is NOT physical scanout evidence.

Combined all+GLES suite:122pass/4skip/1fail. Skips: QEMU oracle, unsupplied
package for that run, physical multi-display and physical screenshot gate.
The package/artifact and manifest gates pass separately. Failure retained:
frame_rate_gate maximum render21.754ms >20ms. Do not call the broad run clean.
The120s/four-PTY soak passes12080 snapshots/1098 resizes. Native composition,
pointer phase/hotplug, input, Hibr attachment and all eight GLES checks pass.

Fixed-count local comparison subsequently runs three alternating pairs using
packaged567 and exact candidate568 binaries, dummy/software, Terminus scale1,
80x24 workload, unchanged30Hz minimum and20ms render cap. All six pass:
59.998..60.006Hz and zero missed window deadlines. Baseline max-render values
16.442/17.898/16.456ms; candidate16.604/16.446/16.457ms. Retain every result,
not a retry-until-green. No demonstrated regression follows from these pairs,
but the initial timing miss is unresolved, not invalidated or fixed.
Evidence: build/sdl568-timing-comparison/results.json, per-run logs and copied
full-suite-frame-rate-failure.log. Tool: tools/probes/local_frame_rate_comparison.rb.

Package rebuild byte-identical SHA256
23459bf85da2c702344f86ac16e7f5370d2c1d840caa4f8750f02eeaf2a69402;
TCC server/helper, artifact and manifest checks pass. NOT deployed/tagged stable.
Live10.54 stays ready native567, Modern22px, clean settings237, lower primary.
SDL connector enumeration/hotplug/physical timing remain open under104.
Blit109 tracks the required independent rollback: initialization precedes
the API listener, so a blocked startup cannot be recovered via that API alone.

## 2026-10-20 deployed567: measured bell optical bound

Production-raster probe reports Modern22px H9x13/pencil11x11/bell20x20 ink,
the latter inside22x22(two cells). Shared colour artwork now uses fitted em
instead of cell height; output bell ink17x18, same allocation. New22px
optical/advance regression fails before and passes after. Font suite
15pass/0skip/0fail. Expanded per-backend bell checks1026 samples each pass:
native exact incl guards, SDL software/offscreen GLES tolerance2.
Package rebuild byte-identical; SHA256
9fb04177c04cb7af210cc89321d47d474228c51a0e4d98f4c0dc60df279bd468.
Artifact/manifest gates pass; API-deployed/version567 verified. Modern22px,
native KMS ready, settings237 clean/unchanged. Login awaits authentication;
operator aesthetic approval remains pending, not inferred from API state.

## 2026-10-20 deployed566: Modern Nerd repertoire and U+270E pencil

Old Hack fails new raster regression at U+270E8px; upstream Nerd Mono also
fails because the complete pencil has negative sidebearing. Build-time
whole-outline fitting (no cropping) and semantic pencil mapping pass1140
samples across8..64px, no fallback and exact single-cell dimensions.
Derived TTF byte-identical rebuild; source and license hashes pinned.
Font suite15pass/0skip/0fail; native969 sample pixels/guards exact; SDL
software and offscreen GLES each969 samples within2 levels/channel.
TCC server/helper566 build; no full all-suite rerun. Package rebuild identical
SHA2565eb77e95475cbd3e644b288566d8e13ce6b97002cf9af5bcdc4ebcd62e6fead4;
artifact/manifest gates pass. API deployment/version566 verified on10.54;
new Modern outline active22px, native KMS ready, saved revision237 clean and
unchanged. Physical regions and lower-primary login retained. Login awaits
authentication; visual pencil/Nerd approval remains pending.
Scope: Hibr Nerd set/Font Awesome, not all Nerd families; colour
bell unchanged. No Hibr edits, backend switch or settings changes.

## 2026-10-19 pointer565: independent output phase regression

Clean564 API sweep:180 motions requested60Hz over3s,73 confirmed DP flips
in3.090s (~23.6Hz), zero physical mouse events. Network arrival jitter is
included. Source inspection found global previous-pointer consumption by an
idle, differently phased output. Production-compositor/mock-DRM regression
fails before the fix at idle-output consumption and passes afterward.
ADR0149 makes submitted cursor state per-output; no scheduler/input/font/SDL
changes. The same gate covers120 idle-first motions on both outputs, crossing
orders, hide, pending flips/latest position, modeset and exact no-trail pixels.

Targeted565 checks pass: native composition (including48 art and64 held-scene
frames plus128 full-reference frames), pointer art, clipped RGB/RGBA graphics,
64 output hotplug cycles, pointer geometry and25,472 pointer RGBA pixels.
TCC server/helper builds, byte-identical package rebuild and artifact/manifest
checks pass. This is NOT a rerun of564's full112 checks.
565 source3bac488, package
f2e732b3d63e7df4c757fae1fb5b5e5b1bab7fc47acf35f7816a53c28877e89e
is API-deployed/version-verified; native KMS and Modern22px retained.
After verified desktop login, requested60Hz/3s:170 confirmed DP flips in
3.099802s (~54.84Hz),180 injections, zero physical mouse events. Before:
73 flips in3.090041s (~23.62Hz). Absolute position/desktop scene differed;
network arrival/order remains a confound, not physical input latency.
Requested120Hz/2s capacity:122 submissions/121 confirmed completions in
2.079841s (~58.18 confirmed Hz),240 injections, zero physical mouse events,
zero terminal bytes. Nominal DP refresh59.997Hz; one flip outstanding at
snapshot. No full-refresh or physical-mouse guarantee follows. Pointer restored,
saved settings revision230 clean and unchanged; issue101 awaits operator feel.
Evidence: build/mouse101-564-clean60/, build/mouse101-565-clean60/ and
build/mouse101-565-capacity120/. SDL104 remains separate and unmodified.

## 2026-10-19 fonts564 deployed: measured native antialiasing

Final archive sourceda7e32d, SHA256
712b0b72897d9db244ecb2a702bf1ccd0a9026491697a3e75ce9d5f812d60556.
Server55fa017d190add2dd4777487e19d4f79bc7bc8b4642941dc8b850c1e432efec6
is unchanged throughout full112pass/3skip/0fail; GLES7pass/0skip/0fail.
The three explicit skips are QEMU and the two dedicated live fixtures.
Actual package artifact/update-restart gates pass within this full run;
byte-identical rebuild and manifest generator/check pass separately.
Four-PTY120-second soak:11,564 snapshots/1,052 resizes. Reversible host-font
probe gate passes separately (both profiles, original profile/policy restore,
unavailable-profile refusal). Production adapter glyph/alpha checks pass all
57 heights8..64 and513 samples/backend: native KMS exact with guards, SDL
software/GLES within2 channel levels. Native draw Valgrind has7,478 allocations
and frees, zero errors/leaks. Hibr0.99.262/ABI16 fingerprint remains
2277b8f5557d972a34eaa3b3f7ee3b82512dd7e76574993cf9a45670fba040da.

API deployment/version564 verified on10.54; FreeType2.13.3+dfsg-1+deb13u1
was confirmed installed first. Upgrade preserved the complete saved document
before previews. Both physical outputs present, native KMS ready, all three
pane pixel regions and non-font saved settings unchanged afterward; non-font
document SHA256fd5a258342527af096ebd48f56bb0f484fa9d6dca66ca0a757a6d4cb75a81c7a.
Retro/Modern17/19/23px native geometry/capture previews restore the original
profile and size policy. Modern19px was selected afterward; another client
changed it to22px, observed clean revision230 and not overwritten.

Actual primary-menu F at19px, pixel rectangle x50..59/y1088..1106: declared
foreground#2de2e6, background#1a0533. Retro capture has2 distinct RGB colours,
zero intermediate levels. Modern has13 colours,11 intermediate levels; every
intermediate matches integer foreground-over-background coverage within1 level.
Native BMPs/cropped PNGs and before/after facts are in build/font564-evidence/.
The actual Hibr control-panel UI also passes modern19px drag and+1/-1 with
inspected captures under build/font564-panel-evidence/ (hibr-apps8006a7c).

These are raster/geometry/persistence observations, not universal Unicode,
shaping, desktop-image or mouse-performance acceptance. Initial preview
captures contain in-flight incomplete application redraws. Sessions1–3 became
4–6; the operator confirmed restarting Hibr, so that is not evidence of a
Blit-caused restart. Pointer101 and operator aesthetic/resize review remain
open. No Hibr-core edits, SSH or backend switch.

## 2026-10-19 config-only563 deployed (Blit108 / ADR0148)

Maintenance artifact source2fb6f7f is based on released561, not font candidate562.
TCC build and eleven provenance/invalid-default/API-repair cases pass. Full
regression:104pass/5skip/0fail; GLES:6pass/0skip/0fail. The skipped package
artifact and update-restart checks pass separately with the actual563 archive;
rebuild is byte-identical and manifest checks pass. Remaining skipped boundaries
are QEMU and the two explicit live fixtures, not claimed as passes.
The120-second four-PTY soak completes11,512 snapshots and1,046 resizes.
Installed Hibr during final integration/end checks is0.99.262/ABI16,
SHA2562277b8f5557d972a34eaa3b3f7ee3b82512dd7e76574993cf9a45670fba040da;
do not infer a frozen earlier runtime from that observation. The adapter uses
the pinned0.99.225/ABI16 headers recorded in the manifest.

API deployment on10.54 verifies563, ready native DRM/KMS, both DP-1 and
HDMI-A-1 presenting, three retained panes, bottom-primary login running,
clean revision213 and no pending presentation restart. The saved document
SHA256 is unchanged before/after:
`90cd4aaaf1b692b4950b72bef3b8c04be617681b434142578f85bd9021a2f198`.
Provenance reports saved-settings ownership, valid environment fallbackkms,
SDL renderer not applicable and video driver not-applicable. Service restart
reloaded the corrected environment line; original file backup remains.
SDL library hash matches561. No renderer/input/font engine or Hibr-core change.

Catalogue panel0.1.7/source2cd8f7c passes actual callbacks against563 and561,
UI, Mouse and signed catalogue lifecycle tests. Installed live bundle hash
matches the catalogue. Logs and bounded before/after facts are under ignored
`build/config108-evidence/`. These are configuration/API checks, not a new
visual acceptance of every desktop mode. SDL multi-output issues100/104 and
the unfinished font release remain open.

## 2026-10-19 native KMS recovery and held font release

Operator priority interrupts font rollout. Existing live561 switched via
canonical settings and supervised API restart from SDL to native KMS. Sysfs
had DP-1 and HDMI-A-1 connected but the running SDL inventory exposed DP only.
Native reports both physical outputs presenting, ready DRM/KMS and active
uevent+periodic hotplug. DP1x2/HDMI1x1 retained; bottom-primary login preference
remapped to `pane-display-93-2`, clean saved revision213. No SDL renderer,
font package, SSH or Hibr modifications were made during recovery. This is
API/presentation-state evidence, not operator visual/interaction acceptance.
Configuration-source/invalid-env ambiguity is tracked by Blit108.

Candidate562 source b63d7f4/package d9836e635b625d722a5d93267498c4629d78c84f1e55d6d4db13a27eade4543b
is not deployed. Reproducibility yes; GLES7pass/0skip/0fail. Full exact-binary
run110pass/3skip/1fail, unchanged Hibr259 and extracted binary during run.
Pointer fixture incorrectly demanded incremental damage on a first scene;
batched requests reproduce `initialized=0 graphics_changed=1 path=full-redraw`
followed by pointer-cache frames. Revised fixture commits a seed frame and
waits for capture revision before content mutation, preserving all assertions.
Ten candidate repeats plus released561 and full-rebuild mode pass. Final
full-suite rerun and physical font approval remain pending. Do not turn the
dependency-fingerprint success into a claim that the failed suite passed.

## 2026-10-19 candidate562: production smooth/colour profile integration

Shared raster module is now linked into native KMS and both SDL drawing paths.
All57 cell heights8..64,399 glyph samples per backend: native KMS exact with
guard pixels; SDL software/GLES2 within2 channel levels for blend rounding.
Queued SDL hash-collision replacement is exercised. Profile/size API covers
all sizes, profile-only policy preservation, canonical save/restart and
missing colour-file rollback. Actual Hibr Control Panel slider/+1/-1 with
modern font passes; inspected PNG under `build/font-modern-panel-evidence/`.
Valgrind on actual native KMS raster draw:7,364 allocations/frees, zero
errors/leaks. Explicit GLES suite7pass/0skip/0fail. Full regression is running;
first exploratory run was not a frozen binary and is not release acceptance.
Final exact-binary regression, packaging and physical approval remain pending.
Live561 unchanged. These entries supersede the older "modern not integrated"
status below, not its historical evidence.

## 2026-10-19 candidate562: retro profile and exact SDL UV sampling

New optional Spleen/Hibr profile:1,575 scalar mappings, all1,181 unique
fallback mappings retained;92 different printable ASCII masks. Protected
geometry/nonblank tests and pinned-source regeneration pass exactly.
Output SHA256 `13e0c44d6254d3de6b2eb1fac87fb8412bb3361ecd566517c8daabc9cc5cce37`.
New asset initially fails software U+2581 with only its last row painted;
GLES2 passes. Read-only SDL source plus repeated red test identifies integer
UV truncation with900px atlas extent. Power-of-two atlas allocation and
cached actual dimensions make the same software test green. No SDL changes.

Expanded oracle115cells/14,720exact pixels passes on software and offscreen
GLES2 for both Spleen and the original Terminus. Retro legacy scale and exact
8..64px glyph/reflow tests pass on both paths. UV round-trip, production damage,
held-scene pointer and two-renderer metrics fixtures pass on both. Default
font remains Terminus. Full regression is running; package/physical/aesthetic
acceptance remains pending. Modern colour/outline rendering is not delivered.

Full runner reports108pass/7skip/0fail;120-second four-PTY soak10,996
snapshots/1,000 resizes. The enclosing fingerprint guard exits1 because
Hibr changes257->258 (ABI16) during testing. Therefore this is NOT a
frozen-baseline full pass. Package/deployment is held pending a repeat on
an unchanged dependency baseline. Installed258 fingerprint after the run:
`a17716c1a56eb4ca9f0e691b4323dbd4cef300526f6a0b99ffaadda084a3ceeb`.
Three pinned-header adapter gates pass separately. Updated font fixture
passes retro software/GLES2 and default software separately; no weakening
of the glyph oracle is made to address the UV failure.

## 2026-10-19:561 deployed and physical font sizing exercised

Package source `65e785d`, identity `3c5371b`, SHA256
`728dc380db96faf5fd3859ed820eabaa4fd0ef5bbd3f10bb4108b8cda4a1d147`.
Independent packages match byte-for-byte; artifact/provenance gate and
API installation/version verification pass. Physical SDL/GLES2 bounded
font-size probe passes17/19/23px, unchanged two-pane physical regions,
grid bounds and BMP capture; restores scale1.0/16px, backend and bottom login
unchanged, clean storage revision162. Evidence:
`/tmp/blit-font-size-561-20261019/`. Captured scene is a screensaver, not a
desktop glyph specimen. This does not accept aesthetic quality, all Unicode,
new retro/modern fonts, colour glyphs, desktop pixels or performance.

## 2026-10-19 candidate561: exact font pixel-height policy

New font API regression fails before implementation, then passes for exact
8,16,17,19,23,32,48,64 heights with actual solid-glyph pixel checks. Legacy
scale, profile-only policy retention, invalid/duplicate/competing controls
and restoration pass. The shared fixture separately verifies actual offscreen
GLES2 identity and passes the same assertions. Updated schema assertions pass.
23px settings survive restart; only the selected policy is saved; a rejected
ambiguous settings write leaves the durable document/revision unchanged.
TCC, split/pointer geometry, production damage and three pinned-header adapter
gates pass. Full regression is running against installed0.99.257/ABI16,
checking installed binary identity before/after. No live561 result claimed.

Separate source-only feasibility probe `font_source_capabilities.c` compiles
with TCC and FreeType2.12.1. Hack provides partial grayscale coverage at
17/23/32em pixels; Noto provides a136x128 U+1F600 bitmap with10,279 coloured
pixels satisfying premultiplied-BGRA invariants. This is not Blit glyph
rendering or sequence acceptance. New retro/modern profiles, shared rich-glyph
data and native-size rasterization remain pending. Source identities and
licensing review are recorded in `font-evolution-plan.md`.

Completed full run:107pass/7explicit skips/0fail;120-second four-PTY soak
11,816 snapshots/1,074 resizes. Hibr0.99.257/ABI16 binary fingerprint remains
`572f88f60eac0656bf6bd86b9a89a9a939de05caf03c5bd1175e87dce8dd4735`.
Updated shared font fixture separately passes on software and offscreen GLES2,
and updated schema assertions pass. The new bounded host font-size probe
passes locally with a real two-pane software server, capture and restoration.
Package/live verification remains pending here.

## 2026-10-19:560 physical comparison and package verified

Source `71d55cf`, manifest identity `4c7a629`. Independent builds are
byte-identical; artifact/provenance gate passes. API installation/version
verification passes. All three actual paths pass bounded motion12/12,
Kitty composition/deletion,2,688 font/grid pixels and sixel assertions.
Native/login/pointer baseline restoration passes. Evidence:
`/tmp/blit-backend-cadence-560-240hz-20261019/`.

| Backend | Delivered motions | Client queue skips | Request p95 ms | Submissions/s | Confirmed flips/s |
| --- | --- | --- | --- | --- | --- |
| native KMS | 2,400 | 0 | 19.78 | 59.39 | 59.39 |
| SDL/software | 2,400 | 0 | 32.88 | 59.82 | unavailable |
| SDL/GLES2 | 2,394 | 6 | 33.92 | 59.32 | unavailable |

Ten-second240-slot/s sweep, with restoration motion included in server
counters. Setup-time p95=11.66/11.92/12.80ms and post-connect exchange
p95=11.84/26.14/25.52ms respectively. Neither is server-only processing or
input-to-photon latency. SDL559 previously skips171/154 and p95=51.76/
51.45ms: this sample improves but does not establish sole causality for
every RTT difference. One approximately60Hz DP canvas, no physical mouse
events, no terminal-output workload. All report0missed deadlines in this
sample. Longer repeated acceptance and physical multi-connector/hotplug/
high-refresh testing remain open;105 stays open for residual pressure.

## 2026-10-19 candidate560: ready request is serviced at bounded admission

The actual admission helper fails a new socket regression before the change:
a complete request is queued before accept, but no response is produced by
the bounded turn. Accepted sockets now explicitly use `O_NONBLOCK`, with
one call to the existing request-service function per admission. The socket
regression passes afterward. Empty clients, capacity and descriptor flags
remain checked; software and offscreen GLES2 production fixtures and the
delayed-present burst pass. TCC build succeeds.

Full regression and physical revalidation remain pending. No560 live result
is claimed. Idle network spot checks independently show curl connect times
around102ms then949ms, with2.6ms from connect to first response on the latter,
and one ICMP sample43ms. These are transient point observations, not a stable
transport baseline. They reinforce separating request RTT from server-stage
latency rather than attributing every observed delay to Blit. ADR0142 records
the bounded change;105 remains open until physical revalidation.
The first full run exposes a font-fixture race: the child writes `ready`
between revision GET and cell PUT, producing a legitimate409 conflict.
A silent-child attempt exposes the fixture's cursor-at-origin dependency
instead. The final test-only correction retains the marker and waits for
its actual cell contents before reading the revision; it both removes the
competing write and parks the cursor away from the glyph oracle. The focused
font gate then passes. No production font/cursor/revision change is made;
the interrupted full run is not a pass.

A later full run finishes106pass/7skip/1fail at native restart/rejoin.
ADR0143 identifies a Blit placement-helper coordinate translation error:
`hold move` is native-primary-relative, not absolute. The corrected helper
passes the explicit nonzero-primary regression and the installed-desktop
variant with resize, preserving the selected primary and user placement.
A fresh full run uses operator-frozen Hibr0.99.256/ABI16, with installed
binary fingerprint checked before and after. It is still in progress here.
The three separately invoked pinned-header adapter gates pass.

Fresh complete run:107pass/7explicit skips/0fail, including six offscreen
GLES2 gates. Four-PTY soak:120seconds,11,504 snapshots,1,046 resizes.
Installed Hibr fingerprint is unchanged before/after:
`1dd031259b4d16ccbfc3c0ffe6335d28fdaaa6be4d2cfe0f6187b6d1680a73b9`.
This supersedes the failed candidate runs for local regression only;
package reproducibility and physical comparison are not yet accepted.

## 2026-10-19:559 physical admission improvement, residual pressure remains

Package559 is deployed/version-verified; independent builds match. Package
SHA256 `a683956a73b6aff17eb820b045977247aa8c050f2bdd89be60c36a98177089b6`,
source `f87def0`, identity commit `9c1b80f`.

All three actual backends pass motion12/12, Kitty composition/deletion,
2,688 grid/font pixels and sixel checks. Native/login/pointer restoration
passes. Evidence: `/tmp/blit-backend-cadence-559-240hz-20261019/`.

| Backend | Delivered motions | Client queue skips | Delivered requests/s | Request p95 ms | Submissions/s |
| --- | --- | --- | --- | --- | --- |
| native KMS | 2,400 | 0 | 238.72 | 27.94 | 59.15 |
| SDL/software | 2,229 | 171 | 220.71 | 51.76 | 58.30 |
| SDL/GLES2 | 2,246 | 154 | 223.46 | 51.45 | 58.65 |

Native confirmed flips match its submission delta. SDL completion rates are
unavailable. Workload is10 seconds with240 requested pointer slots/s; final
restoration motion and server observation boundary overhead are labelled.
No physical mouse events occur. These short samples do not accept the full
performance contract. The SDL delivered rate is over3x its prior67–71/s and
p95 improves from approximately135ms, but client skipping remains. Keep105
open and reproduce the remaining first-read turn delay before changing it.

## 2026-10-19 candidate559: bound HTTP admission rather than one per refresh

`http_accept_budget_gate.rb` uses the actual gateway/SDL renderer with a
test-only16ms public-present delay. Eight queued requests finish at
17.57..139.39ms before the change, exceeding its80ms regression budget.
The bounded nonblocking admission change makes all eight finish within
17.83–18.29ms in focused runs. A subsequent single request completes too.

The production-code socket fixture checks the eight-admission bound,
under-filled draining, existing render work/deadline retention, descriptor
inheritance,32-client capacity and five503 overflow rejections. TCC build
and focused fixtures pass. Full regression passes107 gates with7 explicit
skips and0 failures, including six offscreen GLES cases. Its120-second
four-PTY soak completes11,320 snapshots and1,030 resizes. No559 deployment or
physical throughput improvement is claimed. This gate does not change the
physical latency/performance acceptance thresholds. ADR0141 and issue105
record the decision and required live revalidation.
The same fixture also fails on actual offscreen GLES2 with the manifest-
matched0.1.558 staging binary (last response142.53ms), then passes against
canonical0.1.559 (18.21ms). This is a separate focused GL run, not a claim
of physical GPU scanout timing. Three pinned-header adapter gates pass.
Terminology correction: the earlier short, HTTP-paced cadence samples do
not by themselves establish a pass or failure of the sustained physical
refresh acceptance plan. Its status remains open; the measured rates and
producer/boundary limitations remain recorded unchanged.

## 2026-10-19: 558 deployment and bounded physical revalidation

Package 0.1.558 is installed/version-verified. Its independent builds match;
SHA256 `299075721ddf7409d64d401594df2cea7b278b6042698f7314ebeab927a36532`.
Source `c411650`; package identity commit `71a7c45`.

All three physical backends pass motion (12/12), Kitty composition/deletion,
2,688 grid/font pixels and sixel assertions. The native 10-second diagnostic
sweep records 51.26 confirmed flips/s with 59.20 offered input requests/s.
The prior 557 runs recorded 38.72 and 40.85 confirmed flips/s. Retained render
tails show 0 no-op attempts in 63 events on558, versus14 in64 on557. The
tails are bounded and not whole-run counts. This supports the targeted fix,
not general 60Hz or latency acceptance. SDL/software and GLES2 measure52.83
and52.24 submissions/s; confirmed completion timing is unavailable.

Evidence: `/tmp/blit-backend-cadence-558-20261019/`. Native/login/pointer
restoration succeeds. Sustained and multi-connector acceptance remains open.
Issue105 separately tracks the controlled one-refresh-per-HTTP-connection
failure (eight queued responses at17.57..139.39ms with a16ms present delay).

## 2026-10-19 candidate 558: completion no longer fabricates visual work

The actual KMS service path is extracted into one production helper, then
tested with cached adapter metadata. Before the fix, an idle completion
creates a render request and moves the deadline from 16000 to 32666; the
regression reports that failure. Removing the unconditional request preserves
both idle deadlines and existing pointer work. Recovery metadata still
requests rendering explicitly. Existing ready-output retry checks also pass.

The production-code fixture passes on software and offscreen GLES2 alongside
held-scene pointer, graphics sampling and independent-output metrics. TCC
build succeeds. The first full run was intentionally stopped to add the
timeout-recovery guard; its partial results are not a full pass. A fresh full
run passes 106 gates, with 7 explicit skips and 0 failures, including six
offscreen GLES cases. Its 120-second four-PTY soak completes 11,416 snapshots
and 1,038 resizes. The three adapter gates pass separately against the pinned
Hibr 0.99.225/ABI16 headers. Candidate 0.1.558 is not packaged/deployed yet, and no
physical performance improvement is claimed before revalidation. ADR0140
records the decision and the captured timeline.

The unchanged live 0.1.557 baseline was also sampled with 240 requested
pointer slots/s for 10 seconds. Native delivers all 2,400 injections (237.26/s
over client elapsed time), with request p95 29.66ms and 56.15 confirmed flips/s.
SDL/software delivers 745 (70.88/s), skips 1,655 at the client's bounded queue,
and has p95 135.13ms; SDL/GLES2 delivers 706 (67.26/s), skips 1,694 at that
queue, and has p95 135.43ms. SDL submission rates are 57.62/s and 57.49/s;
completion rates remain unavailable. These are client-side skipped offers,
not demonstrated server-side input loss. They invalidate any claim of an
identical continuously pending accepted-input workload across these runs.

Evidence: `/tmp/blit-backend-cadence-557-240hz-20261019/`. All pixel/protocol
checks still pass and native/login/pointer restoration succeeds. The API
throughput/latency gap requires its own reproduction; the event loop accepts
one connection per turn, but causal attribution needs a controlled test.

## 2026-10-19: bounded cadence diagnosis, not performance acceptance

The measurement regression fails against the previous pointer probe because
it lacks the server observation interval. The corrected probe passes exact
server-window rate arithmetic, separate native completion/SDL-unavailable
semantics, and rejection of restart, output removal, refresh change and zero
observation interval. Failure-restoration coverage passes separately.
Timing suite passes 3 gates with 2 explicit physical-host skips and no failures;
the 120-second four-PTY soak completes 11,876 snapshots and 1,080 resizes.

Live 0.1.557 exploratory API-injected sweeps produce:

| Backend | Offered requests/s | Output submissions/s | Confirmed flips/s |
| --- | --- | --- | --- |
| native KMS | 58.78 | 38.72 | 38.72 |
| SDL/kmsdrm/software | 59.31 | 54.44 | unavailable |
| SDL/kmsdrm/opengles2 | 59.27 | 50.78 | unavailable |

Evidence: `/tmp/blit-backend-cadence-557-20261019/`, including both raw server
observations and all pixel-probe results per backend. Workload: 10-second,
12-pixel pointer sweep with concurrent HTTP requests at advertised refresh;
final restoration motion is included and explicitly labelled. Native receives
601 position changes/input events, no physical mouse events and no PTY bytes;
409 submitted flips complete and 147 pointer-affecting attempts defer. The
server observation interval includes HTTP boundary overhead. Arrival ordering
is not deterministic and this is not physical input-to-photon measurement.

All three still pass motion, Kitty, font/grid and sixel correctness assertions;
native/login/pointer restoration succeeds. These rates do not accept the
refresh target or establish the cause of the cadence gap. Issue101 remains
open. Longer acceptance workloads and multiple connectors remain untested.

## 2026-10-19: physical sixel checks and split-origin fixture

The operator's existing sixel assertions pass on live 0.1.557 through direct
KMS, SDL/KMSDRM software and SDL/KMSDRM OpenGLES2. The same run repeats all
previous motion (12/12 per backend), Kitty composition/deletion and 2,688
font/grid-pixel checks successfully. Evidence directory:
`/tmp/blit-backend-parity-557-sixel-20261019/`. The native baseline/login
policy and pointer pose are restored after comparison.

The probe now explicitly attaches its pixel scenario to a free pane, verifies
that attachment, samples relative to its actual grid origin, reads real BMP
offset/depth/orientation and requires capture revision/presentation agreement.
Its decoder assertions retain independent surfaces. Software and offscreen
GLES2 also pass the local lower-pane fixture at origin 0,384, with the upper
pane occupied. Original un-split fixture passes are not claimed as evidence
that its former fixed-origin probe correctly tested split panes.

This adds bounded protocol evidence, not universal sixel conformance or
performance acceptance. The comparison failure-restoration gate still passes.
No runtime or Hibr implementation was modified.
The complete renderer plus GLES suites pass 63 gates, with zero skips and
zero failures. This includes the lower-pane sixel fixture and six actual
offscreen GLES cases. The failure-restoration gate passes separately.

## 2026-10-19: 557 physical comparison passes bounded cases on all three paths

The updater installs and version-verifies 0.1.557. Package/artifact provenance
passes and a second independently built package is byte-identical. Source:
`7dfc512`; package manifest: `releases/0.1.557.yaml`.

On 10.54, each actual presentation identity passes the same assertions:

| Identity | Motion captures | Kitty composition/deletion | Font/grid pixels |
| --- | --- | --- | --- |
| direct KMS | 12/12, no discarded samples | exact | 2,688 exact |
| SDL3 / kmsdrm / software | 12/12, no discarded samples | exact | 2,688 exact |
| SDL3 / kmsdrm / opengles2 | 12/12, no discarded samples | exact | 2,688 exact |

Evidence directory: `/tmp/blit-backend-parity-557-20261019/`. Baseline
restoration verifies direct KMS and the original login policy after the
comparison; the original pointer position is restored. Hardware under test
has one connected 1920x2160 DP canvas split 1x2. This is not multi-connector,
high-refresh, physical-input or full protocol acceptance. Sixel, hotplug,
broader effects and sustained cadence/latency require additional evidence.

## 2026-10-19:556 physical evidence and557 graphics-sampling regression

Two independently built0.1.556 packages are byte-identical; artifact and
provenance checks pass. Package SHA256:
`8c5f803f813787b40cb10230403b2713f8fde50e145cc456d3b6c6cd0860ce39`.
The supervised updater installed it on10.54 and verified its version.

The first native motion trial had11/12 matching frames; the failed capture
contains a software pointer in the checked region. Inspection of the saved
capture identifies that footprint. The probe now parks the pointer outside
the fixture and checks its reported state. No failed pixels are masked.
The rerun passes12/12 coherent captures on both native and SDL/software;
native Kitty quadrants/deletion pass. SDL/software Kitty samples include
red211,31,13 instead of255,0,0 and blue31,31,223 instead of0,0,255.
The actual identities were `drm-kms/direct-kms` and
`sdl3/kmsdrm/software`. Automatic restoration to native and enabled login
was verified after failure. Evidence: `/tmp/blit-backend-parity-556-20261019-b/`.

The0.1.557 regression exercises the production graphics-texture path and
fails before the fix at pixel2,0 (223,31,0 vs255,0,0). Explicit nearest-neighbor
sampling makes all256 tested image pixels exact on two software renderers
and two OpenGLES2 renderers. GLES suite passes 5/0/0. Full regression passes
103 gates, with 7 explicit skips and 0 failures. The 120-second four-PTY soak
completes 11,560 snapshots and 1,051 resizes. The three adapter gates pass
separately against the pinned Hibr 0.99.225/ABI16 headers; no Hibr source is
modified. Physical revalidation remains pending; the filtering mismatch is not yet
claimed fixed on the physical host.

## 2026-10-19 candidate0.1.556: backend selection API and expanded GLES checks

`backend_selection_gate.rb` was red before the new backend setting existed,
and now passes deferred apply with the same terminal process, durable save,
eight invalid-value/type rejections without mutation, failed writer preserving
the last durable selection, precedence in both directions, renderer restart
flag, reset, ignore recovery and API availability when KMS initialization fails.
TCC build and schema/lifecycle suites pass17/0/0. The full run passes99 gates,
7 explicit skips,0 failures, including the two GLES gates present at its start.
Its120-second four-PTY soak completed10,744 snapshots and977 resizes. The final
expanded GLES suite passes5/0/0 separately; the added comparison-cleanup gate
passes separately, injecting a readiness failure and verifying baseline
restoration while preserving unrelated settings. These focused runs cover
the test additions made after the full runner started.

The explicit GLES suite passes5/0/0 using verified offscreen/OpenGLES2 and
software GL. The shared fixtures cover geometric/wide glyphs and half blocks,
Kitty z bands/default-background transparency,12-step motion trails with799
blank cells checked, wallpaper survival/deletion, held-scene pointer pixels
and two-renderer timing/counter isolation. The motion fixture reads actual BMP
stride/depth/orientation rather than assuming a24-bit framebuffer. No new
pixel oracle or production renderer was introduced.

The live host has not been updated in this cycle yet; physical SDL/KMSDRM
and multi-output timing acceptance remain open.

## 2026-10-19 candidate0.1.555: independent SDL output presentation metrics

The production SDL finish path now counts/times each output independently.
The existing per-output API fields retain their shape and gain explicit
OpenAPI semantics; runtime aggregate counters remain unchanged. Output
resource teardown resets the new counters. The TCC build succeeds.

Red/green evidence: before the fix, a production-code two-renderer fixture
presented output1 once and observed the idle output2 incorrectly reporting
`present_calls:1`. After the fix, the same fixture passes output counts2/1,
aggregate3, global-timing isolation,60/120Hz scheduling periods and reset at
resource teardown. The held-scene pointer pixel fixture also passes. The
schema/API suite passes5 gates with0 skips and0 failures. Full suite passes96
gates with7 explicit skips and0 failures. Its120-second four-PTY soak completed
11,252 snapshots and1,023 resizes. Skips are the three adapter gates without
the pinned checkout, explicit QEMU oracle, package validation without a new
package, and the two physical-host gates. Candidate0.1.555 has not been packaged or deployed; live10.54
remains0.1.553. No physical SDL scanout or cadence claim follows from this test.

`tools/run-gates.sh gles` passes2/0/0. It runs the same wallpaper-damage and
image-deletion assertions through SDL offscreen/OpenGLES2 with software GL,
checking the actual renderer identity before accepting pixels. The second
gate runs the production output-metrics fixture with two verified GLES2
renderers, checking independent counters/timing and teardown reset. This is real
GLES2 coverage for these fixtures; GPU/KMSDRM/multi-output scanout
acceptance remains open. The suite is explicit because standard `all` also
runs on environments without EGL/GLES.

The same held-scene pointer fixture now selects the requested driver/renderer
and verifies their identity. Its12 positions and complete pixel comparisons
pass on software and GLES2, preserving pending visuals until release. This
extends the existing fixture rather than creating a separate GL oracle.

## 2026-10-19: KMS checkpoint and first parity fixture

The authenticated live API returned0.1.553. Annotated tag `v0.1.553` was
pushed at source86d28b2, matching the release manifest's source and package
identity. The annotation retains issue101's open physical-motion performance
acceptance. Neither the live renderer nor sessions were changed.

The existing SDL wallpaper-damage gate now accepts explicit driver/renderer
inputs, checks ready/backend/driver/renderer identity before pixel assertions,
discovers a display and attaches its fixture explicitly. The default
dummy/software run passes all original wallpaper damage/deletion assertions.
On this host, requesting `opengles2` with the dummy driver fails the new
identity assertion. Running the pre-change fixture with that identical
requested renderer incorrectly reports a pass, proving that the added check
detects a real coverage gap. This environment has no `/dev/dri`; actual SDL
KMSDRM/GLES2 and physical multi-output acceptance remain pending.

`tools/run-gates.sh renderer` passes56 gates, skips0, fails0 against the
existing0.1.554 local binary. Only test tooling/documentation changed; no
new runtime binary or Debian package was produced by this increment.

The [parity matrix](history/backend-parity-matrix.md) inventories recent direct-KMS
work and common feature requirements under issue104. It records pending
acceptance rather than extrapolating local software results to hardware.

## 2026-10-19:554 pointer-state transition counter candidate; local gates pass

Candidate0.1.554 adds `performance.pointer_position_changes`, incremented
only when Blit accepts a new pointer coordinate or output after processing
physical or API-injected input. The direct-KMS lifecycle gate injects one
position and requires this counter and the per-output pointer request and
submission counters to advance. TCC0.9.27 build and API schema/observation
checks pass. The complete local run passes **96, skips 7, fails 0**; the
120-second soak completed with four sessions, 11,364 snapshots and 1,034
resizes. Skips: three Hibr adapter gates, opt-in QEMU oracle, package-artifact
gate (run separately), and two live-host gates. This bridges raw evdev report
counts to frame submission in the API contract, without changing input,
render scheduling, or pixels. Package and live validation are pending; no
claim that this fixes observed pointer cadence is made.

## 2026-10-19:553 pointer-presentation telemetry deployed; cadence still low

TCC0.9.27 builds version0.1.553. The candidate adds per-output KMS counters
for pointer-intersecting present attempts, attempts deferred by output/flip
state, and successfully submitted pointer-bearing frames. The direct-KMS
mock lifecycle injects a pointer move and requires its output request and
submission counters to advance. SDL observation verifies all KMS-only and
pointer counters remain unavailable/zero. Schema/API suite passes **5/5, no
skips**, and direct-KMS lifecycle passes with allocation/free balance20/20.
The full local `tools/run-gates.sh all` run passes **96, skips 7, fails 0**;
the 120-second soak reports four sessions, 11,748 snapshots and 1,068 resizes.
The seven skips are the three Hibr adapter gates, opt-in QEMU oracle,
package-artifact gate (run separately), and two live-host gates. This remains
mock/local evidence only. The reproducible package hash is
`e5909075c0a38e1cfdaed21c3d68f19659716e9976caca7df82bfe36956cb010`; it is
deployed and version-verified on10.54. In an approximately8s physical-motion
sample, the DP canvas submitted114 frames (100 pointer-bearing) and HDMI
submitted57 (54 pointer-bearing); respectively30 and12 pointer attempts were
deferred. Raw mouse motion was received, but the sample includes two button
events and is not mouse-only. A separate360-event synthetic API sweep took
7.43s at a requested60Hz and produced224 DP submissions (30.16Hz); HTTP
request p50/p95 were19.99/23.01ms, so this does not isolate renderer cadence
from API transport. No Hibr source or live settings were changed. Physical
visual acceptance and exact input-to-pointer-state correlation remain open;
this release adds diagnostics, not a fix claim.

## 2026-10-19:552 scanout telemetry deployed; physical motion remains slow

TCC0.9.27 builds the candidate with server version0.1.552. The direct-KMS
hotplug/lifecycle gate verifies `kms_scanout` reports a completed page flip,
nonzero vblank sequence/timestamp, and a measured vblank span from mock DRM
callbacks. API schema, SDL observation semantics, and the full schema suite
pass (**5pass,0skip,0fail**). The Debian artifact is byte-identical across two
independent builds and passes package provenance validation; it was deployed
and verified on10.54 via the supervised updater. A4.19s physical-motion
sample measured59.909/59.999Hz vblank on DP/HDMI,84 DP frame submissions,zero
HDMI submissions,212 relative mouse events,117 sync reports and20 pointer
position traces. Global composition reported5.907Hz and the maximum loop-gap
window was10.327ms. Twenty-two Hibr frame-barrier timeouts overlapped the
sample, but no causal pointer/frame association existed yet. This establishes
that monitor scanout clocks are normal and Blit's changed-frame cadence is
low; it does not isolate the responsible Blit scheduling/damage path.
Candidate0.1.553 adds per-output pointer request/defer/submission counters. No
settings, sessions or Hibr state were modified during the sample.

## 2026-10-19:551 live cadence probe; wallpaper/UI acceptance not complete

API-deployed Blit0.1.551 remains active. On the current single DP output
(1920×2160,59.997Hz) with two Hibr pane clients, the bounded API-injected
60Hz sweep submitted305 frames/6.025s (50.62Hz) at1px/event and356/6.024s
(59.10Hz) at8px/event. Both had zero scheduler missed deadlines and zero
physical mouse events. Blit CPU was9.49% and10.41% of one core respectively;
these measurements do not cover the physical mouse or a button-held window
drag. Earlier, with two outputs inventoried, a separate1px/event run submitted
123 frames/6.023s (20.42Hz); state/topology differ, so no causal conclusion.
The host later reported only the DP output; the cause is unknown. #101 stays
open. Evidence: `diagnostics/persistence-motion-551/` (ignored local captures).

The API screenshot of the desktop's Hibr `htop` lists eight
`desktop [sess…]` process rows at12.4–19.8% CPU. This points to host workload
worth investigating, but does not prove they are duplicate desktop owners.
No process was killed. The authenticated Blit view verifies the managed Hibr
owner/clients only, not unrelated process ownership.

Wallpaper acceptance is **not verified**. Native UI navigation during the
test was incorrect; an earlier Hibr panel capture showed `retro_car.png` for
`blit-DP-1-p2`, while a later live surface snapshot showed All Displays with a
pattern and no image. A live Terminal/editor is visible in the last capture;
the effect of injected keystrokes on its unsaved buffer is unknown. Do not
continue UI input or assert the original wallpaper is restored until that
state is inspected safely. No Hibr code/settings file was edited. #103 stays
open; the deployed stable names alone do not pass its wallpaper round trip.

## 2026-10-18:550 deployed; stable native names and cursor framebuffer verified

Runtime/documentation source a1ce53d, TCC0.9.27; package and binary identities
are fixed by `releases/0.1.550.yaml`. Byte-identical server and reproducible
package rebuilds pass. Frozen all-suite: **99pass,3skip,0fail**.120s four-PTY
soak:11272 snapshots/1025 resizes. Skips explicitly remain QEMU, physical
multi-display gate and live screenshot backpressure. Separate actual SDL
pointer gate verifies25472 pixels/3shapes/2sizes/4rotations. It was registered
in the runner after the loaded full run; its pass is not in the99 count.
The extended actual native CLI gate also passes literal `name#2` rejection.

API updater verifies550 on10.54. Complete settings document and revision72,
font1.0, `drm-kms`, both physical output geometries and lower primary are
preserved. Three quiet authenticated observations verify one UID1000 owner
and primary `blit-DP-1-p2`, upper join `blit-DP-1-p1`, HDMI join
`blit-HDMI-A-1-p1`; both managed joins are confirmed. Local native restart
retains exact client names and held owner without aliases. Real per-display
wallpaper persistence across another restart remains #103 acceptance.

Read-only host canonical-art checks match142 opaque cursor pixels/hotspot on
each physical output, default arrow/pearl24/shadow. The initial DP capture is
pre-desktop first paint, not a desktop rendering acceptance. Later cached
DP/HDMI captures show wallpaper and application windows. No universal
rendering or physical-latency claim follows. Two bounded asynchronous550
pointer probes:110 submissions/6.039s and115/6.125s on DP-1, CPU6.62/6.08% of
one core. Workload/location differs from548; #101 stays open. Files:
`diagnostics/mouse-550/`. Catalogue0.1.5 remains the single Blit/Blit Mouse
bundle; user catalogue installation is separate from its published/tested state.
Final550/a1ce53d retest with installed Hibr0.99.250 ABI16 passes Mouse callback,
shared polling/private-credential restoration, native Blit grid/font and Mouse
size64/save interactions, plus signed isolated catalogue install/update/remove.

## 2026-10-18:549 mouse local checkpoint, not yet deployed

Superseded by550 before deployment. The later549 final collection was stopped
after release review, not counted as complete. New pointer API scope regression
is red on549 and green on550: opaque nested extension preserved, canonical and
escaped duplicate top-level keys rejected, escaped appearance/member names
decoded, invalid requests leave state unchanged.550 also passes live apply,
stale409, font independence and durable restart in that focused gate. Final
full/package/live validation is pending here.549's byte-identical TCC and
reproducible package checks passed, but are not a550 release claim.

Stable-name addition (ADR0135/Blit#103): the actual native regression fails
the preceding timestamp-name binary, passes549, and verifies both names
across a server restart with the same held owner and no aliases. Installed
Hibr0.99.250 ABI16 duplicate-name and colon/dot grammar tests pass. TCC tests
cover numeric-ID churn, name bounds, unsafe selectors and managed/inventory
collisions. Existing login-generation test now expects a stable name while
still requiring a new session generation and newly verified owner lifetime.
Final frozen package and physical wallpaper persistence remain separate.

Initial full collection98pass/4skips/0fail,120s soak10364 snapshots/942 resizes.
No package was supplied; the other skips are QEMU, physical multi-display and
live screenshot backpressure. Shared art tests cover3shapes/4palettes/41sizes;
appearance API rejects invalid changes without mutation, persists across
restart and is independent of font. Production KMS verifies48 full frames
including edges/hide/size/shadow changes; actual SDL pixel test separately
verifies25472pixels across3shapes/2sizes/4rotations. Native Mouse callback and
UI drag-to64/save pass locally. Pending: final source/package freeze, catalogue
retests against the current Hibr, #103 stable-name integration and real host
deployment/acceptance. Evidence remains `diagnostics/mouse-547/`.

## 2026-10-18:548 nonvisual PTY correction, physical acceptance pending

547's final frozen collection completes97pass/3explicit skips/0fail;120s
four-PTY soak10996 snapshots/1000 resizes. The corrected diagnostic package
identity is `releases/0.1.547.yaml`, source96a9425. It remains a diagnostic
checkpoint, not a fix for jerky input.

The revised pointer probe offers eight bounded asynchronous request workers
to avoid serializing60Hz injection behind the measured network RTT (one ping
54.6ms). The547 baseline enqueues360 motions with no late slots or skips,
completes in6.105s, records117 submissions on pointer outputDP-1 (53 on the
other output), and Blit27.99% of one core. Request p50/p95 are35.85/62.84ms.
This proves actual injection intent/counters, not physical input-to-photon
latency. Same-coordinate alternating motion can coalesce; submitted frames
are not necessarily completed scanout. Earlier serial HTTP results were
network-limited and cannot establish the renderer's ceiling. Evidence:
`diagnostics/mouse-547/async60-final/pointer-cadence.json`.

Production parser test fails twice before the correction (hidden-cursor
controls and partial APC schedule visual work) and passes after. It checks
mode/title/cursor state still changes, printable cells still cause damage,
and retains the existing large-PTY/ten-fragmentation tests. The return value,
not parsing or backend selection, is corrected. Broader548 tests/package/live
measurements remain pending. ADR0134 and Blit#101 track this separately from
cursor appearance#102.547 is already API-deployed for phase measurements;
copy/submission are much cheaper than the measured expensive drawing frames.

## 2026-10-18:0.1.547 KMS phase instrumentation checkpoint

The user still reports jerky pointer motion on546. The physical host now has
DP-1 and HDMI-A-1, three occupied desktop panes. A bounded read-only runtime
sample (9.155s) records Blit34.18% of one CPU core, render calls20–42ms and
loop gaps31–59ms without new physical mouse-motion events. This establishes
a frame-budget problem, not its cause.547 adds per-output draw/copy/submit
timing and requested-cell counts to the existing observer; do not change
renderer/layout or replace authenticated desktops to investigate it.
Evidence: ignored `diagnostics/mouse-547/`. Build/gates/deployment are pending
at this source checkpoint. High-quality shared cursor styles and a native
Blit Mouse panel are the next requested implementation boundary.

## 2026-10-18:0.1.546 deployed; final local and bounded host checks

The frozen full collection with the exact package completes **97pass/3skip/
0fail**. The120s four-PTY soak records11288 snapshots/1026 resizes. Skips are
explicit: QEMU oracle, physical multi-display, live screenshot backpressure.
Manifest/artifact checks, byte-identical TCC server rebuild and reproducible
package rebuild pass. `releases/0.1.546.yaml` fixes the source/documentation,
package and runtime hashes. Commit7e4cd56 corrects only the auxiliary-policy
fixture's startup-save receipt ordering; the production artifact is unchanged.

The API updater verifies546 on192.168.10.54. Fresh scale1.0, pure `drm-kms`,
lower-primary policy, auxiliary intent and both240x67 grids are preserved.
Migration adds only the DP-1 output map plus revision59; the entire settings
response is unchanged across a subsequent API restart. The actual framebuffer
font/grid oracle passes21cells/2688pixels and removes its temporary PTY.

Catalogue pane0.1.4 (`hibr-apps:e309874`) passes actual callback/API, native UI
drag and signed catalogue lifecycle gates against546. Its native-order test
specifically restores URL preferences after sourcing the pane and before first
use: red0.1.3, green0.1.4. Publishing is not installing the app on the host.

After the user's authentication, API/native inventory verifies one owner,
primary lower/session1 and joined upper/session3,134x240 union. The captured
framebuffer shows pixel wallpaper on both and an About window below. A second
bounded360-motion API probe records369 output submissions/26.47s, Blit CPU
3.55% of one core, native-owner CPU delta0 and sampled submission rates
11.14–17.67Hz. It injects no clicks/drags; its pointer is near the pane boundary
and HTTP limits cadence. The earlier login-screen result was711 submissions/
24.83s/6.84% CPU. Neither establishes60Hz capacity, physical input latency,
authenticated drag correctness, or a multi-monitor speedup. Only DP-1 is
connected. An `input_device_missing` diagnostic warning also remains visible:
open keyboards2/pointers2 are below per-process peaks5/4. Source intentionally
warns on that reduction, not only absent inventory entries. Do not silently
turn it into either a healthy-input claim or proof of current input failure.

Blit#100/#101 remain open for actual second/third-output hotplug and the
reported desktop slowdown. Local clipping/scaler speedup is not their physical
acceptance. Evidence: `diagnostics/per-display-546/`; see current-state for the
resume point. Superseded545 remains explicitly not deployed/tagged.

## Historical pre-deployment checkpoint:0.1.546 durability correction

The first546 full run reports95pass/4skip/1failure. The failed controller
fixture sampled settings before the startup migration save settled; its
`join progress wrote settings` diagnosis was incorrect. The fixture now waits
for the canonical clean receipt before testing Apply/join independence, and
the targeted gate passes. The production hash is unchanged. A fresh full run
including the package gate is in progress. Both earlier output and the final
run are retained in `diagnostics/per-display-546/`.

The546 package SHA256 is
`c0d6e1c26970e4fef476b56b2f8ff6f6d6ac1dd1ec91347c20163b60f2a5223f`;
source/documentation commit `d7515efd48988ed46e1bb266bb860c41bb4891a1`.
Manifest/artifact checks, byte-identical TCC server rebuild, and reproducible
package rebuild pass before deployment.

The stronger native-order credential test fails pane0.1.3: cp_panes loads it
before dt_open/dt_load restores the saved network URL. Pane0.1.4 defers loading
until first use and retries on origin changes/explicit Reload. Its actual
callback/API, native UI drag and catalogue gates are being repeated; do not
claim the earlier new-process test covered this startup order.

The frozen0.1.545 suite completes96passed/4skipped/0failed, including the120s
soak with11156 snapshots/1014 resizes. Its manifest/artifact checks and
reproducible package/server rebuild pass. However, a new startup-only test
then fails against that exact archived binary: its in-memory migrated map
never reaches disk without a later settings mutation. A green broad suite
did not cover that invariant. The candidate is not deployed/tagged and its
immutable package identity is retained as superseded, not silently replaced.

0.1.546 schedules non-default legacy migration through the existing settings
writer. The new red/green test verifies the disk map before any API settings
write. The full independent-grid matrix, conflict/no mutation, same-PTY resize,
legacy capacity and restart tests pass against546. Its frozen server SHA256
is `24596e3cfd2fde4eae443759609aefebc547599973288e3e7382bd8e7c755d2f`;
the complete suite is running from that canonical artifact. Package and live
acceptance remain pending at this checkpoint.

Fresh10.54 observation shows the user changed scale to1.0/settings revision58
and restarted the desktop since the earlier1.5 baseline. Keep the latest
saved document and240x67 lower-primary/upper-auxiliary geometry during update.
OnlyDP-1 is connected. No host speedup or physical multi-output acceptance is
inferred from different workloads or font sizes.

## 2026-10-18:0.1.545 local candidate, physical slowdown still open

ADRs0131/0132 and public schema cover independent per-output grids and bounded
fractional image work. Against archived0.1.544, the new layout gate fails
`legacy grid not migrated`; old pane0.1.2 fails the native-slider assertion.
Current focused tests pass the1–8 grid matrix, saved/offline capacity,
occupied-pane409/no mutation, same-PTY resize, centred complete-cell bounds
and restart persistence. Hotplug's second/third outputs default to1x1 while
the primary grid and settings stay unchanged (mocked DRM, not physical).

The scaler regression is red before the fix (469154µs full/178884µs clipped
for20 draws), green after (447398µs/183µs), with exact RGB/RGBA/source-crop/
negative-origin/outside-damage pixels. The128-frame compositor oracle passes.
This demonstrates computational waste and its local removal, not a measured
physical-host speedup. Runtime adds cumulative process/native-owner CPU and
host load; native-owner PID/start-time protects against reuse.

Actual Hibr0.99.244 callback/API, isolated catalogue lifecycle and native UI
pointer-drag tests pass. Scale coalesces to the final requested2.3; actual UI
drag reaches1.2 and reflows. URL is written through native desktop settings;
API token survives a new process in a private data-only file, with origin
isolation, permission rejection, masking and export exclusion.

Initial broad checking exposed a missing required-schema declaration for CPU
fields; corrected network/auth retest passes. A subsequent broad run was
deliberately stopped for a legacy bulk/offline-capacity edge. No successful
complete-suite claim is made for either preliminary candidate. The final
frozen binary is SHA256
`6fbdbaa3e667c1e7783f0dfd2e73200350c4febdd7481242b71d6c054d3d01b4`;
its complete suite is running, with output retained in
`diagnostics/per-display-545/gates-final.log`. Package/release and real-host
deployment remain pending at this source checkpoint.

Live0.1.544 evidence currently has one connectedDP-1, scale1.5, two160x45
panes. Baseline pointer-only workload:360 motions,492 presents in23.96s;
request latency limits that workload, so it proves neither60Hz capability nor
the reported multi-output slowdown's cause. Blit#101 remains open until a
reconnected physical output and actual activity are measured. No Hibr-core
changes, backend substitution or SSH.

## 2026-10-18: deployed direct-KMS hotplug implementation (0.1.544)

The user-selected backend switch is observed on10.54 at0.1.543: direct KMS,
ready, lower preferred pane translated to DRM connector93, unchanged240x67
grids and saved `DP-1` upper auxiliary. After authentication, three read-only
samples verify owner296618/starttime67930595 and the exact lower-primary/
upper-auxiliary134x240 native union. This is association evidence, not a new
visual or physical multi-monitor acceptance claim.

TCC0.9.27 builds the frozen0.1.544 runtime, SHA256
`fc53615cceb68a341ba3033f97da30374cfdfa5f9e730347f444b4017cea680b`.
The actual gateway/direct backend runs against a test-only libdrm substitute:
second/third output discovery, removal/reconnect, unchanged primary/grid,
stable enumeration order, display/topology revisions, Apply/Save separation,
activation and teardown failure, quarantined recovery, failed/unknown probe
retention, zero-output startup/loss/return, mode-change PTY resize and orderly
direct-KMS restart pass. Thirty version requests overlap a300ms worker probe;
each remains below the gate's200ms bound. This is mock-boundary evidence,
not real-driver API latency or a frame-rate guarantee.

Red controls are recorded:0.1.543 times out waiting for new outputs; an earlier
0.1.544 candidate discovers them but fails `display inventory revision
unchanged`. The shared display-resource revision now advances with topology.
The separate64-cycle production lifecycle/cookie gate passes with primary
buffers unchanged, late events ignored, current events accepted and386/386
scanout buffers released. Compositor reference/pixel and generation/cookie
capacity gates pass. The frozen complete run finishes93 passed/four explicit
skips/zero failures, including120seconds of four-PTY soak:11,672 snapshots and
1,062 resizes. The64-cycle gate is additional to those93 and is now registered
in the renderer suite. Skips were package, QEMU, physical multi-output and
live screenshot backpressure; package validation passes separately below.

Control Panel callback/API and installed Hibr UI/keyboard gates also pass
against that frozen binary with Hibr0.99.244 ABI16. Its canonical bundle stays
0.1.2; hibr-apps documentation/UI-version-fixture updates are pushed through
commit106373d. Neither SDL nor Hibr source is modified. Physical second/third
monitor plug/unplug on the selected DRM device remains unverified.

Package `blit_0.1.544-1_amd64.deb`, SHA256
`bd9521943e054efb6ed25088b9c8f2b7d53fdd1c8ede4dc5b3046343082b5771`, is built
from source/documentation commit `8f45ccc45d37407d3e207e32e629013dfb552b17`.
Manifest/artifact gates and reproducible rebuild pass against pinned
Hibr0.99.225/ABI16. The API updater verifies live0.1.544 on10.54. The complete
saved document (clean revision44), active font and both pane grids are
identical across deployment. Pure KMS is ready, observer `uevent+periodic`,
with empty errors/warnings. Three observations show background scans20/21/22,
stable inventory revision1 and2.811/2.218/2.196ms scan duration: no unexplained
output recreation on the unchanged connected monitor.

The real-host framebuffer oracle passes21cells/2688pixels, including the
complete right-edge bold diamond. The temporary upper PTY is deleted and lower
login focus restored. Final inventory has one physical output, one lower login
and upper saved binding waiting for authentication. No post-update authenticated
desktop acceptance, second/third physical connection/removal, real-driver
failure injection or high-refresh workload is claimed. Evidence is retained in
ignored `diagnostics/kms-hotplug-544/`; source/package identity is in
`releases/0.1.544.yaml`.

## 2026-10-18: quiet pane0.1.2 and hotplug dependency diagnosis

The actual callback regression fails against pane0.1.1 with
`idle redraw launched early refresh`: it starts I/O after four seconds despite
a later refresh deadline. It passes with pane0.1.2 at `hibr-apps:cd417d0`:
quiet15-second refresh, deadline-sized desktop wakes,250ms completion checks,
15/30/60-second read-error backoff, no repeated invalid-URL starts per draw,
and no scratch-search I/O. Existing auth/offline/timeout/save/conflict/draft/
font/secret checks remain green. Installed catalogue lifecycle and actual
Hibr UI/keyboard gates pass; generated index signature verifies. Local UI
captures: `diagnostics/control-panel-012/`. No physical performance guarantee
or absence of every Hibr repaint is inferred from these tests.

Source inspection for#100 finds both startup-only Blit discovery and missing
runtime connector discovery in the bundled SDL KMSDRM backend. Its event pump
handles input only, while `KMSDRM_InitDisplays()` enumerates/adds displays at
initialization. Thus a Blit-only handler cannot establish real hotplug.
ADR0129 records the proposed dependency boundary and pending local SDL patch
decision. No dependency patch, Blit hotplug implementation, service restart,
renderer change or physical unplug/replug test occurred in this cycle.

## 2026-10-18: authenticated split acceptance and pane0.1.1

The user reports the live joined setup looks perfect. Read-only API evidence
shows one verified native owner293391/starttime67784223, lower primary at
`(67,0,67,240)`, upper managed auxiliary at `(0,0,67,240)`, union134x240.
The auxiliary reports `joined/native_client_verified` with confirmed
offset(-67,0). No diagnostic join, movement, input injection or restart was
performed. Evidence: `diagnostics/auxiliary-543/deploy/user-accepted-login.json`
and `joined-policy.json`. Three read-only native association samples also
pass, including background freshness and unchanged owner lifetime across
the observation TTL (`deploy/authenticated/`). This is acceptance of this physical one-output
split, not general monitor hotplug, every protocol or high-refresh workloads.

The catalogue pane is renamed **Blit**, version0.1.1, commit
`hibr-apps:2b2608e`. Actual Hibr registration asserts the exact new title;
callback/API, installed Hibr UI/keyboard and installed catalogue lifecycle
gates pass. Generated catalogue metadata/checksums and signature verify.
Screenshots: `diagnostics/control-panel-011/` (local SDL software, not a
physical capture). The server binary and live renderer/settings are unchanged.

Source inspection identifies a specific remaining gap: SDL display discovery
is startup-only, and its event handler does not reconcile display additions/
removals. The panel's observation refresh cannot compensate for that. Blit#100
tracks implementation and physical validation; the guides now state this
limitation explicitly.

## 2026-10-18: 0.1.543 package, catalogue publication and API deployment

The manifest gate and package artifact gate pass for
`blit_0.1.543-1_amd64.deb`, SHA256
`c77a52a0ce12a71cf054fb9286cb3246647cd06edeca93bf4b6601e4ed4de96d`, built
from source/documentation commit `61d4db1bfa90c67786a8890f100d3a500aa38c1b`.
The artifact gate verifies a reproducible rebuild and canonical packaged
README, schema and native placement helper. Adapter headers are the pinned
Hibr0.99.225, ABI16, not the newer installed runtime.

All three hibr-apps gates pass again against the final binary: callback/API
errors and bounded asynchronous behavior, actual installed catalogue
install/update/remove, and installed Hibr UI rendering/keyboard/token
masking. Pane0.1.0 is committed/pushed at `hibr-apps:2844df1`. Its generated
index signature verifies. An unrelated local Task Manager edit is preserved
and excluded; index generation used an isolated tree with its committed bytes.

The authorized updater verifies live0.1.543 on10.54. Independent before/after
checks preserve the complete settings document, active font, pane geometry,
SDL video driver/renderer/synchronization and report no diagnostic errors or
warnings. Afterwards, explicit Save adds upper `DP-1` pane1 auxiliary intent
with clean revision40; separate Apply reports waiting for authentication.
Only the lower login terminal exists, focused. The cached screenshot shows
its screensaver in the lower half and an empty upper half.
The read-only native association probe passes three pre-authentication samples;
a separate settings comparison confirms the auxiliary is the only saved
configuration change (apart from the server-owned revision).

Evidence: `diagnostics/auxiliary-543/deploy/` and
`diagnostics/control-panel-543/`. No authenticated physical automatic join,
catalogue mirror fetch, general multi-output/hotplug, high-refresh workload
or universal rendering acceptance is claimed by this deployment checkpoint.
Those boundaries require their own observations, not a successful updater.

## 2026-10-17: live auxiliary controller (0.1.543 local candidate)

TCC builds the server. `auxiliary_policy_gate.rb` passes authentication
waiting, exact native-inventory placement confirmation, one-time move,
user-move preservation, unknown release reporting, explicit stop/retry,
missing connector/pane, occupied primary protection, invalid request and
revision rejection, Apply/Save independence and boot restoration of defaults.
`auxiliary_native_gate.rb` passes with installed Hibr 0.99.241 ABI16 standby
and native hold in an isolated namespace: API startup, documented Enter join,
confirmed upper/lower placement, native user move, native drop with the
standby alive, q exit without respawn and logout cleanup. Its held workload is
sleep; the real desktop auto-invite loop is not tested by that fixture.
The additional installed-desktop mode (`BLIT_NATIVE_AUXILIARY_DESKTOP=1`)
passes automatic invitation and placement, native move/drop/quit and cleanup,
without injected Enter. A cleanup race found on its first run was corrected
by waiting for the scoped native owner/descendant lifetimes to end.
`native_hold_observer_gate.rb` also verifies the actual placement helper and
rejects a stale owner lifetime. OpenAPI schema gate passes with45 paths.
Package, broad suite, Control Panel and physical-host acceptance are pending.

The broad local run passes88 checks with seven explicit skips (package,
QEMU, physical-host gates and the three adapter checks whose default pinned
directory was absent), including a120-second four-session soak. The three
adapter checks then pass separately against the exact pinned0.99.225 headers.
Two original split fixtures failed first: one loaded a stale installed font,
and the barrier fixture could present one producer before creating its peer.
Pinning the canonical font and synchronizing both producers makes their
original assertions pass; no renderer code changed.

A final native regression changes font scale to1.1 while the join is pending.
It fails before the geometry guard:21-row panes retain the old24-row offset,
leaving a three-row gap. The controller now refreshes initial offsets until
confirmation, and reports an explicit Blit API pane reassignment as a conflict
instead of falsely claiming the configured pane is effective. Final focused
controller/native/schema gates pass after this scoped correction; the
broad result above predates that guard and is not represented as an identical
final-binary run. Package and physical-host acceptance remain pending.

The canonical Control Panel source in `hibr-apps` passes actual Hibr callback
tests against Blit: Apply/Save separation, staged import/export, stale revision
and503 save failure preserving the draft,401 authentication, offline/timeout,
nonblocking callbacks during the timeout, scale1.1, token masking and exports
without connection secrets. The installed catalogue client passes install of
an older fixture, update to the canonical0.1.0 hash, and clean removal in an
isolated scope. Actual installed Hibr desktop UI libraries render the pane
through SDL software; API-delivered keyboard input opens/closes connection
and token dialogs, and terminal cells and screenshots show a masked token.
Screenshots: `diagnostics/control-panel-543/{panel,connection,token-masked}.png`.
This is local UI acceptance, not a physical monitor capture.

## 2026-10-17: saved auxiliary intent (0.1.542 source candidate)

TCC 0.9.27 builds the 0.1.542 server. The existing settings persistence gate
passes with additional checks that two stable output/pane bindings round-trip,
survive restart, and reject duplicate bindings, pane ordinals outside 1–4,
unsafe output selectors, undeclared properties, and more than 16 entries.
Every invalid replacement leaves the prior revision and saved intent intact.
The OpenAPI schema gate passes. These are local source-candidate results; no
package has been created and 10.54 has not been updated. This delivers only
validated durable intent. It does not start Hibr standby clients, position
them, or change current-session Hibr Displays choices.

ADR 0128 specifies the next API/controller boundary: live Apply is volatile
and distinct from Save as default, with asynchronous per-binding states and
native proof of join/initial placement. This is a contract only; no Apply
endpoint, standby reconciler, or physical acceptance exists yet.

## 2026-10-17: native association client inventory (local candidate)

TCC 0.9.27 builds the server at version 0.1.541. The installed-Hibr native
CLI gate verifies the exact login client and, using `hold attach -m`, a second
simultaneous named client in one owner; both native rectangles are reported.
The synthetic login observer gate passes its ready/secondary/waiting/error,
owner replacement, freshness-expiry, cancellation and logout cases with the
new bounded `clients` collection. The OpenAPI schema gate passes. These are
local acceptance results only: this candidate has not been packaged, deployed,
or physically inspected on 10.54. It adds observability only; persisted
auxiliary policy, standby launch, one-time positioning and the Hibr Control
Panel are not implemented.

## 2026-10-17: deployed 0.1.540 native join PTY boundary

### Physical deployment checkpoint

The user explicitly requested deployment; preflight identity was waiting,
not an authenticated desktop. Manifest verification passes and the API updater
installs/verifies exact0.1.540. Before/after comparisons preserve font, both
pane grids, backend/sync/scale/inset and the complete settings document (clean
revision38). SDL `kmsdrm`/`opengles2`/`sdl-vsync` is unchanged. One focused
lower login terminal remains, upper pane free, no diagnostic errors/warnings.
The three-sample read-only pre-authentication association probe passes, as does
the physical21-cell/2688-pixel font/edge oracle; its temporary terminal is
deleted and lower focus restored. Evidence: `diagnostics/native-join-540/deploy/`.
After the user's normal login, the three-sample ready probe passes with
verified UID/GID1000, native owner254198/starttime64069385 and ownership role
primary/desktop. A recognized API upper join(id3) derives that user's identity
without an explicit `user` parameter and requests native initial row-67,col0,
derived from the current grid. A scoped native helper, invoked through a
temporary API diagnostic terminal as osakka, returns exactly
`ready 254198 134 240 0 0 67 240 0` for named client `blit-upper`. The main
association independently reports primary row67,col0,height67,width240 in the
same134x240 union and with the same owner/starttime. The diagnostic terminal
is removed; only primary1 and join3 remain. Passive physical input trace
records an upper press at target3/input3/local column95,row21. This is route
evidence, not proof of every button/gesture or its application response.

Joined and follow-up screenshots show wallpaper in both panes and the menu
bar on the lower primary, but also a persistent dark empty rectangle in the
lower pane beneath the upper Control Panel position. A sampled70x26 region
contains1820 blank cells with background `#120428` in the lower surface model.
Thus GPU cache staleness alone is insufficient; the incoming stream/parser
boundary still needs independent evidence. Do not label the entire desktop
visually accepted or infer a Hibr defect. Evidence: deployment `joined`/
`settled` captures, `lower-surface.json`, `upper-native-query.json` and
`pointer-buttons.json`. No injected clicks, Hibr-core edits, SSH or renderer
changes. Saved automatic provisioning and complete visual/input acceptance
remain pending despite the verified named attachment and input route.

The user subsequently reports the empty rectangle disappears after moving
the window. A new read-only capture confirms that separate orphan rectangle
is no longer visible: About on upper, Control Panel/Task Manager on lower,
menu on the lower primary. The same70x26 sampled region now includes wallpaper
half-blocks and actual window content rather than1820 uniformly dark blanks.
Its1099 remaining dark blanks overlap the currently positioned Control Panel;
that count is not evidence of continuing orphan damage. Owner254198/starttime
64069385 and the134x240 union remain unchanged. No diagnostic movement, input
injection or restart was used. Evidence: `after-user-move.{bmp,png,json}` and
`lower-after-user-move.json`. This is repaint-dependent recovery of this
scene, not a code fix or proof of the fault's producer. The current session
graphics arrays are empty and wallpaper cells include `▀`; do not label this
capture a Kitty/sixel pixel-path test. Raw-output/parser comparison across the
responsible transition is still needed.

### Pre-deployment validation history

References to pending deployment or the preserved0.1.539 host below describe
the earlier validation checkpoints, not the current installed version.

The revised `hibr_join_viewport_gate.rb` fails against0.1.539 with the precise
trace `target_session=2 input_session=1 column=129 row=1`. The TCC candidate
passes: target2/input2/local column1, independent primary/join surfaces. The
old input-owner redirection and horizontal coordinate helper are removed.
The launcher no longer moves the primary. Explicit one-shot native coordinates
are schema-bound and do not combine with standby.

`native_join_pty_gate.rb` uses installed Hibr CLI in an isolated namespace,
not a mock desktop: two67x240 clients yield primary `(67,0,67,240)` and upper
`(0,0,67,240)`. Raw input reaches the held program with lower row+67 exactly
once, upper coordinates unchanged, and button press/release, Alt modifier,
wheel and keyboard preserved. The held fixture and attach clients are removed.
An initial Ruby thread-rescue syntax error in this new fixture was corrected
before the oracle ran successfully; it was not a product or physical pass.

The initial expanded credential-dropping observer fixture passes recognized
login-owned join creation, derived UID/GID65534, missing service API token,
explicit negative placement, occupied-pane/identity/schema rejection, local
clicks and asynchronous logout cleanup (maximum API request37.46ms). Later
coverage adds owner replacement, query-expiry preservation and refusal of new
joins without fresh authority. Its first survival assertion incorrectly
required `running` for a silent `/bin/sleep` fixture that legitimately remains
`starting`; the corrected assertion permits either live state. This failure
alone did not establish that logout signalled the reported owner. The corrected
expanded run passes, including old-client retirement on verified owner
replacement, survival of the replacement owner across logout, preservation of
existing clients through a query failure, and refusal of new joins after TTL
expiry. Its maximum API request is56.43ms. A subsequent child-only hardening
closes inherited descriptors and copies HOME before supplementary-group NSS
initialization; the final broad run must include that change. Broad/package
and physical checks are still pending.

Source/documentation commit `22acbd61e76806f62c33e630dd24e8c3a3c5d8ba`
builds `blit_0.1.540-1_amd64.deb`, SHA256
`7df991c9e2e724ffa44ee3f9b471222f613ae9359e1f0db5daabe85253e137ec`.
Manifest validation, artifact checks and reproducible rebuild pass. The
package gate also compares changed `blit-session.hibr` to the recorded source
commit. A later test-only extension runs that actual launcher, rather than
only direct `hold attach`, against installed Hibr0.99.240 ABI16. All three
buttons' press/release, modified drag, both wheel directions and keyboard pass
the same independently observed134x240 union/input oracle. It is included in
the broad run; no production/archive
change followed22acbd6. Package headers remain pinned0.99.225 ABI16, not the
unrelated development Hibr tree. Physical acceptance remains separate.

The final full run uses that exact package and the strengthened actual-launcher
fixture, with `BLIT_GATE_REBUILD=1`: **90 pass / 3 skip / 0 fail**. It includes
the final inherited-descriptor/HOME hardening, credential-dropping owner/
expiry/logout cases, schema/terminal/font/renderer/input/Hibr/lifecycle gates,
package rebuild and120-second four-PTY soak (11,312 snapshots;1,028 resizes).
The skips are QEMU, physical multi-output and live screenshot backpressure.
The local cadence fixture reports60.006Hz, not a physical refresh-rate guarantee.
Evidence: `diagnostics/native-join-540/all-gates.log`. A final read-only host
observation confirms0.1.539 still running, one focused lower login(id3),
verified UID1000/native owner251045. No live join, renderer change, Hibr-core
edit or SSH. Safe upgrade clearance and native physical join acceptance are
pending; local test processes have exited.

The user requests saved automatic joins, not manual launch instructions. This
increment is their native boundary prerequisite; it does not claim saved
auxiliary policy, automatic boot/login provisioning or standby placement is
already implemented. The real host remains0.1.539; no renderer or live
authenticated-session change was made.

## 2026-10-17: deployed 0.1.539 native desktop association

### Physical deployment checkpoint

After explicit user logout/restart clearance, manifest verification passes and
the API updater installs the exact archive recorded below, then verifies live
server_version0.1.539. Before/after observations compare equal for the complete
settings document, both pane grids, active font and render backend/scale/inset.
Storage remains clean revision38. SDL `kmsdrm`/`opengles2`/`sdl-vsync` is unchanged.
One focused lower login terminal remains; the upper pane is free.

`host_native_association.rb` passes its real-host pre-authentication check:
three read-only samples separated by3.2s, identity waiting, desktop association
inactive, owner/client null. The temporary free-pane font oracle again passes
21cells/2688pixels, deletes its terminal and restores lower focus. A captured
image shows the lower login prompt and animated background. These are not
post-authentication association, desktop interaction or universal rendering
acceptance. Evidence: `diagnostics/association-539/{deploy,waiting,pixels}/`.

Following the user's normal login, the real-host ready probe also passes:
verified UID/GID1000, exact native client `blit-login-638499997805-1`, primary
67x240 at row0/column0, owner PID249984 with kernel starttime63853831. Three
read-only observations separated by3.2s retain that owner lifetime and contain
genuinely refreshed native observations despite exceeding the3s TTL between
requests. Observed ages are789203,150910,625710us. The API's post-authentication
association is ready/native_client_verified. The inspected screenshot shows
retro_car wallpaper and the menu bar on the lower pane; the upper is empty.
Evidence: `diagnostics/association-539/ready/` and `.../deploy/desktop.{bmp,png}`.
This verifies installed authentication/named association and quiet refresh,
not automatic joins, failover or universal rendering/physical input quality.
No join, Hibr-core edit or SSH was performed.

### Candidate validation history

The following records the pre-deployment chronology; references to a host
still running0.1.538 below describe those earlier checkpoints.

The new association assertion fails against 0.1.538: `native login association
API absent`. TCC builds 0.1.539. Expanded identity tests pass. The helper oracle
uses actual installed Hibr hold CLI in an isolated TMPDIR, creates only a
uniquely named fixture held program/client and verifies exact-name lookup,
67x240 geometry, missing owner/client and owner continuity. Its fixture is
removed. Synthetic worker-result tests separately exercise the controller's
real credential-drop/hook boundary and UID/start-time/geometry checks, malformed
integer/NUL/oversized output rejection, two-second timeout, shell/wait gating,
expiration and nonblocking logout. These are not actual PAM or native desktop
acceptance. Broader tests and package remain pending.

A scoped API-created native query on 10.54 reports UID1000, `desktop attached
247920 67x240`, `client-4 0 0 67 240 1`. The diagnostic terminal is deleted,
and the lower login focus restored. This proves the host's native query
interface, not that its old unnamed client is associated with the new API.
Host remains 0.1.538; no restart, join, renderer or Hibr-core edit. Evidence:
`diagnostics/association-539/live-query/native.txt`.

The schema/Hibr/lifecycle suite reports 27 pass / 1 skip / 0 fail (QEMU is the
skip). A manually overlapping observer-gate invocation separately saw an
unexpected oversized-output reason. Gate ports are now explicitly overridable,
and the final-drain path prioritizes output-limit rejection consistently with
the ordinary read path. The isolated expanded rerun passes, including logout
while a query is blocked, fresh login/name/owner generation and API latency
under its 500ms bound. The upcoming all-suite run uses the final source without
overlapping gate ports. This history is not a claim that the initial overlapping
execution was a clean pass or that concurrency alone proved its cause.

Package `blit_0.1.539-1_amd64.deb` is built from source/documentation commit
`573562705e52954c2c5d7572b78b8eb162c40f6f`, SHA256
`30daa8356f5068e8af101f8e90c6c62d4bc89754e256d69f5bfad91198f7eb35`.
Artifact validation/reproducible rebuild pass. The gate now additionally
compares both changed Hibr scripts to the immutable source commit, not only
their presence/executable bit. The read-only `host_native_association.rb` probe
rejects live 0.1.538's absent desktop field with zero mutations (initial KeyError
now replaced by an explicit missing-contract error). Its positive physical
waiting/ready checks are pending deployment/fresh login. Full all-suite run
includes the new package and is in progress. Host remains 0.1.538.

An isolated expanded run then reproduces `native_query_failed` during the
geometry scenario, ruling out shared ports as a sufficient explanation.
The synthetic helper could run before its target wrote the owner-PID file;
it incorrectly returned exit1 for that normal startup interval. The production
native helper already reports waiting/owner_missing for the equivalent state.
The fixture now does likewise, and its geometry scenario deliberately delays
owner publication by500ms and asserts that the missing-owner branch occurred.
An in-memory reproduction of the old fixture exit1 behavior fails deterministically
with the same geometry/native_query_failed result on its own port; the corrected
fixture passes. The missing-client assertion also waits past the legitimate
initial owner-missing phase rather than conflating the two waiting reasons.
No production source or archive changed for this fixture correction.

The expanded passing controller run additionally invokes the read-only
association probe against its known fixture: three samples separated by3.2s
quiet intervals, longer than the3s TTL, observe genuinely refreshed bindings.
Measured maximum API request latency in that run is21.32ms (fixture bound500ms).
This does not establish a physical refresh-rate guarantee or actual native/PAM
acceptance; those remain separate. Final broad run continues on the corrected
fixture and the same0.1.539 package.

The final full run, with pinned Hibr headers and
`BLIT_GATE_PACKAGE=blit_0.1.539-1_amd64.deb tools/run-gates.sh all`, finishes
**89 pass / 3 skip / 0 fail**. It includes both new observer gates, the corrected
startup-ordering fixture and quiet read-only acceptance client, existing
schema/terminal/font/renderer/input/Hibr/lifecycle tests, the pinned-script
package gate and the120-second four-PTY soak (11,480 snapshots; 1,044 resizes).
The three skips are QEMU, physical multi-output and live screenshot backpressure,
not implied passes. The artifact also independently rebuilt reproducibly.
No production source/package changes followed5735627; subsequent commits are
test, manifest and evidence updates. Host remains0.1.538 with its current
authenticated desktop preserved pending safe restart clearance. Actual named
login association on10.54 and standby joins are not claimed complete.

## 2026-10-17: deployed 0.1.538 private login identity

The new `login_identity_gate.rb` fails against 0.1.537 (`login identity API
absent`), then passes against the TCC 0.1.538 candidate. It uses real Hibr,
actual UID/GID 65534 dropping and a cleared environment to run Blit's hook for
both desktop and shell. The target observes no inherited handoff socket or
API token. Root, invalid payload, oversized datagram, FD-passing and
reparented foreign sender are rejected with explicit reasons. Custom commands
are unchanged; login destruction drops the identity and replacement has a
new session ID. Ordinary PTY traffic cannot register identity. A missing
acknowledgement times out after the configured five-second receive deadline;
the session still starts with its sender descriptor closed. The first expanded
test run exposed two fixture mistakes: TerminalInput was submitted as `text`
instead of `data`, and Ruby's socketpair sender was nonblocking unlike the
production sender. Both fixture corrections retain the actual assertions;
the expanded focused test passes. Schema/lifecycle suites previously passed
14/14 with no skips. Fixtures do not authenticate using PAM or prove held-owner
readiness. No automatic joins or Hibr-core edits. Broad/package/physical
acceptance are pending; live host is still 0.1.537.
The live capture shows a logged-in lower desktop and open Control Panel.
Deployment must wait for logout/operator clearance, not kill that session
merely to test the new login boundary.

Source/documentation commit `30cdfdb144101f1b2ca5a788d3704bf5a5f3e891`
builds package `blit_0.1.538-1_amd64.deb`, SHA256
`46ea81c1c116592d04b727f6934f51a787be94ab5e455c29cd1f0bdb83cf6130`.
The generated release manifest records server/helper/adapter hashes and the
ABI-16 Hibr 0.99.225 header input. Artifact validation and a reproducible
rebuild pass with that same package hash. The all-suite runtime run is still
in progress; no live deployment or actual-user authentication claimed.

The subsequent full `BLIT_HIBR_ROOT=/tmp/hibr-225.X7SwWK tools/run-gates.sh all`
finishes **86 pass / 4 skip / 0 fail**, including the expanded identity gate,
existing schema/terminal/font/renderer/input/Hibr/lifecycle gates and the
120-second four-PTY soak (11,340 snapshots; 1,031 resizes). The skips are the
package suite entry (no BLIT_GATE_PACKAGE, artifact gate passed separately),
QEMU, physical multi-output and live screenshot backpressure. None is claimed
passed by the local run. No source changes followed the packaged commit;
later commits record the manifest and evidence only. The live version remains
0.1.537, with deployment and actual authenticated identity acceptance awaiting
safe logout/operator clearance. No joins were started and no Hibr core modified.

Subsequent authorized physical deployment passes: after the user said ready,
the API updater verified 0.1.538 with the exact manifest archive. Before/after
observations agree on SDL `kmsdrm`/`opengles2`/`sdl-vsync`, active font/scale,
both pane grids and the entire persisted settings document (clean revision
38). One lower login terminal is focused. Pre-authentication identity reports
waiting/null fields. After the real login boundary the installed hook reports
verified UID/GID 1000, sender PID 247917 and desktop selection. This is not a
claim that the sender PID is Hibr's detached held owner. The physical font/edge
oracle also passes 21 cells/2688 pixels; its temporary upper session is deleted.
The final observation contains one terminal and no diagnostic errors/warnings.
The captured lower desktop shows retro_car wallpaper; the upper pane is empty.
Evidence: `diagnostics/identity-538/deploy/` and `diagnostics/identity-538/pixels/`.
No SSH, Hibr-core edits, renderer changes or automatic joins. Native held-owner
readiness/association and standby lifecycle acceptance remain pending (#96).

## 2026-10-17: deployed 0.1.537 policy/persistence foundation

The old staged binary fails `login_policy_gate.rb`: a real settings `.new`
directory prevents the atomic write, but PUT reports success. Corrected source
passes the same failure scenario with HTTP 503, explicit error state and an
unchanged previous durable file. The gate also verifies login startup-policy
precedence, invalid-value rejection without mutation, missing-target wait
and first-available fallback without erasing preference, and ignore recovery.
Root login assignment is exercised with a `/bin/cat` fixture, not a Hibr
authentication or physical-hotplug test. Existing settings-persistence tests
also pass. TCC builds 0.1.537; schema gate passes.

The first broad run exposed an incorrect new test assertion: it expected no
restart flag after changing enabled back to its effective value, overlooking
that the saved pane preference still differs. The assertion now compares the
effective enabled field and independently checks the earlier startup flag;
focused rerun passes. Broader corrected rerun/package/physical acceptance are
pending. The real host stays 0.1.536. No Hibr-core edits or hibr-apps publication.

The first schema/renderer/lifecycle/Hibr run finishes at 68 pass, 4 skip,
2 fail. The other failure is the legacy join fixture's fixed x=10 click:
removing the surplus four-pixel inset in 0.1.536 correctly puts that point
in column 2, not column 1. The fixture now targets the reported first-cell
origin and retains its exact legacy projection assertion; focused rerun
passes. It explicitly does not prove native login-owned 2-D joins (#96).
The four skips were QEMU and three adapter tests without their header input;
the final all-suite run supplies the pinned Hibr checkout explicitly.

The final all-suite execution reports 85 pass, 3 skip, 1 fail. All executed
runtime tests pass, including the 120-second terminal soak. The sole failure
is package verification comparing its documentation to newer HEAD notes,
instead of the manifest's recorded documentation commit. The corrected gate
compares the immutable snapshot, and rebuilds with that explicit documentation
input; its focused rerun passes with `reproducible=yes`, same original
package SHA256 `63d2381bae4aaa4e1c98981e9a9dfa57103cd69ec52fd720fe096055f926c991`.
Do not describe this as a single all-suite 86-pass run: it is 85 suite passes
plus the corrected package-gate pass. The three skipped checks are QEMU,
physical multi-output and live screenshot backpressure. Physical acceptance
for the new configuration contract remains pending, not covered by those
local runtime results.

Subsequent physical acceptance passes on 192.168.10.54: the authorized updater
verified 0.1.537; the new opt-in `host_login_policy.rb` saved through revisioned
settings and performed one API restart. The login child PID changes, policy
restores at saved revision 38 with clean storage, and preferred/assigned pane
both equal `pane-display-1-2`. Effective policy needs no restart. Exact topology
geometry, SDL backend/renderer/vsync and loaded font identity remain unchanged.
The physical edge/font oracle also passes 21 cells/2688 pixels after restart.
Temporary upper test terminal removed; exactly one focused lower login
terminal remains. Host Hibr is 0.99.235 ABI 16, compatible with pinned ABI 16;
this cycle did not update or edit Hibr. Evidence: `diagnostics/policy-537/`.

These are configuration and bounded pixel assertions, not authentication,
native join recovery, physical-output failover, full Control Panel acceptance
or a physical refresh-rate claim. No hibr-apps bundle is published yet. The
user subsequently confirmed explicit saving: Hibr's existing Displays actions
are session-only until saved into Blit. That design choice is recorded in
ADR 0124; it does not constitute implemented Apply/Save UI. Issue #99 and
hibr-apps #1 stay open.

## 2026-10-17: deployed 0.1.536 edge/font regressions

Before correction, the actual pane API gate reports complete1024px grid plus
inset4 clipping beyond1024; the old diamond bitmap is asymmetric/truncated.
After removing the surplus inset and fitting complete fallback rasters, the
focused pane geometry gate and font-fit gate pass (regular/bold diamond and
12 independent full-mask symbol comparisons). Regenerated PSF has930glyphs,
unchanged8x16cells; required447-codepoint manifest passes. At this initial
candidate stage, broad suites, package and exact live pixel checks were
pending; the subsequent results below supersede that pending status.

The first broad run was 52 pass / 6 fail, no skips. Five failures were stale
test assumptions about the old four-pixel sampling origin (one refused zero
inset); the sixth correctly detected the old 929-glyph staged copy beside the
930-glyph asset. Sampling assertions now use the reported geometry, preserving
their exact pixel/rotation expectations, and the derived staged font was
refreshed. All six focused reruns pass. The full suite is being repeated.
The new edge/font probe also passes against a local dummy-renderer server:
21 cells / 2688 pixels, complete left/right edge cells and bold diamond.
That is not yet physical-host evidence.

The complete rerun passes **58 gates, zero failures and zero skips** across
renderer, terminal and font suites. The package artifact gate also passes
reproducibility for the checksum in `releases/0.1.536.yaml`. Original base
glyphs 0–511 retain their exact bitmap bytes. Before deployment, the lower
login target was explicitly read back as
`BLIT_LOGIN_PANE_ID=pane-display-1-2`; SDL/backend selection was not changed.

The updater subsequently verified 0.1.536 on the actual 192.168.10.54 host.
Post-update API identity is SDL3/KMSDRM/OpenGLES2, SDL vsync, 8x16 scale 1,
930 glyphs, zero extra inset and unchanged 240x67 panes. Diagnostics report no
errors/warnings at that check. The physical edge/font oracle passes 21 cells /
2688 exact pixel comparisons, including the complete rightmost bold diamond.
Its temporary upper terminal was deleted; only the focused lower login
manager remains. The upper native join awaits user authentication, not a
pre-login attachment. Evidence is `diagnostics/grid-font-536/physical/` and
the adjacent post-update API captures. These results do not claim universal
terminal conformance, motion acceptance or resolution of issues #95/#96.
Issues #97/#98 are closed with this bounded evidence.

## 2026-10-17: live native bottom-primary/top-join orchestration

Same 0.1.535 SDL GL package, no binary deployment. The existing login PTY5
moved to the lower pane; one ordinary Hibr terminal9 runs native
`desktop --join --session desktop --name blit-upper` as osakka above it.
Native `hold move` places the join above in Hibr's union. Before: primary
client-4 `(0,0,67,240)`, join `(0,240,67,240)`. After: primary
`(67,0,67,240)`, join `(0,0,67,240)`. Held owner remains PID239437; union
134x240. This proves attachment/geometry/single-owner continuity, not all
visual or interactive behavior. Upper click trace reports target9/input9,
leaving native coordinate rewriting to Hibr's own client.

The lower menu bar and separate upper applications are visible. Initial and
settled captures also show dark lower-pane residual rectangles; their cause
is not yet established. Concurrent physical input occurred during injected
context-menu attempts, so no context-menu UI-pass claim is made. The user is
validating the arrangement. Artifacts: `diagnostics/join-20261017/`.

Hibr is now0.99.232 ABI16 on this host. Dependencies #238/#240 are closed.
No Hibr source edits or SSH. API role metadata remains none for the login
wrapper and native join; [issue #96](https://git.home.arpa/itdlabs/blit/issues/96)
tracks proper association and removal of obsolete projection special-casing.
No boot/logout/reconnect acceptance is claimed.

A later lifecycle check found a new lower login PTY11 and held owner240371,
with only its primary client attached. The original join was no longer a
client of that desktop. Removed only our retired join9; started native join13
after confirming the current authenticated desktop and arranged it above.
Final `hold clients`: primary client-4 `(67,0,67,240)`, blit-upper
`(0,0,67,240)`, held owner240371, union134x240. `final-native-geometry.json`
and `final.png` record the handoff. Recovery was manual API orchestration,
not an implemented automatic reconnect feature; issue96 covers the gap.

## 2026-10-17: requested live SDL GL switch, package unchanged

The same reproducible 0.1.535 package now runs SDL3/KMSDRM/OpenGLES2 with
SDL vsync on 10.54. API reports ready, no diagnostic errors/warnings, and
render/viewport 1920x2160 at scale 1. The 1x2 layout and single upper-pane
login session are preserved; only the backend-derived output identity
changes to `display-1`. No SSH, Hibr changes or package deployment occurred.

Real-host damage union (both corners), upper/lower half-block RGB and large
split-UTF-8 PTY assertions pass. The SDL framebuffer capture was inspected
and already shows the Hibr desktop with Control Panel, Terminal and Task
Manager. Evidence: ignored
`diagnostics/renderer-switch-20261017/`, with before/after settings, topology,
diagnostics and screenshot headers. Wallpaper is visible in the capture;
interactive window dragging and sustained SDL refresh acceptance have not
yet been established here;
the preceding visual acceptance remains explicitly direct-KMS evidence.

The broader colour-agreement probe has separate non-pass observations. First
it captured a different surface after the login session was replaced;
that is lifecycle skew, not renderer evidence. Later runs reported one cell
(10,6), 15 pixels, at frame1491/revision355 and four cells at frame2603/
revision380. The pointer was moving and the checker cached its exclusions
only once before its retries. These flags are unclassified, not established
renderer defects. The operator probe now brackets each capture with pointer
state and discards moving samples. Its subsequent attempt correctly refuses
retained graphics, now present in the live surface. Ruby syntax passes; a
stationary, cell-only agreement sample remains pending. Logs and later
diagnostics/cells are preserved, not represented as the exact flagged frame.

## 2026-10-17: authenticated 0.1.534 fails; UTF-8 read-loss regression

The user's authenticated desktop has an incomplete wallpaper. Captured
canonical cells below row 22 are blank; the screenshot reflects that missing
state. Prior synthetic renderer/cadence passes did not establish desktop
correctness. Evidence: `diagnostics/authenticated-20261017/blit-auth-*`.

The actual PTY service test fails on 0.1.534 with
`first=0 tail=0 pending=1 bytes=4097`: a split U+2580 followed by a 4096-byte
read is discarded by the parser's small prefix-join buffer. The correction
passes this regression and a large mixed ANSI/UTF-8 corpus at ten external
fragment sizes from 1 to 65535 bytes, comparing codepoints, colours,
attributes, combining state, cursor and completed OSC title to continuous
parsing. The same controlled shell/PTY reproduction on the real 0.1.534 host
also fails: zero half-blocks, zero of 4000 text cells, and missing END marker.
Its temporary lower-pane session was deleted; the existing desktop remains.
Corrected-source renderer/terminal suite: 51 pass, zero skip/fail. Package
0.1.535 from `01b57f5` passes reproducible artifact validation, SHA-256
`ccf8c4f8d79ab58cf93f964dd33d3063503200a6588b94ca090cc5c41cc9246d`.
The API updater verifies this version on 10.54. The identical host probe now
passes: one half block, 4000 text cells and END at revision 3. Evidence is
in `diagnostics/authenticated-20261017/535-utf8/`.

The authenticated 0.1.535 capture shows wallpaper through row 66, unlike the
0.1.534 truncation below row 22. Control Panel was moved through API pointer
press/motion/release; a revision-matched cell/pixel check passes with 14,909
eligible cells, including 13,527 block cells, and 1,904,128 checked pixels.
No disagreements were found. Pointer neighbourhoods, unsupported styles and
ordinary shaped glyphs are outside this colour check. Captures are
`535-desktop.png` and `535-drag1.png` in the same evidence directory. The user
independently confirms correct movement/rendering and reports the temporary
right-edge shift resolved. No geometry/backend changes were made.

The 6000-frame real PTY/pointer recheck separately **fails** strict cadence:
1980 completed flips across 1986 DRM vblanks (six skips) over 33.151181 s,
observed clock 59.907368 Hz, measured submission 59.746 Hz. Its blank-pixel
assertions passed before the refresh assertion failed. All six skips fall
in one clock-sample interval; runtime records a 106.169-ms maximum loop gap,
not an established cause. Evidence: `535-cadence/scanout-verdict.json` and
runtime/active-vblank samples. [Issue #95](https://git.home.arpa/itdlabs/blit/issues/95)
tracks the investigation. Do not report this workload as refresh-pass.

Tag v0.1.535 records this accepted visual/movement checkpoint with explicit
remaining performance and wider protocol/hardware acceptance work.

## 2026-10-17: exact 0.1.534 physical acceptance boundary

Source `8c6a26f`; manifest `releases/0.1.534.yaml`; reproducible package SHA-256
`4dc79e0deffbe7d2cb727f5c3dcb1821cf521551a2f90378ccc224afc159a9de`.
The API updater verifies this version. KMS callback/clock, fractional-mode,
readiness, full-reference pixel and canonical surface/deadline regressions
pass. The latest broad renderer/terminal suite was 51/51 on the 0.1.532 cycle;
0.1.533/534 additionally received their focused timing/callback regressions.

The 0.1.534 nominal-rate comparison initially **failed** at 59.906 Hz, but its
new clock evidence records 1980 completed flips across exactly 1980 vblanks:
zero missed display refreshes. Nominal mode timing is 59.997136 Hz; actual DRM
clock is 59.908173 Hz. This distinguishes clock variation from lost frames.
Earlier nominal-rate failures remain recorded; they are not retroactively
reported as passing tests.

The final independent acceptance run uses actual sequence counts, rejects
even one skipped vblank, and passes:

```text
PTY_POINTER_SCANOUT completed=1980 vblanks=1980 skipped=0 observed_hz=59.908161 window_s=33.050589
PTY_POINTER_REFRESH_PASS completed=1980 vblanks=1980 skipped=0 observed_hz=59.908161
PTY_POINTER_PASS producer_frames=6000 pointer_requests=466 blank_pixels=2051904 stale_pixels=0 revision=5998
```

Evidence: `diagnostics/rendering-20261017/validated-soak-534/`, including final
BMP/state, runtime samples, active vblank samples and `scanout-verdict.json`.
Final live screenshot: `diagnostics/rendering-20261017/0.1.534-final.png`.
It was inspected and shows the existing login manager's username prompt and
clock in the upper pane, with the intentionally empty lower pane. Temporary
sessions were removed and focus restored. Backend, topology and chosen mode
were preserved. Hibr source was unchanged and no SSH was used.

This closes the bounded renderer/cadence reproductions, not the whole delivery
contract. Authenticated Hibr wallpaper/window dragging, joins and other
hardware/protocol cases still require their own acceptance evidence.

## 2026-10-17: candidate 0.1.534 DRM clock evidence

Exact 0.1.533 is deployed from `bc1a0e5`, package SHA-256
`e1b69b90242dd991a38c37d7f29babefa05df0b7fd5555b294aaf2a6d165ab24`,
reproducible artifact check passed. Active-mode metadata is 59.997 Hz with
unchanged resolution/selection. The repeated 6000-frame soak checks 2,051,904
blank pixels with zero stale pixels but **fails** its strict rate check:
59.902 submissions/s over 32.820 s, minimum 59.967. Mode rounding alone does
not explain this. Evidence: `diagnostics/rendering-20261017/refresh-soak-533/`.

Candidate 0.1.534 records the actual DRM sequence/time without altering
presentation. The callback fixture distinguishes nominal 59.997 Hz from an
observed 60-Hz fixture with three completions spanning 120 vblanks. uint32
wrap, KMS ownership and full-reference pixel tests pass. Live clock/submission
correlation remains pending.

## 2026-10-17: candidate 0.1.533 fractional KMS refresh

Exact 0.1.532 is deployed: package SHA-256
`11cccbf128f97158fc51d5b075b17c3a4d10a22b2c321f55bdab82afa541b82c`,
source `0fb9b0a`, reproducible artifact gate passed. The short strict live test
passes at 59.832 submissions/s in 3.209 s, with 600 producer frames, 193 pointer
requests and zero stale pixels over 2,051,904 blank pixels. Evidence:
`diagnostics/rendering-20261017/refresh-required-532/`.

The 6000-frame soak's pixel check passes, but its refresh assertion **fails**:
1991 submissions over 33.232 s = 59.912 Hz; minimum against reported 60.0 Hz is
59.970. Window missed-deadline counters remain zero. Evidence:
`diagnostics/rendering-20261017/refresh-soak-532/`. This is not called a pass.

The active/enumerated direct-KMS rates came from Linux's integer-rounded
mode.vrefresh. A real-helper fixture fails at 60.000000 versus 59.940202 before
correction. Candidate 0.1.533 calculates the timing fraction and scan factors;
focused arithmetic, ownership and pixel gates pass. Exact live mode timing
and the unchanged long acceptance test remain pending. The renderer behavior
and chosen mode are unchanged from 0.1.532.

## 2026-10-17: candidate 0.1.532 direct-KMS vblank retries

[Issue #91](https://git.home.arpa/itdlabs/blit/issues/91) records the real
pre-fix refresh failure: 54.123 submissions/s versus an initial 58.2-Hz
discriminator. The captured trace identifies deferred attempts that wait for
another software deadline after flip completion. Candidate 0.1.532 remembers
the actual deferred outputs and retries each when KMS reports its buffer ready.

The production KMS readiness mask excludes pending/failed outputs and becomes
ready through the actual flip callback. The state-helper test verifies that
only a ready deferred output is rescheduled immediately; a second still-busy
output retains its deadline, and a consumed retry cannot repeat. Focused
tests and the Hibr join barrier pass. The TCC renderer/terminal run passes
51/51 with no skips, and API schema/observation checks pass. Deployment remains
pending. Direct-KMS FPS now excludes deferred/no-op attempts and the existing
global present_calls field counts KMS submissions. Their semantics are explicit
in OpenAPI and tested against the actual submission-counter helper.

The final live refresh assertion permits only one-event quantization over the
measured interval (`refresh_hz - 1/window_seconds`), rather than accepting an
arbitrary percentage of lost frames.

## 2026-10-17: candidate 0.1.531 bounded presentation deadlines

[Issue #90](https://git.home.arpa/itdlabs/blit/issues/90) is reproduced with
actual functions: an expired quiet deadline `1` is rearmed by a PTY read;
an active eight-millisecond quiet window returns a zero wait; and an expired
primary/join group barrier is rearmed by another member update. All three
regressions fail before correction and pass afterward. The direct-KMS batch
flag is now cleared at the same consumption boundary as SDL.

The focused Hibr join-barrier gate passes. The local dummy-backend frame-rate
fixture records 59.999 Hz with zero window missed deadlines. The TCC
renderer/terminal suites also pass: 51 pass, 0 skip, 0 fail. Deployment was
pending at that source-verification stage; physical follow-up is below.

### Physical follow-up: exact 0.1.531 deployed

The API updater verifies 0.1.531, built from `0933cad`, SHA-256
`9d4b891c7340f20e7aaf0b94104aae51175a967106bca04c4bbae48094d5d54c`.
Its manifest is `releases/0.1.531.yaml`; artifact verification reports
`reproducible=yes`. The two-corner and half-block RGB probes pass again.
Two whole-pane PTY/pointer runs each check 2,051,904 blank pixels with zero
stale pixels. Cadence is 53.185 and 52.581 submissions/s in active windows.
The captured render ring contains 14 deferred attempts among 82 entries;
examples at 608506458026 and 608506490916 us retry only at 608506477782 and
608506510188 us. A completed flip still waits for the software phase, making
some consecutive submissions approximately 32 ms apart. This is the next
timing defect; 60-Hz physical acceptance remains unmet. Evidence is under
`diagnostics/rendering-20261017/pty-pointer-low-overhead-531-repeat/`.

The improved live PTY/pointer benchmark on 0.1.530 polls small title metadata
while drawing, then obtains the large cell snapshot only after the producer
finishes. This avoids contaminating cadence with repeated multi-megabyte JSON
serialization. Its active window records 47.908 submissions/s over 3.131 s,
600 producer frames, 186 pointer requests, and zero stale pixels. Evidence:
`diagnostics/rendering-20261017/pty-pointer-low-overhead-530/`.
The live half-block probe also confirms exact upper/lower red/navy halves.

## 2026-10-17: candidate 0.1.530 damage accounting correction

Live 0.1.529 remains visually broken. [Issue #89](https://git.home.arpa/itdlabs/blit/issues/89)
records two deterministic root defects reproduced against actual Blit code:
left/up damage expansion discards old bounds, and simultaneous KMS pointer
movement replaces terminal damage before consuming its revision. Partial
scroll/DEC rectangle operations can also discard earlier pending work.

Before correction, `surface_damage_gate.sh` reports five failures, including
`got=2,1,1x1 want=2,1,59x30`. The production-presenter regression reports
`KMS_POINTER_TERMINAL_FAIL old=ff0000 new=102030 expected=102030,ff0000`.
After correction both pass, and 128 mixed half-block/graphics/pointer frames
match a fresh full render at every pixel. The test simulates only the DRM page
flip; it executes the actual scene, pointer, damage, and buffer-swap code.

The TCC-built 0.1.530 binary passes the complete renderer/terminal suites:
`RUN_GATES_PASS pass=51 skip=0 fail=0`. Package and live acceptance are pending.
The identical defect was also reproduced on the real 0.1.529 host with
`tools/probes/host_damage_union.rb`: one API request writes bottom-right first
and top-left last; the screenshot reports the new revision but returns
`pixels=[[255,0,0],[16,32,48]] expected=red,red`. The temporary shell surface
is created in the free pane and deleted by the probe. The exact same probe
must pass after deployment before this defect is closed.
### 0.1.530 exact package and physical-host follow-up

Source `590ea31` and manifest `releases/0.1.530.yaml` identify the TCC-built
package. Artifact verification passes with `reproducible=yes`; SHA-256 is
`0f62c457dc0cadf78731c51271a0023353668c0d0dc3696384a849b10f811071`.
The API updater confirms live `server_version=0.1.530` on 192.168.10.54.

- Identical two-corner probe: `LIVE_DAMAGE_UNION_PASS revision=3
  display=display-93 both-corners=exact` (the pre-update run failed).
- Existing motion probe: 12/12 accepted steps, no discarded captures.
- Kitty probe: exact RGBy quadrants, untouched background, and deletion.
- New `host_pty_pointer_stress.rb`: 600 genuine PTY animation frames,
  106 concurrent pointer API requests, 100,352 checked blank pixels,
  zero stale pixels. Its final state and BMP revisions agree.
- Existing live Hibr saver state/pixel probe: three samples, zero stale cells,
  zero missing cells, with continuing state churn (520, 1164, 736 cells).

The stress evidence is under the ignored local directory
`diagnostics/rendering-20261017/pty-pointer/`; screenshots before and after
deployment are in `diagnostics/rendering-20261017/`. Temporary sessions were
deleted; keyboard focus and pointer position were restored. Backend and pane
topology were unchanged. Hibr source was not changed.

The bounded stress capture measured 36.57 page-flip submissions per second over
3.391 seconds including the producer's initial one-second wait. That mixed
interval does **not** establish 60-Hz motion. Authenticated Hibr dragging,
steady producer timing, and complete protocol conformance remain separate
acceptance items. The login manager is the only remaining Blit session.

Historical entries below describe their own versions and do not override
this current failure status.

## 0.1.524 live API-owned cell and Kitty composition boundary

### Source correction pending live deployment: direct-KMS cursor damage

The source comparison against Kitty, xterm, and suckless `st` found a concrete
direct-KMS damage violation. Blit's SDL path already restricted terminal-cursor
drawing to damaged rows; direct KMS drew the cursor unconditionally after the
partial cell repaint. The new `tools/tests/kms_compose_gate.sh` regression
reproduced the defect by repainting `(0,0)` and observing an unrelated cursor
cell change. The correction bounds the cursor to the damaged row and its
one/two-cell damaged-column footprint; see [ADR 0112](adr/0112-kms-partial-repaint-must-bound-the-terminal-cursor.md).

The correction is locally verified with `KMS_COMPOSE_PASS` and the complete
TCC renderer/terminal run `RUN_GATES_PASS pass=50 skip=0 fail=0`. It has not
yet been packaged or deployed to `192.168.10.54`, so no live visual claim is
made for it.

On 2026-10-17, the authenticated direct-KMS host at `192.168.10.54` reported
one 1920x2160@60 Hz output and the persisted 1x2 topology. The corrected
`tools/probes/host_motion_agreement.rb` updated a known block twelve times in
the free lower pane and passed:
`MOTION_PASS steps=12 accepted=12 discarded=0 direct_kms=true
display=display-93`. The probe now uses the topology's display-global cell
origin and reads the BMP bit depth from the capture header; the earlier
lower-pane result made before those corrections is not evidence.

`tools/probes/host_kitty_composition.rb` then created a separate API-owned
surface, painted a known `#102030` cell background, emitted a 2x2 RGB Kitty
image from the child PTY, and captured the direct-KMS framebuffer. All four
image quadrants matched exact RGB values and an untouched cell matched the
known background. A Kitty `a=d,d=I` delete was then observed and the former
image location returned exactly to the background:
`KITTY_COMPOSITION_PASS display=display-93 image=9001 direct_kms=true
pixels=exact delete=exact`.

The probes cleaned up their own sessions; the host was left with only the
supervised login-manager session. This is isolated renderer/protocol evidence,
not acceptance of Hibr's complete desktop, wallpaper, joins, physical mouse,
physical keyboard, or window interaction. The live runtime still reports a
large cumulative missed-deadline count from the long-lived login-manager and
diagnostic workload; no 60-Hz physical-performance claim is made here.

The subsequent read-only graphics discriminator found the same boundary:
`session-1` is `login_manager=true` with `graphics=[]`, and the filtered trace
contains only its Kitty capability query. No authenticated Hibr desktop
wallpaper payload is present in this live state. The next required capture is
therefore one authenticated primary desktop, followed by its graphics state
and screenshot, before any join is started.

## 0.1.523 live direct-KMS surface-local damage and cadence

The exact `0.1.523` package is deployed on `192.168.10.54`. Hibr source was
not modified. The live API reports `drm-kms`, `direct_kms=true`,
`direct-kms`, `drm-page-flip`, and one 1920x2160@60 Hz output. The persisted
1x2 test topology places the supervised login manager in the lower pane and
leaves the upper pane empty.

The compositor changed from full-output rebuilding on every changed terminal
view to surface-local damage in [ADR 0108](adr/0108-surface-local-kms-damage-boundary.md).
Startup, view-count, origin, and output-wide changes still force a complete
output rebuild. The KMS composition gate passes, including a moved graphics
placement with no pixels left at its old position.

The controlled live fast-terminal workload measured 61.957–63.137 Hz,
14.085–16.892 ms last frame gaps, and 10.903 ms maximum KMS present time.
Its measurement windows added zero missed deadlines. The lifetime diagnostic
counter contains startup/login-relocation gaps and is not used as motion-pass
evidence. Direct-KMS frame-rate counters now update through the same path as
SDL, so `0 Hz` is no longer reported merely because the active backend is KMS.

This is bounded renderer evidence. It does not claim a visually accepted Hibr
desktop, physical mouse/keyboard acceptance, wallpaper/Kitty/Sixel acceptance,
or a working join.

## 0.1.517 candidate: atomic KMS scene rebuild, login-pane invariant, and screenshot evidence

The source candidate targets the measured direct-KMS workload in which Hibr's
opaque 960x1080 wallpaper is placed at 1920x2160. The compositor now uses a
bounded integer-scale replication path for opaque RGB/RGBA images and retains
the general scaler for alpha or non-integer placements. This avoids the
per-destination-pixel source-coordinate divisions that were present during
full wallpaper redraws. It also makes the session returned by `/v1/login`
explicitly inherit the requested pane before topology derives the surface
assignment, closing the live mismatch in which the lower-pane request
returned a session on the upper pane. Direct-KMS composition now renders into
a persistent CPU scene before the sequential scanout copy; see [ADR 0102](adr/0102-kms-integer-scale-fast-path.md)
and [ADR 0103](adr/0103-kms-cpu-scene-cache.md). An already-running
auto-started login manager is relocated when `/v1/login` explicitly names a
different pane, and an origin change forces a complete KMS redraw; see [ADR 0104](adr/0104-login-target-relocation-and-pane-redraw.md).
The KMS screenshot endpoint now requests one bounded present for the requested
output and captures after the persistent scene is copied to the page-flip
buffer, so a capture cannot report the previous scanout frame; see [ADR 0105](adr/0105-kms-screenshot-capture-boundary.md). A changed unsynchronized terminal view now rebuilds the complete persistent KMS scene before the page flip, preventing stale pixels from the incremental path.

Local evidence: `tools/tests/kms_compose_gate.sh` passes with
`KMS_COMPOSE_PASS full=512`; the TCC server build reports `0.1.517`. The
package gate passes for `build/packages-517/blit_0.1.517-1_amd64.deb`, whose
SHA-256 is recorded in [`releases/0.1.517.yaml`](../releases/0.1.517.yaml).

Live evidence on `192.168.10.54` is complete for this renderer boundary:

- `/v1/version` reports `0.1.517`; `/v1/server` reports ready direct
  `drm-kms`.
- The API-only handoff and `/v1/login` request place one login session in
  `pane-display-93-2`; `pane-display-93-1` has no surface.
- A lower-pane shell moved a coloured label through 120 rapid terminal
  updates, cleared the grid, and wrote `done`. The final surface had six
  non-empty cells and the API screenshot showed only `done`; the screenshot
  contained no earlier moving label. The artifact is
  `/tmp/blit-kms-0.1.517/motion-screen.png`.
- The screenshot-free timing sample measured 131 frames over 5121 ms, a
  4.533 ms maximum KMS present, and a 13.316 ms maximum rolling loop gap.
  These are compositor measurements for the controlled workload, not a claim
  of physical-input acceptance or sustained 131 FPS.
- The restored Hibr login capture is
  `/tmp/blit-kms-0.1.517/hibr-login-screen.png`; it shows a clean lower login
  pane and a black upper pane.

The required live configuration remains direct KMS, one physical output, one
lower-half pane, and one primary Hibr session; no join is part of this
performance check. Physical mouse/keyboard acceptance and Hibr desktop
interaction remain separate acceptance evidence.

## 0.1.510: direct-KMS frame-boundary fix and live renderer matrix

The exact `0.1.510` package is deployed on `192.168.10.54`. Hibr source was
not modified. The direct KMS compositor now copies the complete displayed
front buffer into the acquired back buffer before applying damage; see
[ADR 0101](adr/0101-kms-incremental-frames-copy-the-presented-buffer.md).

The local coherence gate and TCC build passed. The live renderer matrix was
then exercised through the authenticated API:

| Path | Runtime identity | Focused probe | Result |
| --- | --- | --- | --- |
| SDL/OpenGL | `sdl3`, `kmsdrm`, `opengles2`, `sdl-vsync` | cell updates, pointer motion, Hibr primary/join, Kitty image movement | no missed deadline in focused probes |
| SDL/software | `sdl3`, `kmsdrm`, `software`, `scheduler-only` | cell updates and pointer motion | one startup scheduler miss; no subsequent focused miss |
| direct KMS | `drm-kms`, `direct-kms`, `drm-page-flip` | full-frame coherence gate and pointer motion | no missed deadline in focused probe |

The live SDL/OpenGL run accepted one Hibr primary in the lower pane and one
Hibr `--join` in the upper pane as distinct running surfaces. The Kitty image
probe recorded a complete 32x32 image, one texture upload, cache reuse, and
zero rejected graphics payloads. The final live observation was restored to
SDL/KMSDRM + OpenGLES2 at 59.99 Hz with the same primary/join topology.

An API-driven context-menu probe then moved the pointer to `(500,1500)` and
sent a right-button press/release. The trace identified `target_session=2`
through pane hit-testing, and the display capture showed the menu at that
location. After dismissal, the `surface-2` cell snapshot returned to the
expected desktop background cells. This proves the Blit API dispatch and
surface/screenshot path; it is not a physical evdev click acceptance test.

Evidence captures and JSON observations are retained outside Git under:

- `/tmp/blit-direct-kms-fixed-motion-20261016/`
- `/tmp/blit-sdl-gl-motion-20261016/`
- `/tmp/blit-live-hibr-join-sdl-gl-20261016/`
- `/tmp/blit-live-kitty-motion-20261016/`
- `/tmp/blit-final-live-20261016/`

This is bounded renderer/composition evidence, not a claim of complete
physical acceptance. Physical fast window dragging, physical button/key
traces, context-menu placement, and end-to-end Hibr interaction remain open
acceptance boundaries.

## 0.1.509: canonical observation API and live presentation-path matrix

The exact `0.1.509` package is deployed on `192.168.10.54`. The authenticated
observation endpoint was used to run each presentation path and record the
identity fields needed to distinguish them:

| User-facing path | Backend | Video driver | Renderer | Presentation sync | Ready | Output |
| --- | --- | --- | --- | --- | --- | --- |
| SDL/OpenGL | `sdl3` | `kmsdrm` | `opengles2` | `sdl-vsync` | yes | `DP-1`, 1920x2160@60 Hz |
| SDL/software | `sdl3` | `kmsdrm` | `software` | `scheduler-only` | yes | `DP-1`, 1920x2160@59.99 Hz |
| direct KMS | `drm-kms` | `direct-kms` | none | `drm-page-flip` | yes | `KMS connector 93`, 1920x2160@60 Hz |

Each observation reported an empty health error and empty diagnostic warning
list. “SDL/KMS” is not a third top-level backend here: it is the SDL3 video
path using the KMSDRM video driver. The server was restored after the matrix
to SDL/KMSDRM + OpenGL ES2 with the login manager running. This is exact
backend/readiness evidence, not visual acceptance; the user’s login is the
next physical desktop observation.

### Manual physical comparison, 2026-10-16

The three modes were then presented one at a time for user login and direct
visual comparison. In SDL/KMSDRM + OpenGLES2, the static picture-rendered
background was reported correct, but movement of approximately one block per
second caused rendering to break. SDL/KMSDRM + software produced the same
reported result. Direct KMS displayed the background image and desktop
content, but left more persistent artefacts during movement, including at very
slow movement. These are physical visual observations; they do not by
themselves identify the failing composition boundary or replace screenshot,
damage, and input traces.

## 0.1.508: canonical observation API

Source now defines the schema-first `GET /v1/diagnostics/observation` endpoint
and composes it from the existing focused resource serializers. The OpenAPI
schema gate, TCC build, focused observation gate, and complete schema/API gate
pass locally. The exact package was installed through the supervised update
path and the authenticated Bash client confirmed `0.1.508` on
`192.168.10.54`. The live response reported SDL3/OpenGLES2, one
1920x2160@60 Hz output, one running login-manager session, 158 presentation
calls, zero missed deadlines at capture, and one graphics payload.

## Latest review: 0.1.507 is not visually accepted

The 0.1.507 package is deployed on `192.168.10.54` and `/v1/version` reports
`server_version=0.1.507`, `api_version=0.1`. The live server can create one
primary Hibr session and one `--join` session through the API, but the latest
fresh-session screenshot showed a flat-colour scene with the menu/status line
and no Kitty graphics in either session. The sessions were alive and had
distinct surface revisions; that is process/surface evidence, not visual
correctness.

A preceding live capture showed the more specific stale-resource failure:
the retained primary surface contained `[desktop ended, status 0]`, while a
new join reported `hibr: hold: no such session`. Removing the exited resources,
starting a fresh primary without `--resume`, waiting for its desktop surface,
and then creating the join produced running sessions. This is now the
documented recovery sequence; it is not an acceptance result.

The controlled API pointer workload delivered 600 synthetic motion events and
produced 531 presentations with zero new missed deadlines in that interval.
The local pointer-damage, motion-trail, wallpaper-stress, and Hibr
frame-barrier gates passed. These facts narrow the timing path but do not prove
that Hibr emitted the expected scene or that a real window can be dragged.

The authenticated 20-second physical capture recorded zero evdev motion and
zero evdev button events. Physical window movement therefore remains
unmeasured, not passed. The next acceptance transaction must include a visible
window, physical evdev traces, Hibr surface revisions, render-path traces, and
a screenshot. See [current-state.md](history/current-state.md).

The claim vocabulary is strict: timing stability is only timing stability;
process liveness is only process liveness; an incomplete screenshot is a
failed visual result. No broader claim may be inferred from these observations.

## Unreleased: rendering contract fixes (#84, #85, #87) -- validated, not host-accepted

Three server defects behind the Sixel/half-block/Kitty inconsistency are fixed
in source: Kitty z bands and default-background transparency in the SDL path
(#84), sixel slots never released so the ninth picture was refused (#85), and
a DA1 reply that did not advertise sixel (#87). New gates
`sdl_graphics_band_gate.rb` and `sixel_slot_gate.rb` fail on the 0.1.507
binary (band gate: 0 of 512 wallpaper pixels visible; slot gate: 5 pictures
rejected with `image-store-full`) and pass on the fix; the renderer and
terminal suites pass (49 gates). Validated on the dummy SDL backend, and for
direct KMS by `kms_compose_gate` on a memory buffer (it fails on the 0.1.507
compositor at the explicit-black case).
Not deployed, not host-accepted. The live half-block fallback on the host is
not yet explained by these defects and needs a Hibr debug log from a restored
desktop.

## 0.1.507 candidate: ping-pong SDL scene composition

The real 0.1.506 host reproduced the reported fast-update symptom through a
controlled API workload: approximately 55 pointer updates per second produced
about 28 presentations per second and 16 additional missed 60 Hz deadlines
in five seconds. The OpenGLES2 path had disabled incremental scene damage
because a single render-target texture did not preserve its contents when
rebound, so changed Hibr surfaces rebuilt both panes from scratch.

0.1.507 keeps two SDL scene render targets. Each content update copies the
last complete scene into the work texture, applies the canonical damage, and
swaps the textures only before presentation. This removes the implicit
render-target persistence assumption without changing Hibr or the terminal
protocol boundary. The TCC renderer/Hibr suites passed 54 gates, the schema
and package gates passed, and the exact package was deployed to the live host.

The same five-second high-rate control workload after deployment produced no
new missed deadlines, a maximum present time of 16.882 ms at a 60 Hz output,
and a maximum loop gap of 17.026 ms. Three one-second idle screenshots had
the identical SHA-256 (`f240696d9fe8b5b58c8515564220806b68875566a3c7e68495ebba6bf06b9390`)
and one live two-pane screenshot showed the Kitty wallpaper on both panes.
That was a bounded historical composition observation, not current visual
acceptance. It did not prove a complete Hibr desktop, physical fast-window
dragging, or a persistent join. The later live review above supersedes any
broader interpretation of that screenshot.

## 0.1.505 candidate: reassert the Hibr graphics contract after login

The live surface showed half-block wallpaper and literal truecolor control
text while Blit's Kitty trace contained only Hibr's capability query and a
delete. Source inspection of Hibr's unchanged authentication boundary proved
that `auth run` clears the environment before launching the selected desktop;
the desktop therefore never received Blit's `HIBR_GFX=kitty` default. Blit's
own `blit-session.hibr` now reasserts `HIBR_GFX=kitty`, `DT_BIDI=on`, and
`COLORTERM=truecolor` after that boundary, preserving explicit overrides.

The local terminal and package gates must pass, then the live host must be
restarted from the 0.1.505 package. Acceptance is not complete until the
authenticated live trace records a complete Kitty upload and texture upload;
the old half-block screenshot is retained as the pre-fix evidence.

## 0.1.504 candidate: preserve complete Hibr Kitty PNG chunks

Live graphics traces identified a concrete transport defect: Hibr's Kitty
wallpaper chunks carry 4096 base64 bytes, while Blit's terminal APC buffer was
4096 bytes total. The control header consumed part of that capacity, so every
chunk was truncated to 4095 bytes and the final PNG transmission was rejected
as incomplete. The parser buffer is now a bounded 16 KiB buffer; graphics and
decoded-image limits remain unchanged.

The focused TCC graphics gate now emits the same wire shape for both raw RGB
and a real multi-chunk `f=100` RGBA PNG. It verifies complete Kitty images,
exact 64x64 dimensions, 64x64x4 decoded bytes, full trace chunk lengths, and
zero new rejections. The renderer gate passes 43/43 with no skips. This is
local evidence only until the package is deployed and the live Hibr wallpaper
trace and screenshot show a complete Kitty image.

## 0.1.503 candidate: preserve Hibr session-relative imports

The live login attempts provided the missing evidence: keyboard input was
delivered, authentication completed, and both desktop children exited with
status 0. A screenshot of a controlled API-created desktop showed Hibr
looking for `/usr/share/blit/hibr/desktop.hibr` and then reporting its desktop
functions missing. The cause was Blit sourcing Hibr's installed
`session.hibr` through the wrapper, which changed Hibr's `$0` path. Blit now
executes the installed session as the script entrypoint for the native
terminal-provider path; the API-provider path remains separate. Hibr source
and installation are not modified. The candidate must be rebuilt, gated,
deployed, and retested through login.

## 0.1.502 candidate: use Hibr ABI as the compatibility contract

Hibr `--version` reports both its release and its module ABI, and Hibr's
module documentation defines `HIBR_ABI` as the load-time compatibility
boundary. Blit now packages that ABI in `HIBR_ABI`, validates it when building
the TCC adapter, reports both pinned and runtime identities through
`/v1/diagnostics/runtime`, and decides compatibility from ABI equality. Exact
release values remain provenance. This allows a host to advance from Hibr
0.99.212 to 0.99.213 while ABI 16 remains stable, while still failing closed
on a future ABI change. Hibr source and installation are not modified.

This candidate also renames the mismatch event to `hibr_abi_mismatch` and
retains the structured `login_session_exit` event from 0.1.501. The package,
schema, focused gates, and live deployment must be completed before the
authenticated desktop login is retested.

The TCC build, schema/network/login focused gates, package artifact gate, and
reproducibility check pass. The complete local run recorded 75 passes, three
explicit environment skips, and one transient frame-budget sample at 20.756
ms against the 20 ms limit. Three immediate frame-rate retries and the timing
suite passed without changing the threshold. This is recorded as evidence,
not converted into a false full-suite pass.

## 0.1.501 candidate: retain login child exit evidence

The live Hibr login loop exposed an observability gap: Blit retired the
authenticated login child before `/v1/diagnostics/runtime` could identify why
it exited. This candidate records one bounded `login_session_exit` diagnostic
event with the session ID, state, and exit code before the login manager
restarts. It changes no Hibr code or login behavior; it makes the existing
handoff falsifiable through the API.

## 0.1.500 candidate: match the installed Hibr ABI

The 0.1.499 package was built and gated against Hibr 0.99.204 after the live
host reported that version. Before deployment, the host advanced to Hibr
0.99.212. After deployment, Blit's diagnostics correctly reported
`hibr_compatibility.compatible=false`; 0.1.499 is rejected as a physical-host
artifact. No Hibr source or installed file was modified by Blit.

The current candidate follows ADR 0093 and pins Hibr 0.99.212, using the
released tag from the local Hibr checkout. It must be rebuilt, gated, and
deployed before any physical desktop behavior is accepted.

The exact 0.1.500 package passed the full local suite (`76 passed, 3
explicitly skipped, 0 failed`), was deployed through the supervised update
API, and reports `hibr_compatibility.compatible=true` on the physical host.
The host is currently at Blit's Hibr login manager with no registered Hibr
desktop owner, so menu, input, and join behavior are not yet physical-host
accepted for this candidate. No second desktop was started for this check.

## 0.1.499 candidate: match the installed Hibr ABI

The first direct-installed-tree package was deployed to the live host as
0.1.498. Its post-deployment diagnostics exposed a second, independent
boundary issue: the package was built against Hibr 0.99.191 while the host
was running Hibr 0.99.204. The server correctly reported this as
`hibr_compatibility.compatible=false`; the package is not accepted as the
final host artifact.

The packaging pin was 0.99.204, selected from the Hibr release tag that
matched the host at that point. The adapter was compiled from the exact pinned
checkout, and the launcher sourced `/usr/share/hibr/desktop/session.hibr`
directly. No Hibr source, installed file, or Hibr repository state was changed.

The 0.1.498 deployment remains useful evidence: the update path, direct
installed-session boundary, and diagnostic mismatch reporting all worked. The
0.1.499 package is retained as rejected compatibility evidence; 0.1.500 is the
candidate for the current host.

## 0.1.498 candidate: use Hibr's installed desktop tree

The live menu investigation found that Blit's packaged integration tree
omitted Hibr's `system/` sibling. The packaged launcher therefore registered
ordinary applications but not Hibr's own Control Panel, Applications
Catalogue, Modules, or Task Manager entries. This was a Blit packaging/path
defect; Hibr source, modules, and desktop files were not modified.

The launcher now sources Hibr's installed
`/usr/share/hibr/desktop/session.hibr` directly. Blit no longer creates a
second symlink tree beside Hibr's installation. QEMU retains an explicit
`BLIT_HIBR_DESKTOP_SESSION` override for its complete staged fixture. The
package regression gate asserts both the direct installed-session path and the
absence of the old mirrored session/system paths.

Implementation commit: `c514f50` (`source Hibr desktop from its installed
tree`). The TCC-built 0.1.498 package passed the packaging regression and
reproducibility gates against the exact pinned Hibr 0.99.191 checkout:

```text
PACKAGE_ARTIFACT_PASS version=0.1.498-1 reproducible=yes
RELEASE_MANIFEST_PASS package=0.1.498-1 manifest=releases/0.1.498.yaml
```

## 0.1.497 candidate: authenticated diagnostic bundles

The live troubleshooting path now uses one shared bearer-aware transport for
all diagnostic tools. The canonical collector records capability/settings
documents, capture metadata/completion state, filtered wheel and graphics
traces, and screenshot response headers containing frame and surface-revision
identity. `validate-capture.py` rejects incomplete or malformed bundles, and
the local bearer-file regression gate passes. Hibr source was not modified.

The 0.1.497 package is built after this source commit; the exact artifact and
reproducibility result will be recorded in `releases/0.1.497.yaml`.

The strengthened collector was exercised read-only against `192.168.10.54`
with bearer authentication. It discovered one 1920×2160 OpenGLES2 output at
60 Hz, one session and one surface, and produced a validated screenshot whose
headers identified frame `443107` and surface revision `surface-1=561712`.
The two-second timing window observed no active input or surface work, so it
does not diagnose the visual artifact; it proves the evidence path is now
usable and makes the next reproduction falsifiable.

## 0.1.496 candidate: generated release identity

The release tooling slice of issue #27 now derives the package identity from
the Debian artifact rather than trusting hand-copied hashes. The focused gate
passed against the 0.1.495 package and existing release record, and a
deliberately stale server hash was rejected. The package artifact gate now
invokes the same check. The adapter build-method field remains explicit
evidence because an archive cannot prove which external checkout or compiler
produced its embedded adapter. Hibr source was not modified.

Focused evidence:

```text
RELEASE_MANIFEST_PASS package=0.1.495-1 manifest=releases/0.1.495.yaml
RELEASE_MANIFEST_GENERATOR_PASS fields=9
NEGATIVE_DRIFT_PASS
PACKAGE_ARTIFACT_PASS version=0.1.495-1 sha256=de362664dba1949f0952d1d7906a1a16dfd9e61f17a4014f99a8399e55703333 reproducible=skipped
```

The 0.1.496 package is built after this source commit; CI and automatic
live-update rollback/restore remain open portions of issue #27.

## 0.1.495 candidate: full-frame composition budget

0.1.495 adds the executable evidence boundary for Blit issue #80. The timing
gate accepts authenticated remote endpoints and configurable surface
dimensions, so it can exercise a full 240×135 terminal surface instead of a
small smoke workload. The release host threshold is 17 ms at 60 Hz; the gate
also requires at least 55 Hz and zero missed deadlines.

Physical evidence on `192.168.10.54` (SDL3/OpenGLES2, 1920×2160 at 60 Hz):

```text
FRAME_RATE_PASS hz=59.916 min_hz=55.000 max_hz=75.000 frames=30 window_ms=500 age_ms=0 window_max_render_ms=16.789 render_budget_ms=17.000 target_interval_ms=16.000 window_missed_deadlines=0
```

The same workload failed with a 14 ms threshold at 16.848 ms, proving the
budget assertion is not decorative. No scene-cache change is claimed; the
OpenGLES2 cache remains disabled under ADR 0070.

## 0.1.494 candidate: API-owned server presentation settings

0.1.494 addresses Blit issue #70. The settings document now persists render
cadence, pane layout, requested renderer, direct-KMS async pageflip policy,
empty-output expectation, and the selected font profile/scale. The environment
is used only as the boot default when the document is silent. `/v1/settings`
reports the requested and active renderer separately; `/v1/topology` remains
the live owner of pane layout and persists that choice through the document.
`BLIT_EVDEV_MOUSE` is explicitly retired from the API because stable input
device resources supersede a node-path override. Hibr source remains
unchanged.

Focused evidence so far:

```text
SETTINGS_PERSISTENCE_PASS
font API gate: PASS (profiles, tenth-step scales 1.0..3.0, rounded pixels, reflow, rejection, restore)
PANE_SPLIT_GEOMETRY_PASS output_grid=78x29 pane_grid=78x14 top_origin=5,10 bottom_origin=5,394
API_SCHEMA_PASS paths=41 terminal_input=/v1/terminal-sessions/{session_id}/input
```

The reproducible package, full renderer/terminal gates, and physical-host
acceptance are still pending for this candidate.

## 0.1.492 candidate: opt-in deferred middle-button emulation

0.1.492 addresses Blit issue #71. Pointer devices now expose an implemented,
disabled-by-default `middle_button_emulation` setting with a bounded 50..500
ms window. When enabled, a left/right chord emits one middle press and
release; a single press is flushed as itself when its deadline expires, even
when the event loop is otherwise idle. Motion is not swallowed, state is per
device, and API injection with `device_id` uses the same path as evdev input.
Hibr source remains unchanged.

Focused evidence so far:

```text
API_SCHEMA_PASS paths=41 terminal_input=/v1/terminal-sessions/{session_id}/input
INPUT_DEVICE_CONFIG_PASS ...
POINTER_SETTINGS_PASS
```

The exact pinned-Hibr package is reproducible and the full local gates pass:

```text
RUN_GATES_PASS pass=43 skip=0 fail=0
RUN_GATES_PASS pass=3 skip=0 fail=0
PACKAGE_ARTIFACT_PASS version=0.1.492-1 sha256=142b6994b6f9170ad99a1958968e6b1f3771f664bfe30e5ead2851d6aaa0f291 reproducible=yes
```

Physical-host deployment and acceptance remain pending for this candidate.

## 0.1.491 candidate: graphics follow terminal-row scrolling

0.1.491 addresses Blit issue #62. Kitty and sixel placements now carry an
explicit page-anchor state and move with later index, reverse-index,
scroll-region, and insert/delete-line operations. Destination and source
rectangles clip together at the active page boundary. API-owned pixel frames
remain absolute scene objects. Hibr source is unchanged.

Focused gates pass:

```text
SIXEL_DECODER_PASS
KITTY_PLACEMENT_PASS
```

The full renderer gate and reproducible package evidence are pending for this
candidate.

## 0.1.490 candidate: pinned Hibr adapter provenance and runtime compatibility

0.1.490 closes the release-integrity part of Blit issue #81. The Debian
builder now requires `BLIT_HIBR_ROOT` and compiles `console-blit.so` into the
package staging tree with TCC; it cannot copy an arbitrary adapter from the
ignored build directory. The server binary embeds the same
`packaging/HIBR_VERSION` value and `/v1/diagnostics/runtime` reports the
packaged pin, the version returned by the configured Hibr command at startup,
the probe state, and compatibility. A mismatch is also a structured runtime
log event. Hibr source remains untouched.

The exact pinned fixture is Hibr `0.99.191` from `/tmp/hibr-0.99.191`. The
negative package gate rejects an omitted checkout, and the positive package
build compiles the adapter from that checkout. The package artifact gate also
rebuilds the package byte-identically. The TCC/API/renderer evidence is:

```text
API_SCHEMA_PASS paths=41 terminal_input=/v1/terminal-sessions/{session_id}/input
NETWORK_AUTH_PASS ... runtime_diagnostics=200 ...
RUN_GATES_PASS pass=43 skip=0 fail=0
PACKAGE_ARTIFACT_PASS version=0.1.490-1 reproducible=yes
```

This candidate has not yet been deployed to the physical host. The live
acceptance must report the host's actual Hibr version through the new API
field before issue #81 can be closed.

## 0.1.489 candidate: rotation rebuilds pane geometry

0.1.489 closes Blit issue #73. A display rotation changes the logical pixel
rectangle and therefore the complete-cell pane grid. `apply_display_rotation`
now recomputes panes in the same accepted operation; live surfaces are still
refused with the existing resize-protocol conflict because their owner must
repaint the new geometry.

The display settings gate now asserts both directions: the dummy 1024×768
output reports a 96×64 pane after 90° rotation and returns to a 128×48 pane
after rotation back to 0. The full gate result is:

```text
DISPLAY_SETTINGS_PASS capabilities=derived rotation=presented refusal=in-use persistence=connector-name brightness=seam
```

The 0.1.489 package is installed on `192.168.10.54`; `/v1/version` reports
`0.1.489`, and the live topology reports matching `1920×2160` display and
`240×135` pane bounds. The live rotation write was deliberately not forced:
the login surface is attached and the API correctly returns the existing
`display_rotation_in_use` refusal. Hibr source is unchanged.

## 0.1.488 candidate: Hibr-compatible Kitty graphics deletion and KMS invalidation

0.1.488 fixes two independent stale-pixel causes at the Blit boundary. Hibr's
header-only Kitty delete (`a=d,d=I,q=2,i=<id>`) is now accepted without a
semicolon, so a deleted wallpaper/image is removed from the live graphics
scene. Direct KMS now includes the graphics-scene signature in its unchanged
view decision, so an image-only move or delete triggers the repaint needed to
clear the pixels it exposed. Hibr source is unchanged.

The focused pixel gate passes with exact evidence:

```text
SDL_WALLPAPER_DAMAGE_PASS before=0,0,255 after=0,0,255 deleted=0,0,0
```

The full renderer suite passes:

```text
RUN_GATES_PASS pass=43 skip=0 fail=0
```

The package is deployed on `192.168.10.54`; `/v1/version` reports `0.1.488`.
The post-restart live trace contains one Kitty capability query, zero image
uploads, and zero rejections. The captured live screen is a clean Hibr login
saver, so it confirms the deployment and presentation path but is not a
Kitty/Sixel image-transport acceptance.

This closes the confirmed parser/invalidation defects. It does not claim that
every live overlap is caused by Kitty/Sixel: a live capture must still show a
non-empty graphics trace before graphics transport is assigned as the cause.

## 0.1.487 candidate: Hibr-compatible Kitty continuation uploads

The live 0.1.486 capture established that the login screen and desktop cells
were present, but the authenticated graphics trace recorded 768 Kitty
`unsupported-action` rejections. Hibr's unchanged Kitty encoder sends the
opening wallpaper chunk with `i=<id>` and deliberately omits `i` from each
`q=2,m=1` / `q=2,m=0` continuation. Blit was incorrectly interpreting the
omitted id as image zero, so the visible wallpaper record remained
`complete:false`.

0.1.487 keeps the current upload id per terminal session and resolves those
id-less continuations before decoding. This is a Blit-only correction; the
Hibr source tree is unchanged. The focused TCC probe and
`tools/tests/graphics_trace_gate.rb` both pass with the exact Hibr wire form:
the continuation is accepted, the image reaches `complete:true`, and the
trace records `rejected=0`. The terminal and renderer suites pass
(`RUN_GATES_PASS pass=46 skip=0 fail=0`).

The live host still requires a fresh 0.1.487 deployment before its wallpaper
trace and screenshot can be called accepted. The current captured screenshot
is evidence that the login box renders, not proof that the multi-chunk
wallpaper path is fixed on the host until that deployment is installed.

## 0.1.504 candidate: preserve complete Hibr Kitty chunks

The 0.1.503 live capture showed the actual rendering failure shape: Hibr sent
thousands of Kitty wallpaper chunks, Blit recorded them at 4095 bytes, and
the final upload was rejected as `incomplete-data`. The terminal string buffer
was exactly 4096 bytes, so it could not hold Hibr's 4096 base64 bytes plus the
Kitty APC header. The resulting image inventory was empty while the desktop
continued rendering its terminal stream.

0.1.504 raises only the bounded terminal-string capacity to 16 KiB. Hibr and
its encoder are unchanged; decoded image limits are unchanged. The graphics
trace gate now builds a TCC probe that emits four 4096-byte chunks and passes
only when the image is complete, all four trace payloads are accepted, and no
rejection is added. The package and live-host acceptance remain pending until
this build is deployed and the authenticated live trace reports the same
successful boundary.

## 0.1.486 candidate: Blit login-manager root entrypoint

The root login failure found during the 0.1.485 Hibr acceptance attempt was
reproduced exactly: Hibr's unchanged `login.hibr` reached `need sys` with
`SYS_MOD` undeclared and exited before opening the login screen. This is the
expected result when the root entrypoint has not loaded Hibr's `sys` module.

0.1.486 makes the boundary explicit in the Blit package. Its
`blit-login.hibr` shim runs `mod load sys`, sources Hibr's installed
`login/login.hibr`, and invokes its existing `lg_main`. No Hibr source or
login behavior is copied. `hibr -n hibr/blit-login.hibr` passes, and the
package gate requires the shim and its explicit module load.

The controlled lifecycle gate remains unchanged; live PAM/logind acceptance
still requires Hibr #79 on the provided host or a VM. This change removes the
known missing-module blocker but does not claim that root PAM is complete.

## 0.1.485 candidate: Blit login-manager boundary

Blit #83 now has a first-class `/v1/login` resource. The root-owned service
supervises Hibr's login script in one PTY, exposes its state and underlying
`login_manager` session, stops it deterministically, and recreates a fresh
login session after the login process exits. The package configuration enables
this manager with `BLIT_LOGIN_AUTOSTART=1`; Hibr remains an external runtime
and its source tree is unchanged.

The focused root-service gate passed with TCC-built 0.1.485 source using a
controlled `/bin/true` login command:

```text
LOGIN_MANAGER_GATE_PASS restart=1->2 stop_status=204
```

This proves Blit's lifecycle, privilege gate, API resource, and restart
behavior. It does not prove PAM, logind, or a real authenticated Hibr desktop;
that acceptance remains Hibr #79 on a VM or real host. Hibr provider and join
issues remain separate and are not modified by this Blit change.

The reproducible package `blit_0.1.485-1_amd64.deb` has SHA-256
`0376c45fdcc07957d791d4b09462dbc1e8033b9203da3becd0b9ff1741fbe368`; the
package artifact gate rebuilt it byte-identically and verified the packaged
server, updater, adapter, schema, documentation, service, and login hook.

## 0.1.482 Hibr native-PTY live evidence

0.1.482 is deployed on `192.168.10.54`. The live API reports one Hibr
desktop session named `blit` with one primary client on the lower pane and one
`--join` client on the upper pane. It does not create two desktop instances.
The live renderer reports 60 Hz, a 16 ms refresh-aware interval, zero missed
deadlines, and zero API/render errors. An injected motion at physical `(100,
100)` in the upper pane produced the diagnostic coordinate `column=253,
row=6`: the pane-local column is translated into the single desktop's
projected union coordinate before delivery to the primary owner.

The live screenshot still fails visual acceptance: the upper joined viewport is
mostly flat/incomplete and the full wallpaper/desktop scene is not present.
This is not a presentation-rate failure and is not fixed by treating the
panes as separate terminals. It is the remaining Hibr 2-D union and picture
propagation boundary tracked by Hibr #240 and #238. The screenshot is evidence
that the implementation is not complete; it is not a claim of success.

Blit 0.1.483 applies a bounded one-refresh presentation barrier to the primary and
joined PTYs of one Hibr desktop. The barrier prevents a dirty member from being
presented alone while its sibling's redraw is already in flight, releases
immediately when all active members contribute damage, and times out at the
display interval so a quiet join cannot freeze the primary. The focused gate
`tools/tests/hibr_join_frame_barrier_gate.rb` passes and verifies that no
`render_path` event occurs between barrier open and release. This fixes the
Blit-side partial-frame presentation boundary only; it does not create the
missing Kitty/Sixel payload that Hibr did not send.

The subsequent live capture also exercised the Kitty capability boundary. Hibr's
deployed probe is the documented one-pixel `a=q ...;AAAA` form; 0.1.483 already
accepted it. 0.1.484 additionally accepts the header-only form and proves the
raw-PTY `OK` reply without allocating an image, but that compatibility change
is not the cause of the missing live wallpaper. After 0.1.484 deployment the
live trace records six Kitty queries, zero rejections, and zero image uploads.
That is direct evidence that Hibr did not send the picture in this run; Blit
cannot render a bitmap absent from the PTY stream. Picture/theme state and
joined picture propagation remain the Hibr boundary tracked by #238.

The earlier 0.1.481 visual acceptance is revoked by the subsequent
physical capture. The live 1x2 result is one Hibr desktop, not two terminal
instances, but the lower primary and upper join do not form a complete,
coordinate-consistent physical desktop: the upper pane is mostly empty, the
wallpaper is incomplete, and pointer/context-menu coordinates disagree. The
fresh capture also shows that distinct PTY surfaces and a nominal 60 Hz output
are not sufficient acceptance evidence. Hibr #240 now tracks the required 2-D
union/layout contract; Hibr #238 tracks spanning picture propagation.

The live renderer-versus-state comparison was then corrected to use the
topology-reported origin of each pane. The former probe always sampled the
top-left pane, which produced a false failure for the lower surface. With the
correct origin, `host_render_agreement.rb` passes for both live surfaces
(`surface-1` and `surface-2`): the pixels in every checked blank cell equal
the background reported by that surface's API snapshot. This is strong
evidence that Blit is painting the incomplete Hibr cell scene without stale
pixels or a pane-origin error; it does not turn absent Hibr picture payloads
into a complete joined wallpaper.

The same live capture also isolates the apparent display-wide shadow. Blit's
effects are disabled and its overlay list is empty. The Hibr cell snapshots
contain `#070f17` in 69.6% of the lower pane and 83.7% of the upper pane,
while the wallpaper colour is `#0d1b2a`. Hibr's desktop settings define a
55% shadow darkening, and `#070f17` is the corresponding darkened colour.
Therefore the dark regions are Hibr shadow cells, not an SDL effect, stale
frame, or Blit overlay. Hibr's `DT_SHADOW` is enabled by default and its
window/bar shadow geometry is calculated in the joined desktop union; the
wallpaper remains primary-display-confined. This combination explains the
large shadow-like regions in the physical photograph and remains part of the
Hibr #240 joined-union contract, not a Blit compositor defect.

Live 0.1.477 evidence identified the remaining join defect: the primary
`console-blit` adapter painted its API surface, but Hibr's hold PTY had no
primary stream to fan out, leaving the joined pane black. A native-Hibr probe
then produced real joined PTY cells, while the primary was incorrectly
rejected by Blit's adapter-owner requirement. The fix makes the packaged
entrypoint use Hibr's native console and makes Blit parse both primary and join
PTYs. The adapter remains available only for explicit `surface_mode: external`
clients.

The focused TCC server gate now runs both clients in `terminal` mode and proves
distinct PTY output on distinct surfaces, joined-surface write rejection, and
joined-pane input routing to the primary. The 0.1.481 live deployment on
`192.168.10.54` has exactly one Hibr hold session with one primary and one
join; `hold clients` reports the primary at `0 0 67 240` and the join at
`0 240 67 240`. The API evidence proves distinct PTY surfaces and
primary-owner routing, but not a correct physical desktop. The focused Blit
fix now translates joined-pane input into the projected Hibr union column;
its local gate asserts the exact logical coordinate.

Spanning Kitty/Sixel wallpaper is not yet accepted: Hibr's hold picture rule
does not send a bitmap to a client whose rectangle does not contain the whole
picture, so the upper viewport lacks that wallpaper region. This is recorded
with exact reproduction and acceptance criteria in
[Hibr #238](https://git.home.arpa/itdlabs/hibr/issues/238). Blit source does not
patch Hibr's picture semantics. The 2-D desktop/input contract is tracked in
[Hibr #240](https://git.home.arpa/itdlabs/hibr/issues/240). The exact Hibr
QEMU oracle, context menus, window placement, and reconnect behavior remain
open.

The preceding 0.1.477 artifact and evidence remain recorded in
[`releases/0.1.477.yaml`](../releases/0.1.477.yaml); its mirror-primary live
behavior is superseded by ADR 0079 and must not be used as the current join
contract.

## 0.1.472 fractional font-scale contract

The font API now accepts `1.0` through `3.0` in exact tenth-step increments;
integer requests remain compatible. The runtime stores tenths as fixed-point
state and applies one nearest-pixel rule to every physical cell boundary, so
an 8x16 font at 1.1 is reported and rendered as a 9x18 cell. That same metric
drives SDL, direct KMS, panes, PTY pixel sizes, display-session reflow,
surface origins, and pointer hit-testing. Hibr source is unchanged.

The focused suite exercised all 21 valid values, representative rendered
pixels at 1.0, 1.1, 2.0, 2.3, and 3.0, display-session reflow, and rejection
of 0.9, 1.05, and 3.1. The full focused font/renderer suite passed 47/47.
The exact package was then installed through the supervised updater on
`192.168.10.54`; `/v1/version` reports 0.1.472. The live API sweep accepted
all 21 values on one running primary Hibr session, including 1.1 as 9x18,
2.3 as 18x37, and 3.0 as 24x48. The live session remained registered and
painted, the SDL3 output reported 60 Hz with zero missed deadlines, and
1920x2160 screenshots were captured at 1.1 and 3.0. The exact package and
live evidence are recorded in [`releases/0.1.472.yaml`](../releases/0.1.472.yaml).

## 0.1.471 font-scale physical-pixel correction candidate

The live scale-3 screenshot exposed a gap in the previous 0.1.470 evidence:
`/v1/fonts` reported 24x48 cells and the pointer changed size, but the SDL
terminal glyphs remained at the base 8x16 raster size. The display-attached
Hibr surface also retained its old grid. This was a real renderer defect, not
an Hibr defect; Hibr source was not changed.

0.1.471 moves font scale into one physical cell-metric boundary. SDL scene
textures stay at physical output size, SDL drawing uses the scaled metrics
directly, pointer hit-testing uses those same metrics, and a display-attached
Hibr session reflows to the new display grid. The strengthened local font API
gate now checks pixels at scale 1 and scale 2, not only JSON metadata. The
focused font/renderer run passed 47/47, and the reproducible package is
`blit_0.1.471-1_amd64.deb` with the exact checksum in
[`releases/0.1.471.yaml`](../releases/0.1.471.yaml).

Live deployment and scale-3 screenshot acceptance remain pending until the
exact package is installed on `192.168.10.54`. No physical multi-monitor or
physical high-refresh claim is made here.

## 0.1.470 refresh-bound damage coalescing candidate

The live trace identified the jerky-motion root cause: Hibr surface commits
arrived about every 5 ms while the GLES2 backend rebuilt the full 1920x2160
scene for each event. The event-driven scheduler was re-phasing after each
completed frame and allowed pointer/pixel damage to bypass the output deadline.
0.1.470 retains pending work per output and presents the newest complete state
only when that output's refresh deadline is due; input and API handling remain
immediate. Pointer damage is now retained independently for every affected
output, which preserves the cursor across differently phased displays.

The TCC build and focused frame-rate, pointer atomicity, pointer-cache,
full-rebuild, and motion-trail gates pass. The frame-rate workload reached
60.000 Hz with zero missed deadlines while its faster-than-refresh producer
burst stayed below the bounded 125% guard. The reproducible 0.1.470 package is
deployed through the supervised API on `192.168.10.54`; `/v1/version` reports
0.1.470, exactly one primary Hibr owner is registered and painted, and a
120-event API pointer burst produced contiguous live render-trace intervals
of 15.209–16.486 ms (mean 15.971 ms) with zero missed deadlines. Physical
window-motion acceptance remains pending because the API burst isolates the
presentation scheduler but does not prove the operator's hand movement or
Hibr's drag action.

The live font sweep then exercised the existing ADR 0047 API one step at a
time. Scale 1 was accepted with 8x16 cells, scale 2 with 16x32 cells, and
scale 3 with 24x48 cells. Scale 4 and scale 0 were rejected with
`invalid_font_scale`. The three installed profiles—`blit-hibr-terminus16`,
`uni2-terminus16`, and `lat15-terminus16`—were each selected successfully via
`PUT /v1/fonts`; the original Hibr profile at scale 1 was restored. The Hibr
primary remained registered and painted, proving this is a live geometry/font
operation rather than a restart requirement.

## 0.1.469 KVM source identity diagnostics

The live KVM check showed that raw mouse and keyboard counters could increase
while `last_evdev_*_path` named an event node no longer present in the current
inventory. The path is historical after Linux re-enumerates a USB device, so
0.1.469 adds the associated input resource ID and a current `present` flag for
both mouse and keyboard sources. The OpenAPI schema, runtime implementation,
diagnostic guide, ADR 0071, and evdev scan gate are updated together. Hibr
source and input ownership are unchanged.

The focused schema, network, evdev scan, renderer, input, Hibr, terminal, and
hotplug-cycle gates pass. The complete local suite reached 69 passes, 3
explicit skips, and 0 product-test failures; its package gate was rerun after
the 0.1.469 release manifest was added. The reproducible package was then
installed through the supervised update API on `192.168.10.54`, where
`/v1/version` reports 0.1.469 and exactly one Hibr primary is registered and
painted. A post-deployment KVM input capture is still pending.

## 0.1.468 drag-action correction

The live drag investigation found a second, narrower defect at the Blit-owned
Hibr adapter boundary. Hibr's documented console protocol requires a held
button in every drag action (`mouse drag left row column`); the adapter had
sent `mouse drag row column`. Hibr therefore parsed the column as the row and
an empty column, which explains directional movement that appeared vertical
only. The correction adds the deterministic held-button name to plain and
modifier-prefixed drags. Hibr source remains untouched. The focused adapter
gate passes the corrected contract. The live host now runs 0.1.468 with one
registered, painted Hibr primary; a synthetic diagonal drag moved the window
with both axes. Physical pointer motion has also been observed with both axes,
but a physical button/drag acceptance is still pending. A separate capture
also shows a stale-render artifact that must be diagnosed independently of
the drag-coordinate correction.

## 0.1.467 live Alt-drag correction

The live host was updated through the supervised API to `0.1.467`, and the
existing primary was restarted cleanly before one new primary was created.
The new session registered its Hibr owner and painted 32,400 cells on the
single 60 Hz output.

The root cause of the window-movement report was then confirmed at the source
boundary: Hibr's window manager requires `alt-press` followed by `alt-drag`,
but the Blit pointer stream previously omitted pointer modifier state. The
new live WebSocket stream carries `alt:true` while the held Alt state is
active, and the adapter gate translates it to `mouse alt-drag`. Hibr source
was not changed. Physical Alt-drag after this deployment remains the final
operator check.

## 0.1.466 live acceptance

The reproducible `0.1.466-1` package was uploaded through the supervised update
API to `192.168.10.54` and `/v1/version` returned `0.1.466`. The live host
reported one 60 Hz 1920x2160 output with refresh-aware scheduling at 16 ms.

The API then created exactly one Hibr primary using the packaged
`blit-session.hibr` entrypoint. Session 1 reported `hibr_desktop.role=primary`,
held session `blit`, a registered owner, an owner-painted surface, and 32,400
populated cells at 240x135. A cached framebuffer capture contained the full
menu bar, wallpaper, icons, cursor, and Hibr menu. API-injected pointer motion,
left-button press/release, and F10 key events were accepted and appeared in
the diagnostic trace; the probe recorded zero missed deadlines and render
times between 0.6 and 13.9 ms.

The operator subsequently confirmed that the physical mouse and keyboard work
on the live display. This closes the single-output manual input smoke check,
but not sustained physical-motion cadence, multi-output joins, hotplug, or
the outstanding screensaver trail issue (#72). Those require separate
evidence and remain open.

## 0.1.465 current candidate

Issue #75 was reproduced on the physical host while preparing the next input
and rendering run. Blit 0.1.464 accepted a revision-matched
`configuration.enabled=true` write for the only keyboard and opened its evdev
descriptor, but after the coalescing interval `/v1/settings` still held
`enabled:false` at revision 14. The settings merge could not distinguish a
known property omitted because it returned to its default from an unknown
future property that must survive a downgrade; it copied the old value back,
so the next restart would disable the keyboard again.

The serializer now uses the same input-property vocabulary as request
validation and makes the ADR 0067 distinction explicit: known and applicable
properties absent from live non-default state are removed, known but presently
inapplicable properties remain dormant, and unknown properties are preserved.
The focused gate fails twice against 0.1.464 (`enabled:false` remains and is
restored after restart) and passes against the candidate, including a separate
future-property preservation scenario.

The TCC-built candidate passed the canonical full suite with 64 passes, five
explicit skips, and zero failures, including the 120-second four-session soak
and a settled 59.999 Hz renderer workload. Two independent Debian builds were
byte-identical; the artifact gate matched the package, server, update helper,
adapter, schema, and documentation hashes. The package SHA-256 is
`c977de538edbb9c5ab75f4644138223e9d22c0f2f20246a351ad8c8db0d70828`.

The supervised update API deployed 0.1.465 to the physical host. The exact
live sequence then persisted `enabled:false` at settings revision 26,
re-enabled the keyboard and removed that property at revision 27, requested an
in-process restart, and required the reported uptime to reset. After the
asynchronous evdev opener settled, the keyboard reported `enabled:true` and
`open:true`, runtime reported one keyboard, and settings revision 27 still had
no keyboard override. This closes issue #75 on the named host. No Hibr session
was running during the settings acceptance; rendering and physical input
acceptance remain separate next steps.

## 0.1.410 current candidate

The terminal-input JSON decoder now handles the complete bounded JSON escape
set used by API clients, including Unicode escapes that represent VT control
bytes. The regression sends JSON `\\u001bX` to a PTY and verifies that the
terminal receives ESC followed by `X`, rather than the literal characters
`u001bX`. The full TCC-built terminal conformance suite passes, including
VT500, UTF-8, Hibr parity, Kitty, Sixel capability, and the new
`network-terminal-input-json-escapes` case. This candidate has not yet been
deployed to the physical host; the host remains on 0.1.409 until the package
and live lifecycle gates complete.

## 0.1.409 current candidate evidence

The production Hibr launch path now installs and selects an explicit
`blit-runtime-console.hibr` RC for API-launched Hibr children. The RC matches
the validated QEMU contract and loads only `console-blit`; the parent Blit
entrypoint already loads Hibr's native `img`, `pty`, `term`, and `hold` modules.
This avoids duplicate native module loads while closing the systemd/deployment
gap where QEMU supplied `HIBR_RC` but the live service did not. The package
gate requires this RC and checks that it loads the configured Blit adapter.
Hibr source remains unchanged.

The current launcher also opens the Blit provider before the stock desktop
enters its held-session transition. A focused live API experiment proved the
distinction: the explicit pre-open path registered the owner and produced 229
printable cells, while the previous implicit desktop path failed closed with
`hibr_attach_unresolved` and an empty surface. The fix is Blit-owned and does
not alter Hibr.

The TCC-built 0.1.407 candidate passed the OpenAPI schema gate, full terminal
conformance, Hibr singleton checks, and the exact Hibr 0.99.100 QEMU lifecycle
matrix: `LAYOUT_MATRIX_PASS`, `HIBR_PRIMARY_RESTART_PASS`,
`HIBR_JOIN_RECONNECT_PASS`, and `HIBR_PANE_MATRIX_PASS`. The live external
image probe also registered its owner and completed a 512x512 graphics upload
through the deployed adapter. Physical multi-monitor, physical button,
physical high-refresh, and TCG 240 Hz deadline-capacity claims remain open.
The 0.1.407 package is deployed on the supplied host and `/v1/version` reports
0.1.407. Its live SDL3 output reports 60 Hz and zero missed deadlines. A
single-primary desktop launch was tested through the API; Hibr reported its
desktop startup, but no Blit adapter owner registered and the fail-closed
`hibr_attach_unresolved` path retired the empty surface. The host was cleaned
back to zero sessions afterward. This is an open Hibr integration failure, not
a renderer or frame-rate pass claim.

The 0.1.409 candidate supersedes that failed live attempt. After explicitly
retiring the stale detached Hibr hold left by the failed run, the ordinary
packaged `blit-session.hibr` API launch stayed `running`, registered its owner,
and reached 32,400 printable cells at 240x135. The captured 1920x2160
framebuffer contained the Hibr menu bar, wallpaper, desktop icons, and status
line **as terminal cell art**: that capture holds ten distinct colours in
total and no bitmap was presented at any point -- `graphics_images` was 0,
`graphics_texture_uploads` 0 and `pixel_frames_accepted` 0. The wording above
used to stop at "contained the Hibr menu bar, wallpaper, desktop icons, and
status line", which is true of cell art and easy to read as a picture having
been presented. It had not been (issue #19). A versioned API input write was
accepted while the owner remained registered. This is live one-output evidence; physical pointer events and
additional physical outputs remain open.

The same live 0.1.409 service now has explicit API routes for the discovered
physical pointer and keyboard to the single primary session. The runtime
reported 2,505 evdev mouse events, including 1,573 motion events and 10 button
events, with 927 dispatched input events and no missed presentation deadlines.
The filtered trace showed API-injected button delivery to the primary; the
physical button trace contract remains open until a button event is captured
with an evdev source in the trace. Device counters prove that Blit read input;
the source-qualified trace proves which device and target session received a
specific event.

Fresh QEMU input/render evidence was also rerun against the exact 0.1.409
server and Hibr 0.99.100 fixture. With `blit.input_soak=1`, the guest passed
`BLIT_INPUT_STREAM_PASS`, `BLIT_INPUT_GAMEPAD_PASS`,
`BLIT_INPUT_RAW_EVDEV_PASS`, `BLIT_INPUT_MOUSE_REPEAT_PASS`,
`BLIT_INPUT_MULTI_MOUSE_BUTTON_STATE_PASS`, and
`BLIT_INPUT_RENDER_SOAK_PASS`. The raw fixture observed 926 events, 547
motions, 44 buttons, one ignored repeat, and two aggregate button-state
coalesces. These are exact-current virtual input/render results; they do not
close the source-qualified physical button trace on the supplied host.
The same run now also passes `BLIT_INPUT_POINTER_BUTTON_TRACE_PASS`, proving
that the critical trace retains an evdev source, button transition, and routed
target session rather than merely incrementing aggregate counters.

The exact-current two-output 240 Hz pixel-stream fixture accepted all 240
complete frames with zero pixel-frame errors. Under this host's QEMU TCG
execution it recorded 22 additional deadline misses and 78 page-flip presents,
so `PIXEL_FRAME_RATE_240_FAIL` remains an honest
`open_tcg_deadline_capacity` result. This is not evidence of transport loss or
a physical renderer defect; KVM-backed or physical hardware evidence is still
required before changing the production scheduler or closing the 240 Hz gate.

## 0.1.405 current candidate evidence

The TCC-built 0.1.405 candidate adds bounded producer-side surface cadence
diagnostics to `/v1/diagnostics/runtime`: `surface_commit_hz`, its settled
window counters, age, and inter-commit gaps. This is intentionally separate
from output presentation cadence, so a slow or idle Hibr producer cannot be
misreported as an SDL/KMS refresh failure. An explicit eight-update API
workload measured `surface_commit_hz=7.998` with approximately 158 ms gaps.

The corrected frame-rate gate now discards the cold-start presentation window
and requires a settled window. The rebuilt 0.1.405 server measured `59.996 Hz`
at a 60 Hz SDL dummy target with zero missed deadlines. The API schema (33
paths), full VT/UTF-8/Kitty/Sixel/Hibr terminal conformance, singleton,
restart, and 20-second four-session soak gates passed; the soak remained below
the 131072 KiB RSS ceiling.
The focused current-source damage gates also passed:
`SDL_WALLPAPER_DAMAGE_PASS` preserved the wallpaper pixel across an
incremental cell commit, and `POINTER_WALLPAPER_STRESS_PASS` restored the
under-pointer scene across six samples with three pointer-cache hits. These
results cover Blit's local composition path; they do not convert the live
host's absent graphics objects or zero physical evdev events into a Hibr or
hardware acceptance claim.
The current PTY/API graphics gates also passed: Kitty texture-cache reuse
reported five cache hits without an additional upload, and the fragmented
RGBA pixel-frame gate accepted and drained all 30 frames (`26766 Hz` ingest
rate, zero pending frames). These validate the controlled graphics transport;
they do not imply that an external Hibr session actually emitted a Kitty or
Sixel image.

Fresh QEMU/VKMS images staged with the exact Hibr 0.99.100 checkout passed the
four-output Hibr window-content gate on all four 1024x768@240 Hz outputs and
the two-output layout/pane/primary-restart/join-reconnect lifecycle matrix.
The fresh two-output input/render soak also passed against this exact binary:
`LAYOUT_MATRIX_PASS`, `BLIT_INPUT_GAMEPAD_DISCOVERY_PASS`,
`BLIT_INPUT_STREAM_PASS`, `BLIT_INPUT_GAMEPAD_PASS`,
`BLIT_INPUT_RAW_EVDEV_PASS`, `BLIT_INPUT_MOUSE_REPEAT_PASS`,
`BLIT_INPUT_MULTI_MOUSE_BUTTON_STATE_PASS`, and
`BLIT_INPUT_RENDER_SOAK_PASS`. It observed 905 raw mouse events, 533 motion
events, 44 button events, one ignored repeat, and two aggregate button-state
coalesces. This is virtual input/render evidence, not physical evdev
acceptance.
Fresh four-output QEMU runs with the same binary and Hibr checkout also
passed independent red/green/blue/yellow output pixels and the stock Hibr
primary-content case. All four outputs reported 1024x768@240 Hz and
`KMS_FOUR_OUTPUT_PASS`; the Hibr run reported one populated primary and three
`HIBR_CONTENT_AUXILIARY_EXPECTED_BLANK` joins followed by
`KMS_FOUR_HIBR_PRIMARY_CONTENT_PASS`. The blank auxiliary state is an
intentional Hibr desktop-placement result, not a renderer pass-through.
The exact server SHA-256 is
`3b45d994ac80ae65588e4981546c31ebe6b42a8f664a42c3176a750677e14d46`.
Physical deployment remains deliberately unperformed; the supplied host is
still 0.1.401, one 60 Hz output, and its read-only evidence shows 60 Hz
presentation with zero missed deadlines but roughly 7 Hz Hibr surface commits
and zero physical evdev mouse events.

The remaining 240 Hz pixel-stream claim was characterized again against the
same 0.1.405 binary. QEMU accepted all 240 complete frames with zero pixel
frame errors, but the two-output VKMS guest accumulated additional page-flip
deadline misses in every TCG run: 11 with one vCPU, 12 with two, 18 with four,
and 26 with eight vCPUs (the earlier two-vCPU run measured 12). This host has
no `/dev/kvm`, so these are TCG capacity results, not evidence of physical
240 Hz behavior or a proven renderer defect. The production scheduler remains
unchanged; KVM-backed or physical hardware evidence is required before this
acceptance can be closed.

## 0.1.404 current candidate evidence

The TCC-built 0.1.404 candidate adds compact `codepoint_cells` and
`printable_cells` fields to `SurfaceSummary`, and separates the four-output
Hibr visual gate into the stock-desktop primary-content case and the
deterministic populated-window case. Exact Hibr 0.99.100 QEMU evidence passed
both `KMS_FOUR_HIBR_PRIMARY_CONTENT_PASS` and
`KMS_FOUR_HIBR_WINDOW_CONTENT_PASS`; the latter recorded visible screenshot
content on all four 1024x768@240 Hz outputs. The stock case correctly recorded
blank auxiliary joins as an expected Hibr state. Hibr source was not modified.

Focused TCC/local evidence passed: OpenAPI schema (33 paths), full terminal
conformance, Hibr singleton/owner/restart, font/scale, pointer composition,
54.368 Hz frame-rate gate with zero missed deadlines, and a 20-second
four-session soak (`2532` snapshots, `230` resizes, peak RSS `66704 KiB`).
Exact QEMU lifecycle, four-output independent pixels, and input/render soak
also passed. The 0.1.404 Debian artifact passed the package gate; its exact
checksum and source relationship are recorded in
[`releases/0.1.404.yaml`](../releases/0.1.404.yaml). The TCC server SHA-256 is
`7f44f7aa883fc99a2f987d92473105b0ae62db960b5ac67286aba043df291187`.
Physical-host deployment remains not performed.

## 0.1.403 current candidate evidence

The strengthened four-output Hibr visual gate is now correctly split into two
acceptance cases. The stock desktop passes
`KMS_FOUR_HIBR_PRIMARY_CONTENT_PASS`: the primary contains desktop content,
all four Hibr surfaces and KMS views exist, and auxiliary joins are explicitly
allowed to be blank because Hibr keeps its desktop chrome on the primary until
a window is placed there. The deterministic Hibr one-window workload passes
`KMS_FOUR_HIBR_WINDOW_CONTENT_PASS` with visible screenshot content on all
four outputs. The earlier single threshold was invalid because it treated an
intentional Hibr blank join as a Blit renderer failure.

The TCC-built 0.1.403 server makes the Hibr owner handshake fail closed for
fresh primaries as well as joins and resumes. If the adapter never registers
its token-scoped owner and bounded discovery finds no matching process, Blit
marks the session failed, retires its surface, disables its routes, and emits
`hibr_attach_unresolved`. A legitimate registered owner may restart and
reconnect; the restart path is not mistaken for an ownerless launch. Hibr
source was not modified.

Exact build hashes: server
`f4b8396118b55da28d82bbf0e8856ef23c5b19b3a7fa979960d05e40ff0efaac`, update
helper
`cff624c8da3a24c3867e7230407b9dcf49cfae5597e74cb1974d63ea6f21dcad`, and
adapter
`c1ac8a2cc2898b27411f79a665ce3c0c3156b227b9a2c4d77347c072b6a70db9`.
The ownerless local probe passed; local singleton, restart, font/scale,
pointer-composition, schema, and full terminal-conformance gates passed.
The exact Hibr 0.99.100 QEMU two-output lifecycle passed layout, four-pane,
primary-restart, join-reconnect, and final-topology markers. The independent
four-output 240 Hz pixel fixture, stock-desktop primary-content gate, and
four-output Hibr window-content gate passed. The input soak also passed.

This candidate is not deployed to the physical host. The host remains on
0.1.401; its current read-only evidence and the roughly 7 Hz Hibr producer
cadence are recorded below. Physical evdev, multiple physical monitors,
physical Hibr geometry, and physical high-refresh acceptance remain open.

## 0.1.402 prior candidate evidence

The TCC-built 0.1.402 server adds diagnostic classification to every
non-deferred API cell commit: `transport=api-cells` and the owning
`surface_mode` (`terminal`, `external`, or `mirror`). This distinguishes a
producer-side API update from PTY terminal output in the bounded trace; it
does not change rendering, Hibr behavior, or frame pacing. The optional Hibr
adapter was rebuilt against the exact configured Hibr 0.99.100 ABI; the
development checkout at `/home/osakka/hibr` is 0.99.120 and was not used or
modified.

The exact TCC server binary SHA-256 is
`1a6cf13e4a26c6a68d2e729f9c34047209b09ecd8db5fedccdac4c8021a5793f`; the
adapter SHA-256 remains
`c1ac8a2cc2898b27411f79a665ce3c0c3156b227b9a2c4d77347c072b6a70db9`.
The API schema gate passed with 33 paths, the full terminal conformance
suite passed, and the new external-surface trace assertion passed. Restart
of the exact serving binary passed, session write/resize passed, and the
bounded frame-rate gate measured `54.370 Hz` over `514 ms` with zero missed
deadlines. The 20-second four-session soak passed with `2372` snapshots,
`216` resizes, and peak RSS `18540 KiB` under the `131072 KiB` limit.

This candidate has not been deployed to the physical host yet; its live
0.1.401 evidence remains below. QEMU and package acceptance are run against
the final 0.1.402 artifact before release publication.

The 0.1.402 Debian artifact passes the package allowlist, embedded-version,
binary, schema, and packaged documentation gate. Its SHA-256 and source
commit are recorded in [`releases/0.1.402.yaml`](../releases/0.1.402.yaml).
The exact Hibr 0.99.100 QEMU lifecycle fixture boots two VKMS outputs, passes
the 1x1/2x1/1x2/2x2 layout matrix and four-pane session matrix, then passes
primary restart, joined-client reconnect, and final topology cleanup. The
separate adapter probe also passes. Earlier QEMU evidence using a 0.99.120
development Hibr fixture is not interchangeable with this 0.99.100
package-ABI result.

The exact 0.1.402 four-output VKMS fixture passes independent red/green/blue/
yellow screenshot pixel assertions on four 1024x768@240 Hz outputs. Its
four-output Hibr mode passes with one primary and three `desktop --join`
clients and four live surfaces. The exact QEMU input-soak fixture passes
stream input, gamepad discovery, raw evdev events, mouse-repeat filtering,
multi-device button aggregation, and render soak. These are virtual-display
and virtual-input results; physical monitor, evdev, and high-refresh
acceptance remain host-specific and open.

## 0.1.401 prior release evidence

The current rebuilt package is `blit_0.1.401-1_amd64.deb`. Its exact
checksum/source relationship is recorded exclusively in
[`releases/0.1.401.yaml`](../releases/0.1.401.yaml). The TCC server binary
SHA-256 remains
`8cade338f37f1374549af5d56a2803c083ebbda9ee5a82eedaf6bc5fe2f872a7`.

The 0.1.401 source and artifact pass the OpenAPI structural gate (33 paths,
including the versioned terminal-input subresource), full terminal
conformance, Hibr singleton ownership, font/scale, resize, SDL glyph/pixel,
frame-rate, binary pixel-frame, package, and 20-second four-session soak
gates. The latest local soak recorded `2300` snapshots and `210` resizes with
peak RSS `80636 KiB` under the `131072 KiB` limit. No Hibr source was changed.
The restart gate also re-executes the exact TCC-built binary through
`/v1/control/restart`, preserves its port, and returns a ready runtime; it no
longer depends on the package installation path.

Fresh QEMU evidence also passes: the lifecycle/rejoin wrapper emitted all
four required markers, and the four-output direct-KMS/Hibr fixture reached
four independent 1024x768 outputs, four sessions, independent pixel checks,
and `KMS_FOUR_OUTPUT_PASS`/`KMS_FOUR_HIBR_PASS`. These are virtual-display
results; the fixture's TCG deadline misses are retained as VM timing evidence
and are not described as physical 240 Hz scanout.

The authorized live host reports 0.1.401, one SDL3/OpenGLES2 output at
1920x2160 and 60 Hz, and zero renderer errors. The network frame-rate gate
measured `60.071 Hz` over a 516 ms window with `0` missed deadlines and a
16 ms target interval. This is valid live presentation evidence for that one
output under an active bounded workload; it is not a claim that an unchanged
terminal scene is continuously re-presented at vblank.

A fresh live primary was then created through the documented API using the
unchanged Hibr installation. The one primary reached `running`, its pointer
and keyboard routes were installed for `session-4`, and the canonical
10-second experience capture recorded `106` surface commits and `106`
damage-driven presents in `14120 ms` (`7.507 Hz`), with zero missed
deadlines. The runtime's selected target remained 60 Hz/16 ms. This lower
number is producer/damage cadence, not scanout rate; it identifies the live
Hibr scene-update path as the next performance/visual-fidelity boundary.
The cached 1920x2160 framebuffer artifact is recorded outside the repository
at `/tmp/blit-live-audit-primary-20261009T110254Z/screenshots/display-1.bmp`
with SHA-256
`14237d62536919fcda0cf642ff022ee2f8bc0d75354281db25c7e4e8feb57b46`.
The capture observed no physical evdev mouse events, so physical button and
motion acceptance remains open. The host exposes one physical output;
physical multi-monitor Hibr geometry and physical 120/240 Hz scanout remain
open and are not inferred from QEMU or synthetic API input. Visual Hibr
geometry/fidelity remains an open acceptance boundary pending a deliberate
comparison against the expected desktop image.

A subsequent read-only API framebuffer capture from that same live 0.1.401
host made the visual boundary concrete. The 1920x2160 image is mostly black
with sparse colored dot glyphs; its matching `surface-4` snapshot is 240x135,
revision `1340583`, with 1,114 non-space cells and zero graphics images. The
capture hash is `5a39acb2fa382e8d52bf843f28a7077ba7d86a49d23793ce3280feca637887d7`
and it was saved outside the repository at
`/tmp/blit-live-capture-20261009.bmp`. This proves the API surface and
framebuffer agree for that scene; it does not prove that an expected Hibr
wallpaper was delivered to Blit, and it is not evidence for the undeployed
0.1.405 candidate.

A later read-only runtime sample on the same unchanged 0.1.401 host reports
`present_calls=12022`, `surface_commits=11964`, `frame_rate_hz=7.190`,
`missed_deadlines=0`, one 60 Hz output, one session, two input routes, and
zero physical evdev events during the sample. This is consistent with the
earlier finding: the service can schedule/present at the display cadence, but
the active Hibr producer is only committing changed scenes at roughly 7 Hz
in this workload. It is live evidence for 0.1.401, not validation of the
un-deployed 0.1.402 artifact.

## 0.1.400 deployed baseline and 0.1.401 contract correction (historical)

The deployed baseline TCC build embeds version `0.1.400` and has server SHA-256
`73a07f5a0cce7148c77aa673f2b14cf1defab629d36e8011a8660673eef36cf4`.
The Debian artifact
`blit_0.1.400-1_amd64.deb` has SHA-256
`3881dd591e41e87acd61a973ce47bd37e1636a23957b82ff667ed0572daf9a58` and
passes the package allowlist, embedded-version, schema, binary, and packaged
documentation checks. It was deployed through the supervised update API and
the live host now reports 0.1.400.

The 0.1.400 binary passes the local font, resize, glyph, frame-rate,
pixel-frame, Hibr singleton, full terminal-conformance, and 20-second
four-session soak gates. Fresh QEMU images staged with the 0.1.400 binary
also passed the two-output lifecycle/rejoin wrapper, raw multi-device input
(`BLIT_INPUT_RAW_EVDEV_PASS`, `BLIT_INPUT_MOUSE_REPEAT_PASS`, and
`BLIT_INPUT_MULTI_MOUSE_BUTTON_STATE_PASS`), and four-output Hibr marker
(`KMS_FOUR_HIBR_PASS`) runs. These remain virtual evidence; no physical
multi-monitor or physical high-refresh claim is made.

The deployment also closed the live terminal-input observation: the canonical
`POST /v1/terminal-sessions/{session_id}/input` route accepted a 9-byte
`LIVE400` request and the session was deleted cleanly. The earlier `405` came
from probing the undocumented parent session path; the OpenAPI file and ADR
0022 had incorrectly described that parent path. 0.1.401 corrects the schema,
API guide, gateway guide, ADR wording, and adds `api_schema_gate.rb`, which
rejects both the wrong parent POST and a missing `/input` route.

The corrected 0.1.401 package was then deployed through the supervised update
API and `/v1/version` reported 0.1.401. A valid plain UTF-8/box-drawing live
capture produced a 1920x2160 24-bit BMP with SHA-256
`4647a5073882e2040dfca4d255b9f6735d133a8857717a8a50996830800f2d58`.
The authoritative surface snapshot and framebuffer both showed `BLIT401 TEST`,
UTF-8 characters, and box-drawing text legibly. The canonical `/input` route
accepted terminal data, synthetic pointer motion/button events were accepted,
and cleanup returned sessions, surfaces, streams, and input routes to zero.
The host still has one physical 60 Hz output; this is not multi-monitor or
physical-evdev acceptance.

The 0.1.401 TCC binary has SHA-256
`633167c51397f0a7c129406a5ecb192e24f0fb16919e815d2ac0e991f75a500f`.
Its corrected-schema Debian artifact checksum is recorded in
`releases/0.1.401.yaml`.
The artifact passes the package gate, API schema gate, terminal conformance,
font/resize/glyph/pixel/frame gates, singleton ownership, and the 20-second
four-session soak. Fresh 0.1.401 QEMU images pass the lifecycle/rejoin
wrapper, raw multi-device input markers, and four-output Hibr marker.

## 0.1.399 focused local acceptance after commit 6888dc5

The canonical TCC rebuild produced the 0.1.399 server binary with SHA-256
`dd7095814328ed384027ccfc90969ad5dab81af96827ffa2889ed37d65fc4071`.
The following local SDL dummy/software gates passed against that binary:

- pointer composition, pane hit-testing, free-pane fallback, hidden-cursor
  damage, pointer-plus-terminal damage atomicity, and wallpaper-pointer stress;
- SDL background batching, graphics-image cache reuse, and wallpaper damage;
- authenticated network access, HTTP fragmentation/back-pressure, WebSocket
  stream replay, session deletion escalation, clean API shutdown, update
  cancellation/idle timeout/reset, and screenshot overlay invalidation;
- font selection/scale reflow, session write/resize, SDL glyph rendering,
  frame-rate scheduling (`54.373 Hz` over a `30 Hz` minimum), and binary pixel
  frames (`30/30` accepted with `0` ingest errors);
- the complete terminal conformance suite, Hibr singleton ownership, and a
  20-second four-session terminal soak (`2240` snapshots, `204` resizes,
  peak RSS `80652 KiB` under the `131072 KiB` limit).

The QEMU reruns used the exact current staged 0.1.399 fixtures and exited
cleanly. The two-output lifecycle fixture emitted
`LAYOUT_MATRIX_PASS`, `HIBR_PRIMARY_RESTART_PASS`,
`HIBR_JOIN_RECONNECT_PASS`, and `HIBR_PANE_MATRIX_PASS`. The input fixture
emitted `BLIT_INPUT_RAW_EVDEV_PASS`, `BLIT_INPUT_MOUSE_REPEAT_PASS`, and
`BLIT_INPUT_MULTI_MOUSE_BUTTON_STATE_PASS` with 800 raw events. The
four-output fixture emitted `KMS_FOUR_HIBR_PASS`. These are virtual QEMU/VKMS
results; they do not close the physical monitor, physical evdev, or physical
120/240 Hz scanout gates described below.

## Live host 0.1.398 physical/API observation: 2026-10-09

The authorized read-only/API probe at `192.168.10.54` reported Blit 0.1.398,
one `1920x2160` output at 60 Hz, SDL3/OpenGL ES2, and one discovered evdev
pointer. A temporary ordinary `/bin/sh` session was created on `display-1`
with the display-derived `240x135` cell geometry. Its screenshot was a
1920x2160 24-bit BMP (SHA-256
`a10c539a70cb4f4c63a5258b94241b2be13a13460f40844228a9867dedd95153`); visual
inspection showed legible ANSI-colored text, UTF-8/box-drawing characters, a
correctly placed cursor, and a correctly placed pointer. Two synthetic API
input events (motion and button) were accepted and appeared in runtime input
counters. Physical evdev counters remained zero, as expected for a synthetic
probe.

The 0.1.398 host initially returned `405 method_not_allowed` for the then-
incorrectly documented parent session POST. After deployment of 0.1.400, the
correct `/input` route accepted terminal data; the temporary session was
deleted and a follow-up runtime query reported zero sessions, surfaces,
streams, and input routes. No Hibr process or Hibr source was touched.

## Current 0.1.399 Hibr singleton-owner and lifecycle acceptance

The TCC-built server now classifies the Hibr desktop entrypoints and enforces
one primary owner per Hibr held-session name. The local API gate passed all
four cases: an orphan `--join` returns `409 hibr_desktop_owner_missing`, one
primary is accepted and reports `hibr_desktop.role=primary`, a duplicate
primary returns `409 hibr_desktop_exists`, and a join against that primary is
accepted and reports `hibr_desktop.role=join`. Ordinary non-Hibr shell
sessions remain unaffected. The request argument buffer is cleared for every
request; this prevents a prior `--join` argument from leaking into a later
shorter request. Hibr source was not modified.

The exact 0.1.399 binary was also staged with the unchanged Hibr 0.99.100
tree into the four-output VKMS fixture. It reached four displays, one primary
Hibr desktop plus three `--join` clients, four running sessions and four
surfaces, and emitted `KMS_FOUR_HIBR_PASS`. The QEMU fixture ran at its
configured 240 Hz mode but reported TCG scheduling misses; this validates
topology and ownership, not physical 240 Hz performance.

The exact current TCC binary also passes the restart/rejoin variant in the
two-output VKMS fixture: `LAYOUT_MATRIX_PASS`,
`HIBR_PRIMARY_RESTART_PASS`, `HIBR_JOIN_RECONNECT_PASS`, and
`HIBR_PANE_MATRIX_PASS`. The fixture uses the real staged stock Hibr desktop
launcher, kills the registered primary owner, kills a joined attach client,
and then creates a replacement join. The primary remains running while the
dead join becomes `failed`, allowing the replacement join to be accepted.
The fixture's `qemu_exit=0` is checked alongside all four markers; no Hibr
source was modified. The host-side
`tools/tests/qemu_hibr_lifecycle_gate.sh` wrapper independently asserts the
four markers, so a guest poweroff cannot mask a missing lifecycle result.

The 0.1.399 direct-KMS 240 Hz pixel-stream run accepted all 240 frames with
zero pixel-frame errors and selected a real KMS-reported 240 Hz mode, but the
visible cadence gate correctly failed under QEMU TCG: the two-vCPU run grew
missed deadlines from 20 to 40. A comparison with eight vCPUs and
multithreaded TCG improved the run to 3 baseline and 16 post-stream misses,
but still did not pass. `/dev/kvm` is absent on this test host. This is
retained as VM-capability evidence; it is not converted into a physical
240 Hz claim or “fixed” by enabling asynchronous tearing.

## Current 0.1.396 live glyph geometry acceptance

The live host accepted 0.1.396 and reported SDL3/OpenGL ES2 with
`render.glyph_path=geometry-batch`. A fresh API-launched Hibr desktop produced
a clean framebuffer with the wallpaper, menu, icons, and terminal status
legible; no coloured-dot glyph corruption was observed. The 60 Hz output
reported zero missed deadlines. During a five-second live sample the output
recorded 232 presents (about 46 Hz) while the desktop workload was active.
The Hibr sessions were deleted afterward and the live resource counts returned
to zero. `BLIT_SDL_GLYPH_BATCH=off` remains the explicit rollback path.

## Current 0.1.394 font API and left-edge artifact evidence

The TCC-built 0.1.394 server passes the font API gate: profile enumeration,
runtime scale 2 (8x16 to 16x32 cells), pane/PTy reflow, profile selection, and
restoration to scale 1. The packaged 0.1.394-1 artifact passes the package
gate and was deployed to the live host.

On the live Hibr session, the full authoritative surface snapshot contained
the text `0` at cells `(0,20)` and `(0,21)`, and the surface cursor was at
`(0,22)` with a visible block cursor. The cached framebuffer screenshot shows
the same two glyphs followed by that cursor at the left edge. This establishes
that the reported `0`/block is Hibr-owned terminal content and cursor state,
not an uninitialized Blit framebuffer or an extra compositor overlay. The
session was deleted after capture; the live resource counts returned to zero.
No Blit change was made to conceal or rewrite those cells.

## Current 0.1.392 troubleshooting and refresh-boundary evidence

## Current 0.1.393 Hibr lifecycle and tall-surface evidence

### Live host boundary capture: 2026-10-09

The live host at `192.168.10.54` was queried through the network API using
Bash `curl`. It reported 0.1.393, one SDL3/OpenGL ES2 output at 1920x2160 and
60 Hz, zero missed deadlines, and a 16 ms refresh-aware target. A controlled
ordinary `/bin/sh` session at the same `240x135` surface size returned
`stty size` as `135 240`, and its surface cell snapshot contained the marker;
this proves the Blit PTY geometry and full-height terminal path independently
of Hibr.

The unchanged packaged Hibr entrypoint was then launched through the API with
the same `240x135` surface. The captured framebuffer showed Hibr's scene in
the upper region and a uniformly black lower region. Runtime evidence showed
the Hibr session running with `xterm-kitty` and Kitty/Sixel capabilities,
nonzero terminal bytes and surface commits, SDL presents, zero missed
deadlines, and no physical evdev events during the automated window. The
capture is retained under
`diagnostics/live-hibr-screenshot-20261009T084834Z/`; it is a diagnostic
failure for Hibr full-height geometry, not a Blit renderer pass. Hibr source
was not modified. The physical Hibr geometry gate therefore remains open and
requires Hibr-side investigation/support, while Blit retains the evidence and
the API control path.

The exact TCC-built 0.1.393 source passes terminal conformance and the
focused atomic pointer, wallpaper, and background-batch gates. The canonical
four-output VKMS fixture now explicitly stages the Blit Hibr adapter path;
the tall 240x135 fixture passes `KMS_FOUR_HIBR_TALL_PASS` with one primary and
three joins. This closes the previously open tall-surface boundary in QEMU.

The fix keeps API-launched Hibr sessions running after the short launcher
process exits, continues bounded owner reassertion after the launcher PTY is
closed, and exposes owner registration/discovery state in `hibr_attachment`.
The adapter registration path is Blit-owned and token-scoped. Hibr source was
not modified. Physical Hibr geometry, physical multi-monitor behavior,
physical evdev behavior, and physical high-refresh acceptance remain open.

The exact TCC-built 0.1.392 SDL renderer passes the focused pointer-plus-damage
atomicity, wallpaper-pointer stress, wallpaper preservation, and batched
full-screen background gates. These gates exercise the artifact shape reported
on the physical host and preserve untouched scene pixels across pointer motion
and incremental terminal updates.

The authorized live host reports 0.1.392 with SDL3/OpenGL, one 60 Hz output,
and approximately 16 ms SDL presents. A five-second canonical troubleshooting
capture recorded no physical evdev events and no active Hibr session; that is
an input/session observation, not a renderer failure. An API-injected pointer
control sample accepted and presented four motions, proving the API input and
SDL composition path independently of physical-device access.

The live 0.1.392 frame-rate gate then created a bounded temporary terminal
session through the network API and measured 61.433 Hz on the 60 Hz output,
with a 16.954 ms maximum render window and zero missed deadlines. The gate
deleted its session successfully; the host returned to zero sessions and zero
surfaces afterward.

The exact direct-KMS VKMS fixture accepted all 120 and all 240 producer frames
with zero protocol errors, but did not sustain visible page-flip cadence under
the available two-output QEMU TCG environment. The 240 Hz synchronous run
retired 81 presents in its capture window; the asynchronous comparison retired
68 and had larger loop gaps. The 120 Hz run also failed the visible-presentation
gate. No production scheduler change is justified by this evidence: the
failure is at virtual VKMS/TCG page-flip delivery, and enabling asynchronous
flips would trade correctness for possible tearing. Physical 120/240 Hz
acceptance remains open and requires the real display hardware.

The fresh 0.1.392 TCC binary also passes the canonical four-output Hibr
fixture: four 240 Hz VKMS outputs, one primary session plus three joins, four
independent surfaces, and clean guest shutdown. The tall 240x135 diagnostic
variant remains intentionally open as the held-session boundary described
above.

The canonical capture protocol is documented in `docs/diagnostic-capture.md`.
Hibr source was not modified.

The TCC adapter build now rejects the development Hibr checkout at `0.99.116`
when the package target is `0.99.100`, and accepts the exact unchanged
`0.99.100` checkout. The resulting 0.1.392 package passes the artifact
allowlist and checksum gate; its adapter and package provenance are recorded
in `releases/0.1.392.yaml`.

## Current 0.1.388 compositor and multi-output evidence

## Current 0.1.389 KMS submission-boundary evidence

The exact TCC-built 0.1.389 binary passes the complete terminal, renderer,
pointer, pixel-frame, glyph, timing, and package gates. Direct KMS now returns
submitted and deferred output masks: pending pixel-frame credits are consumed
only after a page-flip or recovery modeset is submitted, and pointer damage is
retained while an output remains deferred. This fixes a real state-retirement
bug without treating a deferred page flip as a visible presentation.

The exact 0.1.389 Hibr QEMU input fixture passes the layout, keypad, stream,
gamepad, raw evdev, mouse-repeat, and multi-mouse button markers. The exact
four-output Hibr fixture passes with four 240 Hz VKMS outputs, four Hibr-backed
surfaces, and one primary plus three `desktop --join` clients. The 240 Hz
scheduler still passes; the producer-driven pixel stream remains open because
the no-KVM TCG/VKMS guest misses virtual page-flip deadlines.

The physical host remains on 0.1.385. Physical deployment, real evdev input,
physical multi-monitor behavior, and physical high-refresh behavior remain
unverified. Hibr source was not modified.

The exact TCC-built 0.1.388 binary passes terminal conformance, including
malformed UTF-8 replacement as one U+FFFD cell per invalid leading byte. The
SDL wallpaper-damage gate, external-pointer composition gate, pointer-damage
atomicity gate, wallpaper pointer-stress gate, background batching gate,
60 Hz frame-rate gate, and API pixel-frame gate all pass.

The exact 0.1.388 Hibr-staged QEMU input fixture passes the layout matrix,
keypad, stream, gamepad, raw evdev, mouse-repeat, and multi-mouse button
state markers. The exact four-output fixture passes with four 240 Hz VKMS
outputs, four Hibr-backed surfaces, and one primary plus three
`desktop --join` clients. The exact KMS fixture passes the 240 Hz scheduler,
wide Kitty pixel oracle, two-output capture, and API screenshot checks.

The sustained 240 Hz pixel-stream acceptance remains open: QEMU is running
without `/dev/kvm`, and TCG/VKMS misses visible page-flip deadlines. This is
not converted into a product pass. The physical host at `192.168.10.54`
remains on 0.1.385, so live deployment, physical input, and physical
multi-monitor acceptance remain open. The live 0.1.385 screenshot evidence
showed sparse scene corruption; commit `0053a34` restores under-text
wallpaper during incremental damage and is included in 0.1.388. Hibr source
was not modified. A controlled QEMU comparison with 8 vCPUs and
multithreaded TCG completed 240 frame uploads but only 83 visible presents,
versus 81 with 2 vCPUs; no safe renderer change is justified by that result.

## Current 0.1.387 terminal-parity and high-refresh boundary

The exact TCC-built 0.1.387 binary passes the complete PTY terminal
conformance suite, including Hibr-parity `DECRQM` reports for alternate-screen
modes `47/1047/1049` and legacy X10 mouse mode `9`. The corresponding package
passed the exact-artifact gate; Hibr source was not modified.

The exact 0.1.387 direct-KMS QEMU rerun selects two 240 Hz VKMS outputs and a
4.166 ms refresh-aware deadline, and passes `REFRESH_SCHEDULER_240_PASS`. Its
pixel producer accepts all 240 frames with zero frame errors. The guest
completes only 81 visible page flips and records 10 missed deadlines under
QEMU TCG; `/dev/kvm` is absent on this test host. Therefore
`qemu_high_refresh_acceptance` and physical high-refresh acceptance remain
open. This result is retained as a virtual-driver/VM-capability boundary, not
converted into a product pass and not addressed with asynchronous tearing.

The exact 0.1.387 Hibr/input fixture also passes `LAYOUT_MATRIX_PASS`,
`BLIT_INPUT_RAW_EVDEV_PASS`, `BLIT_INPUT_KEYPAD_PASS`,
`BLIT_INPUT_STREAM_PASS`, `BLIT_INPUT_GAMEPAD_PASS`,
`BLIT_INPUT_MOUSE_REPEAT_PASS`, and
`BLIT_INPUT_MULTI_MOUSE_BUTTON_STATE_PASS`; the guest powered down cleanly.

The exact 0.1.387 four-output Hibr fixture passes `KMS_FOUR_HIBR_PASS` with
four independent 240 Hz VKMS outputs, four Hibr-backed sessions, and four
surfaces. The guest powered down cleanly. This closes the virtual
multi-output/orchestration evidence for the release; physical multi-monitor
and physical high-refresh acceptance remain open.

## Current 0.1.366 renderer-isolation result

The live API screenshot from 0.1.365 showed the wallpaper/menu correctly but
the terminal glyphs as coloured dot patterns. A controlled API pointer probe
changed only the cursor-sized pixel region, so pointer motion was not the
source of the large corruption. The live renderer is SDL `opengles2`.

0.1.366 adds `render.glyph_path` to `/v1/diagnostics/runtime` and defaults
GLES2 to the immediate atlas-texture path (`immediate-texture`). The prior
`SDL_RenderGeometry` path remains selectable with
`BLIT_SDL_GLYPH_BATCH=on`; `BLIT_SDL_GLYPH_BATCH=off` is explicit. Local TCC
glyph, pointer-atomicity, and wallpaper stress gates pass. The live visual
acceptance gate is open until the 0.1.366 package is installed and its
post-install screenshot confirms legible terminal glyphs.

The package was subsequently accepted by the live supervised updater on
`192.168.10.54` and `/v1/version` reported `0.1.366`. The live diagnostics
reported `renderer=opengles2` and `glyph_path=immediate-texture`. The API
pointer artifact capture found only cursor-sized pixel differences between
positions, and the live synthetic motion/button verifier passed. These are
not physical evdev or physical-display visual acceptance: the automated
captures recorded zero physical evdev events, and the visual gate remains
open pending an operator-visible confirmation of the real display.

The attempted current QEMU input rerun is explicitly not recorded as a Blit
result: the available `/home/osakka/new_project/build-inputs/bzImage` ignored
both the newly staged and an older known initramfs, then panicked trying to
mount `/dev/root` before `/init` ran. This was reproduced with and without
`root=/dev/ram0`; the guest emitted no Blit marker. The staged 0.1.366 image
and unchanged Hibr checkout therefore remain untested in that particular
kernel fixture until a kernel with working external-initrd support is used.

Using the workspace VKMS kernel `/tmp/linux-vkms-build/arch/x86/boot/bzImage`
(`6.19.14`) instead, the current 0.1.366 binary reached the Hibr input
fixture. It passed `LAYOUT_MATRIX_PASS` for 1x1, 2x1, 1x2, and 2x2 layouts,
`BLIT_INPUT_KEYPAD_PASS`, `BLIT_INPUT_STREAM_PASS`,
`BLIT_INPUT_RAW_EVDEV_PASS`, `BLIT_INPUT_MOUSE_REPEAT_PASS`,
`BLIT_INPUT_MULTI_MOUSE_BUTTON_STATE_PASS`, and `BLIT_INPUT_GAMEPAD_PASS`.
The fixture observed 656 raw evdev events, 392 motion events, 27 button
events, 230 synchronization events, and one ignored button repeat. Hibr was
staged from the unchanged `/home/osakka/hibr` checkout.

The same current binary then passed the full Hibr pane workload under the
same VKMS kernel: `HIBR_PANE_MATRIX_TOPOLOGY` configured a 2x2 logical layout,
four Hibr sessions reached `running` with four independent surfaces, and the
guest emitted `HIBR_PANE_MATRIX_PASS`. This validates primary plus three-join
orchestration on two VKMS outputs; it is not evidence for four physical
monitors.

## Current 0.1.363 diagnostic correctness

The TCC build corrects the per-output presentation timing source in the API:
SDL-backed outputs now report SDL present durations, while direct KMS outputs
continue to report DRM present durations. The terminal conformance suite now
asserts this distinction when SDL has presented a frame. The local gates pass:
terminal conformance, pointer-damage atomicity, wallpaper/pointer stress, and
the 60 Hz frame-rate gate.

The canonical live troubleshooting transaction is
`tools/diagnostics/experience-capture.sh`. Its timed phase excludes screenshot
readback; screenshots are collected afterward for every discovered display.
The first live 0.1.362 capture completed against `192.168.10.54`, but observed
no physical evdev events because no pointer movement occurred during the
window. Physical input and physical multi-monitor acceptance therefore remain
open. This release does not claim those gates are closed.

After deployment, the live Hibr session was restored with `--resume` and the
explicit API routes `hibr-keyboard` and `hibr-pointer` were installed against
`session-4`. Before that operation `/v1/input/routes` was empty; a discovered
evdev device alone is not sufficient to deliver input to Hibr. The synthetic
input verifier now passes through the configured route. Physical movement and
clicks still require a real operator action during a capture and remain open.

## Current 0.1.364 pointer target evidence

The pointer trace now records the selected session and routing mode. On the
live one-pane Hibr desktop, an injected click selected `session-1` with
`routing=pane-hit-test` after the fixed `evdev-pointer` route was removed. This
is the required multi-pane behavior: pointer targeting follows global pointer
position and pane geometry, while keyboard focus remains an explicit route.
A fixed pointer route remains available for dedicated input-probe workloads,
but is not used for the Hibr desktop topology.

The deterministic `tools/tests/pointer_target_gate.rb` now protects this
invariant and passes alongside pointer-damage atomicity, external pointer
composition, and wallpaper stress. Physical evdev input remains a separate
hardware gate and is not inferred from these API-injected tests.

The exact 0.1.364 TCC binary was also rerun in the two-output VKMS fixture
using the refreshed initroot: `PPM_DISPLAY_47_WIDE_KITTY_PASS`,
`PPM_DISPLAY_48_PASS`, `KMS_API_SCREENSHOT_PASS size=3145782`, and
`KMS_CAPTURE_PASS`. The first attempted rerun was rejected as invalid evidence
because an empty temporary initroot produced a 4 KiB initramfs and a kernel
panic before Blit started; it was not recorded as a Blit failure.

The exact same 0.1.364 binary was then staged with the unchanged Hibr
0.99.100 checkout into the four-output VKMS fixture. One primary Hibr desktop
and three `desktop --join` clients reached four live sessions and four
presented surfaces across four independent 240 Hz VKMS outputs. The run
returned `KMS_FOUR_HIBR_PASS` and powered the guest down cleanly. This closes
the current software orchestration/topology gate; it is not physical
multi-monitor or sustained physical-240-Hz evidence, and the Hibr checkout
was not modified.

## Current 0.1.365 live diagnostic result

0.1.365 adds recognition of UTF-8-encoded C1 terminal controls at the PTY
parser boundary. The TCC terminal conformance suite passes both UTF-8 C1 CSI
and UTF-8 C1 OSC isolation cases, in addition to the existing raw-C1 cases.
SDL glyph, graphics-cache, and wallpaper/pointer stress gates also pass.

The exact 0.1.365 package was accepted and verified by the supervised update
API on `192.168.10.54`. A post-deployment experience capture measured `212`
presents over `8683 ms` (`24.416 Hz`) against the live `60 Hz` target, with
zero missed deadlines and no physical evdev events during the window. The
capture's surface snapshot contained no regex-detectable CSI/SGR fragments,
but the visual screenshot still requires further renderer/lifecycle
investigation; this release therefore does not claim the physical visual gate
closed. The primary Hibr session was reattached to
`pane-display-1-1` after restart. The unchanged Hibr checkout remains outside
the Blit change set.

## Current 0.1.362 live Hibr evidence bundle

The live host was started through Blit's API with the documented primary
desktop command. The first attempt was intentionally retained as evidence: it
created a surface containing only 125 non-empty cells and Hibr exited with
code 1 after reporting that the held desktop was already running. This is a
launch-state failure, not a renderer failure. Deleting that failed API session
and retrying with Hibr's `--resume` option produced a running session whose
`240x135` surface advanced to more than 17,000 non-empty cells.

The synchronized capture is stored under
`diagnostics/live-0.1.362-hibr-resume-capture-20261008T233122Z/`. Its
screenshot shows the full-screen animated Hibr scene. During the capture Blit
recorded `326` presents, zero missed deadlines, and a maximum render duration
of `22.149 ms` on the physical host's `60 Hz` output. The measured
damage-driven frame rate is workload-dependent and must not be confused with
the output scanout rate.

The same evidence bundle recorded zero physical evdev events. Therefore the
physical pointer/click acceptance gate remains open; no claim is made about
mouse behavior from this run. The canonical troubleshooting sequence is now:
capture topology and session state, capture surface summary/revision, capture
runtime timing and render-path trace, capture a screenshot, then compare raw
evdev counters and filtered pointer traces over the same window. A failed
Hibr launch is repaired with `--resume` or Hibr's own lifecycle command; Blit
does not alter Hibr state or source.

The exact TCC-built 0.1.362 input fixture was also rerun after making QEMU
staging self-contained. It passed raw evdev delivery (`800` events, `479`
motion events, `33` button events), mouse autorepeat rejection, multi-device
routing, per-device button-state coalescing, keyboard/gamepad delivery, and
stream routing. The staging helpers now include their Hibr workload probes and
normalize the guest shell interpreter, so this result does not depend on a
historical initroot tree.

The exact current candidate also passes the refreshed two-output KMS capture
(`KMS_CAPTURE_PASS`) and the four-output Hibr fixture
(`KMS_FOUR_HIBR_PASS`). The four-output run reports four independent 240 Hz
VKMS outputs, four sessions, and four surfaces representing one primary Hibr
desktop plus three joined clients. It records startup deadline misses under
the virtual 240 Hz workload, so this is topology and presentation evidence,
not sustained physical 240 Hz acceptance.

The exact current Hibr adapter fixture also completed with `ACCEPTANCE_PASS`.
It rebuilt `console-blit.so` against Hibr `0.99.100`, loaded the adapter probe,
started a primary and joined Hibr client, verified both Hibr control displays,
installed keyboard and pointer routes, and shut the guest down cleanly. This
closes the software adapter gate; it does not change the rule that Hibr source
is external and unmodified.

A further ten-second physical observation was run against the same live Hibr
session on 0.1.362. The session remained running and the surface revision
continued advancing; the 60 Hz output recorded zero missed deadlines and the
capture-window maximum loop gap was `9.049 ms`. No physical evdev motion,
button, or wheel event arrived, so the physical-input gate remains open. The
result is preserved under
`diagnostics/live-0.1.362-physical-observation-20261008T234837Z/`.

The current pixel-stream matrix is explicit. The 60 Hz producer stream passes
with all 60 frames accepted, no additional missed deadlines, and
`KMS_API_PIXEL_PASS`. The 240 Hz producer stream accepts all 240 frames with
zero frame errors, but the QEMU TCG/VKMS guest presents only 79 before the
bounded run ends; KMS reports a maximum present duration of `27.137 ms` and
additional missed deadlines. `/dev/kvm` is unavailable on this test host, so
the 240 Hz result is recorded as a VM capability limit rather than a physical
hardware result. No scheduler relaxation or asynchronous tearing workaround
was introduced.

The same 240 Hz run was repeated with QEMU TCG multi-threaded translation
explicitly enabled. It improved visible presents only from `79` to `81`, but
still recorded `16` missed deadlines and a `23.473 ms` maximum KMS present.
This rules out the default TCG threading mode as the sole cause; the result
remains a virtual VKMS/TCG limitation rather than a production scheduler
change.

The intervening 120 Hz producer stream has the same boundary: all 120 frames
were accepted with zero frame errors, but missed deadlines increased from `3`
to `22`, with a maximum KMS present duration of `35.558 ms`. Therefore the
current validated virtual cadence is 60 Hz only; 120/240 Hz presentation must
be validated on hardware or a VM with working KVM acceleration before any
production claim is made.

## Current 0.1.359 live diagnostics and physical-input boundary

The authorized live host reports `0.1.359` and remains reachable at
`192.168.10.54:8080`. The release adds per-device evdev counters to the
runtime diagnostics endpoint. The live service currently discovers one pointer
at `/dev/input/event5` (fd `8`), but the capture window recorded zero events,
zero motion events, zero wheel events, and zero button events. Consequently,
the physical mouse symptom is still open: this evidence proves device
discovery, not that a physical event reached Blit's process.

The live synthetic API input probe passes motion, button, dispatch, pointer
position, and render-path checks. The renderer reports SDL OpenGL ES 2 with a
60 Hz display mode, a 16 ms refresh-aware target interval, no missed deadlines,
and sub-14 ms maximum observed loop/render gaps in the current window. The
reported frame rate is damage-driven and is zero while idle; it must not be
interpreted as a monitor-refresh measurement.

A real-host renderer isolation run created a temporary API-owned `80x30`
opaque surface, committed all `2400` cells in bounded batches, moved the API
pointer through six positions, and captured six distinct screenshots. All
sampled scene pixels remained non-black, and the temporary session was deleted
cleanly. This proves the deployed SDL composition path can render and update a
surface on the real host; it does not prove physical evdev input or Hibr's
wallpaper/graphics scene.

The TCC-built `0.1.359` package passed the local pointer-damage,
external-pointer-composition, hidden-cursor, glyph, wallpaper-stress, and
terminal-soak gates. The corrected two-output VKMS QEMU fixture passed KMS
capture, the wide Kitty grid, the 48-cell display capture, and the API
screenshot gate. QEMU was powered down and no QEMU process remains. Physical
mouse, physical multi-monitor, and sustained physical high-refresh acceptance
remain open.

Package SHA-256: `faecc11058d4d19c6d0b28f4650d44c033af744bff31c3702d0f1d84abac255a`.

## Current 0.1.360 input-protocol correction

The TCC-built `0.1.360` candidate ignores Linux mouse `EV_KEY` value `2`
(autorepeat) instead of forwarding it as another button press. The QEMU Hibr
input fixture emits this event deliberately and passes
`BLIT_INPUT_MOUSE_REPEAT_PASS`, while also passing raw evdev delivery and the
two-mouse routing checks. This addresses a concrete duplicate-click failure
mode without changing Hibr or the SDL compositor.

The candidate has passed the pointer-damage, external-pointer-composition,
hidden-cursor, full-surface wallpaper stress, and glyph gates. Physical host
mouse acceptance remains open because the live device capture has not observed
a physical evdev event.

The exact `0.1.360` binary also passes terminal conformance and the bounded
two-session PTY soak (`356` snapshots, `32` resizes, `53580 KiB` peak RSS).
The exact binary passes the two-output VKMS capture with
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`; the guest powered down and
no QEMU process remained. The live host now reports `0.1.360`, and its
synthetic API input probe passes. Its physical pointer inventory is present,
but its physical counters remain zero outside an actual movement window.

## Current 0.1.361 cached-scene pointer correction

The `0.1.361` candidate no longer treats pointer motion plus a committed Hibr
cell damage rectangle as a full-screen SDL redraw. The pointer is composed
after the complete cached scene is copied, so the renderer updates only the
committed damage region and presents one complete frame. The atomic pointer
gate, full-surface wallpaper stress gate, and external-pointer-composition
gate all pass with the `incremental-damage` trace path and intact untouched
pixels. Hibr remains unmodified; physical host acceptance remains open.

The deployed live `0.1.361` service also passed an API-owned real-host
`80x30` surface test: pointer motion and committed cell damage produced the
`incremental-damage` trace in one attempt, with zero missed deadlines, and the
temporary session was cleaned up. The live synthetic input probe passes. This
still does not close physical mouse acceptance because the live evdev counters
remain zero without a real movement window.

## Current 0.1.362 multi-device button-state correction

The `0.1.362` candidate maintains button state per evdev mouse and emits a
logical press or release only when the aggregate state changes. A release from
one mouse can no longer clear a button still held by another. Runtime
diagnostics expose `evdev_mouse_button_state_coalesced`. The exact QEMU Hibr
input fixture passes with `state_coalesced=2`, autorepeat rejection, raw evdev
delivery, and multi-mouse routing. Hibr remains unmodified; physical host
acceptance remains open.

## Current 0.1.358 real-host evidence and remaining visual gate

The authorized host now reports `0.1.358`. The attach PTY geometry transition
is active: the primary Hibr session surface is `240x135` with all `32400` cells
populated, correcting the earlier rows `25..132` omission. The six-second
timing capture recorded zero missed deadlines and render/present calls with
sub-millisecond steady-state render cost; it recorded zero physical evdev
events because no physical movement or click occurred during capture.

An earlier API screenshot is a valid `1920x2160` BMP and is saved as
`diagnostics/live-358-visual/display-1.png`; that older capture showed a
mostly black composition with a small Hibr panel at the lower-left. The later
`diagnostics/live-358-layout/` capture has the complete `240x135` cell grid,
but its visible scene is Hibr's animated coloured-dot content rather than a
static desktop reference image. The surface-layout gate therefore remains
partial rather than accepted. This is now a visual composition/presentation
investigation, not the former incomplete Hibr surface. A final visual gate
must correlate pane bounds, cell coordinates, screenshot pixels, pointer
damage, and physical evdev events in the same timestamped window.

The live API pointer control capture produced five distinct screenshots. Pixel
deltas were confined to the old and new cursor regions; the API path showed no
cursor trail or full-screen damage. The TCC-built binary also passed the full
terminal conformance suite and a five-second two-session soak (`356` snapshots,
`32` resizes, `53744 KiB` peak RSS). These are API/control-path results, not
physical mouse acceptance: the real-host physical capture still observed zero
evdev events.

The exact TCC-built `0.1.358` binary was rerun through the VKMS QEMU fixture:
the two-output capture returned `KMS_CAPTURE_PASS`, and the four-output fixture
returned `KMS_FOUR_HIBR_PASS` with one primary Hibr desktop plus three
`desktop --join` clients. The four virtual outputs independently reported a
240 Hz active mode and four KMS presentations; the guest powered down cleanly
and no QEMU process remained. This is virtual KMS/topology evidence, not
physical monitor or sustained physical 240 Hz acceptance. The dedicated
240-frame pixel-stream gate remains open.

The new TCC-built full-surface pointer stress gate also passes. It submits a
`120x40` opaque coloured terminal scene in bounded deferred chunks, commits
updates while moving the pointer, checks six untouched screenshot samples for
black holes, and requires both the pointer-cache and pointer-plus-damage
full-redraw trace paths. This closes the deterministic compositor regression
boundary; it does not close physical mouse acceptance.

The exact `blit.pixel_stream_240=1` gate was rerun on `0.1.358`: all `240`
frames were accepted without frame errors, but synchronized KMS produced only
`83` visible presents and recorded a `16.661 ms` maximum KMS present. The
diagnostic-only `blit.kms_async=1` comparison produced `85` presents, so async
page flips do not solve the bottleneck and remain unsuitable as a production
substitute for atomic presentation. No scheduler change was retained from
this experiment.

The same fixture's cadence matrix is explicit: `blit.pixel_stream=1` passed
with `60/60` visible presents and `KMS_CAPTURE_PASS`; the `120` and `240`
variants accepted every input frame but failed their visible-present count
under VKMS/QEMU. The current validated boundary is therefore the 60 Hz virtual
stream, while 120/240 Hz remains an open KMS timing requirement rather than an
API or terminal-state failure.

The exact current Hibr VKMS input fixture also passed on `0.1.358`: layout
matrix, keypad and keyboard PTY delivery, multi-mouse routing, WebSocket input,
gamepad discovery/input, and raw evdev input all passed. The raw evdev probe
recorded `728` events, `431` motion events, and `34` button events. This is
QEMU input evidence; physical host mouse/button acceptance remains open.

## Current 0.1.357 release and live-validation gate

The TCC-built `0.1.357` package contains the attach-time PTY notification
transaction from ADR 0033. A controlled live resize experiment established the
causal test: a fresh Hibr desktop initially attached at `240x25` populated only
the startup rows; changing the authoritative surface to `240x135` caused all
`32400` cells to become available. A fresh desktop attached directly at
`240x135` reproduced the partial-row state when only same-size reassertion was
used. The release therefore forces one real PTY geometry transition after the
bounded Hibr descendants are identified.

Local TCC pointer-damage, external-pointer-composition, and hidden-cursor gates
pass for `0.1.357`. The package is built and pushed, but the live host has not
yet been upgraded and this release is not marked live-accepted until the API
capture confirms rows `0..134`, stable screenshots, and runtime timing. Physical
mouse/button, physical multi-monitor, and sustained physical high-refresh gates
remain open.

## Current 0.1.356 live and QEMU evidence

The live host now reports `0.1.356`. The SDL raw-evdev pointer feedback loop
was removed: raw evdev updates the Blit software cursor directly and no longer
warps SDL's native pointer into an asynchronous second motion stream. TCC
pointer-damage, external-composition, and hidden-cursor gates pass after the
change. API-injected live motion reached five pointer-cache renders with zero
missed deadlines; physical pointer acceptance remains open because no physical
event has been observed through the live API capture.

The canonical Hibr QEMU input soak was rerun with the 0.1.356 binary and
current Hibr staging. It passed `BLIT_INPUT_RENDER_SOAK_PASS`,
`BLIT_INPUT_STREAM_PASS`, `BLIT_INPUT_GAMEPAD_PASS`,
`BLIT_INPUT_MULTI_MOUSE_PASS`, and `BLIT_INPUT_RAW_EVDEV_PASS` with `914`
events, `546` motion events, and `40` button events. The same run passed the
two-output KMS screenshot checks. No QEMU process remained after shutdown.

The current four-output Hibr fixture also passed `KMS_FOUR_HIBR_PASS` with
four independent VKMS outputs, one primary Hibr desktop, and three
`desktop --join` clients reaching four live surfaces and four-output KMS
presentation. This proves virtual topology/orchestration for 0.1.356; the
fixture recorded initial deadline misses under the synthetic 240 Hz workload,
so it is not evidence of physical high-refresh acceptance.

The dedicated mixed 60/240 Hz scheduler fixture passed
`REFRESH_SCHEDULER_240_PASS` with the 240 Hz output reporting a 4.166 ms
target interval, plus the KMS capture and API screenshot checks. This proves
refresh-mode discovery and scheduler selection in VKMS; startup composition
misses remain visible in the fixture and physical sustained high-refresh
acceptance remains open.

The TCC-built 0.1.356 binary also passed the public PTY conformance suite:
VT500 controls, fragmented UTF-8, wide/combining cells, colors, alternate
screens, synchronized output, Kitty graphics, Hibr defaults, and input/report
queries all passed. A two-session terminal soak passed for five seconds with
`346` snapshots, `32` resizes, and `53580 KiB` peak RSS under a `131072 KiB`
limit, with clean session and render-queue teardown.

The authorized host reports `0.1.356`. A fresh ordinary Hibr desktop started
through `POST /v1/terminal-sessions` reached the authoritative `240x135`
surface. Restarting Blit intentionally terminates its child Hibr process; the
primary desktop was restored through the documented API launch contract after
deployment. Hibr source was not modified.

Physical pointer/button acceptance, multiple physical monitors, and physical
high-refresh acceptance remain open.

## Historical 0.1.355 real-host Hibr handoff evidence

The authorized host reports `0.1.355`. A fresh ordinary Hibr desktop started
through `POST /v1/terminal-sessions` reached the authoritative `240x135`
surface with `32400` non-empty cells automatically. The evidence is in
`diagnostics/live-355-handoff-1/`; six synchronized `1920x2160` screenshots
have identical hashes, and the runtime reports a 60 Hz display, a 16 ms
refresh-aware target, zero missed presentation deadlines, and no renderer
errors.

The cause of the earlier partial desktop was a Hibr hold-process handoff:
the exported identity could identify the owner, but the desktop child lived
in a descendant process group. Blit now uses a unique session token, follows
only that bounded descendant tree, and performs the delayed PTY resize plus
the proven negative-PID `SIGWINCH` operation. Hibr source was not modified.

The same TCC-built binary passed the VKMS QEMU boundaries using the 6.19.14
test kernel: `KMS_CAPTURE_PASS` for two outputs,
`KMS_FOUR_OUTPUT_PASS` with independent red/green/blue/yellow output pixels,
and `KMS_FOUR_HIBR_PASS` with one Hibr primary plus three `desktop --join`
clients. These are virtual KMS/topology acceptances; physical multi-monitor
and physical high-refresh acceptance remain separate open gates.

The current-Hibr QEMU input soak also passed: UTF-8 keyboard output,
multi-pointer/button/wheel routing, WebSocket input stream, render soak,
gamepad discovery, and raw evdev delivery (`914` events, `546` motion, `40`
buttons). Physical input acceptance is still open because virtual evdev does
not prove the particular host's physical devices or user-visible click path.

The normal current-Hibr QEMU integration fixture also reaches
`ACCEPTANCE_PASS`. Its external `console-blit` probe, native primary and join
sessions, input probes, and surface checks all complete after the fixture
passes the staged adapter path explicitly. This closes virtual production
adapter acceptance; the physical host remains on the native terminal path and
does not yet claim physical adapter acceptance.

Physical pointer/button acceptance, production adapter acceptance, multiple
physical monitors, and high-refresh physical acceptance remain open; this
capture records input inventory but no physical user event.

## Current 0.1.345 real-host boundary evidence

The authorized host reports `0.1.345` and the reproducible capture is in
`diagnostics/live-345-snapshot/`. The SDL3 output is `1920x2160` at `60 Hz`,
uses the refresh-aware `16 ms` interval, and recorded zero missed deadlines
over the capture window. The screenshot API returned two identical valid
`1920x2160` BMPs, proving that framebuffer capture and presentation are
observable independently of the user's visual report.

The remaining rendering defect is now isolated to the Hibr handoff: the live
surface is `240x135`, but only `5659` cells are populated and the desktop
cursor remains at row `23`. The PTY and Hibr held-client reports both say
`135x240`; Hibr's `desktop` command creates a detached `hold` owner, so a
resize signal sent only to Blit's attach client cannot resize the actual held
desktop state. Blit's bounded retry does not change that result. This is not
currently evidence of an SDL frame-rate failure or a missing physical mouse
event.

The capture recorded zero physical evdev events because no physical movement
or click occurred during that interval. Physical input acceptance remains
open and must be tested with the capture running. The production adapter path
also remains open: its stream connects, but its surface received no cell
commit in this host run, so it is not being called accepted.

## Historical 0.1.341 real-host troubleshooting status

The 0.1.339 packaging correction keeps the optional `console-blit.so` provider
out of `/usr/lib/hibr`, so the ordinary `/usr/bin/desktop` path selects Hibr's
native console provider. The authorized host now reports `0.1.341`; a fresh
ordinary desktop starts with `5659` non-empty cells and its Hibr log reports
`desktop: started` without `console-blit` flush failures. Pointer and keyboard
routes are configured through the API.

The live timing capture is now topology-aware and records session details,
surface summaries, runtime timing, filtered traces, input inventory, and route
state in one directory. The latest four-second capture recorded zero missed
deadlines and zero physical evdev events; physical mouse acceptance therefore
remains open until movement is observed on the real machine. The SDL API
framebuffer snapshot still returns `screenshot_failed` on this host and is
not claimed as accepted; this is a separate capture-backend issue from the
clean native Hibr terminal path.

## Current 0.1.338 Hibr ABI packaging status

The packaging build now requires an explicit `BLIT_HIBR_ROOT` and has a TCC
`adapter` target. This prevents a stale `console-blit.so` from being copied
into a package after Hibr's headers or modules have changed. The 0.1.337 live
deployment exposed this gap: its Hibr process ran and produced PTY bytes, but
the external surface stayed empty. The corrected package must be rebuilt and
deployed against the current Hibr checkout before Hibr rendering is accepted.

## Current 0.1.337 atomic pointer-damage status

The renderer now treats pointer state plus concurrent external terminal damage
as one complete scene boundary. Pointer-only motion continues to use the
cached scene; when both pointer state and surface damage are present, Blit
redraws the complete scene after clearing the target. This prevents the black
holes, trails, and blinking caused by clearing an SDL target and then drawing
only the damaged rectangle.

The deterministic `POINTER_DAMAGE_ATOMIC_PASS` gate queues pointer input and an
external commit together, verifies the `pointer_dirty=1` full-redraw trace,
and checks framebuffer pixels outside the changed cell. The exact TCC gates
remain required before packaging. Physical mouse, multi-monitor, and
high-refresh acceptance remain open; Hibr source was not modified.

## Current 0.1.336 diagnostic-window status

The runtime now exposes a completed bounded event-loop timing window through
`loop_gap_window_ms`, `loop_gap_window_sequence`, and
`loop_gap_window_max_ms` in `GET /v1/diagnostics/runtime`. The sequence advances
once per completed 500 ms interval, so a capture can correlate a user-visible
artifact with a known observation interval instead of inferring timing from
unrelated lifetime counters. Existing lifetime and last-sample counters remain
unchanged for compatibility.

The local TCC server passed terminal conformance, frame-rate, HTTP
backpressure, session-lifecycle, and slow-reader screenshot checks with the
new fields present. The exact package passed the package artifact gate and is
deployed on the authorized physical host; `/v1/version` reports `0.1.336`.
The live timing-only capture recorded 49 frame advances in five seconds, zero
missed deadlines, a 500 ms completed loop window, and a 16.989 ms window
maximum gap. The primary Hibr session and focused pointer route were restored
through the API. The physical mouse, multi-monitor, and high-refresh
acceptance gates remain open; Hibr source was not modified. A screenshot-heavy
pointer probe was stopped after its 16 MB framebuffer transfer exceeded the
deliberate 30-second diagnostic transfer bound; this confirms that screenshots
must be taken outside the timing/input interval.

## Current 0.1.335 screenshot-delivery status

The source change for 0.1.335 moves framebuffer screenshot transmission out of
the SDL/KMS event loop. Encoded bytes are queued per HTTP client and drained
only on writable readiness. The local TCC binary passed the glyph-render gate
and the slow-reader screenshot gate: while a deliberately throttled
framebuffer download was in progress, `/v1/version` completed in 12 ms.
This directly protects input and presentation from a slow diagnostic client.

Package `blit_0.1.335-1` is built; its externally recorded SHA-256 and source
commit are in [the 0.1.335 release manifest](https://git.home.arpa/itdlabs/blit/src/branch/main/releases/0.1.335.yaml).
The hash is intentionally kept outside this ledger because the ledger itself
is included in the Debian package.
The exact TCC binary passes terminal conformance, frame-rate, HTTP
backpressure, session-lifecycle, and the slow-reader screenshot gate. The
The package is deployed on the authorized physical host and `/v1/version`
reports `0.1.335`; the primary Hibr session and focused pointer route were
restored. The real-host slow-reader gate kept `/v1/version` responsive in
96 ms while a deliberately throttled screenshot was downloading. The runtime
then reported zero missed deadlines and a 39.572 ms maximum loop gap. The
latest physical sample still reports zero raw evdev mouse events, so this is
not a physical-mouse acceptance result. Exact 0.1.335 QEMU/KMS gates remain
now pass. The exact staged TCC binary SHA-256 was
`ec8657f8cea3adb2deb9507c56a9791b51b6fb5264630606739174c0a58bbd1f`.
The normal VKMS run passed `PPM_DISPLAY_47_WIDE_KITTY_PASS`,
`PPM_DISPLAY_48_PASS`, `KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`.
The mixed, high-refresh, sixel, and pixel-stream variants passed
`REFRESH_SCHEDULER_MIXED_PASS`, `REFRESH_SCHEDULER_240_PASS`,
`PPM_DISPLAY_47_SIXEL_PASS`, `PIXEL_FRAME_RATE_PASS`,
`KMS_API_PIXEL_PASS`, and their corresponding capture/API markers.
The exact Hibr QEMU fixture passed `LAYOUT_MATRIX_PASS`,
`HIBR_PRIMARY_RESTART_PASS`, `HIBR_JOIN_RECONNECT_PASS`, and
`HIBR_PANE_MATRIX_PASS` with staged Hibr SHA-256
`f8dbc10779193c27d2eb47f0e858cf656912f8b96f56a45af820ad05d18cdb7e`.
Hibr source was not modified.
The exact 0.1.335 input-only QEMU fixture also passed
`BLIT_INPUT_MULTI_MOUSE_PASS`, `BLIT_INPUT_KEYPAD_PASS`,
`BLIT_INPUT_STREAM_PASS`, `BLIT_INPUT_GAMEPAD_DISCOVERY_PASS`,
`BLIT_INPUT_GAMEPAD_PASS`, and `BLIT_INPUT_RAW_EVDEV_PASS`. Those are
deterministic uinput/evdev results and remain distinct from physical-host
mouse evidence.
The exact 0.1.335 TCC binary also passed a 20-second four-session PTY soak
with 2,584 snapshots and 235 resizes; maximum RSS was 66,776 KiB against the
131,072 KiB limit, and all sessions drained cleanly.

## Current 0.1.334 diagnostic-observability status

The source change for 0.1.334 makes diagnostic observation independently
bounded: `GET /v1/diagnostics/trace` returns the 32 newest matching events by
default and accepts `limit=1..128`. A TCC-built local server returned exactly
one event for `kind=render_path&limit=1`; the version endpoint reported
`0.1.334`. This prevents a trace read from becoming an unnecessarily large
single-threaded HTTP response while investigating live pointer artifacts.

Package `blit_0.1.334-1` is deployed on the authorized physical host;
`/v1/version` reports `0.1.334`. The bounded live trace check returned one
event in 306 bytes in 41 ms. Hibr was restored through the API as the primary
external session and the focused evdev-pointer route was restored.

The live synthetic pointer transaction then injected four motions and captured
the framebuffer after each one. It observed four input events, zero missed
deadlines, stable `incremental-damage` paths, and `graphics_changed=0` for
every motion. The five framebuffer hashes differed as expected for cursor
movement. This does not prove physical evdev correctness, but it does not
reproduce the reported artifact through Blit's API input path; the physical
capture must now correlate raw evdev counters with the same render and pixel
evidence.

The exact 0.1.333 Hibr QEMU restart fixture completed with
`LAYOUT_MATRIX_PASS`, `HIBR_PANE_MATRIX_PASS`, `HIBR_PRIMARY_RESTART_PASS`,
and `HIBR_JOIN_RECONNECT_PASS`. The staged Hibr executable SHA-256 was
`f8dbc10779193c27d2eb47f0e858cf656912f8b96f56a45af820ad05d18cdb7e`;
Hibr source was not modified, and no QEMU process remained after the fixture.

The authorized physical host reports one 60 Hz output, zero missed deadlines,
and millisecond-scale rendering. The latest physical sample still reports zero
physical evdev mouse events. That is not a physical-mouse pass: the remaining
live step is to capture while the real mouse is moved and correlate raw evdev
receipt, input routing, pointer state, render-path trace, and post-interaction
pixels using `docs/diagnostic-capture.md`.

## Current 0.1.333 live diagnostic status

The 0.1.333 package is deployed on the authorized physical host at
`192.168.10.54:8080`. A disposable Hibr image probe completed with exit code
zero and was then deleted. The live API reported one complete `api` graphics
object (`512x512`, `786432` bytes), `pixel_frames_accepted=1`, and
`pixel_frame_errors=0`. This proves the packaged Blit-owned Hibr adapter can
submit and retain a pixel frame without changing Hibr.
Package SHA-256 is
`0bc069e6245844d85764e1cfd6b0d69ae3ab8bbc172e75ff484db062e8f14cf3`.

The same live sample reported `last_render_ms=4.411`, `max_render_ms=30.148`,
`missed_deadlines=0`, and a 60 Hz display target. Its `input_events` count was
zero because no physical movement occurred during that capture. Therefore it
does not claim that physical pointer movement is correct. The required next
evidence is `tools/diagnostics/verify-live-physical.sh` run while reproducing
the pointer movement; its exit status 2 means the capture was valid but no
physical movement was observed, while status 1 identifies an actual invariant
failure.

The 0.1.331 TCC binary also passes the two-output VKMS capture fixture with
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`. The mixed-refresh and
high-refresh variants pass `REFRESH_SCHEDULER_MIXED_PASS` and
`REFRESH_SCHEDULER_240_PASS`. These are deterministic VKMS/QEMU results, not
claims about physical 120/240 Hz hardware.

The live runtime now exposes raw physical-mouse receipt counters alongside
post-routing `input_events`: `evdev_mouse_events`, sync, motion, wheel, and
button counters, plus the last evdev path and event age. This closes the
diagnostic distinction between a kernel event that was read but did not change
the pointer and a device that produced no records during the capture.
It also reports SDL mouse events discarded or processed. A nonzero discarded
SDL count with unchanged raw-evdev counters identifies backend delivery or
competing input ownership rather than a compositor failure.
The exact 0.1.332 TCC binary passes the full terminal conformance suite,
including VT500 controls, UTF-8/wide glyph handling, Hibr defaults, Kitty
image placement, synchronized output, and network terminal input.
The exact 0.1.332 binary also passes the two-output VKMS capture with
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`.
Its direct-KMS 60-frame pixel-stream workload also passes
`PIXEL_FRAME_RATE_PASS`, `KMS_API_PIXEL_PASS`, and `KMS_CAPTURE_PASS`; all 60
frames were accepted with zero additional missed deadlines in the stream
workload.
The exact binary's sixel fixture passes `PPM_DISPLAY_47_SIXEL_PASS`,
`PPM_DISPLAY_48_PASS`, `KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`.
Its mixed-refresh and high-refresh scheduler fixtures pass
`REFRESH_SCHEDULER_MIXED_PASS` and `REFRESH_SCHEDULER_240_PASS` respectively.

The 0.1.332 live synthetic probe passes with zero missed deadlines. With the
physical evdev node present but idle, one SDL mouse event was accepted through
the bounded fallback and reported as `sdl_mouse_fallback_events=1`; this is
controlled evidence that the fallback is reachable, not physical-mouse
acceptance evidence.
The subsequent probe after warp-echo suppression reports
`sdl_mouse_fallback_events=0`, confirming that Blit's own cursor warp is not
re-injected as user motion.

The latest live Hibr timing sample contained 128 incremental render paths over
20.778 seconds; the largest path-to-path gap was 1.205 seconds, while the
reported render samples remained in the millisecond range and missed deadlines
stayed at zero. This is damage-driven composition: a static terminal scene is
not presented continuously at the panel refresh rate. `frame_rate_hz` must
therefore be read together with the display's `refresh_hz`, render timings, and
deadline counters; it is not evidence that the renderer itself took seconds.

The 0.1.333 package adds the read-only OpenAPI
`GET /v1/surfaces/{surface_id}/summary` endpoint. The live Hibr surface
returned a compact response of 214 bytes with the current observed revision
`111633`, dimensions `240x135`, and 32,400 non-empty cells; the full `/cells`
repair endpoint remains separate.

The exact 0.1.329 binary with the unchanged Hibr checkout also passes the
QEMU/VKMS Hibr pane matrix: `LAYOUT_MATRIX_PASS` and
`HIBR_PANE_MATRIX_PASS`. The restart variant additionally passes
`HIBR_PRIMARY_RESTART_PASS` and `HIBR_JOIN_RECONNECT_PASS`; the staged Hibr
executable SHA-256 was
`6cec6189cde303a030d6bf8e3936d5c03e2914a47e6c2e80765f62b0cb53356a`.
Hibr source was not modified.

The 0.1.329 input fixture passes `BLIT_INPUT_MULTI_MOUSE_PASS`,
`BLIT_INPUT_KEYPAD_PASS`, `BLIT_INPUT_STREAM_PASS`, and
`BLIT_INPUT_GAMEPAD_PASS`; its new raw-evdev assertion passes with
`events=680`, `syncs=241`, `motion=399`, and `buttons=34`. This confirms the
diagnostic counters against deterministic uinput devices, while remaining
distinct from physical-host mouse evidence.

## Current 0.1.326 live diagnostic-boundary status

Package `blit_0.1.326-1_amd64.deb` is deployed on the authorized host;
`/v1/version` reports `0.1.326`. Package SHA-256 is
`fbbafb832d0465f14b8bd38f2df596bea333c8cd4e41fbb9b22bf6b9431aec8d`.

The live timing-only input probe passed API motion, both button edges, input
dispatch accounting, pointer position, and render-path evidence. After the
initial scene transition, the pointer workload stayed on
`incremental-damage` with `graphics_changed=0`, `graphics_images=0`, a stable
graphics signature, and zero missed refresh deadlines. The capture mechanism
now records the session graphics list beside each trace. Screenshot captures
are explicitly excluded from timing conclusions because the screenshot route
forces a fresh scene and can block the single-threaded loop during transfer.

The fix is Blit-only: an empty graphics scene no longer incorporates session
membership into its graphics signature. Hibr source remains unmodified.

The exact 0.1.326 TCC binary also passes the two-output VKMS capture fixture:
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`. The mixed-refresh and
high-refresh variants pass `REFRESH_SCHEDULER_MIXED_PASS` and
`REFRESH_SCHEDULER_240_PASS`. The fixture used the checked VKMS kernel
`/tmp/linux-vkms-build/arch/x86/boot/bzImage`, SHA-256
`17ffba47e1e21d902c71c331bca474fb2de1209f03176d316b333d488bd3fcea`.
The dedicated sixel variant also passes `PPM_DISPLAY_47_SIXEL_PASS` and
`KMS_CAPTURE_PASS`.

The exact 0.1.326 Hibr VKMS fixture also passes `LAYOUT_MATRIX_PASS`,
`HIBR_PANE_MATRIX_PASS`, `HIBR_PRIMARY_RESTART_PASS`, and
`HIBR_JOIN_RECONNECT_PASS` with four active Hibr surfaces across the two
outputs and a final `2x2` pane topology. The staged Hibr tree was unchanged;
its executable SHA-256 was
`c2f6522354394bdb443d00d15ec0eb425009c07115fd105f98270eb5c0b040ef`.
The exact-version input-only fixture also passes
`BLIT_INPUT_MULTI_MOUSE_PASS`, `BLIT_INPUT_STREAM_PASS`,
`BLIT_INPUT_GAMEPAD_PASS`, and the keypad/PTTY delivery checks.

## Current 0.1.320 live graphics-probe status

Package `blit_0.1.320-1_amd64.deb` adds the Blit-owned, non-Hibr-source probe
`/usr/share/blit/probes/blit-live-image-probe.hibr` and is deployed on the
authorized host. Package SHA-256 is
`f79f7263bc9bf6c6d79e5aef9dc190d5196a4084b099f5c317533217d0b7e417`.

The live API pixel path passes independently: the TCC-built WebSocket probe
returns `PIXEL_FRAME_PROBE_PASS`; the real host reports one accepted frame,
one texture upload, zero pixel-frame errors, and an empty pending queue. A
1920x2160 live SDL screenshot contains the expected 32x32 red probe image at
the translated surface origin `(20,20)`.

The live input probe also passes on 0.1.320. An API-launched Hibr probe was
attempted with both `hibr -c` and the packaged script; both entered Hibr's
desktop startup path and produced desktop cells but no image upload. This is
recorded as an unresolved Hibr invocation/configuration boundary, not a Blit
graphics failure. Hibr source remains unmodified.

The exact 0.1.320 TCC binary also passes the QEMU VKMS primary/`--join`
restart fixture: `LAYOUT_MATRIX_PASS`, `HIBR_PRIMARY_RESTART_PASS`,
`HIBR_JOIN_RECONNECT_PASS`, and `HIBR_PANE_MATRIX_PASS`.

## Current 0.1.322 live composition status

Package `blit_0.1.322-1_amd64.deb` is deployed and `/v1/version` reports
`0.1.322`. Package SHA-256 is
`370abcffdae41bb5556348490ed4dccd4450dbc4e7cce9a32e33029bcec70ae8`.
The authorized host reports a ready SDL3/OpenGL ES 2 renderer, a 60 Hz
1920x2160 active mode, refresh-aware 16 ms scheduling, and zero missed
deadlines.

The primary Hibr desktop was restored through the API as external session 1
with `display-1`, focused input, and the `live-pointer-322` evdev-pointer
route. A controlled 30-motion live run produced
`incremental-damage target_changed=1 external_changed=1 graphics_changed=0`
paths rather than full-scene rebuilds; the affected frames measured about
3.65 ms render time and the runtime reported zero missed deadlines. The
controlled HTTP injection rate is not a physical refresh-rate claim. The
temporary pixel probe image is absent from the restored session.

The exact 0.1.322 TCC binary passes the QEMU VKMS primary restart, join
reconnect, and 2x2 pane matrix markers. Hibr source remains unmodified.

## Current 0.1.321 external-pointer composition status

The TCC-built `0.1.321` binary changes the external-surface compositor so
committed cell damage is applied incrementally to the atomic scene cache.
Graphics-scene changes still force a complete rebuild, identified by the
`graphics_changed` diagnostic field. The new
`EXTERNAL_POINTER_COMPOSITION_PASS` gate records pointer-cache hits after an
external cell commit, while the full terminal, graphics-cache, glyph, batch,
frame-rate, and shutdown gates also pass. The package SHA-256 is
`958e000608ae91e73cfd83341774fd7bb48c1b410f49900420517814abaed9df`.

The exact source state also passes the QEMU VKMS primary/`--join` restart and
2x2 pane fixture with `LAYOUT_MATRIX_PASS`, `HIBR_PRIMARY_RESTART_PASS`,
`HIBR_JOIN_RECONNECT_PASS`, and `HIBR_PANE_MATRIX_PASS`. Hibr source remains
unmodified.

The live pointer-artifact transaction reproduced the physical symptom through
the controlled API path. All sampled render traces used
`full-redraw target_changed=1 external_changed=1`; pointer-cache hits stayed
at zero while pointer-cache misses increased. During the four-position sweep
the reported frame-rate window ranged from 0.65 to 3.32 Hz, with zero missed
refresh deadlines. This isolates the current bottleneck to external-surface
recomposition under pointer activity; it does not implicate evdev discovery
or SDL refresh timing. Capture output was kept outside the repository.

## Current 0.1.319 terminal lifecycle status

The TCC-built terminal path now preserves the final parsed PTY frame after a
child exits. `waitpid(WNOHANG)` marks the session stopped but does not clear
its surface before the PTY reaches EOF; explicit API deletion still releases
the surface. This fixes the short-lived `stty -echo; dd` race that previously
made the final `NETWORK` input disappear from snapshots.

The complete terminal-conformance suite passes, including raw and bracketed
network input, final PTY bytes, VT500 controls, fragmented UTF-8, wide cells,
truecolor, alternate screens, Kitty queries, Kitty image placement, and Hibr
integration defaults. Focused TCC gates also pass session write/resize,
hidden-cursor damage, shutdown, glyph rendering, graphics cache, chunked
pixel frames, and the 60 Hz frame-rate workload (54.4 Hz measured, zero
missed deadlines). Package `blit_0.1.319-1_amd64.deb` was built from this
source state; SHA-256 is
`46b4a88b03fc3918deada6d203aa25b9fde36ccc11d18564c2a170e8c8961c4f`.

The package is deployed on the physical host and `/v1/version` reports
`0.1.319`. The live input probe passes again with approximately 0.017 ms
dispatch latency, zero missed deadlines, and the active 1920x2160/60 Hz
output. Physical pointer trails/click behavior, live image activation, and
physical multi-monitor acceptance remain open.

## Current 0.1.318 diagnostic and graphics status

The exact TCC-built server `0.1.318` is deployed on the authorized physical
host at `192.168.10.54:8080`. The live API reports the active SDL output as
1920x2160 at 60 Hz with a 16 ms refresh-aware interval and zero missed
deadlines. The deterministic live input probe passes motion, both button edges,
dispatch accounting, pointer position, and render-path tracing; input dispatch
is approximately 0.016 ms. A non-invasive capture mode was added because the
large screenshot endpoint can block the single-threaded gateway and must not be
used for timing claims.

The local TCC gates pass the 60 Hz frame-rate workload (54.4 Hz measured,
zero missed deadlines), glyph rendering, graphics-cache reuse, fragmented
chunked pixel frames, and session lifecycle. The provider-level Hibr image
probe accepts one chunked image with `pixel_frames_accepted=1`,
`graphics_texture_uploads=1`, and zero pixel-frame errors. The exact current
binary plus unchanged Hibr checkout also passes the QEMU two-output pane
matrix with `LAYOUT_MATRIX_PASS` and `HIBR_PANE_MATRIX_PASS`.

The physical host still reports approximately 1 Hz of Hibr surface damage
because the running desktop is producing commits at that cadence; this is not
an input-dispatch or missed-refresh failure. Its graphics counters remain zero
because this session has not generated an image command, so live wallpaper
transport is not claimed as validated. Physical pointer trails/click behavior,
live image activation, and physical multi-monitor acceptance remain open.

## Superseded 0.1.300 Hibr integration status

The TCC-built server retains the API restart recovery path from 0.1.296 and
adds a focused SDL scene-cache correction. When Hibr changes DECTCEM cursor
visibility, the affected surface is fully redrawn once; ordinary cursor
movement remains incremental. A live 0.1.296 screenshot proved that the API
could report a hidden cursor and blank canonical cells while the old cursor
pixels remained in the cached scene. The new screenshot assertion reproduces
that boundary and passes on the TCC-built 0.1.297 binary.

Local 0.1.297 evidence: full terminal conformance, hidden-cursor pixel and
frame-suppression gate, and frame-rate gate pass. The authorized physical host
was then running 0.1.297; its settled screenshot no longer contained the
stale left-edge cursor artifact, and runtime reported zero missed deadlines at
the active 60 Hz mode. The live 0.1.297 diagnostics then exposed a separate
input ownership defect: KMSDRM SDL and Blit both consumed the same evdev pointer.
0.1.299 makes raw evdev the single pointer owner, hides SDL's native cursor
after each output window is created,
and retains SDL mouse handling only as a no-evdev fallback. This directly
addresses duplicate clicks, two initial pointers, and pointer trails. The
physical host now reports 0.1.299 with the Hibr session running; a further
hit-testing defect was then confirmed: the primary display-attached session
had no pane, so its pointer reports were discarded. 0.1.300 routes display-
attached sessions using their rendered stacked bounds.

## Superseded 0.1.295 Hibr integration status

The current TCC-built server and exact Hibr `0.99.79 abi 16` adapter add an
atomic cell-frame boundary. Hibr flushes are sent as bounded `defer` requests
followed by one `commit`; deferred revisions do not set the renderer pending
state. The focused API gate verified this behavior, and the update-recovery
gate verified that an invalid package can be reset from `failed` to `ready`
through the authenticated API without restarting the gateway.

The 0.1.295 QEMU VKMS stock Hibr fixture completed with `ACCEPTANCE_PASS` and
reported no `flush failed` or `revision_conflict` errors. This is QEMU evidence;
the physical host still needs the service restarted and 0.1.295 deployed before
the live screenshot/overlap claim can be made.

## Superseded 0.1.293 Hibr integration status

The current TCC-built server and exact Hibr `0.99.79 abi 16` adapter were
validated without modifying the Hibr checkout. The two-output VKMS/QEMU stock
desktop fixture completed with `LAYOUT_MATRIX_PASS` and `ACCEPTANCE_PASS`; it
started the unchanged primary desktop and `desktop --join` client, exercised
the control displays, and reported no `flush failed`, `revision_conflict`, or
`console-blit` adapter errors. Both desktop surfaces reported
`cursor.visible:false`, confirming that the adapter now matches Hibr's
zero-initialized hidden-cursor default.

On the authorized physical host, the corrected API request used the schema
field `arguments` (not the non-contract `args` spelling). It produced a real
Hibr desktop on the 1920x2160 display: the surface contained the menu bar in
row 0, a populated row 1, desktop content through row 15, and the control
strip at row 108. The corresponding 1920x2160 API screenshot was captured
after the surface settled. Diagnostics reported SDL3/OpenGL presentation at
60 Hz with zero missed deadlines. This is one-display/60 Hz evidence only;
physical multi-monitor and physical 120/240 Hz gates remain open.

The revision-conflict retry in `console-blit` is retained as a focused
correctness fix: a stale surface revision is refreshed from the structured
409 response and the bounded pending batch is retried without writing the
error back into the same Hibr PTY. The adapter also now starts with the
cursor hidden and only exposes it after an explicit Hibr cursor request. The
package for this source state is `blit_0.1.293-1_amd64.deb`; SHA-256:
`cdb237081f9d2e8d282a1faf8031a419765d7c9fc91044740f495dfa5dbca046`.

## Historical 0.1.289 Hibr integration status

The authorized physical host reports Hibr `0.99.79 abi 16`, while the local
development checkout is `0.99.100`. The `console-blit` adapter was therefore
rebuilt against the exact local `v0.99.79` Hibr worktree without modifying the
Hibr checkout, and package `0.1.289` was deployed to the host. The exact
0.99.79 adapter/server combination passes the QEMU Hibr primary/`desktop
--join` fixture with `ACCEPTANCE_PASS`.

The physical-host `-1`/black screenshot was superseded by the settled `.291`
through `.293` verification above; it remains historical failure evidence, not a
current acceptance result.

The exact 0.1.287 high-refresh fixture also completed with
`REFRESH_SCHEDULER_240_PASS`, `KMS_CAPTURE_PASS`, and the Kitty wide-glyph
capture markers. Physical 120/240 Hz and physical multi-monitor gates remain
open.

## Previous 0.1.287 Hibr integration correction

The exact 0.1.287 TCC server and `console-blit.so` adapter were staged with
the unchanged Hibr checkout into the populated QEMU VKMS initroot. The
two-output Hibr primary plus `desktop --join` fixture completed with
`ACCEPTANCE_PASS`. The corrected adapter handled the full wallpaper write
followed by Hibr's top-bar writes, and the API-launched child diagnostics did
not appear as `desktop:` terminal content. The Debian package
`build/packages-287-final/blit_0.1.287-1_amd64.deb` contains both the server
and adapter; SHA-256:
`6b87137c405d028595c188d05f92890917e3c1a4ab2d561773bd7c9f52b8b265`.

This closes the identified queue-overflow and startup-stderr defects in the
QEMU integration gate. It does not close the separate physical multi-monitor
or physical 120/240 Hz hardware gates.

## Current 0.1.286 live Hibr presentation evidence

On 2026-10-08, the installed 0.1.286 TCC build on the authorized physical
host was exercised through the public API with the unchanged Hibr executable.
The request explicitly created a `240x135` terminal surface for the
1920x2160 `display-1` output. After Hibr startup settled, the surface had
revision 138, 31,993 non-blank cells, and populated cells through row 133;
the API screenshot showed the complete Hibr desktop, including its wallpaper,
top bar, desktop icons, control strip, and pointer. Runtime diagnostics
reported a 1920x2160 viewport at the physical 60 Hz display mode, refresh-aware
16 ms scheduling, and zero missed deadlines in the current frame-rate window.

An immediate screenshot taken while the session was still starting was black;
this is startup timing, not a settled-render result. The live acceptance
procedure therefore waits for the surface revision and populated cell rows to
advance before treating a screenshot as presentation evidence. The session
was deleted through the API and the host returned to zero sessions, surfaces,
streams, and input routes. This is single-display 60 Hz evidence only; it does
not close the physical multi-monitor or physical 120/240 Hz gates. No Hibr
source or installed Hibr file was modified.

## Source and package

- Repository: `main` at the source commit for this ledger update.
- Production C was compiled with TCC.
- The current source candidate is `0.1.300`. It builds with TCC and passes
  the complete terminal conformance suite, SDL screenshot/overlay pixels,
  the hidden-cursor damage gate, and the complete Hibr font manifest gate.
  It includes the versioned network terminal-input endpoint at the canonical
  PTY boundary. Its SDL backend uses a per-output glyph atlas with nearest
  sampling and one-pixel guard borders, suppresses unchanged cell damage, and
  does not schedule frames for hidden cursor movement. The current physical
  host reports 0.1.283 through its version endpoint and exposes actual
  render/viewport dimensions in diagnostics. Its settled Hibr smoke test
  preserved VT500 text, box/block glyphs, combining `Á`, and wide `界`; this
  is one-output evidence, not a multi-monitor or 120/240 Hz claim. The prior
  candidate `blit_0.1.281-1_amd64.deb` was built from its matching binary and passed
  package allowlist, embedded-version, byte-identity, asset-presence, and
  extracted-runtime checks. The final artifact SHA-256 is recorded in the
  package handoff because this ledger is included inside the package itself.
  It is not claimed as a fully validated 240 Hz release: the real-mode QEMU
  stream gate still fails its strict page-flip deadline requirement.

The 0.1.283 source change adds windowed performance diagnostics:
`frame_rate_max_render_ms` and `frame_rate_missed_deadlines`. The frame-rate
gate now accepts `BLIT_GATE_SERVER` and uses those windowed values, so a remote
physical-host measurement cannot be mistaken for the local dummy backend or be
contaminated by an older lifetime maximum. The window sequence counter also
prevents a remote gate from accepting a stale completed window from a previous
workload. The rebuilt Debian package is
`blit_0.1.283-1_amd64.deb`; its SHA-256 is recorded in the external release
handoff because embedding a package's own hash inside its payload is
self-referential.
Its server binary matches the TCC build and the live host reports 0.1.283.

The canonical TCC build entrypoint now has explicit `server` and `helper`
targets. The exact rebuild produced distinct server and root-update-helper
artifacts (`b2d8ec4b...9626be` and `65ebfebf...dee0` respectively); the Debian
packaging allowlist rejects an updater that contains server routes or is byte
identical to the server. The rebuilt package passed this target-separation
check. The helper was smoke-checked to its expected privileged socket bind
boundary; its unprivileged development-shell bind failure is expected because
`/run/blit` is root-owned in deployment.

The 0.1.281 stream-service correction bounds each WebSocket service turn and
parses already-buffered data after `EAGAIN`, preventing a fast graphics client
from starving presentation or spinning on a user-space receive buffer. The
exact package was installed through the supervised live updater. On the real
1920×2160@60 OpenGLES2 host, the no-ACK paced pixel gate accepted 30 frames,
rendered 24, recorded zero pixel-frame errors and zero missed deadlines, and
  returned to zero sessions/surfaces/routes after cleanup. The package SHA-256
  is `2cf122c7e1a9340a5c3e95f5fb3d520d962b34777df4d77d96d598e7109df5b3`.
This is physical one-output 60 Hz evidence; it does not establish physical
120/240 Hz support.

The exact current 0.1.281 TCC binary passed the four-output VKMS Hibr fixture
with one primary and three joins. Its exact 240 Hz pixel-stream fixture also
selected 240 Hz and accepted all 240 frames, but strict presentation measured
117.83 Hz with eight virtual missed deadlines under QEMU TCG, so the fixture
remains scheduler/ingestion evidence rather than a 240 Hz presentation pass.

The installed 0.1.283 host passed the corrected remote terminal frame-rate
gate at 60.382 Hz with a 55 Hz minimum, 31 frames in a fresh 513 ms window,
9,685 terminal bytes, and zero missed deadlines. This is physical one-output
60 Hz evidence, not 120/240 Hz evidence.

The exact 0.1.283 staged binary and unchanged Hibr executable passed the
QEMU/VKMS four-pane fixture: one primary plus three `desktop --join` sessions
were running, each surface reached 1,537 cells, and the guest powered down
cleanly. The exact high-refresh fixture selected the 240 Hz branch and passed
its scheduler gate. Its 60-frame pixel-stream variant accepted all 60 frames,
but strict presentation failed under QEMU TCG with virtual deadline misses;
this remains scheduler/ingestion evidence, not a physical 240 Hz claim.

The exact current 0.1.283 direct-KMS pixel-stream fixture also passed its
standard acceptance path: 60 frames were accepted at a 60 Hz producer cadence,
there were no additional missed deadlines beyond the startup baseline, and
the KMS pixel/screenshot oracles passed for both outputs. The VKMS mode exposed
240 Hz in that run, but the producer remained 60 Hz; this is not a 240 Hz
presentation claim.

The exact current 0.1.283 Hibr input fixture also passed: evdev keyboard and
keypad delivery, pointer motion/buttons with SGR mouse reports, two-mouse
routing, WebSocket input delivery, and gamepad discovery/routing. The PTY
probes received the expected bytes and the guest powered down cleanly.

The authorized physical host also ran the installed Hibr desktop through the
public API on its single DP-1 output. `/usr/bin/desktop` reached `running`,
the surface revision advanced to 69, the API captured a 1920×2160 BMP, and
the active workload measured 59.848 Hz with zero missed deadlines. Cleanup
returned the host to zero sessions, surfaces, streams, and routes with no
diagnostic errors. This is physical single-display 60 Hz evidence only.

The 0.1.281 release-qualification cycle also passed authenticated network
authorization, HTTP fragmentation and back-pressure, session lifecycle and
write/resize, stream replay/snapshot repair, hidden-cursor damage, screenshot
overlay, API shutdown, font manifest, glyph geometry, and full terminal
conformance gates. These checks ran against the exact TCC-built binary; no
Hibr source was modified.

The same live host sustained 59.894 measured frames per second during a
controlled 120×50 full-screen coloured terminal redraw workload carrying
99,433 terminal bytes, with zero missed deadlines. Its maximum observed render
sample was 17.890 ms against the 16 ms target, so this is stable 60 Hz cadence
evidence with a remaining worst-case render-budget issue, not a claim of
unbounded performance.

After deployment of 0.1.276, the physical host ran the installed Hibr desktop
with the `retro_car` theme at a 240×135 terminal surface. The live API reported
100,574 terminal bytes, 91 background batches, 228 background quads, 138
presents, zero missed deadlines, and a maximum complete render sample of
17.272 ms against the 16 ms target. A separate bounded continuous full-screen
terminal workload measured 59.965 Hz over a fresh 500 ms window with zero
missed deadlines; it processed 294,038 cumulative terminal bytes, reached 30
frames in that window, and reported a 20.090 ms maximum complete render sample.
These are physical one-output results. The maximum sample includes the SDL
presentation boundary, so it is retained as a budget signal pending separate
composition/present timing attribution; it is not evidence of a missed display
refresh when the scheduler reports zero missed deadlines.

The focused input/render regression cycle rebuilt the exact 0.1.274 server with
TCC. Complete terminal conformance passed, including VT500 controls, UTF-8,
combining and wide cells, box-drawing, truecolour, Hibr integration, Kitty
graphics, and input-route lifecycle cases. The SDL glyph geometry, nearest
filter, background batching, graphics-cache, hidden-cursor damage, and stream
replay gates also passed. The live host reported the same 0.1.274 version,
60.000 Hz display mode, zero missed deadlines, and zero active sessions after
the controlled inspection. No input or glyph defect was reproduced in this
cycle, so no speculative input change was made.

The follow-up dummy-backend workload passed the pixel-frame gate with all 30
frames accepted and 27 rendered, including fragmented RGBA input and frame
reuse. The frame-rate gate measured 43.758 Hz over a 502 ms window with zero
missed deadlines and a 15.102 ms maximum render sample against a 16 ms target.
Network fragmentation, back-pressure, and authentication gates also passed.
These are deterministic software-backend measurements and do not replace
physical 120/240 Hz evidence.

After ADR-0021 aligned the bounded sixel advertisement with the runtime, the
exact 0.1.274 TCC binary was re-run through terminal conformance; its
`kitty,sixel` capability assertion, lifecycle termination, nearest-filter, and
Hibr font-manifest gates all passed. This confirms the documentation correction
did not diverge from the shipped capability or test contract.

An API screenshot of the live SDL output was also captured with the
display-derived 240×135 surface geometry at 1920×2160. Visual inspection of
the enlarged glyph crop showed clean box-drawing, block, combining, wide-cell,
and colour placement with no adjacent-atlas bleed. Emoji outside the bundled
fixed-cell coverage remains an explicit visible fallback; this is not a claim
of universal Unicode shaping.

### Current 0.1.279 evidence

The 0.1.279 correction makes each SDL display window enter exclusive
fullscreen after it is positioned on its target display. This is required by
the SDL KMSDRM backend for a complete scanout surface; a borderless window
alone can leave a startup-sized composition area even when the display mode is
taller. The versioned diagnostics now expose the actual renderer output size,
viewport size, and render scale per output. The authorized physical host
reported `render_width=1920`, `render_height=2160`,
`viewport_width=1920`, `viewport_height=2160`, and unit scale after the
upgrade.

A fresh Hibr `retro_car` session reached the settled surface revision 138 in
three bounded polls. Its API screenshot was 1920×2160 and had no sustained
black rows; visual inspection showed the wallpaper and desktop content from
the first through the last output row. Capturing before Hibr reached that
revision produced a partial startup frame, so the validation procedure now
waits for the surface revision to settle before treating a screenshot as
render evidence. The session was deleted and the host returned to zero
sessions, surfaces, streams, and input routes with no diagnostics errors.

The installed 0.1.279 physical host passed the API-owned pixel-frame gate with
30 fragmented/reused RGBA frames accepted at 61.034 Hz and zero pixel-frame
errors, and passed the damage-driven terminal frame gate at 44.498 measured
frames over a 516 ms window with zero missed deadlines and a 12.304 ms maximum
render sample against the 16 ms target. These are one-output 60 Hz results;
they do not claim physical 120/240 Hz support.

The exact TCC-built 0.1.279 binary also passed a 12-second four-session SDL
terminal soak with 747 rendered frames at 60.060 Hz, zero missed deadlines,
3.999 ms maximum terminal-processing time, and 17.515 ms maximum complete
render time. Its maximum SDL presentation sample was 17.433 ms, identifying
the display synchronization boundary—not terminal parsing or glyph
composition—as the dominant part of the refresh budget in this dummy
workload. The graphics-cache, background-batch, and SDL glyph gates passed in
the same cycle; the graphics test recorded five cache hits with no repeated
texture uploads, and the background test coalesced the wallpaper-like runs.
These are controlled SDL measurements, not physical 120/240 Hz evidence.

The exact TCC build passed the OpenAPI parse, Hibr font manifest, SDL glyph,
background batching, and graphics-cache gates. No Hibr source was modified.

An additional bounded workload was run against the authorized physical host at
1920×2160 and 60 Hz. It processed 192,855 terminal bytes, submitted 376
background batches and 778 coalesced quads, sustained 60.078 Hz, and recorded
zero missed deadlines. The worst complete render sample was 23.438 ms and the
worst SDL presentation sample was 18.876 ms. The runtime also reported a
684.914 ms cumulative historical maximum loop gap; because that counter is not
reset per workload, it is not attributed to this run. During the observed
workload the current loop gap was 9.759 ms, maximum select time was 13.989 ms,
and maximum SDL event-service time was 0.147 ms. This confirms the physical
60 Hz path is active and measurable while leaving physical 120/240 Hz and
multi-display validation open.

The exact staged 0.1.279 binary (SHA-256
`b75c962524efeb182ff0e83e870c4df02556afb6ffb36535c470c8eb9161e87a`) and the
unchanged Hibr executable passed the four-output VKMS orchestration fixture.
The guest selected 1024×768 at 240 Hz on four connectors, started one primary
Hibr desktop and three `desktop --join` clients, reached four sessions and
four surfaces, and reported `KMS_FOUR_HIBR_PASS`. This is reproducible
multi-output orchestration evidence, not physical multi-monitor evidence.

The exact same current binary and Hibr executable passed the corrected QEMU
input fixture after the staging helper was made to refresh the canonical
`qemu_hibr_init.sh` entrypoint instead of preserving a historical init script.
The non-soak run passed layout, gamepad discovery, keypad, multi-mouse, stream,
and gamepad-routing checks. The 12-second soak passed layout, gamepad
discovery, keypad observation, multi-mouse, stream, gamepad routing, and
render-soak checks, then powered down cleanly. This matters because the stale
init script omitted the gamepad route and could otherwise produce a misleading
partial input result. Hibr source remained unchanged.

With the same staged artifacts, the pane lifecycle fixture passed
`HIBR_PRIMARY_RESTART_PASS`, `HIBR_JOIN_RECONNECT_PASS`, and
`HIBR_PANE_MATRIX_PASS`: one primary desktop and three `desktop --join`
clients were placed across the Blit-owned pane matrix, the primary was
restarted through Hibr's supervisor, and an auxiliary join was reconnected.
The current four-output fixture also passed `KMS_FOUR_HIBR_PASS` with four
presenting VKMS outputs and one primary plus three joins. Both guests powered
down cleanly; Hibr remained unchanged.

The unchanged stock Hibr session entrypoint was also exercised with
`blit.hibr_stock=1` and the four-pane matrix. All four stock Hibr sessions
reached `running`, attached to Blit-owned panes, and the guest powered down
cleanly with no reported Hibr errors. This is stock-entrypoint integration
evidence; it does not replace physical multi-display validation. The acceptance
check now also reads each attached surface: all four sessions advanced their
surface revision and exposed 1,537 cells each. This proves that the stock
entrypoint produced populated terminal surfaces, rather than merely creating
four live processes.
The same assertions passed again with the exact current TCC rebuild after
the build-target correction, and the four-output fixture returned
`KMS_FOUR_HIBR_PASS`; both guests powered down cleanly.

The current 0.1.279 two-output high-refresh fixture passed
`REFRESH_SCHEDULER_240_PASS` and accepted all 240 API pixel frames, but failed
the strict presentation-rate assertion: QEMU TCG presented 165.222 measured
frames per second, recorded 36 missed deadlines, and reached a 19.684 ms
maximum KMS-present sample. This remains an honest virtual-driver limitation;
the result does not establish or disprove physical 240 Hz capability. The
physical multi-display gate returned `PHYSICAL_MULTI_DISPLAY_UNAVAILABLE
displays=1` on the authorized host, so real multi-display and real
120/240 Hz acceptance remain open.

### Current 0.1.277 evidence

The exact TCC-built `0.1.277` binary passed complete terminal conformance,
including raw and bracketed-paste network input, the Hibr font manifest,
SDL glyph geometry/filtering, background batching, graphics-cache reuse, and
the frame-rate gate. The new runtime fields
`last_sdl_present_ms` and `max_sdl_present_ms` separate SDL presentation
synchronization from the existing complete-path render timing. The OpenAPI
schema and conformance gate require both fields. No Hibr source was modified.

The exact staged binary reported `server_version:"0.1.277"` and passed the
two-output direct-KMS visual fixture with
`PPM_DISPLAY_47_VISUALS_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`. It was staged with binary
SHA-256 `2a6762189e5ea3c1d8da93c498a4d63b47d699beda728a9e55dfec7cb8eae82d`.

The authorized physical host was upgraded to 0.1.277 and ran a bounded
full-screen workload at its 60 Hz mode. The live API measured 59.861 Hz with
zero missed deadlines, `max_render_ms=17.378`,
`max_sdl_present_ms=17.259`, and returned to zero sessions and surfaces after
cleanup. This confirms that the observed worst-case sample is at the SDL
presentation boundary; it does not claim physical 120/240 Hz support.

The same live host passed the API-owned pixel-frame gate against the installed
0.1.277 service: 30 fragmented/reused RGBA frames were accepted at 61.058 Hz,
with zero pixel-frame errors and 16 refresh-bound presentations during the
bounded test. This validates the game/arcade frame transport independently of
the terminal-cell glyph path; it is still one physical 60 Hz output evidence.

The exact staged 0.1.277 binary and unchanged Hibr checkout also passed the
current one-vCPU QEMU input/presentation soak with
`LAYOUT_MATRIX_PASS`, `BLIT_INPUT_GAMEPAD_DISCOVERY_PASS`,
`BLIT_INPUT_KEYPAD_SOAK_OBSERVED`, `BLIT_INPUT_MULTI_MOUSE_PASS`,
`BLIT_INPUT_STREAM_PASS`, `BLIT_INPUT_GAMEPAD_PASS`, and
`BLIT_INPUT_RENDER_SOAK_PASS`. The fixture exercised two synthetic mice,
keyboard VT/UTF-8 traffic, three mouse buttons, wheel events, pointer motion,
gamepad buttons and axes, API input routes, and the WebSocket input stream.
It used Blit SHA-256
`2a6762189e5ea3c1d8da93c498a4d63b47d699beda728a9e55dfec7cb8eae82d` and the
same Hibr SHA-256 recorded above, then powered the guest down cleanly. This is
end-to-end protocol and routing evidence for terminal games and API-owned
game input; QEMU TCG timing in this run is not physical refresh-rate evidence.

The exact same 0.1.277 binary was staged into the current one-vCPU VKMS
four-output fixture with the unchanged Hibr executable
(`8903e0c1addf065e54646bfbab9db0e532cc6d028feb5b9def94b32e52c2ba06`). It
reported four 1024×768 outputs at their selected 240 Hz modes, created four
Hibr-backed sessions and surfaces, rendered one primary plus three unchanged
`desktop --join` clients, and finished with `KMS_FOUR_HIBR_PASS`. The run
recorded virtual QEMU deadline misses during startup and is therefore
multi-output orchestration evidence, not physical 240 Hz timing evidence.

An attempted live Hibr reattach also exposed an important test precondition:
the host already had a held `blit` desktop, so a fresh primary invocation
correctly exited with Hibr's "already running" result. Reattaching with
`desktop --session blit --resume` remained running, but the existing held
session's attached surface was blank in the API cell snapshot. This is not
treated as a rendering pass; the held-session lifecycle/state must be reset or
inspected through Hibr before using that host run as current glyph evidence.

That stale state was then inspected and removed through Hibr's own `mod load
hold; hold kill` interface; no Hibr source or installed Hibr file was changed.
A fresh primary named `blit-clean` reached `running`, advanced its surface to
revision 138, populated all 135 rows of the 240×135 cell grid, and produced a
1920×2160 API screenshot with the menu bar, wallpaper grid, desktop icons,
control strip, and pointer visible. A second clean run processed 860,270
terminal bytes, 895 background batches, and 3,350 background quads with zero
missed deadlines. Its complete-path worst sample was 19.027 ms and its SDL
presentation worst sample was 17.259 ms; this is a successful one-output Hibr
render validation, not a physical multi-monitor or high-refresh result.

### Current 0.1.276 evidence

The exact TCC-built `0.1.276` binary passed the complete terminal
conformance suite, including the new network-input capability identity, raw
PTY input, and bracketed-paste framing cases. Session lifecycle, network
fragmentation/back-pressure/authentication, SDL glyph filtering, and the Hibr
font manifest gates also passed. No Hibr source was modified.

The exact same staged binary was run through the two-output direct-KMS QEMU
visual fixture. It reported `server_version:"0.1.276"`, two ready DRM/KMS
outputs, and the checked-in Hibr font, then passed
`PPM_DISPLAY_47_VISUALS_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`. This proves current
two-output composition, glyph/colour capture, and API screenshot correctness
in the reproducible VKMS fixture. The fixture selected 240 Hz with a 4.166 ms
target interval, but its startup page-flip workload is not a sustained 240 Hz
timing proof: QEMU TCG recorded virtual deadline misses and a worst-case
startup present span of 89.732 ms. Physical high-refresh acceptance remains
open.

The exact 0.1.276 binary and the unchanged Hibr checkout were also run through
the four-output orchestration fixture using the stable one-vCPU QEMU topology.
The fixture created four VKMS outputs, started one primary Hibr desktop and
three `desktop --join` clients, and reached four live sessions and four live
surfaces before reporting `KMS_FOUR_HIBR_PASS`. The staged Hibr executable
hash was `8903e0c1addf065e54646bfbab9db0e532cc6d028feb5b9def94b32e52c2ba06`.
This validates the Blit-owned multi-display/session orchestration boundary;
the QEMU TCG run recorded virtual deadline misses and is not physical
high-refresh timing evidence.

The HTTP input endpoint is deliberately bounded to 768 data bytes per request
and reports the actual PTY write count. It is an API transport into the
canonical PTY/terminal path, not a second input or terminal implementation.

### Current 0.1.275 evidence

The 0.1.275 network-input implementation was superseded by 0.1.276 after a
small PTY-boundary correction: API and WebSocket input now return a scrolled
surface to live view, and interrupted nonblocking writes are retried. The
public contract is unchanged.

### Current 0.1.274 evidence

The exact TCC-built `0.1.274` binary was rebuilt from the pushed source and
passed `HIBR_FONT_MANIFEST_PASS` (`required=447`, `mappings=1181`),
`SDL_GLYPH_RENDER_PASS` (light/heavy/double box geometry, blocks, and wide
glyphs), `SDL_GLYPH_FILTER_PASS` (`nearest`), dummy frame-rate,
`PIXEL_FRAME_PASS`, complete terminal conformance, background
batching, graphics-cache, hidden-cursor damage, and a 20-second four-session
terminal soak. The soak completed 244 snapshots and 22 resizes with a maximum
RSS of 66,328 KiB.

The SDL atlas now uses a one-pixel duplicated guard border around each bitmap
cell. This closes the adjacent-texel leak that can produce stray strokes when
scaled glyph geometry lands on normalized atlas boundaries. The canonical PSF
font, cell geometry, and direct-KMS renderer remain unchanged.

The exact same binary passed the direct-KMS two-output visual gate:
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`.

The exact `0.1.273` binary independently re-ran that two-output fixture and
reported `server_version:"0.1.273"`, two DRM/KMS outputs,
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`.

The current source also contains the native-size direct-KMS graphic-frame
copy path, including an alpha-safe packed conversion for opaque API RGBA
frames. The paced dummy pixel gate accepted 30 frames at 60.953 Hz and
rendered 27 of them, satisfying its minimum 24-frame presentation bound; the
burst gate accepted all 30 while coalescing to the newest complete frame. The
two-output VKMS API pixel fixture passed `PIXEL_FRAME_PROBE_PASS` and
`KMS_API_PIXEL_PASS` after this change. The nominal-60-Hz producer stream also
passed `PIXEL_FRAME_RATE_PASS` and `KMS_API_PIXEL_PASS`, accepting all 60
frames with no additional missed deadlines over the two-output startup
baseline. The custom fixture selected its active 240 Hz mode; this validates
the emulator-facing stream contract but does not close the unresolved strict
240 Hz KMS gate or make a 60 Hz run a physical 120/240 Hz release claim.

The exact same binary and current external Hibr checkout passed the dedicated
Hibr VKMS orchestration fixture: `LAYOUT_MATRIX_PASS`,
and `HIBR_PANE_MATRIX_PASS`. The four-output current-source fixture also passed
`KMS_FOUR_OUTPUT_PASS`, presenting four independent KMS outputs and four
attached terminal surfaces.

The exact `0.1.273` binary and unchanged Hibr checkout additionally passed
the input/presentation soak: `LAYOUT_MATRIX_PASS`,
`BLIT_INPUT_GAMEPAD_DISCOVERY_PASS`, `BLIT_INPUT_KEYPAD_SOAK_OBSERVED`,
`BLIT_INPUT_MULTI_MOUSE_PASS`, `BLIT_INPUT_STREAM_PASS`,
`BLIT_INPUT_GAMEPAD_PASS`, and `BLIT_INPUT_RENDER_SOAK_PASS`.
The runtime diagnostics contract additionally exposes `input_events`,
`last_input_dispatch_ms`, and `max_input_dispatch_ms`; the full terminal
conformance gate verified their presence through the versioned API. It also
exposes per-output `last_present_ms`, `max_present_ms`, and `present_calls` so
multi-display presentation bottlenecks are attributable to one output.

The forced-timeout KMS recovery fixture also passed `KMS_RECOVERY_PASS`:
both outputs entered and completed modeset recovery after a one-millisecond
flip timeout, then passed the normal two-output visual and screenshot gates.

The current Hibr VKMS input fixture also passed keypad soak observation,
`BLIT_INPUT_MULTI_MOUSE_PASS`, `BLIT_INPUT_STREAM_PASS`,
`BLIT_INPUT_GAMEPAD_PASS`, `BLIT_INPUT_DEVICE_LOSS_PASS`, and
`BLIT_INPUT_RENDER_SOAK_PASS`. Input routes survived device reconnect when
their target sessions remained live; routes targeting the intentionally
completed soak sessions were correctly disabled by session lifecycle.

The corrected real-mode high-refresh fixture selected 240 Hz from the VKMS
mode itself (`refresh_source:"display-mode"`) and accepted all 240 pixel
frames. Its scheduler metadata gate passed. In the fresh 0.1.274 run, only
85 frames reached presentation in the 240-frame workload (`frame_rate_hz`
169.900); the maximum select gap was 13.277 ms and maximum KMS present span
was 20.859 ms. The diagnostic async page-flip comparison was also red
(168.102 Hz, 14.977 ms maximum select gap, 13.046 ms maximum KMS span), so
async page flips are not an acceptable fix and remain comparison-only.
Therefore 240 Hz presentation is not yet validated and no package claim is
made for it. The remaining bottleneck is QEMU TCG/VKMS scheduling rather than
WebSocket ingestion, terminal glyph rendering, or pixel-frame acceptance.
Changing the VM topology did not produce a usable workaround: four-vCPU
multi-threaded TCG caused the guest kernel to panic in `sched_clock_cpu` before
Blit started, while stable one-vCPU TCG presented only 162.714 Hz with a
17.771 ms maximum select gap and a 47.778 ms maximum KMS span. The two-vCPU
TCG configuration remains the reproducible baseline for this gate.

### Current 0.1.267 release-candidate evidence

The exact 0.1.267 TCC binary passed the strengthened frame-rate gate with
43.418 measured damage-driven frames per second, 15.464 ms maximum render time
against a 16.000 ms target interval, and zero missed deadlines. The gate now
fails if the runtime reports a missed deadline or a render over the active
output budget; this is a scheduler-budget assertion, not a claim that a
60 Hz panel scans at 43.418 Hz.

SDL background geometry now coalesces contiguous equal-color cells into
horizontal runs. The focused 128×48 wallpaper-style gate passed with four
background quads and a pixel-correct screenshot, proving the optimization
without changing cell colors or damage bounds.

The new SDL glyph-render gate passed through the public screenshot endpoint:
light/heavy/double box lines, light vertical geometry, full and lower blocks,
and both halves of a wide glyph all matched their pixel topology. This closes
the previously missing renderer-boundary assertion for deterministic glyph
shapes; it does not claim universal Unicode shaping.

The same exact binary passed the complete terminal conformance suite and the
Hibr font manifest gate (`required=447`, `mappings=1181`). The conformance
vectors include combining marks, wide cells, variation selectors, zero-width
joiners, box drawing, DEC special graphics, cursor state, and malformed
control recovery.

The exact 0.1.267 direct-KMS QEMU fixture passed `KMS_CAPTURE_PASS`, including
two distinct output captures, wide-glyph pixels, API screenshot validation,
and the 929-glyph/1,182-mapping bundled font. The exact four-output Hibr
fixture passed `KMS_FOUR_HIBR_PASS` with one primary and three
`desktop --join` clients and four rendered views. These are VKMS/QEMU results,
not physical multi-monitor evidence; the fixture recorded two virtual
page-flip deadline misses during startup/composition, which remain visible in
diagnostics and are not treated as physical refresh evidence.

The exact 0.1.267 Hibr input fixtures passed layout-matrix discovery,
multi-mouse routing, keypad delivery, stream delivery, gamepad discovery and
button delivery, render soak, and synthetic keyboard/mouse/gamepad loss and
reconnect. The device-loss run preserved surviving input routes and reported
explicit reconnect diagnostics. These are deterministic evdev/QEMU results;
physical pointer/button/wheel behavior remains a separate hardware gate.

The exact 0.1.267 local lifecycle gates also passed authenticated gateway
authorization, HTTP fragmentation/backpressure, supervised update cancellation,
supervised upload idle timeout, and API shutdown. That historical record
predates the authorized 0.1.274 live deployment documented above.

### Current 0.1.265 source evidence

The bundled Hibr font now assigns dedicated deterministic 8×16 glyphs to the
light, heavy, double, rounded, and dashed box-drawing characters, rejects
`.notdef` fallback output, and covers the previously unresolved Hibr symbols
through ordered build-time fonts and four explicit terminal pictograms. The
font manifest gate checks exact bitmap topology independently of the
generator. The 447 required scalars now occupy 353 distinct bitmap shapes;
the previous large `.notdef` alias group is absent.

The exact 0.1.265 TCC binary passed the full terminal conformance suite,
SDL background/cache and pixel gates, network/authentication gates, and the
direct-KMS two-output capture. The latter passed
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS` with the regenerated font;
the guest loaded 929 glyphs and 1,182 mappings.

The authorized live host accepted and restarted on 0.1.265. A controlled
240×135 Hibr desktop workload produced 43,568 wallpaper background quads in
91 batches, with 17.379 ms maximum render time, 6.551 ms maximum terminal
processing time, zero missed deadlines, and no diagnostics errors. The session
was deleted and the live resource counts returned to zero. Its idle
`frame_rate_hz=0` sample is not interpreted as a scanout rate: the changed
content window had expired after Hibr stopped emitting updates.

The follow-up 0.1.265 live Hibr run produced 43,413 wallpaper background
quads in 93 batches, with 17.638 ms maximum render time, 7.189 ms maximum
terminal processing time, zero missed deadlines, and no diagnostics errors.
Its active changed-content sample measured 5.284 Hz; after Hibr became idle,
the rate correctly aged out to zero. Cleanup returned sessions, surfaces, and
input routes to zero.

The exact 0.1.265 direct-KMS fixtures additionally passed the 60 Hz
emulator-like stream (`PIXEL_FRAME_STREAM_SENT frames=60`,
`PIXEL_FRAME_RATE_PASS`, `KMS_API_PIXEL_PASS`), the 240 Hz scheduler branch
(`REFRESH_SCHEDULER_240_PASS`), and the four-output Hibr orchestration
(`KMS_FOUR_HIBR_PASS`) with one primary and three `desktop --join` clients.
The four-output TCG/VKMS run recorded virtual page-flip misses during startup
and Hibr composition; this is retained as virtual-driver timing evidence and
is not a physical refresh-rate claim.

The exact 0.1.265 Hibr/VKMS input fixtures passed `LAYOUT_MATRIX_PASS`,
`BLIT_INPUT_KEYPAD_PASS`, `BLIT_INPUT_MULTI_MOUSE_PASS`,
`BLIT_INPUT_STREAM_PASS`, `BLIT_INPUT_GAMEPAD_PASS`, and
`BLIT_INPUT_RENDER_SOAK_PASS`. The device-loss variant additionally passed
`BLIT_INPUT_DEVICE_LOSS_PASS`, including route continuity for surviving
devices and input loss/reconnect events. The staged runtime loaded the 929
glyph / 1,182 mapping font; Hibr source was not modified.

The exact 0.1.265 TCC binary also passed the bounded endurance set: the
120-second four-PTY soak completed 1,460 snapshots and 133 resizes with
66,492 KiB peak RSS under the 131,072 KiB ceiling and clean teardown;
session deletion completed in 146 ms, stream replay repaired a one-event gap,
shutdown exited cleanly, hidden-cursor damage passed, and the screenshot/
overlay pixel gate passed.

The exact 0.1.265 direct-KMS fixture additionally passed the mixed-refresh
branch (`REFRESH_SCHEDULER_MIXED_PASS`) with independent 60/120 Hz scheduler
metadata, and the output-loss branch (`OUTPUT_LOSS_PASS`) with the surviving
second output continuing to capture successfully. Both runs also passed the
wide-glyph, API-screenshot, and complete KMS capture assertions.

### Current 0.1.263 source and physical evidence

The exact 0.1.263 TCC build passes the complete 0.1.262 regression set plus
the runtime stream-telemetry schema gate. The live host reports zero current
stream queue bytes, zero dropped event deliveries, and zero back-pressure
disconnects at idle. During a real Hibr run it reported 58 SDL background
batches and 5,960 background quads, with the same 59.990 Hz display mode and
zero missed deadlines; teardown returned zero sessions, surfaces, and routes.

The exact 0.1.263 binary also passed the current high-refresh VKMS branch:
`REFRESH_SCHEDULER_240_PASS`, `PPM_DISPLAY_47_WIDE_KITTY_PASS`,
`PPM_DISPLAY_48_PASS`, `KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`.
The virtual 240 Hz output selected a 4.166 ms target interval; its three
emulated page-flip misses remain virtual timing evidence, not a physical
240 Hz claim.

### Current 0.1.262 source and physical evidence

The exact 0.1.262 TCC binary passes the SDL background-batch screenshot gate,
SDL graphics-cache gate, fragmented/back-pressure network gates, pixel-frame
gate, full VT/UTF-8/Hibr terminal conformance, and the 447-glyph font manifest.
The API now reports `background_batches` and `background_quads` so wallpaper
optimization is directly observable.

On the authorized physical host, 0.1.262 reports one DP-1 output at 59.990 Hz,
refresh-aware 16 ms scheduling, and zero missed deadlines. A real Hibr desktop
run reported 170 background batches and 51,819 background quads, with a last
render time of 16.477 ms and a changed-content rate of approximately 8.21 Hz.
The latter is not the panel scanout rate: Blit presents only when terminal
damage exists, while the display remains synchronized by SDL vsync. The
changed-content rate is recorded as an unresolved Hibr workload cadence, not
claimed as 60 Hz animation.

The same 0.1.262 host accepted 30 API pixel frames from a paced 60 Hz producer
and 30 frames with presentation acknowledgements; the acknowledged run
rendered 29 frames with zero pixel-frame errors. This is physical one-output
game-canvas evidence. A physical second connector and physical 120/240 Hz
hardware remain unverified.

The exact 0.1.262 TCC binary also passed the direct-KMS two-output VKMS capture
fixture: `PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`. It reported two outputs at
60 Hz with refresh-aware scheduling and zero initial missed deadlines. This is
current two-output virtual-KMS evidence, not physical multi-monitor evidence.

### Current 0.1.260 source and physical evidence

The SDL glyph atlas now explicitly uses nearest-neighbor sampling. SDL3
defaults texture scaling to linear, which can bleed adjacent atlas glyphs into
scaled cell edges; the new filter gate passes the set/get policy check and the
renderer falls back to its existing per-pixel path if nearest mode is
unavailable. This removes a concrete source of malformed glyph shapes without
changing the canonical font or terminal model.

An isolated live 0.1.260 screenshot of box drawing, block shading, arrows,
common symbols, and combining acute/tilde/ring marks showed those mapped shapes
without replacement `?` cells. Emoji and CJK samples still select the explicit
visible fallback glyph; they are not represented as universal Unicode shaping
support by this fixed-cell PSF renderer.

After the supervised 0.1.260 upgrade, the physical host's existing held Hibr
state was correctly recovered with `/usr/bin/desktop --resume`: the session
reached `running`, reported 59.922 Hz over its active window, and recorded zero
missed deadlines. A bare `desktop` invocation exited 1 because that held state
already existed; this is Hibr's documented lifecycle distinction, not a Blit
rendering failure. Deleting the Blit session then returned the host to zero
sessions, surfaces, routes, errors, and warnings.

The TCC-built 0.1.260 runtime derives a terminal surface's cell geometry from
its authoritative pane or display when the API request omits `surface`. A
request for the physical host's `display-1` therefore created a 240×135 cell
surface for its 1920×2160 mode, eliminating the earlier 120×40 partial-screen
integration mistake. The same request launched the stock `/usr/bin/desktop`
without modifying Hibr.

The SDL renderer now batches atlas-backed glyph quads with
`SDL_RenderGeometry`. On the authorized host's physical 0.1.258 Hibr workload
before this candidate, the API reported an
active 517 ms window at 59.948 Hz, last render 16.420 ms, maximum render
17.234 ms, maximum event-loop gap 17.311 ms, and zero missed deadlines. The
captured 1920×2160 screenshot filled the output and retained the Hibr
wallpaper, desktop icons, menu controls, and pointer without visible geometry
corruption. This is physical one-output evidence at the host's active 59.990
Hz mode; physical multi-monitor and 120/240 Hz hardware evidence remain open.

The full VT/UTF-8/Hibr terminal suite, SDL frame gate, graphics-cache gate,
Hibr font manifest, and OpenAPI derived-geometry check pass from the same
0.1.260 source. The manifest contains 447 required glyphs and 1,181 Unicode
mappings, including exact row-shape assertions for U+2580–U+2588. The
full-screen Hibr workload's measured frame rate is
distinct from the idle diagnostic value: idle servers do not present frames.

The exact 0.1.260 TCC binary was staged into the two-output VKMS/QEMU capture
fixture. It discovered two 1024×768 KMS outputs, passed the known-glyph and
pixel assertions on both screenshots, passed the API screenshot assertion, and
produced `KMS_CAPTURE_PASS`. This confirms the current direct-KMS binary; the
fixture's emulated page-flip timing is not physical high-refresh evidence.

The exact same 0.1.258 TCC binary also passed the four-output VKMS fixture;
the nearest-filter change is SDL-only and does not alter that direct-KMS
path. The fixture discovered and presented four independent 1024×768 outputs,
producing `KMS_FOUR_OUTPUT_PASS`. The QEMU/VKMS run
reported one startup deadline miss per output while its page-flip work took
9–32 ms; this is recorded as virtual-driver timing evidence, not as a claim
of 60 Hz hardware cadence. The high-refresh fixture produced
`REFRESH_SCHEDULER_240_PASS`, but its virtual 240 Hz output recorded three
misses because the emulated page-flip path took tens of milliseconds. It proves
the 240 Hz deadline calculation and API metadata only; physical 120/240 Hz
hardware remains unverified.

The exact 0.1.260 Hibr input fixture then passed `LAYOUT_MATRIX_PASS`,
`BLIT_INPUT_KEYPAD_PASS`, `BLIT_INPUT_MULTI_MOUSE_PASS`,
`BLIT_INPUT_STREAM_PASS`, and `BLIT_INPUT_GAMEPAD_PASS`. It exercised four
VKMS outputs, independent keyboard and pointer routing, multiple mice, left /
middle / right buttons, wheel events, held-button motion, and gamepad
discovery. This is deterministic evdev evidence; physical click behavior on a
second real connector remains open.

The exact 0.1.260 four-output Hibr orchestration fixture also passed
`KMS_FOUR_HIBR_PASS`: one primary and three `desktop --join` clients reached
four Hibr-backed presented surfaces. The TCG/VKMS run recorded six timing
misses per output under that workload; this is retained as virtual page-flip
evidence and is not presented as physical refresh-rate evidence.

With Hibr staged from its existing checkout only, the same four-output fixture
then launched one primary Hibr desktop and three `desktop --join` clients.
All four Hibr-backed surfaces reached the running/presented state and the
fixture produced `KMS_FOUR_HIBR_PASS`. The Hibr checkout was not modified;
this remains virtual multi-display evidence rather than physical connector
evidence.

The live 0.1.258 input inventory and route lifecycle were also exercised with
the physical keyboard and pointer devices. All discovered sources were
reported with their aggregate route IDs; a disposable pointer route was bound
to and removed from a PTY session with HTTP 204, leaving zero routes and no
diagnostic errors or warnings.

### Current 0.1.256 source evidence

The input inventory now exposes `route_ids` alongside each physical
`event-*` device ID. This makes the canonical aggregate route identity
explicit to API clients; all discovered sources of a kind remain active and
feed that route. The OpenAPI schema and live-host route lifecycle were
  validated without modifying Hibr. Input routes now also support DELETE;
  the conformance gate proves a removed route is absent from subsequent
  inventory snapshots.

### Current 0.1.254 source evidence

The 0.1.254 TCC build fixes a JSON-scope defect in API cell updates. Each
cell's style object is isolated before parsing, so omitted foreground,
background, and attribute fields cannot inherit values from later cells. A
regression gate proves independent green foreground, red background, inverse,
and unstyled cells. The full VT/UTF-8/Hibr suite, pixel-frame gate, and dummy
frame-rate gate pass after the fix. Direct-KMS and Hibr input fixtures were
also rerun from this changed source and pass. The physical host now reports
0.1.254; its live 60 Hz stream accepted 60/60 frames with zero pixel errors,
zero missed deadlines, and 60 texture uploads. A live style-scope request
confirmed that green foreground, red background, inverse, and unstyled cells
remain independent. The temporary sessions were deleted with HTTP 204.

The authorized physical host also ran the real `/usr/bin/desktop` command
through the API with the stock Hibr session contract. It reached `running`,
advanced to surface revision 24 after 16,095 terminal bytes, rendered with a
17.106 ms maximum sample and zero missed deadlines, and produced a readable
Hibr desktop screenshot containing its wallpaper, icons, and control UI. The
session was deleted with HTTP 204. This is physical one-output Hibr evidence;
physical pointer/button interaction and multi-monitor Hibr evidence remain
open.

The exact 0.1.256 TCC build also passed the Hibr/VKMS input fixture with
`LAYOUT_MATRIX_PASS`, `BLIT_INPUT_MULTI_MOUSE_PASS`,
`BLIT_INPUT_STREAM_PASS`, and `BLIT_INPUT_GAMEPAD_PASS`, including keypad,
surface key/pointer, and device-loss diagnostics. The authorized physical host
was left with zero sessions, surfaces, streams, and routes.

The current refresh fixture also passed `REFRESH_SCHEDULER_240_PASS` with a
4 ms deadline on both VKMS outputs, followed by the two framebuffer oracles
and `KMS_CAPTURE_PASS`. This proves the scheduler's 240 Hz deadline branch in
the current source; it is not physical 240 Hz hardware evidence.

The current-source four-output VKMS fixture exposed four independent 1024×768
outputs at 60 Hz, created one terminal session per output, and passed
`KMS_FOUR_OUTPUT_PASS`. The mixed-refresh fixture then passed
`REFRESH_SCHEDULER_MIXED_PASS`, the two-output pixel oracles, and
`KMS_CAPTURE_PASS` with the test scheduler's 60/120 Hz metadata. These are
virtual-output scheduling results; physical multi-monitor and physical
120/240 Hz evidence remain open.

The same current-source four-output fixture was run with Hibr orchestration:
one primary session and three `--join` sessions produced four Hibr-backed
surfaces and passed `KMS_FOUR_HIBR_PASS`. Hibr source was copied into the
guest staging area only; the repository checkout was not modified.

### Current 0.1.253 source evidence

The exact TCC-built 0.1.253 binary passes the full VT/UTF-8/Hibr terminal
conformance suite, the font manifest gate, and the refresh-aware dummy frame
gate. Its bounded binary pixel-frame WebSocket gate accepted 30/30 RGBA
frames, including one fragmented frame, with zero frame errors and reusable
texture storage. The measured dummy ingest rate was 21,353 frames/second;
the renderer coalesced those updates into six frames at a measured 16.468 ms
render time. The direct-KMS QEMU fixture then accepted a complete 4,096-byte
RGBA frame through the network API, found the known red canvas in the
framebuffer oracle through the direct-KMS screenshot endpoint, preserved the
second output, and passed `KMS_API_PIXEL_PASS`, `PPM_DISPLAY_48_PASS`, and
`KMS_CAPTURE_PASS`. This proves the API-to-VKMS pixel path; it does not yet
claim physical 120/240 Hz hardware presentation.

The timed direct-KMS stream variant sent 60 complete RGBA frames at a 60 Hz
producer cadence. It accepted all 60 with zero missed deadlines, passed
`PIXEL_FRAME_RATE_PASS`, and then passed `KMS_API_PIXEL_PASS`,
`PPM_DISPLAY_48_PASS`, and `KMS_CAPTURE_PASS`. This validates the
emulator-facing 60 Hz stream and bounded back-pressure path on VKMS; physical
120/240 Hz hardware evidence remains open.

The pixel path now invalidates only the affected graphics rectangle in cell
coordinates instead of forcing a full terminal-surface redraw. Optional
placement fields default to zero as declared by the OpenAPI schema. The
runtime diagnostics expose `pixel_frames_accepted` and `pixel_frame_errors`.

The authorized physical host was then exercised through its network API with
a disposable external surface and a TCC-built remote WebSocket probe. It
accepted 60/60 RGBA frames from a 60 Hz producer with zero pixel-frame errors,
reported `frame_rate_hz: 59.980`, `last_frame_gap_ms: 17.042`,
`last_render_ms: 16.701`, and `missed_deadlines: 0` at the host's active
59.990 Hz mode. The probe also verified 60 graphics texture uploads. The
temporary session was deleted with HTTP 204 and the host returned to zero
sessions and zero surfaces. This is physical one-output evidence; a physical
multi-monitor and 120/240 Hz result remains open.

### Current 0.1.250 source/package evidence

The exact TCC-built 0.1.250 binary preserves the 0.1.249 terminal and KMS
gates. It adds independent evdev gamepad discovery and a versioned input-route
value, `evdev-gamepad`. The QEMU/VKMS input fixture passed
`BLIT_INPUT_GAMEPAD_PASS`: a synthetic gamepad was discovered, routed to the
selected session, and delivered timestamped axis and button events on the
input stream. Gamepad loss was also reported through the existing diagnostic
event path. No keyboard escape-sequence mapping was invented.

The exact 0.1.250 dummy gates passed `terminal conformance: PASS` and
`FRAME_RATE_PASS`; the direct-KMS capture passed `PPM_DISPLAY_47_WIDE_KITTY_PASS`,
`PPM_DISPLAY_48_PASS`, `KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`.
The package is `blit_0.1.250-1_amd64.deb`; the handoff records its final SHA-256
outside the package because the ledger itself is packaged. This candidate still
does not claim the future high-rate pixel canvas for
graphical emulators; that remains the Milestone 5b implementation.

### Current 0.1.249 source/package evidence

The exact TCC-built 0.1.249 binary and Blit Hibr entrypoint pass the stock
Hibr QEMU acceptance path. The fix loads Blit's `console-blit` provider in
the API-launched Hibr child itself; relying on `HIBR_RC` was invalid because
non-interactive children do not consume it. The two-output fixture passed
`LAYOUT_MATRIX_PASS`, started one primary and one unchanged stock `--join`
desktop, exposed both Hibr control displays, and finished with
`ACCEPTANCE_PASS`. The primary reached surface revision 152 and the join
surface revision 10. Hibr source remained unchanged.

The launcher now defaults Hibr's `DT_TERMMS` to zero unless explicitly
overridden, removing Hibr's 70 ms program-redraw throttle while leaving
Blit's refresh-aware scheduler authoritative. The exact 0.1.249 dummy frame
gate measured 43.989 Hz over a 500 ms window. The full 0.1.249 two-output
orchestration variant also passed
`HIBR_PANE_MATRIX_PASS`: four Hibr clients ran across a Blit-owned 2×2 pane
layout, the primary desktop supervisor restarted successfully, and an
auxiliary `--join` client was killed and reconnected on a new pane. The final
topology contained five attached surfaces. The package is
`blit_0.1.249-1_amd64.deb`; the final artifact hash is recorded with the
release handoff because this ledger is included inside the package itself.

The exact 0.1.249 input/render QEMU soak passed
`LAYOUT_MATRIX_PASS`, `BLIT_INPUT_MULTI_MOUSE_PASS`,
`BLIT_INPUT_STREAM_PASS`, and `BLIT_INPUT_RENDER_SOAK_PASS`. It exercised
multiple mice, keyboard and pointer routing, all three buttons, releases,
wheel input, PTY delivery, and synthetic device-loss handling.

The exact 0.1.249 direct-KMS/VKMS capture fixture, staged with the new
TCC-built helper set, passed `REFRESH_SCHEDULER_MIXED_PASS`,
`PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`. The staging helper now
builds `pty-input-echo`, `http-put`, and `ppm-assert` from the repository on
each run, preventing incomplete historical initroots from invalidating the
visual result.

The exact 0.1.249 four-output VKMS fixture also passed `KMS_FOUR_HIBR_PASS`:
four independent 60 Hz outputs presented simultaneously with one primary Hibr
desktop and three unchanged stock `--join` clients. Hibr source remained
unchanged.

The exact 0.1.249 direct-KMS graphics fixtures also passed sixel pixel
rendering (`PPM_DISPLAY_47_SIXEL_PASS`, `KMS_CAPTURE_PASS`) and Kitty
z-order/clipping (`PPM_DISPLAY_47_WIDE_STACK_CLIP_PASS`, `KMS_CAPTURE_PASS`).

### Current 0.1.248 source/package evidence

The 0.1.248 provider-bootstrap correction was superseded by 0.1.249 after
the Hibr redraw-throttle fix above.

### Current 0.1.247 source/package evidence

The exact TCC-built 0.1.247 binary passes the focused font fallback gate,
the expanded 441-glyph Hibr manifest gate, and the complete terminal
conformance suite. The fallback gate proves that a valid but unmapped scalar
outside the PSF range selects the visible `?` glyph rather than blank PSF
glyph zero. The manifest now covers Hibr's Arabic source characters and the
242 presentation forms emitted by its `uni` shaping table. The package is
`blit_0.1.247-1_amd64.deb`, SHA-256
`2b19daa4d8efb91dcf827ccff3e9851005cd702a005fac7bcb5d3516b828c9e0`.
With the expanded bundled font selected, the dummy refresh gate measured
43.975 Hz during its bounded workload and the SDL graphics-cache gate passed
with five cache hits and no additional texture uploads.
The physical host has not yet been upgraded to 0.1.247; its accepted runtime
evidence remains explicitly recorded below for 0.1.245.

The exact 0.1.247 TCC binary and bundled font were then staged into the VKMS
QEMU capture fixture. It reported `server_version:0.1.247`, two ready DRM
outputs, `PPM_DISPLAY_47_WIDE_KITTY_PASS`, `PPM_DISPLAY_48_PASS`,
`KMS_API_SCREENSHOT_PASS`, and `KMS_CAPTURE_PASS`. This is new QEMU/KMS
evidence only; it does not upgrade or replace the physical-host evidence.
The same exact 0.1.247 binary passed the single-vCPU synthetic input/render
soak with `LAYOUT_MATRIX_PASS`, `BLIT_INPUT_MULTI_MOUSE_PASS`,
`BLIT_INPUT_STREAM_PASS`, and `BLIT_INPUT_RENDER_SOAK_PASS`; the fixture
exercised two mice, all three buttons, releases while buttons remained held,
wheel input, PTY routing, and device-loss diagnostics.

### Current 0.1.245 QEMU/KMS evidence

The exact TCC-built 0.1.245 binary and regenerated runtime font were staged
into the rebuilt VKMS kernel
fixture and passed the two-output capture gate with independent 1024×768
outputs, wide UTF-8 glyphs, Kitty pixels, API BMP capture, graphics inventory,
refresh-aware scheduling, and `KMS_CAPTURE_PASS`. The same binary passed the
following variants without modifying Hibr:

- `REFRESH_SCHEDULER_MIXED_PASS` for independent 60 Hz and 120 Hz schedules.
- `OUTPUT_LOSS_PASS` with the surviving output continuing to present.
- `PPM_DISPLAY_47_WIDE_STACK_CLIP_PASS` for Kitty z-order and clipping.
- `PPM_DISPLAY_47_SIXEL_PASS` for sixel pixel rendering.
- The exact 0.1.245 binary also passed the two-output input/render soak:
  `LAYOUT_MATRIX_PASS`, `BLIT_INPUT_MULTI_MOUSE_PASS`,
  `BLIT_INPUT_STREAM_PASS`, and `BLIT_INPUT_RENDER_SOAK_PASS`.
- A current-version 30-second four-PTY soak passed 364 API snapshots, 34
  revisioned resizes, clean session teardown, advancing frames, no runtime
  errors, and 66,312 KiB peak RSS under the 131,072 KiB limit.
- The SDL graphics-cache gate passed with one initial image upload and five
  cache hits during later terminal damage, with no additional upload.
- `KMS_FOUR_HIBR_PASS` with four presenting VKMS outputs, one primary Hibr
  desktop, three unchanged stock `--join` clients, and four running Hibr
  surfaces. Hibr source remained unchanged.

The QEMU VKMS kernel was rebuilt from the repository's existing Linux VKMS
source/build tree because the prior `bzImage` artifact was missing. The
The authorized physical host accepted package `0.1.245-1` and reports
`server_version:0.1.245`, one 1920×2160 output at 59.99 Hz, SDL/OpenGL
readiness, zero missed deadlines, and no diagnostics errors. A fresh Hibr
desktop capture remains clean and the session advertises Kitty and sixel
capabilities. The expanded 148-glyph font is loaded in the runtime. A
controlled two-surface renderer probe sustained 59.943 Hz with zero missed
deadlines and 15.504 ms last render time against the 16 ms target. After probe
cleanup, Hibr remained the sole active session. Hibr source was not changed.
- The previous fully validated source build is `0.1.222`, which includes the
  Hibr-compatible Unicode 15.1 width table and regression vectors for
  variation selectors and zero-width joiners.
- The current TCC source build and turnkey package are `0.1.240`; the complete
  terminal conformance suite passes with the canonical 16x16 Terminus font.
  The package defaults the Blit service to a UTF-8 locale for Hibr's Unicode
  desktop output.
- The runtime font is a checked-in PSF2 merge of the bundled Terminus font and
  the missing Hibr Unicode desktop glyphs. Its required glyph manifest is
  validated by `tools/build-hibr-font.py` before packaging.
- The exact 0.1.232 TCC binary passed the two-output VKMS/KMS capture gate and
  the Hibr pane matrix with one primary plus three `--join` clients. The same
  staged fixture reports the merged font, two ready DRM outputs, refresh-aware
  16 ms scheduling, and `KMS_CAPTURE_PASS`/`HIBR_PANE_MATRIX_PASS`.
- The exact 0.1.232 TCC build passes the fragmented-UTF-8 vector and a
  controlled Hibr API launch with zero visible question-mark cells. The parser
  retains valid UTF-8 prefixes across PTY reads instead of replacing them.
- The version identity gate also passes when the host contains an older
  installed Blit package: a freshly built 0.1.232 binary reports 0.1.232
  through both version endpoints. Runtime identity comes from the compiled
  binary, not from stale host documentation metadata.
- The Debian artifact built from the current implementation is
  `blit_0.1.232-1_amd64.deb`, SHA-256
  `e6b4e85c56d4761560dd9cd4f7afd8f62fdda564bae3d9c20c004b1b0909c59b`.
- The exact 0.1.232 update supervisor passed cancellation and idle-timeout
  gates. The package installs through real `dpkg --unpack` and `dpkg
  --configure` on the local VM. The authorized physical host accepted the
  package through the API, restarted, and reports 0.1.232 ready with no
  runtime errors.
- The exact 0.1.232 TCC gateway also passed the lifecycle, shutdown,
  fragmented/back-pressured HTTP, authenticated-network, and authenticated
  update-cancellation gates. Session deletion completed in 128 ms with
  responsive diagnostics; unauthenticated requests returned 401, authorized
  requests returned 200, and unauthorized command creation returned 403.
- The exact 0.1.232 TCC build passed the 120-second terminal soak with four
  concurrent PTYs, sustained VT/UTF-8 output, 1,460 API snapshots, 133
  revisioned resizes, no runtime errors, no leaked sessions, and 65,996 KiB
  peak RSS. The reusable gate is
  `tools/tests/terminal_soak_gate.rb`.
- The same exact build additionally passed a 600-second run of that gate with
  four concurrent PTYs, 7,296 API snapshots, 664 revisioned resizes, no
  runtime errors, no leaked sessions, and 65,996 KiB peak RSS under the
  enforced 131,072 KiB RSS ceiling.
- The same exact build additionally passed a 1,800-second run with four
  concurrent PTYs, 21,888 API snapshots, 1,990 revisioned resizes, no runtime
  errors, no leaked sessions, and 66,120 KiB peak RSS under that same ceiling.
- The same exact 0.1.232 TCC build additionally passed a 3,600-second run
  with four concurrent PTYs, 43,800 API snapshots, 3,982 revisioned resizes,
  no runtime errors, no leaked sessions, and 66,112 KiB peak RSS under the
  enforced 131,072 KiB RSS ceiling.
- The same exact 0.1.232 TCC build additionally passed a 7,200-second run
  with four concurrent PTYs, 87,576 API snapshots, 7,962 revisioned resizes,
  no runtime errors, no leaked sessions, and 66,104 KiB peak RSS under the
  enforced 131,072 KiB RSS ceiling. The server exited cleanly after the gate.
- The exact 0.1.232 TCC QEMU input fixture additionally passed its combined
  render/input soak: two KMS outputs continued presenting while the existing
  keyboard, two mice, three buttons, wheel, pointer routes, and WebSocket
  input stream were exercised during approximately ten seconds of bounded
  UTF-8/VT output. It produced both `BLIT_INPUT_STREAM_PASS` and
  `BLIT_INPUT_RENDER_SOAK_PASS`.
- The exact 0.1.232 TCC stream replay gate passed disconnect/reconnect,
  bounded-history gap signaling, replayed terminal output, and the documented
  HTTP surface snapshot repair path: `STREAM_REPLAY_PASS gap=1
  terminal_output=1 snapshot_repair=1 frames=66`.
- The exact 0.1.232 TCC session fault gate passed active PTY termination during
  output and six revision-checked resizes: `SESSION_WRITE_RESIZE_PASS
  writes=1 resizes=6 delete=1 sessions=0`.
- The exact 0.1.232 TCC QEMU input-loss fixture passed deterministic evdev
  fault/reconnect coverage with two KMS outputs: it emitted typed
  `input_device_lost` diagnostics, retained enabled surviving input routes and
  ready diagnostics, and produced `BLIT_INPUT_STREAM_PASS` plus
  `BLIT_INPUT_DEVICE_LOSS_PASS` before powering down cleanly.
- The exact 0.1.232 TCC build passed the two-output KMS pixel/screenshot gate,
  the four-layout Hibr pane matrix with four running sessions, and the
  one-vCPU input fixture. The input fixture passed keypad bytes, independent
  multi-mouse routing, three-button presses/releases, wheel, motion,
  WebSocket stream delivery, and device-loss diagnostics.
- The exact 0.1.232 TCC build also passed the four-output KMS boundary fixture:
  four independent VKMS outputs were discovered and presenting, one terminal
  session was attached to each, and the API reported four displays, outputs,
  sessions, and no diagnostics errors.
- The same four-output fixture additionally passed the Hibr orchestration
  variant: one primary Hibr desktop plus three `--join` clients produced four
  running Hibr-backed surfaces across four presenting outputs, with no API
  diagnostics errors (`KMS_FOUR_HIBR_PASS`). Hibr source was unchanged.
- The exact 0.1.232 TCC build passed the mixed-refresh fixture with independent
  60 Hz/16 ms and 120 Hz/8 ms output schedules. It also passed the output-loss
  fixture: a failed connector was reported as `display_presentation_failed`,
  the surviving connector continued presenting, and its API/PPM capture
  remained valid.
- SDL pointer-only presentation now reuses a per-output scene cache instead of
  forcing a full terminal rasterization on every pointer motion. Runtime
  diagnostics expose pointer-cache hits and misses.
- `POST /v1/control/update/cancel` now cancels a stalled authenticated upload,
  and update status exposes active/received/expected byte counts.
- The package allowlist rejects runtime shell launchers and Hibr startup
  wrappers.
- Hibr source and files were not modified.
- A Debian `0.1.240-1` package built from the current TCC binary and source
  commit `353e051` passed the package allowlist audit. Its SHA-256 is
  `99d22f41935d75abe15bc7bd3fa5d583fd6a73747d937e2f311e20ba16ddeb26`.

### Current 0.1.240 VKMS evidence

The exact TCC 0.1.240 binary staged with the current Hibr runtime passed the
following current QEMU fixtures:

- Two-output direct-KMS capture: two independent 1024×768/60 Hz outputs,
  distinct PPM captures, Kitty pixel assertions, and the API screenshot gate.
- Four-output boundary: four independent outputs at x=0, 1024, 2048, and
  3072, with one running terminal surface per output.
- Mixed refresh: independent 60 Hz/16 ms and 120 Hz/8 ms schedules.
- Output loss: connector 47 was marked failed, connector 48 remained
  presenting, the API returned the typed `display_presentation_failed`
  warning, and the surviving PPM/API capture remained valid.
- Hibr four-output orchestration: one primary Hibr desktop plus three
  unchanged stock `desktop --join` clients produced four running Hibr-backed
  surfaces and four presenting KMS outputs (`KMS_FOUR_HIBR_PASS`).
- Current-version input-loss and reconnect: the 0.1.240 input fixture passed
  keypad bytes, independent multi-mouse routing, stream delivery, typed loss
  and reconnect diagnostics, and route re-enablement after reconnect
  (`BLIT_INPUT_DEVICE_LOSS_PASS`). The fixture explicitly holds the
  reconnecting synthetic devices open so the assertion cannot sample after a
  second intentional teardown.
- Current-version Hibr lifecycle: the 0.1.240 pane/restart fixture passed
  primary supervisor restart, auxiliary `desktop --join` termination and
  reconnection, and the final five-surface topology
  (`HIBR_PRIMARY_RESTART_PASS`, `HIBR_JOIN_RECONNECT_PASS`, and
  `HIBR_PANE_MATRIX_PASS`).

These are QEMU/VKMS results. They prove the four-output software path, not a
physical four-monitor arrangement.

## Passing automated evidence

- OpenAPI and TCC build checks pass.
- The canonical `tools/build-tcc.sh` injects `packaging/VERSION` into the
  executable; the exact 0.1.232 local conformance run reports
  `server_version:0.1.232` with `api_version:0.1`. The live host now reports
  the same version through its TCP API.
- Terminal grids are allocated per live session rather than embedded in all
  session slots. The exact 0.1.222 TCC build passed the terminal suite and a
  100,000-line PTY soak with no diagnostic errors; peak RSS was 25,156 KiB
  versus 11,256 KiB idle in the comparable local run.
- The exact 0.1.222 Debian package contains the byte-identical TCC server
  binary and passes the package allowlist check.
- The exact 0.1.222 Hibr primary/join QEMU fixture passed two-output KMS
  presentation, the Hibr session path, and both PPM pixel assertions.
- The stalled-upload gate passes: progress is exposed and authenticated
  cancellation returns 202 without stopping the gateway.
- Terminal conformance passes, including UTF-8/wide cells, VT controls,
  full Hibr Unicode 15.1 width semantics for combining marks, joiners, and
  variation selectors,
  alternate screens, colors, fragmented and malformed controls, Kitty image
  placement, ordinary-session graphics isolation, and immediate final PTY
  bytes.
- Direct-KMS/VKMS passes two-output pixel capture, mixed 60/120 Hz scheduling,
  output-loss recovery, Kitty resource limits, Kitty clipping/z-order, and
  sixel pixel rendering.
- The exact 0.1.232 capture fixture independently passed the mixed-refresh
  predicate (`60 Hz/16 ms` and `120 Hz/8 ms`) and output-loss predicate
  (failed connector retained, surviving connector presenting, typed diagnostic,
  and surviving screenshot/API capture).
- The Hibr fixture passes primary plus `--join` sessions, all four logical
  pane layouts, input routes, keyboard, pointer, multi-mouse, and WebSocket
  input checks. Against the current Hibr 0.99.86 runtime, the ABI-16 adapter
  probe, Hibr display-control socket, and dedicated window workload also pass:
  `move`, `resize`, and `focus` succeed across the joined display. The stock
  Hibr session intentionally starts with zero application windows; that empty
  `windows` response is not treated as a renderer failure. The guest produces
  both 1024×768 PPMs, and their top-left probes are dark theme pixels rather
  than a red diagnostic square.
- The corrected two-display Hibr fixture passes in both modes: the stock
  primary/`--join` session accepts an empty application-window list, while the
  explicit `blit.hibr_window_control=1` workload additionally passes window
  `move`, `resize`, and `focus` operations. The acceptance predicate now
  distinguishes those two intentional workloads.
- The exact 0.1.221 TCC build passes the two-output KMS pixel gate, the
  four-pane Hibr matrix, and the input-only fixture with
  `blit.input_wait=8`: keypad, multi-mouse, button, wheel, motion, stream, and
  PTY delivery all pass. The input-loss variant additionally reports
  `input_device_lost` diagnostics, retains the configured routes, and passes
  device-loss/reconnect recovery. Its terminal conformance gate additionally passes
  variation-selector and zero-width-joiner cursor-position vectors, plus the
  Hibr `DT_BIDI`/`HIBR_GFX` defaults and explicit override vectors.
- The exact 0.1.221 Hibr input-loss fixture passes primary/join startup,
  `1x1`/`2x1`/`1x2`/`2x2` pane layouts, route retargeting, device-loss
  diagnostics, device reconnect, and the final Hibr acceptance predicate.
- The exact 0.1.232 TCC Hibr restart fixture, staged with Hibr 0.99.92,
  exercises the unchanged stock `examples/desktop/session.hibr` through the
  repository-owned launcher that preloads Hibr's canonical `console`, `pty`,
  `term`, and `hold` modules. Four stock sessions reach `running`; the gate
  kills the Hibr `[desktop]` process and observes
  `HIBR_PRIMARY_RESTART_PASS`, then kills an auxiliary `--join` client, keeps
  the primary running, attaches a fresh join on the next pane, and observes
  `HIBR_JOIN_RECONNECT_PASS` and `HIBR_PANE_MATRIX_PASS`. Hibr source was not
  modified.
- The same exact TCC/QEMU restart gate also passes the repository's dedicated
  Hibr window-control workload against Hibr 0.99.92: four sessions reach
  `running`, the Hibr `[desktop]` supervisor restores the primary after the
  process is killed, and an auxiliary `--join` client can be replaced on a
  fresh pane. It emits `HIBR_PRIMARY_RESTART_PASS`,
  `HIBR_JOIN_RECONNECT_PASS`, and `HIBR_PANE_MATRIX_PASS`; Hibr source was
  not modified.
- The 0.1.240 runtime diagnostics add an explicit measured presentation-rate
  window to `/v1/diagnostics/runtime`: `frame_rate_hz`,
  `frame_rate_frames`, `frame_rate_window_ms`, and `frame_rate_age_ms`, plus
  event-loop/presentation counters for root-cause diagnosis. The local TCC
  frame-rate gate passes at 44.860 Hz with a 512 ms window while a continuous
  PTY producer is active. Event-loop and `select()` timing counters are also
  exposed to isolate host scheduling stalls.
- The real-host one-frame-per-second defect was traced to the synchronous
  periodic evdev reconnect scan: it blocked the gateway for approximately
  1.0–1.03 seconds. Version 0.1.239 replaces that scan with an inotify-driven
  `/dev/input` watch. On the live host, the continuous PTY workload then
  measured 44.657 Hz, 234 present calls, zero missed deadlines, and a 12.548
  ms maximum loop gap.
- Surface and scrollback snapshots preserve complete zero-width UTF-8 cell
  sequences; a five-extension combining vector and its cursor position pass.
- Revisioned API cell updates accept wide UTF-8 glyphs and zero-width
  extensions, expose continuation width metadata, and pass the public API
  regression vector.

## Real-host evidence

The latest reachable observation of the authorized host at
`192.168.10.54:8080` reported:

- Blit `0.1.240`, healthy SDL3/OpenGL presentation, reached through the
  versioned TCP API.
- One physical output, `DP-1`, active at 1920×2160 and 59.99 Hz.
- A fresh API-created PTY session reached `running`, emitted `BLIT_BASH_OK`,
  and its surface snapshot contained the expected cells; the session was then
  deleted and resources returned to zero. Live diagnostics report one
  `DP-1` output at 1920×2160 and 59.99 Hz, one keyboard, one pointer, no
  errors, and a 16 ms refresh-aware presentation interval.
- The live host currently exposes one physical output. Multi-display behavior
  is therefore proven by the two- and four-output VKMS/QEMU fixtures, not by
  this host.
- The 0.1.232 local Hibr full-grid workload settled a 240×135 surface in
  approximately three seconds; runtime diagnostics measured 100,264 terminal
  bytes and no pending damage afterward. This is local/QEMU-style evidence,
  not a claim about a physical multi-display arrangement, which this host
  currently does not expose.
- After the 0.1.240 input-scan fix, the installed stock Hibr desktop reached
  261 presentation calls in the live-host validation interval, with a 16.459
  ms last frame gap, zero missed deadlines, and a 17.348 ms maximum loop gap. The
  Hibr session and its resources were then deleted cleanly.
- A later live-host query while Blit was idle reported one active 59.99 Hz
  physical output, a 16 ms target interval, 0.034 ms maximum evdev scan,
  0.154 ms maximum SDL event-pump time, and 17.348 ms maximum event-loop gap.
  Its measured frame-rate window was stale because there were no active
  sessions; this is intentionally not interpreted as a live frame-rate
  measurement.
- A fresh active-PTY measurement on the same host reported 46.724 Hz over a
  513 ms window with 12 ms sample age, 24 measured frames, zero missed
  deadlines, a 17.348 ms maximum event-loop gap, and a 0.076 ms maximum
  evdev scan. The session was deleted after sampling and resources returned
  to zero.
- A live-host logical-pane check temporarily changed the single output to a
  2×2 topology, attached four API-created PTYs, and observed four running
  sessions with a healthy runtime and zero missed deadlines. The topology was
  restored to 1×1 and sessions, surfaces, streams, and routes returned to
  zero. This validates logical pane orchestration, not physical multi-monitor
  behavior.
- The live discovery API reports SDL3 readiness, one AMDGPU DRM/KMS card with
  page flipping, direct scanout, and hardware acceleration, three input
  devices (keyboard, pointer, and consumer control), and no audio devices.
  The absence of audio is an observed host capability, not a missing API
  response; `/v1/audio` returns an empty device list.

- Version 0.1.285 adds per-output graphics-upload timing and a per-output
  pending pixel-frame scheduler. The physical host accepted a sustained 120
  frame API stream at 59.568 Hz and produced 125 presentation passes, drained
  `pixel_frames_pending` to zero, and reported a 0.398 ms maximum texture
  upload. The same host's refresh gate measured 61.507 Hz with zero missed
  deadlines; test sessions and streams returned to zero.
- The physical Hibr smoke test initially exited with status 1 because an
  existing held Hibr desktop was already running. Using Hibr's documented
  `--resume --session blit-279-shot --name display-1` invocation reached a
  running session with surface revision 309 and 279,575 terminal bytes. Blit
  and Hibr were both left clean after the session was deleted; Hibr source was
  not modified.
- The deployed 0.1.286 package was verified through the live API after the
  supervised restart. The active-PTY frame gate measured 59.991 Hz at the
  display-mode cadence with zero missed deadlines; the 120-frame pixel gate
  accepted 120 frames at 59.514 Hz and rendered 121 presentation passes. A
  real Hibr `--resume` session reached `running`, emitted 52,186 terminal
  bytes, measured 59.973 Hz with zero missed deadlines, and was deleted cleanly.
  Live resources returned to zero afterward. The host still exposes one
  physical output.
- Exact-current 0.1.285 QEMU fixtures pass the API pixel/KMS capture gate,
  Hibr four-pane primary/join matrix, keyboard/multi-mouse/gamepad input
  matrix, and 240 Hz scheduler gate. These remain virtual-display evidence;
  the physical host still exposes only one output.
- Exact-current 0.1.286 TCC binaries pass the complete terminal conformance
  suite, Hibr font manifest and SDL glyph-shape gates, local 54.367 Hz
  refresh gate with zero missed deadlines, 120-frame pixel gate at 59.502 Hz,
  graphics-cache reuse, and the four-output VKMS fixture. The four-output
  fixture reports four independently presented 1024×768@240 outputs with
  contiguous placements and four terminal sessions. The direct-KMS cadence
  fix avoids replaying a 60 Hz producer at every 240 Hz slot. These are still
  virtual-display results; the physical multi-monitor gate remains open.
- The strengthened exact-current four-output fixture additionally placed
  distinct red, green, blue, and yellow overlays on the four discovered
  outputs and passed
  `FOUR_OUTPUT_INDEPENDENT_PIXEL_PASS` through four API screenshot captures.
  The same binary passed the two-output KMS capture/pixel gate, Hibr pane
  matrix, keyboard/multi-mouse/gamepad input matrix, and 240 Hz scheduler
  fixture after restaging.
- The remaining exact-current local regression gates are also green:
  wallpaper background batching, hidden-cursor damage suppression, screenshot
  overlay removal, session lifecycle escalation, write/resize cleanup, stream
  replay repair, HTTP backpressure, fragmented HTTP requests, authenticated
  network access, clean shutdown, update cancellation, and updater idle
  timeout. No active local test resources remained after the pass.
- The exact-current 240 Hz producer-driven pixel workload exposes an open
  high-refresh limitation: all 240 frames are accepted with zero pixel-frame
  protocol errors, but the synchronized direct-KMS VKMS run presents only
  89 frames and records 20 additional virtual page-flip deadline misses.
  Diagnostic async page flips and multi-threaded QEMU TCG produce the same
  result (86 and 82 presentations respectively). This is not treated as a
  passing 240 Hz gaming/emulation result; hardware/KVM-backed validation or a
  runtime fix is still required.
- An SDL3 isolation run at the same 240-frame producer cadence accepted all
  240 frames at 227.154 Hz with zero protocol errors and reused the graphics
  image. The dummy renderer presented 183 frames at its own virtual cadence;
  this separates network/graphics ingestion from the unresolved direct-KMS
  page-flip limitation and is not physical 240 Hz evidence.
- The new intermediate 120 Hz producer fixture also accepted all 120 frames
  with zero protocol errors, but the two-vCPU VKMS run increased page-flip
  misses from 3 to 15 and failed the strict cadence gate. This is diagnostic
  TCG/VKMS evidence, not a claim that 120 Hz hardware is unsupported.

## Open release gates

1. Validate at least one physical multi-monitor arrangement, including
   connector discovery, independent presentation, pointer routing, and Hibr
   primary/join behavior. The executable
   `BLIT_GATE_SERVER=http://192.168.10.54:8080 tools/tests/physical_multi_display_gate.rb`
   is ready for this check; the current host exposes only one physical output
   and returned exit status 77 in the latest run.
2. Validate the producer-driven 240 Hz pixel path on hardware or a
   KVM-backed VKMS guest. The current host is 60 Hz and the available QEMU
   TCG guest cannot sustain the 240 Hz page-flip workload without additional
   deadline misses; the failing result is recorded above.

All software-side Gate 6 cases currently in scope—including primary supervisor
restart, joined-client reconnect, session termination during writes/resizes,
stream reconnect/replay, input-device loss, output loss, and the two-hour PTY
soak—have authoritative evidence above. Until the physical-monitor gate has
authoritative evidence, the project must not be
described as fully released or physically multi-monitor validated.
# Current 0.1.367 diagnostics-instrumentation result

The exact TCC-built 0.1.367 binary exposes producer-side
`surface_commits` and `frame_commits` in `/v1/diagnostics/runtime`; both fields
are required by `openapi/blit-0.1.yaml`. The local frame-rate workload passed at
54.381 Hz with a 16 ms target and zero missed deadlines, and the deployed live
workload passed at 63.000 Hz with zero missed deadlines.

The exact 0.1.367 package was deployed to `192.168.10.54` and
`/v1/version` reported 0.1.367. The four-output Hibr QEMU fixture passed
`KMS_FOUR_HIBR_PASS` with the 6.19.14 VKMS kernel when booted with
`vkms.create_default_dev=0`; omitting that argument selects VKMS's default
single-output card and is now diagnosed explicitly by the fixture.

The physical visual and physical evdev gates remain open. A live capture
recorded a 60 Hz display, zero missed deadlines, and zero physical evdev mouse
events; API-injected pointer motions were accepted and traced. Therefore this
release does not claim physical mouse or visual acceptance.

# Current 0.1.382 live and QEMU result

The exact TCC-built 0.1.382 binary passed the terminal conformance suite,
package artifact gate, QEMU input/render soak, and four-output Hibr fixture.
The four-output fixture reported four independently presented 1024x768@240
outputs with a 4.166 ms target interval and no diagnostic errors.

The package was supervised-updated on `192.168.10.54`; `/v1/version` reports
0.1.382. Starting Hibr through the packaged
`/usr/share/blit/hibr/blit-session.hibr` entrypoint produced a 240x135
terminal surface and one complete 1920x2160 graphics image. A free topology
pane no longer swallows input: API motion and both button edges reached the
active session and were recorded in the trace with `target_session=1`.

The live evidence bundle is
`diagnostics/live-0.1.382-experience-20261009T031158Z`. Its screenshot shows
the correctly aligned wallpaper and desktop, plus a reproducible stray
`0`/block at the left edge. The timing capture measured damage-driven presents,
not continuous vblank: 32 presents in about 10 seconds, zero missed deadlines,
and individual presents within the 60 Hz budget. This is an observed cadence
warning, not proof of a 3 Hz display; the scheduler currently presents on
damage and input. Physical evdev activity, physical multi-monitor behavior,
and hardware high-refresh gaming remain open gates.

The API pointer artifact capture at
`diagnostics/live-0.1.382-pointer-20261009T031414Z` produced four framebuffer
captures. After the intentional first screenshot initialization, each adjacent
capture differed in only the cursor region (92 pixels) and had zero changed
pixels outside the old/new cursor bounds. The render trace also recorded the
`pointer-cache` path. This proves API pointer motion does not leave trails in
the live SDL scene; it does not yet prove physical evdev motion on the host.

# Current 0.1.383 live routing result

The 0.1.383 deployment retained the graphics and input behavior while making
routing diagnostics explicit. On the live host, the packaged Hibr entrypoint
produced one complete 1920x2160 graphics image, and API motion plus both button
edges reached session 1 with `routing=display-fallback`. This is the expected
route for a primary display-attached session with no pane ID.

## 0.1.449: the graphics boundary is Hibr's side, measured

Issue #19 asked whether the live desktop presents no bitmap because Hibr never
sends one or because Blit decodes one and discards it. Before 0.1.449 that
question could not be answered from Blit's evidence: both leave a session with
zero images, no errors and a healthy document. It can be now.

Measured on 192.168.10.54 running 0.1.449, with the packaged
`blit-session.hibr` desktop launched through the API, owner registered, 32,400
printable cells at 240x135, revision 860:

```
performance.graphics_payloads            0
performance.graphics_payloads_kitty      0
performance.graphics_payloads_sixel      0
performance.graphics_payloads_rejected   0
performance.graphics_texture_uploads     0
performance.graphics_cache_hits          0
performance.pixel_frames_accepted        0
surface-1.graphics_images                0
performance.terminal_bytes           33454
trace?kind=graphics_payload              0 events
```

Three independent arrival paths, all zero: no graphics escape sequence reached
the terminal parser, no API pixel frame arrived, and nothing was rejected.
33,454 bytes of terminal output did arrive. The desktop is complete and
correct **cell art** -- the captured 1920x2160 framebuffer holds **9 distinct
colours**, dominated by `#0d1b2a` over 4,030,905 pixels:

```
#0d1b2a 4030905   #16324a 64208   #1b3a5c 29730   #000000 16324
#101820    3775   #cbd5e0  1438   #63b3ed   640   #4a5568   154
#ffffff      26
```

The instrument was proven live in the same process rather than assumed: a
probe session on the same host emitting one sixel moved `graphics_payloads`
from 0 to 1 and produced

```
protocol=sixel session=session-2 bytes=21 header=DCS0;0;0q
  images=0->1 rejected=0 reason=-
```

So a zero beside the desktop is a measurement, not a dead counter. The
boundary is on Hibr's side: the desktop emits no image by any route Blit can
receive one. Blit's graphics decoders are not implicated, and the sixel and
Kitty gaps fixed in 0.1.446 through 0.1.448 were real but are not the cause of
this symptom.

## 0.1.450: the update restart race, measured on both sides of its own fix

Issue #63. Two mechanisms restarted the service after a package install and
neither knew about the other, so systemd's one `SIGTERM` was consumed by a
process that then re-exec'd. The unit waited out `TimeoutStopSec` and
`SIGKILL`ed its whole cgroup, taking an attached Hibr desktop with it 90
seconds after the deployment reported success.

The 0.1.450 package was deployed to 192.168.10.54 twice. The first deployment
is performed by the running 0.1.449, which still carries the race; the second
by the fixed 0.1.450.

Before -- 04:55:17 to 04:56:48, 91 seconds:

```
04:55:17 systemd[1]: Stopping blit.service ...
04:55:17 blit[14469]: blit gateway listening ...        <- the same pid, re-exec'd
04:56:48 (TimeoutStopSec expires, SIGKILL, unit restarted)
```

After -- 04:57:30 to 04:57:30, under one second:

```
04:57:30 systemd[1]: Stopping blit.service ...
04:57:30 blit[14788]: blit: package installed; exiting for the unit restart
04:57:30 systemd[1]: blit.service: Main process exited, code=exited, status=1/FAILURE
04:57:30 systemd[1]: blit.service: Stopped blit.service ...
04:57:30 systemd[1]: blit.service: Started blit.service ...
04:57:30 blit[15012]: blit gateway listening ...
```

No `stop-sigterm` timeout, no `SIGKILL`, no child killed, and one `listening`
line from one pid instead of two. Two `listening` lines from one pid is the
signature of the old behaviour.

The non-zero exit is deliberate -- `Restart=on-failure` must remain a safety
net if the helper dies before it reaches `systemctl`, because the package must
never be installed with the service down -- and its cost was measured rather
than assumed, since the ticket itself objected to a permanently noisy unit
result. It is not sticky:

```
systemctl is-active blit   -> active
systemctl is-failed blit   -> active
Result=success  NRestarts=0  ActiveState=active  SubState=running
```

The whole trace is one journal line, immediately preceded by Blit's own
`package installed; exiting for the unit restart`.

A desktop launched right after the clean deployment reached 32,400 printable
cells at revision 859 and was sampled 30 times over five minutes: zero uptime
resets, one session throughout, `errors` and `warnings` empty every time.

How this was found is part of the evidence. The host has no SSH, so the
journal came back through the API: a terminal session running `journalctl`
with a 200x60 surface, read off `GET /v1/surfaces/{id}/cells`. Blit's own
in-process log ring cannot answer a question about why the previous process
ended, because it died with it -- all it could say was that uptime was 5.7
minutes and there were no sessions. A 20-minute watch of the clean process
(118 readable samples, zero uptime resets, one session throughout) is what
established that the kill was a deployment race and not a crash, and so what
to fix.

## 0.1.451 and 0.1.452: a device setting survives a release

Epic #64 stage 1 (#65), ADR 0067. Until these releases a device's
configuration lived only in memory, so every supervised update returned every
pointer speed, keyboard layout and default audio device to its default. This
is the first measurement on this host of one surviving.

Measured on 192.168.10.54:

```
PATCH /v1/input/devices/input-0003-25a7-0124-...-input3
  -> sensitivity_percent 215, natural_scroll true
PATCH /v1/audio/audio-device-pcm0-p
  -> default true

/var/lib/blit/settings.json   -rw-r----- 1 root root 191
{"version":1,"input_devices":{"input-0003-25a7-0124-usb-0000-e6-00.4-1.1.4-input3":
 {"sensitivity_percent":215,"natural_scroll":true}},
 "audio_devices":{"audio-device-pcm0-p":{"default":true}}}

supervised update to 0.1.452  -> both still applied
POST /v1/control/restart      -> both still applied, settings revision 1
```

Only what differs from a default is written, and only against ids derived from
what a device reports about itself. The document's own revision is stored with
it, which 0.1.452 added after reading the live host and finding the revision
back at 0 in the fresh process: it is the `If-Match` a controller writes the
whole document against, and a counter that restarts at zero would let a stale
write match by accident. Measured both ways afterwards -- a document written
by 0.1.451 carries no revision and loads as 0, which is the right answer for
an older document, and a write then records 1 that the restart reads back.

The deployments themselves were clean, which is issue #63 holding across three
releases now: stop, exit and start inside one second, one `listening` line per
process, no `stop-sigterm` timeout and no `SIGKILL` of the unit's children.

**An honest gap in the same window.** The first desktop launch after the
0.1.452 deployment did not take. Blit created session 1, logged
`hibr_resize_discovery session=1 attempt=1 matches=1` and then `matches=0` for
attempts 2 through 4, and retired the surface -- while Hibr's own
`[attached: blit-0-1-452]` and `[hold: blit-0-1-452]` processes stayed alive as
orphans, which were killed by hand afterwards. A second launch under a
different session name reached 32,400 printable cells at revision 860 in about
ten seconds and stayed healthy with `errors` and `warnings` both empty. That is
the fail-closed `hibr_attach_unresolved` shape; it is recorded on issue #32
rather than explained here, because neither release touched the attach path and
one occurrence is not a diagnosis.

## 0.1.453: a keyboard's repeat is the kernel's, and Blit owns it

Epic #64 stage 2 (#66). Two facts were measured on 192.168.10.54 before any of
the implementation was written, because they decided its shape.

`EVIOCGREP` and `EVIOCSREP` both work on the `O_RDONLY` descriptor the opener
thread already holds:

```
/dev/input/event4 O_RDONLY GET=(250, 33) SET=ok
/dev/input/event8 O_RDONLY GET=(250, 33) SET=ok
```

So owning the repeat rate needed no change to how an input device is opened.
The LED is the other half and does need a writable descriptor, so that was
measured too, with the lamp restored:

```
/dev/input/event4 numlock before=0 set->1 (write ok) now=1 restored=write ok now=0
```

The repeat round-trip on four real keyboards, with the quantisation measured
rather than asserted:

```
keyboards reporting EV_REP: 4 of 28 devices

set delay=400 rate=20  ->  kernel delay=400 period= 50 rate=20
set delay=250 rate= 7  ->  kernel delay=250 period=142 rate= 7
set delay=180 rate=30  ->  kernel delay=180 period= 33 rate=30

a device without EV_REP   ->  422 device_property_not_applicable
stored                    ->  {"repeat_delay_ms":180,"repeat_rate_hz":30,
                               "caps_lock_boot":false,"num_lock_boot":true}
restored                  ->  delay=250 rate=30
```

7 Hz is 142.857 ms and the kernel keeps 142, which reads back as 7 Hz; 20 Hz
is 50 ms exactly. This is why what Blit reports is the read-back and not the
request, and why `repeat_period_ms` is reported beside the rate.

`tools/probes/host_keyboard_settings.rb` restores every keyboard it touched.

**What the local gate proves and what it cannot.** A fabricated node is a
regular file and fails every ioctl, so `tools/tests/keyboard_settings_gate.rb`
tests a stand-in for the kernel -- the sidecar's `repeat=` line -- and says so
in its header. What it does prove, and the host probe does not, is the
*effect* of the remap and the boot lock states: keys are injected through the
same dispatch a real device uses and the session echoes what reached its PTY,
so a setting that is stored but changes no byte fails. The LED is skipped for
a fabricated node and is only ever measured on the host.

The deployment itself was clean, which is issue #63 holding across a fourth
release, and the desktop came back with 32,400 printable cells at revision 859
with `errors` and `warnings` both empty -- on the first launch, unlike the
0.1.452 window recorded above.

## 0.1.454: the acceleration curve, on real hardware

Epic #64 stage 3 (#67). Pointer travel is the one measurement a gate
environment cannot make: a fabricated evdev node is a regular file, nothing
opens it as a pointer, and `update_evdev_pointer` deliberately publishes
nothing when no pointer is open. Issue #52's gate records the same limitation
about `sensitivity_percent` and sends that measurement here.

Measured on 192.168.10.54, injecting through a real pointer's own
configuration:

```
pointers: 3 of 28 devices
subject:  input-0003-25a7-0124-usb-0000-e6-00.4-1.1.4-input3

flat      delta 20 travels 20.0 at 100%, 40.0 at 200%
adaptive  delta  2 travels  2.0
          delta 11 travels 22.0
          delta 20 travels 60.0

buttons        272 -> button=2, 273 -> button=0 at the dispatch
aliasing map   400 invalid_device_buttons
scroll_step    1 -> 1 report, 3 -> 3 reports
```

The flat numbers are #52's measurement unchanged, re-run under an explicit
`flat` profile: `sensitivity_percent` means exactly what it meant before an
acceleration profile existed, which is what #67 promised about the property it
did not change. The adaptive numbers are the documented curve exactly --
untouched at the floor of 2, doubled at the midpoint of 11, tripled at the
ceiling of 20.

`tools/tests/pointer_curve_gate.c` pins the same curve at its boundaries
without a server, including its sign, its monotonicity, and that it is never
slower than flat.

**A recorded gap.** This host has no gamepad: its one device reporting an
`axes` capability reads as `other`. So `deadzone_percent` and `invert_axes`
are measured only against a fabricated gamepad, and there is no gamepad
injection kind, so even that is an API contract rather than an effect. Their
behaviour on real hardware is untested and is not claimed.

**Middle-button emulation is absent by decision**, recorded as issue #71 with
its design: it needs a deferred press, and so a time-driven obligation in an
event loop that is otherwise entirely event-driven.

One real bug was found while gating this release and fixed in it: a settings
write that was still coalescing could sit in memory indefinitely on a quiet
server, because nothing woke the loop. The `select` wait is now clamped to the
remaining flush window, the same shape the attach reassert already used, and a
write that cannot reach the disk says so once rather than failing in silence.

## 0.1.455: a card's mixer, on real hardware

Epic #64 stage 4 (#68). The ALSA control ioctls are the thing under test here,
and no gate can serve one: a fabricated control node is a regular file, so
`tools/tests/audio_card_gate.rb` reads a stand-in and this is where the real
`SNDRV_CTL_IOCTL_*` round-trip happens.

Measured on 192.168.10.54, all six cards:

```
cards: 6                                    pcms: 12
  Device      6 elements  shares=2  volume=PCM Playback Volume
  Generic    28 elements  shares=4  volume=(none)
  Generic_1  13 elements  shares=2  volume=Master Playback Volume
  RC          3 elements  shares=1  volume=(none)
  QuadCast    8 elements  shares=2  volume=(none)
  Meet        2 elements  shares=1  volume=(none)

the most shared mixer: Generic, 4 PCMs
```

Four PCMs on one mixer is the case the card-owned model exists for, and it is
on this hardware rather than hypothetical. The resolution rule's three
interesting shapes are all real: a card resolving its sole playback volume, a
card where `Master` beats a `PCM Playback Volume` that also exists, and a card
with two candidates and no `Master` that is refused with
`audio_control_ambiguous`.

Both range classes, because the quantisation is only visible on one:

```
Device     PCM Playback Volume  0..255  1 channel
  asked  25% -> [64]       -> reads back 25%
  asked  50% -> [128]      -> reads back 50%
  asked  75% -> [191]      -> reads back 75%

Generic_1  Master Playback Volume  0..87  2 channels
  asked  25% -> [22, 22]   -> reads back 25%
  asked  50% -> [44, 44]   -> reads back 51%
  asked  75% -> [65, 65]   -> reads back 75%
```

A span of 255 holds every percentage; a span of 87 cannot — 88 values against
101 percentages — so 50% comes back as 51%. That is why what Blit reports is
the read-back. Writing the read-back settles rather than drifting, asserted on
both cards.

The probe originally tested only the first resolved card, which measured only
half of that; it exercises every resolved card now. Every value it touches is
restored — `[102]` and `[60, 60]`.

**What is not claimed.** Every control device was accessible, which is the
root profile working. The `audio` group is now in both unit files, but that
the *unprivileged* profile can open `/dev/snd/controlC*` is a group in a unit
file and not a measurement: the gate runs as the developer against fabricated
files and this host runs root. `state.control_accessible` is reported
separately from a PCM's `accessible` so an operator who switches profiles can
see the difference immediately.

Control values are deliberately not persisted — they are the card's own state
and the card keeps them, so storing and re-applying would make Blit fight
`alsactl` for something that already survives a reboot.


## 0.1.456: a display rotates, and what power costs

Epic #64 stage 5 (#69). A display's `configuration` was `{}`, and ADR 0064
recorded that as a decision rather than an omission: selecting a mode resizes
every surface, and a Hibr desktop's cells come from its owner (ADR 0063), so it
needs issue #60's resize protocol first. This stage is the settings that resize
nothing — and the measurements came before the design, which is why the shape
is what it is rather than what the ticket guessed.

Four facts settled the stage, all measured on 192.168.10.54 (kernel 6.12.101,
SDL 3.4.16):

```
/sys/class/drm/card0-DP-1/dpms   mode 444; a root write returns EACCES
/dev/dri/card0                   one open fd, pid 17721 = blit (SDL has master)
/sys/class/backlight             exists, empty
SDL_kmsdrmvideo.c:2201           SDL publishes its master fd per window
```

The first is stronger than the ticket's claim, and in a useful direction: the
`dpms` attribute is read-only **to root**, so sysfs is not an avenue on any
backend — that is the kernel, not SDL holding master. The fourth is the one
that turned the stage from a gap into a feature:
`SDL_PROP_WINDOW_KMSDRM_DRM_FD_NUMBER` is ADR 0067's "cooperation with SDL"
branch, and it exists in the vendored build.

### `capabilities` is derived, and that is the contract

```
mode-report   always
rotation      the SDL path. Blit's own render transform, no DRM master.
brightness    only where a backlight is attributed.
```

`configuration` offers exactly what `capabilities` claims and a PATCH accepts
exactly that. `mode` is still refused, with `invalid_display_property`. This is
ADR 0064's own reasoning applied per property instead of per resource, and
`display_device_api_gate.rb` was rewritten to assert the new rule rather than
deleted: a property offered without the capability, or a capability with
nothing to set, now fails.

### Rotation: the contract is a corner, not an enum

`rotation` is the angle, clockwise, by which Blit rotates the image before
presenting it; at 90 what was drawn at logical (0, 0) appears at the physical
**top-right**. It is stated as a corner because every enum that could stand in
for it disagrees — DRM's `ROTATE_90` is anticlockwise, RandR calls the same
transform "right", SDL's render angle is clockwise.

`bounds` became the *logical* rectangle and `modes` stayed physical, with
`state.physical` beside them. That one choice is why rotation needed no new
plumbing: the cell grid, the pointer hit test and the topology placements all
already work in that space. `xrandr` reports the same split.

Two sites learn about rotation. The scene-to-panel draw, which all three
present paths now share — the pointer-cache fast path presents the cached scene
without rebuilding it, so a rotation applied only in the full-redraw path would
un-rotate itself the moment the pointer moved. And `render_pointer`, which
draws after the scene in panel coordinates, and transforms both its hotspot and
the arrow's own shape.

### What the gates assert, and what they do not

`display_geometry_gate.c` re-implements SDL's draw model — a destination
rectangle rotated clockwise about its own centre — and asserts that a texel
placed by that model lands exactly where `blit_rotate_point` says it does, for
four rotations and five positions each. The two are used by different code (one
presents the scene, the other places the pointer on top of it), and a
disagreement is a cursor that drifts away from where it is clicking, which a
screenshot gate cannot see because the pointer is drawn after the capture it
would be compared against. Teeth: the anticlockwise point transform fails 8
assertions; the output rectangle in place of the scene's fails the footprint at
90 and 270.

`display_settings_gate.rb` is six scenarios, and the one that carries the stage
is the screenshot. A full block is drawn in the first cell, and the ink is
counted in all four corner rectangles at every rotation:

```
  0: 0=128 90=0   180=0   270=0
 90: 0=0   90=128 180=0   270=0
180: 0=0   90=0   180=128 270=0
270: 0=0   90=0   180=0   270=128
```

128 is exactly a cell, 8x16. The diagonal is what a server that stores the
number and presents unrotated cannot produce: with the present reverted, the
ink stays in the 0 corner for all four and six assertions fail. Requiring
*exactly* the cell area rather than most of it matters — a scene texture left
at the renderer's output size scales instead of rotating and yields 120, which
any looser threshold would have accepted.

Five teeth builds, each a working-tree copy with one change reverted:

```
rotation stored, presented unrotated   6 failures, the screenshot scenario
no refusal under a live surface        3 failures
nothing persisted                      3 failures
scene texture at the output's size     2 failures, 120 lit pixels not 128
brightness claimed with no backlight   1 failure
```

### Power is reported and not settable, and that is deliberate

`state.power` carries the connector's DPMS state, read through SDL's published
master fd, and `state.connector` names the connector it was matched to. The
match is **by name** and not by index, because SDL enumerates only the
connectors it drives while the kernel enumerates all eight on this host — so
display 0 is connector 0 only by luck.

`power` is not in `capabilities`, because nothing can set it yet. Shipping the
read first was not caution for its own sake: it is the only way to prove the fd
and the attribution without the write, and the write carries a hazard that is
worth stating before taking it. SDL's `KMSDRM_WaitPageflip` polls with
`timeout = -1`. A display turned off while a flip is outstanding, if the kernel
did not deliver that flip's event, is an unbounded wait on the single thread
that also serves the API — and the API is the only channel to this host. The
remainder of #69 suspends presentation before the write and resumes after it,
and the host test will prove the output quiescent, by `present_calls`, before
turning anything off.

### What is not claimed

- `/sys/class/graphics/fb0/blank` was not tried. fbdev emulation is one device
  for the whole card, so it could not express "turn off this one display" even
  if it worked behind a master. That is a structural argument, not a
  measurement, and it is recorded as one.
- The direct-KMS path has no rotation transform and says so by omitting the
  capability. No reachable machine runs that path — the development container
  is an unprivileged LXC with no `/dev/dri` and `CapEff=0`, the host runs SDL,
  and `vkms` exists on neither — so writing it would be code that stays at
  *implemented* forever. It joins #20/#21's hardware-blocked list instead.
- Whether the unprivileged profile can write
  `/sys/class/backlight/*/brightness` is not measured: the gate uses fabricated
  files and the host has no backlight. Same unmeasured-group caveat as #68's
  control device.
- On a multi-display host, rotating one display changes its width and a stored
  topology placement may stop tiling; re-`PUT /v1/topology`. Both machines here
  have one output, so that is a stated consequence.
- Done-when 2 of #69 asks for a gate for display power on the direct-KMS path.
  That half is unmeetable as written, for the reason above, and is recorded on
  the ticket rather than reinterpreted.

### Host-accepted on 192.168.10.54

`tools/probes/host_display_settings.rb`. The three things no gate can reach:
SDL's published fd really yielding a connector, the rotated present on
`opengles2` rather than SDL's software renderer, and a real Hibr desktop being
handed the rotated grid.

```
display display-1 name=DP-1 bounds=1920x2160 physical=1920x2160 cell=8x16 inset=4
capabilities mode-report,rotation
state power="on" connector="DP-1" backlight=nil
```

The connector was matched **by name** out of eight on this card, through
`SDL_PROP_WINDOW_KMSDRM_DRM_FD_NUMBER`, and its DPMS state read. That is the
whole of what 0.1.456 claims about power, and it is the fact the rest of #69
needs.

The same diagonal as the gate, on a 1920×2160 panel and a real GL renderer:

```
  0: 0=128 90=0   180=0   270=0
 90: 0=0   90=128 180=0   270=0
180: 0=0   90=0   180=128 270=0
270: 0=0   90=0   180=0   270=128
```

A stored rotation applied at boot after an orderly restart — `bounds=2160x1920`,
`configuration={"rotation"=>90}` — and then the desktop:

```
rotated desktop 270x120 printable=32173
upright desktop 240x135 printable=32203
```

270×120 is 2160/8 by 1920/16, which is the rotated grid. Both are 32,400 cells,
which is why the *count* was never the evidence and the dimensions are: a
server that stored the rotation and handed out the unrotated grid would report
the same 32,400. Everything was restored: rotation 0, the stored entry removed,
a fresh upright desktop, `errors=[]` and `warnings=[]`.

### #69 is not closed by this release

Done-when 2 asks for display power on the direct-KMS path with a gate. Its
premise has changed rather than failed: power is reachable **under SDL** on
this host, through the fd above, so it is worth implementing rather than
recording as a gap — which is the opposite of what the ticket expected and
better than it. The write, the presentation suspension it needs, and the
quiescence protocol for testing it safely are the remainder of the stage.

## 0.1.457 through 0.1.460: the screensaver's trail, and what found it

Issue #72, reported from the screen rather than by a gate: the Hibr desktop's
screensaver was leaving a solid trail of itself across the panel.

### The measurement that framed it

The authoritative cell snapshot and the pixels disagreed, which is the whole
finding — the owner was authoring correctly (ADR 0063) and the renderer was
keeping old pixels:

```
GET /v1/surfaces/surface-2/cells   336 cells carry ink, box x 89..112 y 41..54
the panel                          8706 cells painted, box x 0..239 y 0..133
painted but blank in the data      8407
```

A no-op `PUT /v1/topology` forces a full redraw; it dropped the count from 8706
to 333, matching the data, and the trail then rebuilt at about 96 cells a
second. So the full-redraw path was correct and the incremental one was not.

### Three defects

**The incremental path cleared a rectangle and repainted rows** (0.1.457). The
repaint walks `column = 0` to `surface->width` for every damaged row; the clear
covered only the damage rectangle's columns. A blank cell with the default
background draws nothing — `if (background == 0) { ++column; continue; }` — so
any column repainted outside the cleared rectangle kept its old pixels. A
sprite moving diagonally is exactly that case: consecutive positions overlap in
rows, not in columns. Host effect: 8407 stale cells to 2832.

**Damage was cleared for surfaces that were never drawn** (0.1.458). The tail
cleared `damage_valid` for every surface that *targets* an output, which is a
different question from whether it was painted. Four paths in the per-output
loop skip drawing, and each discarded damage that had never reached a pixel.
The renderer now records what it painted and the tail consults that record, so
every skip path is covered by construction.

**Clearing a wide glyph's partner cell marked no damage** (0.1.460).
`terminal_clear_wide_overlap` blanks a neighbouring cell; only the caller's own
target was marked. Marked at the point of clearing rather than asking every
caller to remember a neighbour it did not know it touched.

### What actually found it

Not reading the code. Three theories came from reading it and all three were
wrong. What settled it was shipping the damage rectangle into both traces
(0.1.459) and reading them off the live host:

```
surface_update  damage=93,97,1x1 valid=1  presentation=immediate
render_path     damage=93,97,1x1  path=incremental-damage
```

The owner writes **one cell per request**, immediate, so every write is its own
frame with a 1×1 damage rectangle. Every reproduction built before that wrote
in batches, which is why none of them reproduced anything.

### Host-accepted

Twelve samples over three minutes with the screensaver running, spanning two
full clear-and-redraw cycles:

```
   drawn   painted  stale  missing
 1  2906     2913      7      0
 3    52       58      6      0     <- screensaver cleared the screen
 7  1059     1068      9      0
10  1813     1819      6      0
11   103      109      6      0     <- and again
12   363      369      6      0
```

The residual 5–9 is the race between reading `/cells` and reading the
screenshot; `missing=0` throughout says nothing is under-painted. The number
does not grow, which is the question.

### The gate gap, stated rather than papered over

Four reproductions were built: `deferred_damage_gate.rb`, a 12×8 host probe,
one at the screensaver's exact 240×135 with deferred-commit batches, and one
writing a cell per request as the trace showed. **None failed before the fix
and passed after.** The development container is an unprivileged LXC with no
GPU, so every local run uses SDL's software renderer, and this failure has only
been observed on the host's `opengles2` path.

`deferred_damage_gate.rb` is in the suite and guards the invariant going
forward, and its header says in as many words that it has no teeth and why. A
regression test with teeth needs a gate host with a GPU — #20/#21's territory.
Claiming the suite covers this would be worse than the gap.

`motion_trail_gate.rb` asserts the same property and passes either way: it
writes immediate and its erase-plus-draw fits one chunk. Issue #72's done-when
asked for it to be fixed so it would have caught this; that is recorded as not
achievable here rather than quietly dropped.

## 0.1.460: input robustness across hotplug

Issue #74, and the last of #72. Asked for directly after the feature work was
not making the server usable.

### Two defects, found by asking about the fiftieth cycle rather than the first

**Retiring an absent device only ever happened on a filesystem event.** A
rescan is the only caller of `retire_absent_input_devices`, and inotify is the
only thing that arms a rescan. The flag coalesces, so a hub dropping thirteen
nodes at once produces one scan; if it runs mid-burst it marks the nodes that
still exist as seen, and nothing arms another. Measured: a deleted node's
device stayed `present: true` for 56 seconds and counting. A watch event now
sets a one-second resettle deadline as well, and the select wait is clamped to
it — a hotplug is exactly when the loop has no other reason to wake, which is
ADR 0067's settings-flush shape.

**A probe that learned nothing erased what the device was.** Opening a node
being torn down succeeds while every `EVIOC*` ioctl fails, so `kinds` came back
zero and that zero was written over a known device. Measured: a pointer
demoted to `other` with empty capabilities. A keyboard in that state is never
claimed by the poll loop again even once the hardware returns.

**`input_device_missing` fired only at zero.** On the live host a microphone's
remote-control interface counted as both a keyboard and a pointer, so while a
USB hub had taken the real ones away `/v1/diagnostics` reported `warnings: []`
and the operator had no usable input. It now fires below the peak this process
has seen.

### The first teethed gate of this stretch

`tools/tests/input_hotplug_cycle_gate.rb`, thirty cycles of two fabricated
devices:

```
fixed    3 runs, 3 passes
pre-fix  3 runs, 3 failures, at cycles 15, 0 and 4
```

always as `unplugging left keyboard=false pointer_present=true`.

It does not cover the poll set: a fabricated node is a regular file and is
never opened as a keyboard, so `state.open` stays false. The host was measured
directly instead — 19 descriptors, 2 on event nodes, zero deleted.

### Host-accepted

The hub returned during this release. Blit picked up the full set
unaided — `input_devices: 28`, `keyboards: 4`, `pointers: 3`, every one
`open: true`, which is the pre-incident state.

The new warning, end to end on real hardware:

```
one keyboard disabled   keyboards 3 of peak 4   warnings ['input_device_missing']
re-enabled              keyboards 4 of peak 4   warnings []
```

The two stale probe settings left on the microphone's HID interfaces by
earlier `host_*` probes were cleared with `PUT /v1/settings`, leaving the
document carrying the audio default alone.

## 0.1.461 through 0.1.464: a keyboard stop chord, the trail's real cause, and a retraction

Four releases driven by an operator using the machine rather than by the
ticket list, and one claim withdrawn.

### The retraction, first

0.1.457 and 0.1.458 were recorded above as resolving issue #72. **They did
not.** Each fixed a real defect with a real mechanism, and the symptom
survived both. With a line saver running, the host measured residue climbing
432, 469, 551, 605, 740 and collapsing to 44 when a whole frame landed —
`stale` far exceeding `missing` throughout, which is residue and not sampling.

The clean readings behind the earlier claim were taken while the desktop was
static and during a quieter phase of a different saver. The operator was right
and the instrument was being read wrong.

Four separate measurement faults produced confident wrong answers during this
work, and they are recorded in `tools/probes/host_cell_pixel_agreement.rb` as
the reasons that probe is shaped the way it is:

1. sampling one pixel per cell — reported `painted=0` on a screen a full scan
   saw as 1536 cells, and produced the quoted 2832-stale figure
2. non-atomic sampling — `stale` and `missing` in roughly equal numbers, which
   is the signature of the sampling, not the renderer
3. the software mouse pointer — three stale cells that survived a forced
   redraw, a fresh capture and deleting every surface turned out to be the
   arrow
4. `?cached=1` versus a fresh capture — the cached form shows the panel, a
   fresh one forces a render that repairs the state and hides the fault

### 0.1.461: a chord that stops the server, and a key release that was not a keystroke

**Host-accepted.** The operator used the chord on the physical machine:
*"ctrl-alt-backspace works, I've killed it, looks nice!"*

`GET`/`PUT /v1/control/shutdown-key` programs a chord, defaulting to
Ctrl+Alt+Backspace and enabled. It performs the same orderly stop as
`POST /v1/control/shutdown` and exits 0, so a unit with `Restart=on-failure`
leaves it stopped. `tools/tests/shutdown_key_gate.rb` asserts the ways it
could be useless or dangerous rather than merely absent: a bare Backspace is
inert, near misses are inert, it fires on press and not on release or
autorepeat, every modifier must be held on the keyboard the key came from, it
is programmable, a reprogrammed chord survives a restart, disabling works, and
the exit status is 0.

Persistence repeated stage 1's ordering bug — the default was assigned after
the stored document was applied, so it silently overwrote it. Invisible until
the first restart; the gate caught it.

The same release fixed `console-blit` translating a key *release* into a
keystroke. Blit publishes all three transitions and labels them, verified on
the live stream:

```text
{"kind":"key","code":1,"pressed":true,"repeat":false}    press
{"kind":"key","code":1,"pressed":true,"repeat":true}     autorepeat
{"kind":"key","code":1,"pressed":false,"repeat":false}   release
```

The adapter emitted a key for every one. A single tap of Escape arrived as two
keystrokes, so anything the desktop toggled went on and straight back off, and
whether it landed on depended on how many autorepeats fitted inside the hold.
Autorepeat deliberately still produces a keystroke.

`packaging/HIBR_VERSION` said 0.99.100 while the host ran 0.99.127, and
`build-deb.sh` does not rebuild the adapter — so every release since had
shipped a `console-blit.so` built against headers two dozen point versions
behind the runtime loading it. The ABI was 16 in both, which is why it worked;
nothing was checking. Issue #81 tracks the missing check.

### 0.1.462 and 0.1.463: the scene cache's precondition

**Host-accepted** for the trail: *"The screen looks better"*. The menu bar
flicker reported immediately afterwards is a separate matter — screen and cell
data agree exactly and the menu bar is absent from the cell data, so that is
the desktop owner's behaviour, which the cache had been hiding.

Recorded in full in [ADR 0070](adr/0070-the-scene-cache-needs-a-backend-that-preserves-render-targets.md).

Five reproductions were built for #72 and every one passed — all of them
against SDL's software renderer, where the cache's precondition holds. 0.1.462
added `BLIT_SDL_SCENE_CACHE` so the precondition could be measured on the
hardware where it does not, and the A/B settled it:

```text
cache on     stale 170 of 329 cells drawn; 740 under a busier saver
cache off    stale 0 across six samples, on a harder workload --
             10875 cells drawn and 1015 changing between the bracketing reads
```

0.1.463 made the cache conditional on the `software` renderer. Cost measured
on the same host before choosing the default: 3.3 ms to render, 0.6 ms to
present, against a 16 ms budget, no missed deadlines. After deployment with no
override set, the host reports `renderer = opengles2`,
`render paths = {'full-redraw': 6}` and `pointer_cache_hits = 0`.

### 0.1.464: evdev numbers letters by QWERTY row

**Validated, not host-accepted.** The gate has teeth (55 failures against the
old arithmetic) and the fix is deployed, but the operator has not confirmed
that the keyboard types correctly on the machine; their next report concerned
the menu bar and the mouse. Host acceptance for this release is outstanding
and must not be inferred from the gate. The standing reason this distinction
is kept: the person who can see the screen is not the one running the tests.

Reported as "the keyboard does not type qwerty, g is , and f is d". The
adapter computed a letter as `'a' + code - KEY_A`, which assumes the codes run
alphabetically. evdev numbers keys by position in the QWERTY rows:

```text
KEY_A 30  KEY_S 31  KEY_D 32  KEY_F 33  KEY_G 34
KEY_Q 16  KEY_W 17  KEY_E 18  KEY_Z 44  KEY_M 50
```

F came out as `d`, the reported symptom exactly. Because `KEY_Z` is 44, the
range `KEY_A..KEY_Z` spanned the home row and its punctuation rather than the
alphabet, so q w e r t y u i o p x c v b n m and every punctuation key
produced no character at all. The digits were right by luck.

This survived because the keyboard measurement taken earlier in the session
used a plain terminal session, which goes through Blit's own keycode table and
is correct. A desktop goes through the adapter's — a different path with no
gate at the time.

The mapping is now a table in `src/blit_evdev_char.h`, shared by the adapter
and `tools/tests/evdev_char_gate.c`. The gate asserts all 26 letters rather
than a sample for a specific reason: the old arithmetic was correct for
exactly one letter, `KEY_A`, where the offset is zero, so a spot check would
have passed against it. Teeth: with the arithmetic restored the gate reports
55 failures, including `code 33 gave 'd' (100), wanted 'f'`.

### What this sequence says about the suite

Two faults in four releases were invisible to a green suite for the same
reason: the gate environment is not the deployment environment. The renderer
fault needed a GPU the container does not have (#79); the keyboard fault
needed the adapter's key path, which had no gate until #76/#77 added one.

A passing suite means the behaviour the suite can reach is correct. It is not
a statement about the behaviour it cannot.

## 0.1.466 candidate: Hibr input translation, before host acceptance

Issues #76 and #77 came from one instrumented Hibr primary on the physical
0.1.465 host, not from visual inference. API injection placed the pointer over
the visible Theme control and sent both primary-button edges. Blit's bounded
trace routed them to session 4 and focused that session; the adapter log
accepted both events in Hibr mouse mode 2; the authoritative surface revision
did not change. An injected Linux F10 event followed the same route and was
accepted by the adapter without changing the surface, while Escape advanced
the revision and opened Hibr's menu.

Issue #78 records the provider-state defects found while following that same
frame from Hibr's public console contract to Blit's surface boundary.

The native Hibr console decoder names mouse cells from zero and accepts
`f1` through `f12`. `console-blit` was forwarding Blit's one-based stream
cells unchanged, deriving fallback rows with an 8-pixel divisor despite its
16-pixel cell height, mapping no function keys, swapping normalized middle and
right buttons, and dropping wheel events. Fallback geometry now comes from
the session's authoritative cell pixels, so font scale does not create a
second mismatch. Hibr source was read for its public provider vocabulary and
was not modified.

`tools/tests/adapter_input_gate.sh` feeds the shipped adapter actual WebSocket
frames. The pre-fix source failed 17 checks: four coordinate cases, twelve
function keys, and modified F10. The candidate passes against the exact
package-pinned released Hibr 0.99.191 checkout:

```text
ADAPTER_INPUT_PASS pointer_origin=zero buttons=3 wheel=2 function_keys=12 resolved_text=6
```

Issue #78 extended the audit from input vocabulary to provider semantics.
Against the same released checkout, the provider gate proves pane ownership,
drop/clipping/stack order, watched application output, quiet waits, wide and
combining UTF-8, idempotent shadows, and the absence of steady-state resize
polls. The old `console resizing` implementation issued a synchronous geometry
request after each input wait, directly coupling mouse event rate to API work:

```text
ADAPTER_PROVIDER_PASS pane_ownership=1 watched_wakeup=1 utf8_width=1 resize_poll=0
```

The production adapter and server compile with TCC 0.9.27 against that
checkout. The complete local pre-deployment run on 2026-10-14 reports 69
passed, 0 failed, and four explicit skips: the separately invoked QEMU oracle,
a not-yet-built package artifact, and two physical-live gates. These are still
implementation and local-gate results only. Package reproducibility,
deployment, F10 activation, visible button/wheel interaction, immediate
terminal output, and stable physical rendering remain pending and must be
recorded before #72, #76, #77, or #78 is closed.
## 2026-10-19 candidate551 pointer fence regression

The new scheduler assertion failed against550 because an active terminal quiet
deadline held a due pointer output (`POINTER_FENCE_FAIL`). With551's scheduler,
the pointer uses its existing per-output refresh deadline while the scene
deadline remains intact. KMS's production compositor gate checks64 frames for
each of page-flip and modeset paths (128 total), every framebuffer pixel,
pending scene revision/geometry/graphics/overlay, damage preservation,
64px pointer art and complete commit after release. It passes. SDL's production
software-renderer gate checks12 cursor frames pixel-by-pixel over the committed
scene and confirms a pending overlay appears after release. It passes. The
standalone gates `kms_compose_gate.sh` and `surface_damage_gate.sh` pass.

The final frozen run passes100 gates, skips3 explicit hardware/live gates, and
has0 failures. The120-second four-PTY soak completes11,216 snapshots and1,020
resizes. The skips are the standalone QEMU oracle, physical multi-display
acceptance, and live screenshot backpressure acceptance.

At package build time, physical deployment and the bounded host sweep remain
These gates establish that the old complete scene is preserved while the
cursor moves; they do not claim a measured physical refresh rate, physical
input-to-photon latency, or smooth Hibr window dragging. #101 remains open.

Wallpaper panel inspection on10.54 confirms only the global `retro_car.png`,
`zoom`, `follow`/actual `pixels` settings. No per-display preference has been
changed or falsely reported as persisted. Stable native names already exist;
the native `dt_walldisp` save/restart/load acceptance remains outstanding in
#103.
