# Programs in windows

What to expect when you run a graphical program -- Firefox, a GTK or Qt
application, a Vulkan demo -- on the Hibr desktop. It opens as a Hibr
window through `blit-compositor`, Blit's own Wayland compositor
([ADR 0228](adr/0228-blit-is-the-compositor-for-programs.md)). Who owns
what between the program, the desktop and Blit is
[ADR 0229](adr/0229-programs-and-the-desktop-one-owner-per-concern.md); the
wire is [the API guide's "Program windows"](api.md). This page is the
promise: if what you see differs from it, that is a bug.

## Before you start

- **Install** `blit-compositor` (`sudo apt install blit-compositor`; Hibr
  suggests it). Hibr starts it with the desktop when **Control Panel >
  Windows > Programs in Windows** is on.
- **Use a terminal opened after that.** Hibr gives every terminal it opens
  from then on `WAYLAND_DISPLAY` (`blit-0`), and `DISPLAY` (`:0` or the
  next free one) when Xwayland is installed (below). A terminal opened
  before the switch was turned on does not have them, and cannot be given
  them (a shell's environment is its own): a program run there fails with
  "cannot open display". Open a new terminal.

## Running a program

- Type its name (`firefox`, `vkcube --wsi wayland`, `gnome-calculator`). A
  new Hibr window opens, titled by the program, placed and sized by the
  desktop. The first frame can show at the program's own size for an
  instant before the window's size reaches it.
- The terminal stays the program's parent, as for any command: its warnings
  print there, Ctrl-C ends it, and closing the terminal ends the program.
  Run it as `firefox &` (or from Hibr's menus) to keep the terminal free.

## X11 programs

*Since Blit 0.3.78 with Hibr 0.99.486 (ADR 0228 phase 2, milestone A).*
Programs that speak only X11 (xterm,
Steam, older applications) run under Xwayland, which
`blit-compositor` starts with itself and manages: install `xwayland`
(`blit-compositor` recommends it; 23.1 or later, as Debian 13 has).
Without it, or with an older one, X11 programs fail with "cannot open
display" and the compositor's log says why. **Control Panel > Windows >
X11 Programs** turns them off and on (on by default; applied at
Restart Desktop): off, X-only programs fail the same way, while GTK, Qt
and Firefox keep running as Wayland programs.

An X program's window is a Hibr window like any other: its title and
application name, placed and sized by the desktop, keys and mouse, and
Hibr's close asks it to close. A program that draws its own frame (Steam)
says so, and Hibr's frame stays off, as for Firefox.

*Since Blit 0.3.81 (milestone C):*

- **Menus, dropdowns and tooltips** show over their window, where the
  program puts them, and take the keys and the mouse as the program
  expects: choose with a click or the keys, and a click elsewhere in the
  program's windows closes the menu. Switching to another window takes
  the focus from the program, which is how X programs that close their
  menus on losing the focus are told (which programs do is still to be
  checked on real hardware, Steam first). A click on the desktop or in a
  Wayland program does not reach X, so a program that waits for a click
  of its own keeps its menu open until you come back to it.
- **Dialogs** belong to their window, as a Wayland program's do, and a
  window's minimum and maximum size hold when you resize it.
- **The program's own buttons**: full screen, maximize, minimize, and
  moving and resizing from its own title bar and edges (Steam's) work as
  for a Wayland program.
- **Pointer shapes**: the program's named cursors (text, hand, resize,
  ...) are Blit's own pointer for that name, as for a Wayland program; a
  cursor the program draws without a name is the display's pointer.

*Since Blit 0.3.84 (milestone D):*

- **Copy and paste** with X programs is the one clipboard, as for any
  program: copy in an X program and paste in Hibr, a terminal or a
  Wayland program, and the other way, Ctrl-C/V and the middle-click
  selection both, large ones too. Text is UTF-8 everywhere; an older X
  program that only speaks Latin-1 gets `?` for what Latin-1 has not.
  X programs copy and paste while one of them has the keyboard, as only
  the Wayland program with the keyboard can, so while you are in Hibr or
  a Wayland program no X program can read the clipboard (xclip run in an
  X terminal works, as that terminal has the keyboard). Vault passwords
  paste into X programs and leave them when the Vault's timer ends; a
  program keeps what it already pasted, and an X clipboard manager, if
  you run one, can read them while you are in an X program and keeps them
  unless it honours the password mark. A program that stops answering
  mid-paste is given up after 3 seconds, so a paste never hangs: it gets
  what came in time, or nothing.

*Since Blit 0.3.86:*

- **A program asking for the focus is the desktop's call.** Keys always
  go to the window the desktop has focused: an X program that grabs the
  keyboard's focus for itself (Steam's window taking it from the game you
  are playing) gets it taken back at once, and its request goes to the
  desktop, which focuses that window or not (its focus-stealing setting).
  The same holds for an X program asking to be the active window and for
  a Wayland program asking with an activation token (a launcher raising
  the program it started). A program that keeps asking is heard once a
  second at most.

*Since Blit 0.3.129:*

- **A game's full-screen X window shows.** Some games draw full screen in
  an override-redirect window, which no window manager manages. One that
  covers a display (or the whole X screen) is now a window of its own,
  drawn by the game, asking the desktop for full screen; it takes keys and
  clicks as any window does.

*Since Blit 0.3.88, with a Hibr that sends its display layout:*

- **Programs see your displays as they are.** Each display is one output
  for programs, named as Hibr names it and at its place in Hibr's
  arrangement; X programs see the same displays (RandR) with Hibr's
  primary display as X's primary, so a game that sizes itself to the
  primary display, or to the display it is on, gets that display's size.
- **Full screen goes to the display the desktop chooses.** A program
  that asks for full screen fills the display Hibr puts it on -- for X
  programs, at that display's corner and size -- not always the same one.
  Which display full-screen programs open on is Hibr's setting (**Control
  Panel > Displays > Full Screen On**). An X program's
  window stays inside the display it is shown on, and moves with it to
  another.

## Using the window

| What | What happens |
| --- | --- |
| Keyboard | Goes to the focused window, with Blit's keyboard layout and key repeat (the keyboard settings in Blit's Control Panel pane). A program cannot take the focus itself; it can ask, and the desktop decides. |
| Mouse | Clicks, scrolling, menus and popups land where they are drawn; a press on a background window focuses it first. A game can lock the pointer after a click; Hibr's release key gives it back. |
| Pointer shape | The program names it (text, hand, resize, ...) and Blit draws its own pointer for that name: the same cursors as everywhere else. A program's own cursor pictures are never drawn. Shapes show over the focused window; the text cursor shows everywhere. |
| Copy and paste | One clipboard with Hibr's terminals and applications, as text. Vault passwords paste in and are cleared again when the Vault's timer ends, and never enter the clipboard history. Middle-click paste (the primary selection) works between programs. |
| Drag and drop | Files dragged from Hibr drop into Wayland and X programs, and a program's own drag drops into Hibr, a terminal or another program, with the program's drag icon under the pointer (0.3.114-0.3.123). |
| Typing other scripts | The keyboard's input method, Arabizi included, types into programs' text fields (text-input-v3, 0.3.101; Arabizi's cycle and teach keys from 0.3.109). |
| Extra mouse buttons | Back, forward and further buttons reach the program, unless the desktop keeps that chord for itself as a shortcut (0.3.107; `INPUT keep`, 0.3.95). |
| A program that stops answering | After 2 s without an answer (Blit's pointer setting `busy_after_ms`, 0.5-10 s) the pointer over its window turns busy, and goes back when the program answers ([ADR 0235](adr/0235-the-busy-pointer.md)). |
| Video and scaled windows | Programs that crop or scale their output (mpv and other `wp_viewporter` users, and a window's buffer scale) show at the window's size (0.3.115, 0.3.124). |
| Moving and resizing | From Hibr's frame, or from the program's own title bar and edges if it draws them (Firefox, GTK applications); right click on such a title bar for the window menu. Maximize, full screen and minimize as for any Hibr window. |
| Closing | Hibr's close asks the program to close, so it can still ask to save. |
| Restart Desktop | Programs keep running; their windows come back as they were. |
| Quitting the desktop | Ends every program. |

## Not yet

- **X11 programs**: Big Picture full screen and Proton games --
  [ADR 0228](adr/0228-blit-is-the-compositor-for-programs.md) phase 2's
  milestone E (Gitea #169).
- **Programs' menus in Hibr's bar** (the global menu): Blit's side is in
  0.3.77, Hibr's to follow. Qt and KDE programs, and GTK 3 ones with the
  appmenu module, get it; Firefox and GTK 4 programs keep their own menus.
- **HiDPI output scale** (outputs tell programs scale 1; no fractional
  scale, #170), **idle inhibit** (#171), **portals** (#172), and **touch
  and tablets** (#173) are
  [ADR 0229](adr/0229-programs-and-the-desktop-one-owner-per-concern.md)'s
  later rows.

## When something is wrong

- **No window at all:** check `echo $WAYLAND_DISPLAY` (and `echo $DISPLAY`
  for an X program) in that terminal (see above) and that
  `blit-compositor` is running; for an X program, that `Xwayland -version`
  says 23.1 or later.
- **A window, but no keys or clicks:** this was a real bug for programs
  that draw their own frame in shared memory (Firefox), fixed in Hibr
  0.99.484. Note the program and what you did, and report it.
- The compositor logs to `~/.local/state/hibr/compositor.log`; Blit's
  input routes are in `GET /v1/terminal-sessions` under `frames.input`.

## How this is kept true

Each release is checked against this page with real programs on the
owner's machine -- vkcube, Firefox, a GTK and a Qt application: open, type,
click, copy and paste both ways, move and resize from both frames,
minimize and raise, Restart Desktop -- besides `compositor_gate`, which
checks every line of the wire with a stand-in program, and
`xwayland_gate`, which runs an X stand-in program under the compositor's
Xwayland (map, title and class, a drawing pixel for pixel, a resize,
focus (and taken back from a program that takes it itself), a key and a
click, its menus with their grabs, a dialog and its
limits, full screen and maximize both ways, its own move and resize, a
named cursor, close).
