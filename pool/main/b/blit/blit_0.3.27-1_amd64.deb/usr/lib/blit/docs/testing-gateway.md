# Gateway testing

## Remote runtime diagnostics

Start Blit on an address reachable by the operator, with authentication
enabled. For example, a system service may set `BLIT_BIND_ADDRESS=0.0.0.0`
and a secret `BLIT_AUTH_TOKEN`; firewall policy should expose the API port only
to the trusted management network. Query the runtime snapshot with:

```sh
curl --fail --silent \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  http://DESKTOP_IP:8080/v1/diagnostics/runtime
```

This endpoint is read-only and reports backend readiness, display/output
counts, refresh scheduling, frame counters, render duration, missed
deadlines, and recent bounded runtime events. Blit may create or stop terminal
sessions through its API, but it cannot start itself after it is dead; daemon
start/stop/restart belongs to the host supervisor (systemd, an init service,
or SSH). Use that supervisor for lifecycle recovery, then use this endpoint to
verify readiness.

For a clean API-driven shutdown while the server is alive, call:

```sh
curl --fail --request POST http://127.0.0.1:8080/v1/control/shutdown
```

The endpoint acknowledges first, then the event loop terminates child process
groups and releases KMS outputs before exiting. Starting a new server still
belongs to the host supervisor or launch command because a stopped process
cannot serve its own restart request.

## Supervised package updates

The Debian package installs a root-owned `blit-update-helper` behind
`/run/blit/update.sock`. The network update API does not write packages as the
gateway user: it verifies the package name and SHA-256, then delegates
installation to that helper and requests a supervised restart.

The package includes `blit.service`, which runs the server as root with the
`video`, `render`, `input` and `audio` supplementary groups; the unprivileged
profile (ADR 0065) ships as an example drop-in,
`/usr/share/doc/blit/examples/blit-unprivileged.conf`. Installation generates
`/etc/blit/update.token` and an API `BLIT_AUTH_TOKEN` in `/etc/blit/blit.env`,
both readable by root and the `blit` group. The default configuration binds
`0.0.0.0:8080` for the trusted LAN and sets `LANG=C.UTF-8` and
`LC_ALL=C.UTF-8`, so Hibr's Unicode desktop glyphs reach its PTY as UTF-8.
Existing values in `/etc/blit/blit.env` and `/etc/blit/update.token` are
preserved on upgrades.

Before publishing a Debian artifact, run the repository-owned package gate:

```sh
tools/tests/package_artifact_gate.sh /tmp/blit-package/blit_X.Y.Z-1_amd64.deb
```

It verifies the external release-manifest hash, TCC binary identity, embedded
documentation/OpenAPI, required Hibr adapter assets, and the runtime package
allowlist.

```sh
sudo systemctl status blit.service
```

`BLIT_UPDATE_TOKEN_FILE` is preferred for the update token. The file is read
once at startup, trimmed of trailing whitespace, and never logged or returned,
so the service user needs read access to it. `BLIT_UPDATE_TOKEN` remains
supported for protected environment-file deployments. The server never
generates, returns or logs the token; the package installer creates it once.
Every other request needs the API bearer token from `/etc/blit/blit.env`:

```sh
curl --fail -H "Authorization: Bearer $TOKEN" \
  http://127.0.0.1:8080/v1/version
curl --fail -H "Authorization: Bearer $TOKEN" \
  http://127.0.0.1:8080/v1/control/update/status
```

These report the expected server version and `state: "ready"`. The upload
itself is authorized by the update token alone. Upload only a
package whose SHA-256 was independently recorded:

```sh
sha256sum blit_X.Y.Z-1_amd64.deb
curl --fail --request PUT \
  --header 'X-Blit-Update-Token: YOUR_UPDATE_TOKEN' \
  --header 'X-Blit-SHA256: RECORDED_SHA256' \
  --header 'Content-Type: application/vnd.debian.binary-package' \
  --data-binary @blit_X.Y.Z-1_amd64.deb \
  http://127.0.0.1:8080/v1/control/update
```

The screenshot route is nonblocking with respect to the display loop. Verify
this with a deliberately slow reader during local or live diagnostics:

```sh
tools/tests/screenshot_nonblocking_gate.sh http://DESKTOP_IP:8080 display-1
```

The gate requires the version endpoint to respond within one second while a
framebuffer-sized screenshot is still being downloaded. It sends no bearer
token, so it runs only against a server without `BLIT_AUTH_TOKEN`.

Poll `/v1/control/update/status` until the supervisor reports the new
version; an interrupted upload or `403` response is not an installation.

For a bounded operator update with preflight checks, use the repository-only
helper. It requires the live update credential explicitly, never substitutes
the API bearer token, and never retries a rejected credential:

```sh
BLIT_UPDATE_TOKEN_FILE=/secure/path/live-update.token \
  BLIT_AUTH_TOKEN_FILE=/secure/path/live-api.token \
  tools/deploy/update-live.sh HOST blit_X.Y.Z-1_amd64.deb
```

`BLIT_UPDATE_TOKEN` may be used instead of the update-token file. `thisisatest`
is not a built-in token; only the value configured on the running host in
`BLIT_UPDATE_TOKEN` or `BLIT_UPDATE_TOKEN_FILE` is accepted. A `403` means the
credential is wrong and the package was not installed. The helper also
requires the package name and SHA-256 to match the checked-in
`releases/<version>.yaml` manifest, then checks package metadata, update
readiness, and the final running version. Uploads are staged in
`/var/lib/blit/updates`, which the gateway shares with the root helper.

The idle-timeout gate holds a valid upload open without sending its body and
verifies that the gateway transitions to `update upload idle timeout` instead
of retaining a dead staged transfer indefinitely:

```sh
BLIT_GATE_BINARY=build/blit/blit-server \
  tools/tests/update_idle_timeout_gate.sh
```

## Acceptance gates

### Physical multi-display gate

Run the hardware gate against a Blit instance that owns the physical DRM
device:

```sh
BLIT_GATE_SERVER=http://192.168.10.54:8080 \
  tools/tests/physical_multi_display_gate.rb
```

The gate requires at least two discovered physical displays. It launches the
unchanged installed Hibr desktop on the first display and one `desktop --join`
session on each auxiliary display, then checks runtime health, pointer
diagnostics, and resource counts. It removes the sessions and restores the
original topology afterward. `BLIT_HIBR_COMMAND` and `BLIT_HIBR_SESSION` can
override the installed Hibr paths. Exit status `77` means the host does not
currently expose enough physical displays and is not a pass. Like the
screenshot gate it sends no bearer token, so a host with `BLIT_AUTH_TOKEN`
set (every package install) answers it with `401`.

### Font and input fixtures

The font suite's `tools/tests/hibr_font_manifest_gate.py` loads the
generator's required-glyph set and checks that every required Hibr glyph is
mapped, non-blank and not `.notdef` fallback output, in the fixed 8×16
geometry; geometric block elements must cover exact cell rows, not a cropped
fallback bitmap. `tools/tests/font_fallback_gate.c` checks that an unmapped
scalar outside the PSF range selects the visible replacement glyph while a
mapped one is unchanged; no suite runs it, so build it with TCC by hand.

The QEMU input gate needs the kernel fragment in
`tools/probes/qemu-kernel.input.config` (`CONFIG_INPUT_EVDEV=y`,
`CONFIG_MOUSE_PS2=y`, `CONFIG_INPUT_UINPUT=y`) merged into the fixture
kernel.

### Network bounds

HTTP reads are event-loop bounded: the gateway retains incomplete requests per
connection, reads at most the bytes available for that readiness event, and
expires a request that remains incomplete for five seconds. This prevents a
fragmented or slow TCP client from stalling KMS presentation, PTY draining,
input routing, or WebSocket servicing. `http_fragmentation_gate.rb` holds one
request fragmented for one second while requiring an independent
authenticated diagnostics request to complete in under 800 ms. It is a
sub-gate: `tools/tests/network_auth_gate.sh` (schema suite) starts the
server and runs it, so do not run it on its own.

`/v1/diagnostics` reports `presentation_sync` as `drm-page-flip`, or
`drm-page-flip-async` when the explicit asynchronous page-flip test policy is
enabled.

Writes use the same bounded policy: HTTP and WebSocket sends are nonblocking.
If a receiver cannot accept the next bounded write, the HTTP response is
closed or the WebSocket stream is removed. Blit does not sleep in the gateway
loop waiting for a remote reader. `http_backpressure_gate.rb`, the other
sub-gate of `network_auth_gate.sh`, opens a small receive buffer, requests a
large surface snapshot without reading it, and verifies that an independent
diagnostics request completes in under 800 ms.

### QEMU Hibr fixture

The Hibr VKMS fixture must stage the exact Hibr executable, modules, and
desktop tree being tested. Refresh an existing initramfs tree with:

```sh
tools/probes/stage_hibr_qemu.sh /tmp/hibr-initroot-current /path/to/hibr
```

The staging helper replaces and version-checks the canonical Blit binary on
every run, then stages the Blit `console-blit.so` provider and adapter files
for provider and held-desktop probes. It does not modify the Hibr
checkout. It also rebuilds the repository-owned HTTP, PTY, WebSocket, and
uinput probe helpers with TCC, preventing stale binaries from entering the
initramfs. It stages the same checked-in Hibr Unicode font used by the Debian
package, preventing QEMU from silently falling back to a different font. It
does not stage or invoke a Blit shell launcher. For the stock Hibr session
gate it stages the repository-owned `blit-stock-session.hibr` integration
entrypoint; that Blit script loads `console-blit` plus Hibr's `pty`, `term`,
and `hold` modules by explicit staged paths in the API-launched process, then
sources the unchanged stock `session.hibr`. The `console-blit` provider is
therefore the active display implementation for the stock desktop, while the
Hibr checkout remains untouched.

The fixture's behaviour is selected on the QEMU kernel command line, after
staging with the helper above:

- `blit.input_only=1` runs the isolated input gate. It checks PTY delivery
  while the network input stream also carries key releases, repeats, pointer
  buttons and wheel events. It enables application keypad mode and requires
  KP1 to reach the PTY as the VT/SS3 sequence `ESC O q`. The wait before
  checking defaults to 30 seconds; `blit.input_wait=8` bounds it for
  automation.
- `blit.input_fairness=1` instead floods one synthetic evdev mouse for five
  seconds and requires a nonzero `performance.evdev_service_budget_yields`
  while the PTY/render loop stays serviced.
- `blit.hibr_panes=1` starts one primary and three `desktop --join` clients
  across a Blit-owned `2x2` pane layout and requires four attached surfaces.
- `blit.hibr_restart=1`, with `blit.hibr_panes=1`, kills Hibr's registered
  primary owner after startup, requires Hibr's supervisor to restore the
  primary session, then kills a join client and attaches a fresh join on the
  next pane. It requires `HIBR_PRIMARY_RESTART_PASS`,
  `HIBR_JOIN_RECONNECT_PASS` and `HIBR_PANE_MATRIX_PASS`.
- `blit.hibr_stock=1` uses the stock-session entrypoint rather than the
  dedicated window-control workload.

The host wrapper boots a packed initramfs, asserts every marker, and rejects
a clean QEMU poweroff when any is missing:

```sh
tools/tests/qemu_hibr_lifecycle_gate.sh /tmp/blit-input.initramfs.gz
```

## Build

From the repository root:

```sh
tools/build-tcc.sh build/blit/blit-server server
tools/build-tcc.sh build/blit/blit-update-helper helper
BLIT_HIBR_ROOT=/path/to/hibr \
  tools/build-tcc.sh build/blit/console-blit.so adapter
```

The adapter is compiled against the exact Hibr checkout that will load it.
`BLIT_HIBR_ROOT` is mandatory; a package build must not silently reuse an
adapter compiled against another Hibr ABI.

The focused input-boundary gate uses that same checkout and the shipped
adapter source:

```sh
BLIT_HIBR_ROOT=/path/to/hibr tools/tests/adapter_input_gate.sh
```

It sends real WebSocket text frames through `console-blit`, then checks the
one-based Blit to zero-based Hibr cell translation, font-scaled pixel
fallback, left/middle/right button identity including the button field in
drag actions, vertical wheel events, and Hibr names for F1 through F12. This
isolates adapter semantics from evdev discovery
and widget behavior; the physical host remains the final click and shortcut
acceptance boundary.

The provider-state gate covers the other half of the same adapter contract:

```sh
BLIT_HIBR_ROOT=/path/to/hibr tools/tests/adapter_provider_gate.sh
```

It proves pane ownership/behind painting, pane clipping and stack order,
watched application-descriptor wakeups, quiet-wait exclusion, Hibr's UTF-8
cell widths, idempotent shadows, and zero HTTP resize polls during steady input.
It must be built against the same pinned released Hibr as the package.

The Blit-owned join contract has a local gate that does not require a running
Hibr installation:

```sh
ruby tools/tests/hibr_join_viewport_gate.rb
```

It creates one primary and one `desktop --join` fixture, proves that the
primary's committed cells appear on the joined surface, verifies that the
joined surface is read-only, and checks that a pointer hit in the joined pane
is routed to the primary session. Physical wallpaper/context-menu acceptance
still requires the exact package on a real display.

The native PTY presentation boundary for one primary plus one join is covered
separately:

```sh
ruby tools/tests/hibr_join_frame_barrier_gate.rb
```

It deliberately staggers the two PTY redraws, then verifies through the
critical diagnostic trace that no render occurs between the bounded Hibr frame
barrier opening and its release. A timeout is allowed only at the display
refresh deadline; it cannot be extended by continued writes.

The native Kitty query acknowledgement is covered locally as well:

```sh
ruby tools/tests/kitty_query_gate.rb
```

The gate sends the header-only `a=q` probe, reads Blit's `OK` reply through a
raw PTY, and confirms that the query does not create an image. This matters for
Hibr wallpaper startup because Hibr performs this probe before transmitting the
actual image payload.

The stream reconnect/replay gate runs against that exact binary on the
DRM mock:

```sh
BLIT_GATE_PORT=19245 ruby tools/tests/stream_replay_gate.rb
```

It requires `replay_gap`, replayed `terminal_output`, and the canonical
`/v1/surfaces/{id}/cells` snapshot repair response after reconnecting with an
expired cursor.

Session termination during active output and resizes is covered by:

```sh
BLIT_GATE_PORT=19246 ruby tools/tests/session_write_resize_gate.rb
```

The gate requires six successful `If-Match` resizes while a PTY is writing,
then deletes the session and waits for the runtime resource count to reach
zero.

## Run locally

The DRM mock the gates use exercises the network contract without owning a
physical DRM device:

```sh
. tools/tests/gate_display.sh && gate_display_setup
env $GATE_DISPLAY_ENV ./build/blit/blit-server 8080
```

`gate_display_setup` selects the CPU compositor; set `BLIT_GATE_BACKEND=gles`
before it to compose with GLES on the surfaceless platform.
`GET /v1/diagnostics/screenshots/display-1` returns the presented frame.

Without `BLIT_AUTH_TOKEN`, Blit listens on 127.0.0.1 only and requires no
authentication. It refuses an explicit network address such as `0.0.0.0`
with no token, unless `BLIT_ALLOW_UNAUTHENTICATED_NETWORK=1` asks for it by
name. With a token it listens on all IPv4 interfaces by default; send
`Authorization: Bearer <token>` on HTTP requests and WebSocket upgrades, and
apply a firewall policy before exposing the API:

```sh
BLIT_AUTH_TOKEN='replace-me' \
  ./build/blit/blit-server 8080
curl --fail -H 'Authorization: Bearer replace-me' \
  http://127.0.0.1:8080/v1/server
```

The repeatable bind/auth gate is:

```sh
tools/tests/network_auth_gate.sh
```

The session lifecycle gate starts a child that ignores `SIGTERM`, verifies that
API deletion escalates to a bounded `SIGKILL`, and immediately checks that the
diagnostics endpoint remains responsive:

```sh
BLIT_GATE_BINARY=build/blit/blit-server \
  tools/tests/session_lifecycle_gate.sh
```

The API-owned pixel-frame gate covers the binary canvas path used by
arcade/emulation clients. Its default burst workload proves that every frame
can be accepted without blocking the API while the renderer coalesces to the
newest complete frame. A paced workload additionally verifies that frames reach
the presentation loop instead of remaining permanently coalesced:

```sh
BLIT_PIXEL_PACE_HZ=60 \
  BLIT_PIXEL_MIN_RENDERED=24 \
  BLIT_GATE_PORT=19249 ruby tools/tests/pixel_frame_gate.rb
```

Set `BLIT_PIXEL_FRAME_COUNT` for a longer sustained workload when diagnosing
physical presentation cadence; the default is 30 frames.

The paced assertion requires at least 24 of 30 accepted frames to be rendered.
It is deliberately below 30 to allow scheduler jitter on the DRM mock;
physical release acceptance still requires display-mode timing and input
latency evidence. The gate registers session cleanup immediately after the
session is created, so a failed assertion cannot leave a test surface running
on a remote host.

The frame-rate gate creates a bounded PTY producer and samples the versioned
runtime diagnostics endpoint. It requires a completed, fresh measurement
window, a configurable minimum measured rate, and zero missed refresh
deadlines; cumulative frame counters alone are not treated as a refresh-rate
measurement. The windowed render maximum is reported for diagnosis and can be
made a hard failure criterion because KMS presentation time can include the
wait for the next physical vblank; missed deadlines are the
authoritative cadence failure:

```sh
BLIT_GATE_PORT=19248 ruby tools/tests/frame_rate_gate.rb
```

For a 60 Hz physical output, use a release-level minimum explicitly:

```sh
BLIT_GATE_SERVER=http://192.168.10.54:8080 BLIT_GATE_MIN_HZ=55 \
  ruby tools/tests/frame_rate_gate.rb
```

The same gate can run against an already-running physical host without
silently starting a local DRM-mock server:

```sh
BLIT_GATE_SERVER=http://192.168.10.54:8080 ruby tools/tests/frame_rate_gate.rb
```

For a full-surface physical composition workload, provide the API token and
the surface dimensions. The 60 Hz release acceptance uses a 17 ms render
budget; the default 20 ms value is only a local DRM-mock smoke budget:

```sh
BLIT_GATE_SERVER=http://192.168.10.54:8080 \
BLIT_GATE_AUTH_TOKEN=YOUR_API_TOKEN \
BLIT_GATE_MIN_HZ=55 \
BLIT_GATE_SURFACE_WIDTH=240 BLIT_GATE_SURFACE_HEIGHT=135 \
BLIT_GATE_MAX_RENDER_MS=17 \
  ruby tools/tests/frame_rate_gate.rb
```

The gate deletes its temporary session in `ensure`. A threshold failure is a
real budget failure and must not be changed to make a run green without a new
measurement and an ADR update. The 17 ms value is specific to the measured
60 Hz host; it is not evidence for 120/240 Hz hardware.

The hidden-cursor damage gate verifies that repeated VT cursor addressing with
the cursor disabled does not schedule presentation frames:

```sh
ruby tools/tests/hidden_cursor_damage_gate.rb
```

The glyph-render gate checks the public screenshot boundary for the
bundled Hibr font. It asserts deterministic light/heavy/double box geometry,
vertical geometry, block coverage, and both halves of a wide glyph; terminal
cell snapshots alone do not prove these pixel shapes:

```sh
ruby tools/tests/glyph_render_gate.rb
```

The result is exposed by `GET /v1/diagnostics/runtime` under `performance` as
`frame_rate_hz`, `frame_rate_frames`, `frame_rate_window_ms`, and
`frame_rate_age_ms`. The completed measurement window also reports
`frame_rate_max_render_ms` and `frame_rate_missed_deadlines`; these are
windowed values and are not contaminated by older lifetime maxima.
`frame_rate_window_sequence` increments only when a new measurement window
completes, allowing a remote gate to distinguish its workload from stale
measurements left by an earlier client. `frame_rate_hz` is the rate of
damage-driven composition and presentation passes; it is not the panel scanout
rate. Use `pixel_frames_pending` to detect an API pixel producer that is
outrunning presentation; the scheduler drains that pending work at the
selected output refresh instead of silently clearing the only boolean render
flag. Use `snapshot.render.outputs[].refresh_hz` and `effective_interval_ms`
for the selected display cadence and scheduler target. The same object
includes `loop_iterations`, `terminal_reads`, `present_calls`,
`last_loop_gap_ms`, and `max_loop_gap_ms`, `last_select_ms`, and
`max_select_ms`, which distinguish kernel-wait stalls from other event-loop
stalls and presentation stalls. The pending terminal, pointer, overlay, and
pixel work is coalesced to each output's deadline; a producer can update state
faster than the display without forcing a present for every event. During a
motion test, compare the interval between `render_path` trace timestamps with
`snapshot.render.outputs[].target_interval_ms`. A trace that follows the
producer faster than that interval is a scheduler regression, not evidence of
a faster display. Pointer damage is retained independently for the old and new
output when a pointer crosses displays. The completed bounded loop-gap window
is exposed as `loop_gap_window_ms`, `loop_gap_window_sequence`, and
`loop_gap_window_max_ms`. The sequence advances once per completed 500 ms
window; use it to take two runtime samples and avoid mistaking a partial or
stale sample for the interval being investigated. direct-KMS duration is
reported as `last_kms_present_ms` and `max_kms_present_ms`; these measure the
complete KMS present call, including page-flip submission and driver event
servicing. Interpret them alongside
`snapshot.render.outputs[].missed_deadlines` to separate renderer work from a
slow KMS or virtual-display backend. The `last_render_ms` and `max_render_ms`
values retain their complete render-path meaning. Evdev scan duration is
reported as `last_evdev_scan_ms` and `max_evdev_scan_ms`. The rate is measured
from presented frames, not inferred from the display mode or configured
interval. Input dispatch is independently observable through `input_events`,
`last_input_dispatch_ms`, and `max_input_dispatch_ms`. These counters cover
keyboard, pointer, and gamepad events after evdev receipt and through Blit's
routing path, so input latency can be separated from rendering and scanout
latency. The `evdev_service_budget_yields` counter records how often a
physical evdev device reached the bounded per-turn input budget and returned
to the main loop. A rising value during motion is expected under a busy
device; a zero value means only that the captured interval did not fill the
budget. It is the counter used by the fairness regression test to prove that
evdev service did not drain an unbounded stream in one loop turn. For physical
mouse diagnosis, compare the lifetime `evdev_mouse_events`,
`evdev_mouse_motion_events`, `evdev_mouse_syncs`, `evdev_mouse_button_events`,
and `evdev_mouse_wheel_events` counters between the capture start and end.
`evdev_mouse_events` increasing while the filtered pointer trace remains empty
means records reached Blit but did not produce a changed pointer position; all
of them remaining unchanged means the kernel device produced no records for
Blit during the window. The endpoint also reports `last_evdev_mouse_path` and
`last_evdev_mouse_event_age_ms` so a stale or changing device can be
identified without shell access to the desktop. During a fast-motion capture,
pair `evdev_service_budget_yields` with `last_loop_gap_ms`, the PTY
`surface_update` trace, and the `render_path` trace. A busy device must
produce yields while the loop continues to service producers and presentation;
an unbounded drain is a gateway defect. The path is historical: Linux can
renumber `/dev/input/eventN` during a KVM or USB re-enumeration. Pair it with
`last_evdev_mouse_device_id` and `last_evdev_mouse_device_present`; an empty
ID or `false` means the last event came from a device generation that is no
longer in the current input table. The keyboard has the corresponding
`last_evdev_keyboard_device_id` and `last_evdev_keyboard_device_present`
fields. This prevents a historical node path from being mistaken for the
currently opened device. Each scheduler output also reports `last_present_ms`,
`max_present_ms`, and `present_calls`, which identify per-output KMS
presentation cost rather than hiding it in one aggregate server-wide maximum.

The shutdown gate verifies that `POST /v1/control/shutdown` acknowledges the
request and the Blit process exits cleanly:

```sh
BLIT_GATE_BINARY=build/blit/blit-server \
  tools/tests/shutdown_gate.sh
```

It requires `401` without a token and `200` with the configured bearer token.

TLS termination, token rotation, and per-client authorization remain
deployment responsibilities.

Native KMS is the only presentation path (ADR 0184): the gateway owns the DRM
connectors and page-flips its scanout buffers on a DRM-capable VT, composing
with GLES by default or with the CPU compositor.

## Exercise discovery

```sh
curl --fail http://127.0.0.1:8080/v1/server
curl --fail http://127.0.0.1:8080/v1/displays
curl --fail http://127.0.0.1:8080/v1/topology
curl --fail http://127.0.0.1:8080/v1/graphics
curl --fail http://127.0.0.1:8080/v1/audio
curl --fail http://127.0.0.1:8080/v1/input/devices
curl --fail http://127.0.0.1:8080/v1/diagnostics
```

The audio inventory is sourced from usable ALSA PCM nodes under `/dev/snd`;
the API returns an empty device list when no playback or capture PCM exists.
It does not infer audio capability from the presence of the directory alone.

## Exercise a PTY-backed session

A terminal session runs the requested command under a real PTY. Keep this
test local unless the deployment has configured its command policy and
`BLIT_AUTH_TOKEN`; bearer authentication is enforced whenever that token is
set.

For a network deployment, set an exact, comma-separated executable allowlist:

```sh
BLIT_AUTH_TOKEN=change-me \
BLIT_COMMAND_ALLOWLIST=/usr/bin/hibr,/bin/sh \
blit 8080
```

The allowlist compares the complete requested path. Blit does not invoke a
shell or perform `PATH` lookup, and a denied executable returns `403` with
problem code `command_not_allowed`. When the variable is unset, command
policy is open for local development and deterministic tests; production
network deployments should set it explicitly. Hibr's installed executable
can therefore be allowed directly while Hibr continues to own `desktop` and
`desktop --join`.

```sh
curl --fail --request POST \
  --header 'Content-Type: application/json' \
  --data '{"command":"/bin/sh","surface":{"width":80,"height":24}}' \
  http://127.0.0.1:8080/v1/terminal-sessions
```

Use the returned numeric session id with `GET` or `PATCH` to inspect or update
its display placement. Pass an enumerated `display_id` at creation time to
route that session's surface to one output:

```sh
curl --fail --request POST \
  --header 'Content-Type: application/json' \
  --data '{"command":"/bin/sh","display_id":"display-2","surface":{"width":80,"height":24}}' \
  http://127.0.0.1:8080/v1/terminal-sessions
```

An omitted `display_id` targets the first output for compatibility. Unknown
display IDs are rejected with `display_not_found`; arguments and environment
are passed only after the executable path passes the configured policy. The
nested `surface` object and its `width`/`height` members are required by the
OpenAPI contract; omitting them returns the typed `session_create_failed`
problem.

## Discover and attach to Blit panes

Blit derives logical panes internally and exposes their opaque identifiers from
topology discovery. A session attached to a pane is automatically sized to the
pane's cell bounds:

```sh
curl --fail http://127.0.0.1:8080/v1/topology

curl --fail --request POST \
  --header 'Content-Type: application/json' \
  --data '{"command":"/opt/bin/hibr-desktop","pane_id":"pane-display-1-1","surface":{"width":80,"height":24}}' \
  http://127.0.0.1:8080/v1/terminal-sessions
```

The pane identifier and dimensions in the topology response are authoritative;
clients must not derive pane names or pixel geometry. For development, the
initial grid can be selected with `BLIT_PANE_LAYOUT=1x1`, `2x1`, `1x2`, or
`2x2`.

The split can also be changed through the topology API before sessions are
attached. The selected layout is persisted by `/v1/settings`, so it is not
necessary to recreate the split after a supervised restart:

```sh
curl --fail --request PUT \
  --header 'Content-Type: application/json' \
  --data '{"layout":{"columns":2,"rows":2}}' \
  http://127.0.0.1:8080/v1/topology
```

Blit rejects layout changes while a pane is occupied with
`topology_in_use`; detach or stop joined sessions before changing the grid.
The environment value is a first-boot default only. A stored API setting wins
until `DELETE /v1/settings` restores the boot defaults.

Resize a running terminal through the same session resource. The gateway
updates the PTY window size, preserves the overlapping cells on both the main
and alternate grids, blanks cells outside the new bounds, clamps the cursor,
resets the scroll region to the full surface, clears deferred wrapping,
increments `surface_revision`, and emits a surface-delta event:

```sh
curl --fail --request PATCH \
  --header 'Content-Type: application/json' \
  --data '{"surface":{"width":120,"height":40}}' \
  http://127.0.0.1:8080/v1/terminal-sessions/1
```

Dimensions outside the bounded surface policy are rejected with
`invalid_surface_resize`.

Main-screen lines that scroll off the top are retained in a bounded 1000-line
ring and can be inspected without disturbing the live surface:

```sh
curl --fail \
  http://127.0.0.1:8080/v1/surfaces/surface-1/scrollback
```

The response is oldest-first and reports the current `view` position. Set the
view through the same resource to render history on the display; `view: 0`
returns to the live screen:

```sh
curl --fail --request PATCH \
  --header 'Content-Type: application/json' \
  --data '{"view":3}' \
  http://127.0.0.1:8080/v1/surfaces/surface-1/scrollback
```

Output from an alternate screen is never added to this history.

## Apply cells and present a frame

The created session owns a surface whose initial revision is `1`. Cell updates
must name that revision; successful updates return the next revision. A frame
request then references the surface and its current revision:

```sh
curl --fail --request PUT \
  --header 'Content-Type: application/json' \
  --data '{"base_revision":1,"cells":[{"x":0,"y":0,"text":"hello"}]}' \
  http://127.0.0.1:8080/v1/surfaces/surface-1/cells

curl --fail --request POST \
  --header 'Content-Type: application/json' \
  --data '{"base_revision":2,"surface_ids":["surface-1"]}' \
  http://127.0.0.1:8080/v1/frames
```

Stale cell revisions are rejected with `409 Conflict`. Cell mutations update
authoritative state; frame receipts record acceptance and trigger the KMS
output from an immutable surface/revision plan. Cell styles accept six-digit
foreground and background colors plus bold, dim, underline, and inverse flags;
invalid colors are rejected. Text is validated as UTF-8 and decoded into
logical cells; malformed UTF-8 and zero-width sequences without a preceding
base glyph are rejected. Wide glyphs occupy two physical columns, and
combining marks, joiners, and variation selectors remain attached to their
base cell. A cell update may also carry a bounded `{x,y,visible}` cursor
object; session GET responses report the current cursor, and out-of-bounds
cursor positions are rejected. The API accepts only valid logical cell
sequences. What the PTY-driven terminal engine interprets is in the [terminal
reference](terminal.md).

Session responses expose `surface_revision` separately from the session
configuration `revision`. Clients should use that value as `base_revision` for
cell updates. A `409 revision_conflict` response also carries the authoritative
current revision in `Problem.revision`, so clients can retry without another
discovery request when PTY output wins the race. The same revision-bearing
conflict applies when a frame references stale surfaces.

Session creation, cell mutations, and frame commits accept the documented
`Idempotency-Key` header. Within the bounded in-memory replay window, an
identical request returns its original response without spawning another PTY
or applying state again; reusing a key with a different payload returns
`idempotency_conflict`.

Display discovery is sourced from DRM/KMS.

Evdev mouse clicks, drags, and wheel events are routed to the Blit pane under
the pointer and encoded as SGR mouse reports for the owning PTY. A primary
button press focuses that pane; keyboard input then follows the focused live
session until the API changes focus. Hibr's console mouse mode controls
whether the joined desktop consumes those reports. KMS outputs and evdev
devices are normalized to the same virtual-desktop coordinate space. This
prevents a pointer on an auxiliary monitor from being hit-tested or clicked
against the primary monitor. The API supports explicit `evdev-keyboard` and
`evdev-pointer` routes through `/v1/input/routes/{id}`; an explicit route
takes precedence over focus or pointer hit-testing for its device source.
Enabling a route disables any other enabled route for that device, preventing
duplicate delivery. The Blit-only QEMU gate verifies both route records and
end-to-end virtual-evdev delivery. SGR button presses use button codes 0–2 and
releases use the same code with the `m` terminator; legacy VT reports use the
protocol's button-3 release code and 32-byte offset. Evdev Shift, Alt, and
Ctrl state contributes the standard SGR/VT modifier bits to button, wheel, and
drag reports.

Network clients can drive a live PTY without synthetic hardware through
`POST /v1/terminal-sessions/{session_id}/input` with `{ "data": "...", "mode":
"raw"|"paste" }`. Requests are limited to 768 bytes. `raw` writes unchanged
data; `paste` adds DEC bracketed-paste delimiters only when the session enabled
mode 2004, otherwise the receipt reports `paste-fallback`. The response
contains requested and written byte counts. This endpoint shares the same PTY
boundary as evdev and WebSocket input and reports typed errors for stopped
sessions or PTY back-pressure.

When a routed PTY exits, Blit disables the route during lifecycle reaping but
retains its `target_session_id` for diagnostics and replay-safe reconciliation.
Re-enabling that route against the stopped session returns the typed
`input_route_target_stopped` conflict; a new live session must be selected.

The evdev service also removes a keyboard or pointer when its descriptor
reports EOF, `ENODEV`, or another terminal read error. It closes and compacts
the active descriptor set, disables the aggregate route only when its last
device disappears, and reports `input_device_missing` with zero active devices
through `/v1/diagnostics`. The device-loss path does not silently reattach a
replacement device; clients must observe `/v1/input/devices` and configure a
new route when hardware returns. The QEMU input gate exercises descriptor
removal with `blit.input_loss=1`; QEMU's surviving baseline devices verify
that aggregate routes remain enabled until the final device disappears, and
the fixture recreates the synthetic devices to verify bounded re-enumeration.
The same run subscribes the WebSocket probe to diagnostics and requires
sequenced `input_device_lost` and `input_device_reconnected` events.

For the combined presentation/input soak, stage the fixture and boot it with
`blit.input_soak=1 blit.input_wait=12`. The existing TCC-built input helper
then emits bounded UTF-8/VT output for approximately ten seconds while the
keyboard, two mice, buttons, wheel, pointer motion, routes, and WebSocket
events are exercised. The fixture requires both `BLIT_INPUT_STREAM_PASS` and
`BLIT_INPUT_RENDER_SOAK_PASS`; scrolling output is not allowed to weaken the
input assertion by relying on old visible cells.

## Exercise the stream upgrade

The stream accepts a WebSocket opening handshake, keeps the connection open,
and sends an initial diagnostic text frame. HTTP surface mutations are
then broadcast to connected streams:

```sh
curl --include --no-buffer \
  -H 'Connection: Upgrade' \
  -H 'Upgrade: websocket' \
  -H 'Sec-WebSocket-Version: 13' \
  -H 'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==' \
  http://127.0.0.1:8080/v1/stream
```

Clients may send a text WebSocket message to receive a subscription diagnostic
acknowledgement, for example a `frames`-only subscription. Event fan-out is
filtered by subscription, and client text frames are unmasked. Ping frames
receive pong responses. The event types are `surface_delta`, `frame`,
`terminal_output`, `input`, `device_changed`, `diagnostic`, and the
`pixel_frame_*` events of the pixel canvas. A `surface_delta` includes the
current surface revision, cursor, and bounded damage rectangle. Input messages
identify `session_id` and carry terminal data inside the event object.
Broadcast surface, terminal-output, and frame events carry a monotonic server
`sequence`; clients can detect missed events when a reconnect produces a gap.
Reconnect with `/v1/stream?since=<last-sequence>` to replay the bounded
retained history. If the cursor is older than retention, the stream emits
`replay_gap`; clients must resynchronize from the HTTP resources.

The canonical resynchronization endpoint is:

```sh
curl --fail http://127.0.0.1:8080/v1/surfaces/surface-1/cells
```

It returns the current surface revision, cursor, non-empty cells, Unicode text,
and cell styles.
