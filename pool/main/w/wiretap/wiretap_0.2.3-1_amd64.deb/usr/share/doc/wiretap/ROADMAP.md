# Roadmap

| | State |
|---|---|
| **M0** | Done: the Tap proven live on the real desktop. |
| **M1** | Monitor. Done: engine, node, CLI, pane reader, the Tap, strip, window, history on disk, packages (published, 0.1.x), the tap logo (ADR 0013), the service verified under a real systemd (ADR 0002, 0012), two alerts (ADR 0014). Open: a history-length setting, the alerts list and a hosts view in the window, new-host alerts (needs hosts in the engine), a categorical palette for a per-app ribbon, the one-cell tap for the strip. |
| **M2** | Firewall: a table of its own (nftables), block/allow per app and per host/port, profiles, "ask before a new app talks" prompts, a root helper and polkit action `org.wiretap.rules`, fail-open on stop. Not testable on the build machine (`nft` is not installed). |
| **M3** | Alerts through the desktop's notifications, a usage report export, a per-host map where the terminal draws pixels. |

The design and its honest limits: [PLAN.md](PLAN.md).
