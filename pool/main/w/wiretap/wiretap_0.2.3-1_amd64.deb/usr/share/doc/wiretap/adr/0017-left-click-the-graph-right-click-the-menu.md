# 0017 — Left click opens the graph, right click opens the menu

Status: accepted. Changes [0015](0015-the-bar-is-the-tap-and-a-menu.md) (which button does what).

## Context

0015 made both buttons open a menu. The owner wants them apart: **left click shows the graph as a drop-down, right click drops a
context menu with all the other options.**

## Decision

- **Left click** on the bar item opens the Tap (the graph popup), as in 0006.
- **Right click** opens the menu (`wtb_context`): how it is going, Show the Graph, Open Wiretap…, Wiretap Settings….
- Everything else in 0015 stands: the item is the tap alone, with the graph and the rate as pane switches.

## Consequences

- `tests/m0_tap.py` right-clicks to check the menu (and that it does not open the graph), closes it, and left-clicks to check the graph.
