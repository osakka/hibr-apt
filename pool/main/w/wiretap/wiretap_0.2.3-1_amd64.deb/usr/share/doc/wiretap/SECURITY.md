# Security

Read first: `man wiretap-security`. This is the long form.

## What the service holds, and why

`wiretap.service` (a `DynamicUser`) holds three capabilities for its whole life ([ADR 0002](adr/0002-the-service-may-read-every-process.md)):

| Capability | For |
|---|---|
| `CAP_NET_RAW` | a receive-only `AF_PACKET` socket: every frame, to count bytes by flow |
| `CAP_SYS_PTRACE` | reading `/proc/PID/fd` links of other users' processes: which socket belongs to which program |
| `CAP_DAC_READ_SEARCH` | listing those directories |

Together they can read every process's descriptor table. That is the product: without it the monitor sees only your own
processes. Each is held for the whole life because the join is repeated every few seconds (ADR 0004), unlike longwire, which
clears its one capability once its socket is open.

## What it cannot do

- **Send.** `RestrictAddressFamilies=AF_UNIX AF_PACKET`: no IP sockets, so no network access of its own. A packet socket opened
  for receive never transmits.
- **Be steered.** The control socket answers `status`, `ifaces`, `apps`, `series`, `stop`; none changes anything but `stop`.
  It is mode 0660, group `wiretap`. A member can stop the node (and `Restart=always` brings it back).
- **Run a script.** The unit runs the packaged module only ([ADR 0010](adr/0010-the-service-runs-the-packaged-module-and-not-a-script.md)).
- **Write outside** `/run/wiretap` and `/var/lib/wiretap` (`ProtectSystem=strict`, `ProtectHome=yes`, private `/tmp`).

## What a member of the group learns

Every app's name, pid, uid and traffic volume on the machine, now and for the last month, **and the remote addresses each talks
to** (`hosts`, ADR 0016: kept in memory since the node started, never written to the history file, at most 1024 of them). Not
contents, not keys. Treat group membership as "may see what runs, how much it talks, and to whom", for every user of the machine.

## Honest limits

- **Names are evidence, not proof.** The app is the kernel's `comm`, which a process can set.
- **Counters can miss a socket** that opens and closes in under about 100 ms; those bytes land in `(unattributed)` so totals still add up.
- **Unreadable owners** are bucketed as `(root)` or `(user N)`; the owner is known, the program is not.
- **The capability grants were run for real** (0.1.2, ADR 0002 "Verified"): a `DynamicUser` service reading other users' processes. Colours and Blit's pixels are not checked from here.
- Nothing here defends against root.
- The control socket and the history file are only as private as their modes (0660 group `wiretap`, 0600).

## Reporting

Open an issue at git.home.arpa/itdlabs/wiretap, or mail the maintainer.
