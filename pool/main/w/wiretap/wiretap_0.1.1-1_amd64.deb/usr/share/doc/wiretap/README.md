# wiretap

See every byte. A network monitor (and, in M2, a firewall) for hibr's desktop, hui. Status: **M1 monitor complete, published**, 0.1.1 (0.1.0 did not start under systemd: ADR 0012).

- **The Tap**: a drop-down on the menu bar with a live graph and the five busiest apps; a Control Strip module; a Control Panel pane; a window with a graph over a minute to a week and every app's traffic; and a CLI (`wiretap`).
- **Per app, for the whole machine**: a service captures packets read-only and joins each flow to the program that owns its socket.
- **Built like longwire** (`../my-vpn`): a C engine as a hibr module under TCC, everything you see is a hibr script, and it is delivered the same way.

## Install

```
please apt install wiretap            # or the rpm / pacman package: the engine, the launcher, the service
catalogue install wiretap             # the CLI, the pane, the Tap, the strip, the window; then Refresh Desktop
systemctl enable --now wiretap        # the service that sees every user's programs (join the group wiretap to read it)
```

Without the service, `wiretap on` runs a node of your own and sees only your own processes.

## Read

[docs/PLAN.md](docs/PLAN.md) the design and its honest limits · [docs/CLI.md](docs/CLI.md) · [docs/DESKTOP.md](docs/DESKTOP.md) ·
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) · [docs/SECURITY.md](docs/SECURITY.md) (what the service holds, and what is untested) ·
[docs/ROADMAP.md](docs/ROADMAP.md) · [docs/BUILD.md](docs/BUILD.md) · [docs/adr/](docs/adr/) why each decision was made.

## Build

`make`, `make check` (needs `tcc`, hibr at `HIBR_MIN` or newer, python3), `make packages` (local only; nothing is published, see [ADR 0011](docs/adr/0011-delivery-is-the-same-as-longwires.md)).
