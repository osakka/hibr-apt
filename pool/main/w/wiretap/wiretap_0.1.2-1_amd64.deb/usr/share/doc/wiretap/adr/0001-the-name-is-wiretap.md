# 0001 — The name is wiretap

Status: accepted (chosen by the owner, 2026-11-05).

## Context

The brief was a GlassWire-style network monitor and firewall for hibr's desktop (hui). GlassWire is someone's product and
name; the repository directory is `hibr-glasswire` only as a working title.

## Decision

The product is **wiretap**: the command `wiretap`, the module `wiretap.so`, the service `wiretap.service`, the group
`wiretap`, the polkit actions `org.wiretap.*`. Its drop-down on the menu bar is **the Tap**.

## Consequences

Nothing ships under the name GlassWire. The plan is `docs/PLAN.md`; this repository mirrors longwire's tree one for one.
