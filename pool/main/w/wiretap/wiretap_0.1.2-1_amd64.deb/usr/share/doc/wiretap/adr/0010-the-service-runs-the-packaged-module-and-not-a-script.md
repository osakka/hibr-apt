# 0010 — The service runs the packaged module, not a script

Status: accepted (2026-11-06).

## Context

longwire's units run `longwire up …`, the launcher, which finds its script in the catalogue's directory. For longwire that
is acceptable: its worker clears every capability the moment its socket is open. wiretap's service holds `CAP_NET_RAW`,
`CAP_SYS_PTRACE` and `CAP_DAC_READ_SEARCH` for its whole life (ADR 0002).

## Decision

`packaging/systemd/wiretap.service` runs `/usr/bin/hibr -c 'mod load /usr/lib/hibr/wiretap.so; wt start --foreground …'`:
the module the package installed, and no script. The catalogue script (`cli/wiretap`) is the command people use; the service
does not need it and does not read the catalogue directory.

## Consequences

The one privileged process runs only code the package put there (hibr and the module), not a file a catalogue update or a
mistaken `catalogue --system install` could replace. The unit has no `WIRETAP_SCRIPTS`/`HOME` plumbing. The service's
options live in the unit's `ExecStart`, so changing them is a drop-in override (`systemctl edit wiretap`), not a script edit.
The unit is checked with `systemd-analyze verify` in `tests/package.sh`, but the capability grants have not been exercised in
a real service on this machine (needs root): that remains open, see SECURITY.md.
