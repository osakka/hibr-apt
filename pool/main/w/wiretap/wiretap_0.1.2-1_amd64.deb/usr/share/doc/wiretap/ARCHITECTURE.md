# Architecture

```
 kernel                        node (engine, plain C under TCC)                 faces (hibr scripts)
 /proc/net/dev  ──────────────▶ sampler ─▶ history rings (1s,1m,1h) ─▶ file ┐
 AF_PACKET frames ───────────▶ packet parser ─▶ 5-tuple ─┐                  │   control socket   ┌─ wiretap (CLI)
 /proc/net/{tcp,udp}{,6} ────▶ socket table ─────────────┼─▶ app totals ────┼──▶ /run/wiretap/ctl ├─ pane  ◀─ bar (Tap), strip, window
 /proc/PID/fd ───────────────▶ pid + comm by inode ──────┘                  │   (JSON lines)     └─ wtp_* is the one reader
```

- **Engine** (`engine/*.c`, never includes `hibr.h`): `hist.c` rings addressed by absolute time + persistence; `sample.c` the
  `/proc/net/dev` deltas; `pkt.c` frame to 5-tuple; `socks.c` + `procs.c` the join (ADR 0004); `apps.c` per-app totals and
  buckets; `json.c` bounded output; `node.c` the loop, the socket, the requests.
- **Module** (`module/wiretap.c`): the builtin `wt`, the glue between hibr and the engine. Forks the worker or runs it in the
  foreground (the service).
- **Faces** (`scripts/`, `control-panel/`, `menubar/`, `control-strip/`, `apps/`): hibr scripts. The pane owns the reader
  ([ADR 0005](adr/0005-the-pane-owns-the-node-reader.md)); the Tap, strip and window call it. Only the CLI talks to the socket
  by itself.
- **Requests**: `status`, `ifaces`, `apps`, `series [secs [count]]`, `stop`, one JSON object per reply, at most 256 KB.

## Decisions

See [adr/](adr/): 0001 the name, 0002 service privilege, 0003 worker fds, 0004 apps and buckets, 0005 the reader,
0006 the Tap, 0007 the strip, 0008 the window, 0009 history on disk, 0010 the service runs the module, 0011 delivery.
