# 0003 — The worker closes every descriptor it does not own

Status: accepted (2026-11-06).

## Context

`wt start` forks a worker. The first version only `dup2`ed `/dev/null` over fds 0, 1 and 2 (longwire's habit). Under
hibr, `$(wiretap on)` then hung forever: hibr keeps a saved copy of the command-substitution pipe's write end on a higher
descriptor, the worker inherited it, and the caller's read never saw EOF until the worker exited, which is never.
The same applies to any wrapper that captures output (`x=$(…)`, CI logs, `ssh host wiretap on`).

## Decision

After the daemonising child's `dup2`s, `wt_node_closeother()` closes every descriptor from 3 up except the control socket
and the packet socket (`engine/node.c`). `tests/ctl.sh` has a regression check: `$(wiretap on)` under a timeout must return.

## Consequences

A started worker holds exactly: stdio on `/dev/null`, the control socket, the packet socket. The loop is bounded by
`sysconf(_SC_OPEN_MAX)` capped at 65536; `close_range(2)` would be quicker but is not in every libc TCC links against.
longwire's `do_start` looks the same but is not affected: its engine already closes inherited descriptors when the worker
starts serving (`close_inherited`, which walks `/proc/self/fd`, since longwire 0.5.49). We checked by asking the longwire
session, which confirmed `$(lw start …)` returns at once and the worker holds only its own descriptors. Walking
`/proc/self/fd` is cheaper than our loop to the open-file limit and is a candidate to adopt here.
