# 0004 — Apps are keyed by command name; what cannot be owned goes in a named bucket

Status: accepted (2026-11-06).

## Context

Bytes are counted from packets; each packet's 5-tuple is joined to a socket inode (`/proc/net/{tcp,udp}{,6}`) and then to
a pid and `comm` through `/proc/PID/fd`. Three things can go wrong: no socket owns the packet, the owner's fds cannot be
read, or the table overflows. A silent drop would make the totals disagree with the interface counters.

## Decision

- An app is its `comm`. Three `python3` processes are one row; pid and uid shown are the last seen. GlassWire groups by
  program as well.
- Packets with no socket (kernel-owned: tunnels, forwarded, ICMP, or a socket that died before the table was read) go to
  `(unattributed)`, which always exists.
- A socket found but whose owner cannot be read goes to `(root)` or `(user N)`: the owner is known, the program is not.
- Table overflow goes to `(other)`.
- Misses trigger a rescan, at most every 100 ms with backoff to 2 s, with a negative cache of tuples that missed, so a
  burst of unowned traffic costs one rescan, not one per packet (`status.rescans` counts them).

## Consequences

Every byte lands in exactly one row, so rows sum to the capture total. Known limits (also in `PLAN.md`): programs that live
under about 100 ms can be missed; `comm` can be changed by the process, so a name is evidence, not proof.
