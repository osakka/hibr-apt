# 0008 — The window reads timescales through the pane, and averages them into columns

Status: accepted (2026-11-06).

## Context

The node keeps history at three resolutions (1 s, 1 min, 1 h) and `series <secs> <count>` returns raw samples. The window
shows 1 minute, 1 hour, 24 hours and 7 days across at most ~100 columns, so some timescales have more samples than columns.
Faces must not talk to the socket themselves (ADR 0005).

## Decision

`wtp_range scale cols` in the pane maps a scale to a resolution and count (1m: 60 x 1 s; 1h: 60 x 1 min; 24h: 1440 x 1 min;
7d: 168 x 1 h), fetches it, and averages groups of samples into at most `cols` **rates** (bytes per second, oldest first)
in `WTP_RI`/`WTP_RO`. The one-minute scale refreshes every second, the others every ten. Averaging is in the pane, not the
engine, because the engine's samples are the exact record and a display choice should not change what is stored; the cost is
measured, not guessed: 1440 `json get` calls take about 7 ms. The window is `apps/wiretap.hibr`, app id `wtview` (the pane
owns the prefix `wiretap`), a single window, two tabs: **Graph** (mirrored, one shared scale for both directions) and **Usage**
(a table of every app: pid, rate over the last 5 s, totals). Keys `1`-`4`, `g`, `u`, tab; clicks on the tabs and timescales;
every key is also in the menus.

## Consequences

Long timescales show the history the node has, which begins when the node started: until history persistence lands (see
PLAN, known gaps) a restart empties the 24-hour and 7-day views. The graph says "60 s ago ... now" and so on, but not yet
real clock times. Hover, a per-app ribbon (needs a categorical palette, see ADR 0006) and the alerts list are not here yet.
`tests/window.py` drives it on the real desktop; `tests/pane.sh` covers `wtp_range`.
