# 0012 — The service's dynamic user is not named like its group

Status: accepted. Corrects [0010](0010-the-service-runs-the-packaged-module-and-not-a-script.md).

## Context

0.1.0 shipped a unit with `DynamicUser=yes` and `Group=wiretap`. On a real machine (the owner's, 2026-11-06) it never started:
`status=217/USER`, `Failed to update dynamic user credentials: User or group with specified name already exists`. A dynamic user is
named after the unit (`wiretap`) unless `User=` says otherwise, and the package creates a group `wiretap` (ADR 0002, 0010):
systemd refuses a dynamic user whose name is an existing group. longwire's units escape it only because their names (`longwire-switchboard`,
`longwire@NIC`) differ from the group `longwire`.

None of our tests could see it: they run the module, the unit file is only checked with `systemd-analyze verify`, and no test runs
the unit under a real systemd (it needs root).

## Decision

- The unit says `User=wiretapd`: the dynamic user has a name of its own, and the group stays `wiretap`.
- A test checks that the unit names a user that is not the group.
- 0.1.1 carries the fix. 0.1.0, published, does not start under systemd: `wiretap on` (a node of your own) is the only way to use it until 0.1.1.

## Consequences

- A lesson for the roadmap: the service path needs a test under a real systemd, which means a root test. It is still unrun on the build machine.
