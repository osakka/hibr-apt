# Roadmap

| | State |
|---|---|
| **M0** | Done: the Tap proven live on the real desktop. |
| **M1** | Monitor. Done: engine, node, CLI, pane reader, the Tap, strip, window, history on disk, packages (built locally, not published). Open: pane settings (history length, alert rules), the alerts list and hosts view in the window, a categorical palette for a per-app ribbon, the capability test in a real service, publishing. |
| **M2** | Firewall: a table of its own (nftables), block/allow per app and per host/port, profiles, "ask before a new app talks" prompts, a root helper and polkit action `org.wiretap.rules`, fail-open on stop. Not testable on the build machine (`nft` is not installed). |
| **M3** | Alerts through the desktop's notifications, a usage report export, a per-host map where the terminal draws pixels. |

The design and its honest limits: [PLAN.md](PLAN.md).
