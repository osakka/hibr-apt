# 0007 — The strip module is one glyph and reads through the pane

Status: accepted (2026-11-06).

## Context

The Control Strip gives a module one cell. longwire's strip module reads the node through its pane's functions and shows
state by colour; the plan asks for the same here.

## Decision

`control-strip/wiretap.hibr` registers `wtstrip` (not `wiretap`: a pane called `wiretap` with a `wiretap_draw` would be
taken for one that draws itself). It is one glyph, `◎` (`o` on ascii), coloured `DT_DIM` when no node answers, `DT_INFO`
when the node is up and the machine is quiet, `DT_GOOD` while bytes moved in the last second. `DT_WARN` is reserved for
alerts and arrives with the alert rules. It reads only `wtp_poll`/`wtp_last` (ADR 0005); it is absent where the pane is
(`wtstrip_shown`). A click opens a menu with Wiretap Settings; the Tap stays on the bar.

## Consequences

Colour is the only channel for state here, so it is not enough on its own where colours are not distinguishable: the bar
item's text and the Tap carry the numbers. `tests/m0_tap.py` checks the glyph is drawn with the strip on; colour is unchecked.
