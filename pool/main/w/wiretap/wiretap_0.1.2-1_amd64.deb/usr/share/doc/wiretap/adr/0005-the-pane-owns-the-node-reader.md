# 0005 — The pane owns the node reader

Status: accepted (2026-11-06).

## Context

Five faces (window, Tap, pane, strip, CLI) all show data from one node. If each polled the control socket on its own, a
busy desktop would ask the same question several times a second, and each face would have its own idea of "no node".
longwire solves it with `lwp_poll`/`lwp_get` in its pane; the bar and strip call those (`# needs: control-panel/…`, `dt_has`).

## Decision

`control-panel/wiretap.hibr` holds the reader: `wtp_poll` (at most once a second: status, apps, last 60 s of series, into
parsed JSON holders), and `wtp_get`, `wtp_app`, `wtp_series`, `wtp_last`, `wtp_rate`. `WTP_UP` says whether a node answered,
`WTP_MOD` whether the module is installed, so the pane can say which one is wrong. The bar, the Tap and the strip declare
`# needs: control-panel/wiretap` and guard with `dt_has wtp_poll`. The module is found by `WT_MOD` (a file) else
`mod load wiretap` on the module path; nothing hardcodes `build/`. The socket is `WT_SOCK`, else `/run/wiretap/ctl`, else the
user's own, the same order as the CLI. The socket is looked for on every poll, so a service started after the desktop is found without a restart; `WT_SOCK` is exported from the pane, which means every program the desktop spawns inherits it (harmless: the CLI resolves it in the same order).

## Consequences

One poll per second regardless of faces. A face never talks to the socket directly. `tests/pane.sh` exercises the reader
without a desktop. The poll runs inside the desktop's single process, so it must stay fast: it is three short local
socket reads; if one ever blocks, the whole desktop does (the node already bounds slow clients, see `tests/ctl.sh`).
