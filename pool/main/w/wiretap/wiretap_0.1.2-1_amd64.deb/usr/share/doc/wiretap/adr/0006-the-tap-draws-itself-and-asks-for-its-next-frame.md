# 0006 — The Tap draws itself and asks for its own next frame

Status: accepted (2026-11-06).

## Context

The bar API has click, wheel and right-click, no hover, and the desktop sleeps until input. A drop-down that is only menu rows
cannot show a live graph. M0 proved on the real desktop that a `dt_baripop` panel's `_popdraw` can draw dense graphics and
keep itself live with `dt_want`.

## Decision

`menubar/wiretap.hibr` is the Tap. Its item shows an 8-cell sparkline of the last 8 seconds and the download rate
(`▂▇█▆▄ ↓136.7K`). A click opens a 21 x 50 panel drawn by `wtap_popdraw`: current rates and the scale, a 60-second mirrored
graph (download above the axis in `DT_GOOD`, upload below in `DT_INFO`, drawn with eighth-blocks, upload as the flipped block
with colours swapped), and the five busiest apps with one meter each. Download and upload share one scale, so the two halves
compare honestly; a quiet direction can be a blank row. The app meters use a single hue because they show a single measure
(download, last 5 s) and the biggest app sets the scale. `_popdraw` ends with `dt_want 1000`; the item with `dt_want 1500`.
Data is the pane's reader (ADR 0005), copied into arrays once per poll, not once per frame.

## Consequences

No node: the panel says why (module not installed / not running / join the group). The item and panel never talk to the
socket themselves. `tests/m0_tap.py` drives it on the real desktop through hibr's pty harness against a real node on a growing
`/proc/net/dev` fixture (no fake data): the bar item, the click, the drawn panel and a redraw with no input. Colours and Blit
pixel rendering are not checked by it (text only). Categorical per-app colours are deferred: `lib/colours.hibr` has no
categorical palette, so the window's per-app ribbon needs one chosen deliberately (a later ADR).
