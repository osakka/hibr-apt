# 0009 — History is saved whole, and checked slot by slot on load

Status: accepted (2026-11-06).

## Context

The rings (1 s x 1 h, 1 min x 24 h, 1 h x 30 d) lived in the process, so a restart emptied the 24-hour and 7-day views,
a gap that PLAN.md listed under known M1 gaps. The rings are addressed by absolute time (`ts / resolution`), so a stretch
with no samples is simply old tags and there is no roll-up state to lose.

## Decision

- `--state FILE` (`wt start`, `WT_STATE` in the CLI) names one history file. The engine writes `FILE.tmp` (mode 0600,
  `O_NOFOLLOW`) then renames it over `FILE`: once a minute from the sampler, and on a clean stop (SIGTERM, `stop`).
- The file is a header (magic `WTHIST01`, a byte-order probe, the three capacities) and the three rings as in memory:
  about 138 KB. It is for this build on this machine; any mismatch is "not a wiretap history for this build" and the node
  starts empty and says so in `status.state_note`. There is no migration: change the capacities and the version of the
  magic, and the old file is ignored.
- On load every slot is kept only if its tag lands in its own index, is not in the future (a clock that went backwards, or
  a hand-made file) and is not older than the ring. A symlink at the path is refused. Per-app totals are not saved: they are
  a session view, and an app's identity (pid, comm) does not mean the same thing after a restart.
- `status` reports `state_loaded` (slots read back) and `state_note` (the last load or save problem, empty if none).
- No state path, no file: tests and `--no-capture` runs stay in memory. The CLI defaults to
  `$XDG_STATE_HOME/wiretap/history` (the service will use its `StateDirectory`, with the packaging).

## Consequences

A crash loses at most the last minute. The time the node was down shows as a gap, which is true. A damaged file never stops
the node starting. The file holds traffic volume per second for a month: it is as sensitive as the counters it came from and
is 0600 in the user's state directory or the service's.
