# wiretap on the desktop

Every face reads the node through the pane's reader (`control-panel/wiretap.hibr`, [ADR 0005](adr/0005-the-pane-owns-the-node-reader.md)).
With no node they say why (module not installed / not running / join the group `wiretap`).

| Face | File | What you see | Keys / clicks |
|---|---|---|---|
| Menu bar item | `menubar/wiretap.hibr` | the tap badge; with the pane's switches also `▂▇█▆▄` (last 8 s) and `↓136.7K` | click opens a menu: Show the Graph (the Tap), Open Wiretap…, Settings… ([ADR 0015](adr/0015-the-bar-is-the-tap-and-a-menu.md)) |
| The Tap | same file, `wtap_popdraw` | rates, a 60 s mirrored graph, the 5 busiest apps | live: redraws each second with no input ([ADR 0006](adr/0006-the-tap-draws-itself-and-asks-for-its-next-frame.md)) |
| Control Strip | `control-strip/wiretap.hibr` | one `◎`: dim = no node, info = quiet, good = bytes moving | click: Wiretap Settings ([ADR 0007](adr/0007-the-strip-module-is-one-glyph-and-reads-through-the-pane.md)) |
| Pane | `control-panel/wiretap.hibr` | engine state, capture state, unreadable processes, rates, top apps, Menu Bar Item switch | |
| Window | `apps/wiretap.hibr` (`wtview`) | Graph and Usage tabs, four timescales ([ADR 0008](adr/0008-the-window-reads-timescales-through-the-pane.md)) | `1`-`4` timescale, `g`/`u`/tab view, up/down in Usage |

Colour: download is the desktop's good colour, upload its info colour, dim is idle. Where the glyph set is ASCII the
strip glyph is `o`; the graphs use block characters throughout.

## Alerts

Two notifications, from the same poll the bar makes ([ADR 0014](adr/0014-alerts-from-the-same-poll.md)): a program talking for the first time (the first run takes everything talking as known) and a program uploading 4 MB/s or more, averaged over 5 seconds (`WT_BIG` in bytes a second; once in ten minutes per program). Both are switches in the pane under Alerts; they run while the menu bar item is shown.
