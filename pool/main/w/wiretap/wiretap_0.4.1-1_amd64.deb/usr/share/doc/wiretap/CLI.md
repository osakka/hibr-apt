# wiretap on the command line

`wiretap` is a hibr script (`scripts/wiretap.hibr`) over the module's `wt` builtin. Everything here is read-only: nothing
changes a firewall (that is M2, see [PLAN](PLAN.md)). The command is a catalogue script (`catalogue install cli/wiretap`); the package ships the engine and the launcher `/usr/bin/wiretap`. The service is `systemctl enable --now wiretap` ([SECURITY](SECURITY.md)).

| Command | What it does |
|---|---|
| `wiretap` | turn it on if it is off, then say how it is |
| `wiretap on` / `off` | start the node in the background / stop it |
| `wiretap show` | is it running, is it seeing packets, how many processes could it not read |
| `wiretap top [N]` | the busiest N programs now (their last five seconds), with a total each |
| `wiretap usage [N]` | the programs that have used the most since the node started |
| `wiretap hosts [N] [--names]` | the biggest N remote addresses (default 20): the program that last spoke to each, bytes down and up, seconds since; `--names` looks each up (the service cannot) |
| `wiretap graph [SECONDS] [ROWS]` | a mirrored graph: download above the line, upload below, hung from it |
| `wiretap watch` | `top`, refreshed every second; Ctrl-C leaves, the node goes on |
| `wiretap status` | the node's raw status, JSON |
| `wiretap version` | this script's version, the installed engine's, and the running node's |
| `wiretap fw` | the firewall rules, numbered (`fw list` is the same) |
| `wiretap fw block\|allow HOST [PORT] [--tcp\|--udp] [--in] [--uid N] [--cgroup /PATH] [--first]` | add a rule (at the end; `--first` puts it at the top, where an allow can override a later block). A port needs `--tcp` or `--udp`. Checked here first, then applied by the root helper after an administrator's password |
| `wiretap fw rm N` | take rule N out |
| `wiretap fw on` \| `off` | apply the kept rules again, or take the firewall table away (the rules stay) |
| `wiretap fw render` | print the nftables script the rules become; changes nothing |
| `wiretap doctor` | whether it can see everything, what is out of step, and, with no node, how to start one |

`--json` after `top`, `usage`, `hosts`, `graph` or `show` prints the node's JSON instead of the table.

```
$ wiretap usage
APP                      PID    DOWN/s      UP/s     TOTAL
wtclient             3430782        0B     61.0K    305.2K
wtserver             3430457     61.0K        0B    305.2K
```

A row marked `?` could not be tied to a program. `(root)` and `(user N)` are traffic on sockets whose owner the node is
not allowed to read; `(unattributed)` is traffic no socket owns (a tunnel, forwarding, ARP).

## Where it looks

- **The socket:** `WT_SOCK`; else `/run/wiretap/ctl` (the system service); else `$XDG_RUNTIME_DIR/wiretap/ctl`; else `~/.wiretap/ctl`.
- **The module:** `WT_MOD` (a path), else the module search (`mod load wiretap`).
- **`WT_STATE`:** the history file `wiretap on` hands the engine (default `$XDG_STATE_HOME/wiretap/history`, else `~/.local/state/wiretap/history`); `WT_STATE=none` keeps history in memory only. The engine saves it every minute and on a clean stop, and reads it back at start, so graphs survive a restart (ADR 0009).
- **`WT_ARGS`:** extra options for `wiretap on`, for example `--no-capture`.

## Seeing every program needs the service

A node you start yourself runs as you: it sees your own processes and, without `CAP_NET_RAW`, no packets at all
(`wiretap doctor` says so). The system service holds the three capabilities of [ADR 0002](adr/0002-the-service-may-read-every-process.md)
and sees the whole machine. Apps are keyed by command name: three `python3` processes are one row.

## The firewall

Rules are plain lines in `/etc/wiretap/rules` (`ACTION DIR PROTO WHO HOST PORT`, [ADR 0022](adr/0022-the-firewall-rules-and-their-nftables-script.md)); the first match wins and anything else is allowed. `wiretap fw` edits them through `/usr/libexec/wiretap-rules` and pkexec ([ADR 0025](adr/0025-the-root-helper-and-the-polkit-action.md)): a bad rule is refused before any password is asked, a rule `nft` rejects changes nothing, and a failed apply removes the firewall table, so the machine is left open. It needs the `nftables` package. Examples:

```
wiretap fw block 93.184.216.34 443 --tcp         # nobody talks to that address on https
wiretap fw block any --uid 1001                  # one user may not use the network
wiretap fw allow 10.0.0.0/8 --first              # the local network is always fine
wiretap fw block 0.0.0.0/0 --cgroup /user.slice/user-1000.slice/user@1000.service/app.slice/app-foo.scope
wiretap fw off                                   # open, until   wiretap fw on
```

A program is told apart by its cgroup, so only programs that run in their own scope or service can be blocked by themselves (ADR 0022).
