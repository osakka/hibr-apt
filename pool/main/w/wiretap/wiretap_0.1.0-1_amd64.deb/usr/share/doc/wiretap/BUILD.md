# Build, test, package

Needs `tcc`, hibr >= `HIBR_MIN` with its headers (`HIBR_SRC`, default `../hibr`), python3; for packages `dpkg-deb`, `fakeroot`,
`objdump`, `rpmbuild`, `makepkg`.

```
make              # build/wiretap.so (TCC only; `make CC=...` is ignored on purpose)
make check        # lint, then every suite: engine units (under TCC's bounds checker), the node, the control socket,
                  # real packet capture in an unprivileged namespace, the CLI, the pane reader, the Tap and the window on
                  # the real desktop through hibr's pty harness, the docs, the packages
make packages     # build/pkg: wiretap_<v>-1_<arch>.deb, then .rpm and .pkg.tar.zst from the deb's files
sh packaging/bump.sh X.Y.Z   # the one way to change the version
```

Building a package is local and publishes nothing ([ADR 0011](adr/0011-delivery-is-the-same-as-longwires.md)).
Publishing to the hibr apt/rpm/arch repositories and the catalogue is a deliberate separate step, and needs the owner.
