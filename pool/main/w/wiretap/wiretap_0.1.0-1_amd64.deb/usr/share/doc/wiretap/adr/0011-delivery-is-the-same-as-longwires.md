# 0011 — Delivery is the same as longwire's

Status: accepted (2026-11-06).

## Context

The brief: "the same delivery to the end user mechanism (exact same style) as longwire". longwire ships an engine and a launcher
as deb, rpm and pacman packages, and every script and desktop piece through hibr's catalogue as one bundle.

## Decision

- **Packages** (`packaging/deb|rpm|arch`): the module `/usr/lib/hibr/wiretap.so`, the launcher `/usr/bin/wiretap`, the unit, the
  sysusers group, manual pages and documentation. The deb is built first with `make packages`; the rpm and the pacman package are
  built from the deb's own files, so the three cannot differ. The package depends on hibr >= `HIBR_MIN` and on libc at the
  newest symbol version the module uses, read from the built module.
- **Catalogue** (`bundles/wiretap.json`): `cli/wiretap`, `control-panel/wiretap`, `menubar/wiretap`, `control-strip/wiretap`,
  `apps/wiretap`; `catalogue install wiretap` then Refresh Desktop.
- **First run**: `postinst` creates the group `wiretap` and adds the installing user (`SUDO_USER` or `PKEXEC_UID`) to it, and
  prints that a fresh login is needed; anyone else is told the `usermod` command.
- `packaging/bump.sh X.Y.Z` is the one way to change the version.
- **Nothing is published** to hibr-apps, hibr-apt, hibr-rpm or hibr-arch from this repository by a build, and nothing is
  published without the owner's say-so: building a package is local; publishing is a separate, deliberate step.

## Consequences

An installed machine has the engine from the package manager and the scripts from the catalogue, as with longwire; the CLI and
the desktop pieces are released independently of the engine. No polkit action ships in M1 (nothing here needs root after
install); M2's firewall adds `org.wiretap.rules`.
