# 0041 — A reading that never lands must not blank the window

Status: accepted (0.8.3)

## Context

ADR 0031 moved every read of the node into background jobs, and the window draws nothing until the first reading has landed (`WTP_SEEN`), so that a frame never says "no node" while the answer is only on its way. The owner then reported that the Wiretap window showed no graph, no hosts and no map (the menu-bar drop-down worked), minutes after a restart and an hour after the node was up, on a desktop that had been running since two days earlier and had been restarted in place. The node, the CLI and the pane's reading code run headless on that machine were all fine; the same scripts drew correctly on the development machine. The window gave no sign of what it was waiting for.

Two silent, permanent states were possible in the code:
1. **The fallback did not count.** When a job could not be started, the reading was made on the spot, but `WTP_SEEN` was not set, so the window stayed blank for good while the drop-down, which draws from the reading itself, worked.
2. **A lost answer left the flag set.** A job's completion is what clears its "busy" flag. If a completion never arrived, no job was ever started again, and with no first reading the window stayed blank.

## Decision

1. The fallback read counts as the first reading (`WTP_SEEN=1`).
2. Each job (the reading, the hosts, the graph, the programs) records when it started. One that has not come back in 20 seconds is taken as lost, `desktop.log` says so (`wiretap: the reading job did not come back in 20 s; starting another`), and the next call starts another.
3. While there is nothing to show, the window is silent for three seconds and then says `Waiting for the first reading from the node (Ns)...`, and from six seconds what the job state is (reading job running, module loaded, node answering), so a blank window is never unexplained again.

## Honest limits

I could not reproduce the owner's blank window; the cause on that machine is unconfirmed. These are the two ways the code could stay blank for good that I found; the note in (3) is there so that, if it is something else, the next report says what the window was waiting for.
