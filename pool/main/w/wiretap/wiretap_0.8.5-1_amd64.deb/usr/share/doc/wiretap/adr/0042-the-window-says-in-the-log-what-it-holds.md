# 0042 — The window says in the log what it holds

Status: accepted (0.8.4)

## Context

The owner's Wiretap window (not the drop-down) kept drawing zero rates, an empty plot and empty Hosts and Map tabs, on a mini PC whose node, group, socket, CLI and headless readings were all healthy. A fresh window, opened from the Applications menu so it had a clean record, did the same. The window drew its tabs, so the first reading had landed and the node had answered; what did not arrive was the series (and the graph, hosts and map that are built from jobs). Run through the desktop's own job code, in a fresh shell and in a fresh isolated desktop on that machine, the same files filled in. Nothing the window kept anywhere said where the answer went.

## Decision

The reader says what it holds, in `desktop.log`, from the numbers it already has (no fork):

1. **A thin reading.** When the node answered (`WTP_UP=1`) but the series did not arrive, at most once every 30 s: `wiretap: the node answered but the series did not arrive: job N status S printed L lines, series keys K, apps keys A, why: ...`. `why` is set by the job itself (`WTP_WHY`, carried back with the other variables): `series: wt failed`, `series: parse failed (N bytes)`, and the same for the apps.
2. **A minute line.** Once a minute: `wiretap: reading up=1 seen=1 series keys K apps keys A graph columns C hosts H programs P busy r=.. h=.. why: ...`, so one reopen shows what the desktop holds against what the node holds.

Both lines only exist in a desktop (`dt_log`); the CLI never calls them.

## Consequences

- A blank window now leaves a line saying whether the child printed the data, whether it parsed, and whether it arrived. A cause that is in the window's own timing or in the desktop around it (a ghost window record making the desktop log 20 errors a second and stall its ticks, hibr #552) will show as a reading that is thin, late, or lost in the log's own lines.
- One log line a minute is not a cost.
- This is evidence, not a fix: no behaviour changes.

## Addendum (0.8.5): the graph job

The 0.8.4 lines on the owner's machine showed the reading landing (up=1, series keys 5, apps keys 2) while the graph columns, hosts and programs stayed 0, with nothing busy and no "series did not arrive" line, in a window that was open and drawing. The graph, and with it the programs, are built from their own job (`wtp_range`), so the evidence has to cover that one too. The minute line now carries how many times the graph was asked for, how many jobs were started and how many landed, the key and the request; and a graph job that lands with no columns says so, at most every 30 s, with the request, how many lines the job printed, how many keys arrived and the reason the job found (`wt series [..] failed`, `parse failed (N bytes)`).
