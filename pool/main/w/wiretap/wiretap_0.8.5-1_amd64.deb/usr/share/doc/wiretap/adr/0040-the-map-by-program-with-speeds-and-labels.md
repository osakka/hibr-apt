# 0040 — The Map by program: roll-ups, speed now, plain labels, one detail line

Status: accepted (0.8.1); reworks the layout of [0039](0039-the-map-tab-flow-layout.md)

## Context

0.8.0's Map listed the biggest hosts as lines on a linear scale, tested only on a two-host fixture. On the owner's own list it was "too raw, not very useful", and it could not be clicked. The real data explains why: this machine has 413 hosts, one of them holding 15 GB while the median holds 2.7 MB, so on a linear scale nearly every line is one cell; the 21 rows that fit showed 21 of 413 hosts; one program (`chromium`) has 48 hosts and another label, `(unattributed)`, has 79. Bytes are totals since the node started, so a host that was heavy yesterday looked as busy as one that is busy now.

## Decision

1. **Roll up by program.** A row per program (the biggest first): its host count, bytes down and up, and its speed now. Under it its three biggest hosts, then `+N more`; Enter or a click opens the rest (and closes them again). Selection follows the row (the program or the address), not its place, so it does not jump when the order changes.
2. **A line is speed now.** The change in a host's total since the last reading, per second, on a log scale (a byte a second and a gigabyte a second are both a few steps long); heavy (`━`) within a factor of four of the fastest. A quiet host is a dot, `idle`, faded. The number beside it is the total since the node started. The first reading has no speed yet and says so (`…`) rather than claiming zero.
3. **Plain labels without a lookup.** A private, loopback, link-local, shared (100.64/10) or multicast address is labelled from the address alone (`local net`, `this machine`, `link-local`, `shared net`, `multicast`); a public address has none. `n` stays opt-in (ADR 0036).
4. **One detail line** under the list: for a host its address, label, whether a rule names it, bytes each way, when first and last seen, and the program that last spoke to it; for a program, a sentence (and what `(unattributed)` means: traffic seen on the wire whose program could not be told).
5. **Mouse.** The Map tab and every row can be clicked; the View menu has Map. A click on a program or `+N more` opens it; on a host it selects it, and `b` acts on that host.
6. **Built off the desktop's thread** (ADR 0031). The model is made in the job that fetches the hosts and handed back packed: one row per host (fields joined by the unit separator, the program's name last so it can hold anything without moving a number), and the program tables. Landing it costs a few milliseconds; the 195-host build, about 11 ms, runs in the job. The window rebuilds only its row list, when a reading lands or a program is opened. Every number is made all digits before anything computes on it, so a program's name can never become arithmetic; a test feeds a name holding the separator and a command and checks nothing runs.

## Honest limits

- A host is listed under the program that **last** spoke to it: the node keeps one program per host. Two programs talking to one server cannot both be shown, and a line's bytes are the host's, not the program's. Counting per program and host is an engine change of its own.
- Speeds are averaged over the two seconds between readings.
- Only the first 200 hosts the node returns are read (it holds more); the title row says `N of M hosts`.
- Text cells only. The world layout and the setting to switch layouts wait for a free address database file the user supplies (0039).

## Addendum (0.8.2): a young node says so

A package upgrade restarts the node (ADR 0032's `try-restart`), and a restarted node has seen nothing yet: the graph reads 0/0, Hosts and the Map are empty. On the owner's report of exactly that, the mini PC's node had restarted about two minutes before it was read, and was serving hosts and samples by then; a window opened with no node picks the node up when it starts (checked), so nothing was broken, but the empty screens looked like a fault. While the node is under two minutes old (from its own start time and clock) the graph shows `node started 12s ago` beside the rates, and an empty Hosts or Map says the same and that hosts appear as traffic is seen. The node's hosts are not saved across a restart, only the history.
