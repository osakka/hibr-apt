# 0015 — The bar item is the tap alone, and a click opens a menu

Status: accepted. Changes [0006](0006-the-tap.md) (the item's text and what a click does).

## Context

The owner did not like the bar item's heading: the tap, then a sparkline, then the rate, all at once. And a click went straight to the
graph popup; they wanted a context menu first.

## Decision

- The item is **the tap badge** (ADR 0013), and nothing else by default. The **sparkline** (`DT_WTGAUGE`) and the **download rate** (`DT_WTRATE`) are
  two more switches in the pane, each off until turned on, under the existing *Menu Bar Item* switch.
- **A click, or a right-click, opens a menu** (`wtb_context`): how it is going (down and up now, or that no node runs), *Show the Graph* (the
  Tap's popup, as before), *Open Wiretap…* (the window) and *Wiretap Settings…*.
- With the tap missing from this Blit and the two switches off, the item says `net`, so there is still something to click.

## Consequences

- Old users who relied on the sparkline and rate must turn them on once; the defaults are the owner's choice.
- `tests/m0_tap.py` checks the menu, that *Show the Graph* then opens the popup, and that the default bar has no `↓`.
