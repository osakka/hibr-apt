# 0043 — The pane's on/off rows are checkboxes

Status: accepted (0.8.6)

## Context

hibr 0.99.534 (#558) treats a Control Panel `set` row that is not `wtype=bool` or a slider as a dropdown, and draws a caret for it. Every `set` row in the Wiretap pane is an on/off switch (the alerts, the menu-bar item, its graph and rate, the firewall), so each would have shown a caret that opens nothing. The pane also carried an empty `wiretap_drop` stub, which hibr's panel took as a reason to treat the rows as dropdowns.

## Decision

Each on/off row carries `CP[$w][$n]["wtype"]=bool`, which the panel draws as a checkbox a click switches, and the empty `wiretap_drop` stub is removed. No version floor changes: older panels ignore `wtype` and still switch the row on a click.

## Consequences

The rows look and behave like every other pane's switches. Nothing in the reader or the window changes.
