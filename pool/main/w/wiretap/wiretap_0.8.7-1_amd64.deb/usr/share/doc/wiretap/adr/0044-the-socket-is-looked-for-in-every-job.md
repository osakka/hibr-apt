# 0044 — The socket is looked for in every job

Status: accepted (0.8.7)

## Context

The pane's reader chose the node's control socket in the reading job and carried the result (`WT_SOCK`) back to the desktop with the job's other variables. From then on `wtp_sock` returned that value for every later job, so a desktop kept the first node it found: if that node went away and another came up elsewhere (a user's own node, then the service, or the other way round), the desktop kept asking the old path. The comment on the line said the socket was looked for every poll, which was not what happened. On the owner's machine only one socket existed and it was live, so this was not what blanked the window, but it was a real latent fault found while looking.

## Decision

1. `wtp_env` looks the socket up (`wtp_sock`) and exports it, and every job calls it first: the reading, the graph, the hosts and the programs. What it sets lives in the job and is not carried back.
2. `WT_SOCK` is no longer in the reading job's list of returned variables. The desktop's own `WT_SOCK` stays whatever the user set, and `wtp_sock` still honours it first, then the service's `/run/wiretap/ctl`, then the user's own socket, as the command does.

## Consequences

A node that moved or came up later is found by the next job without a restart. Nothing else changes.
