# Roadmap

| | State |
|---|---|
| **M0** | Done: the Tap proven live on the real desktop. |
| **M1** | Monitor. Done: engine, node, CLI, pane reader, the Tap, strip, window, history on disk, packages (published, 0.1.x), the tap logo (ADR 0013), the service verified under a real systemd (ADR 0002, 0012), two alerts (ADR 0014). Open: a history-length setting, the alerts list and a hosts view in the window, new-host alerts (needs hosts in the engine), a categorical palette for a per-app ribbon, the one-cell tap for the strip. |
| **M2** | Firewall: a table of its own (nftables), block/allow per app and per host/port, profiles, "ask before a new app talks" prompts, a root helper and polkit action `org.wiretap.rules`, fail-open on stop. Not testable on the build machine (`nft` is not installed). Started: the rules text and its nftables script, pure and tested ([ADR 0022](adr/0022-the-firewall-rules-and-their-nftables-script.md)); `wt fwapply`/`fwoff` check, apply and fail open ([ADR 0024](adr/0024-applying-rules-check-then-apply-then-fail-open.md)); the root helper, polkit action and boot unit ([ADR 0025](adr/0025-the-root-helper-and-the-polkit-action.md)); `wiretap fw` in the CLI ([ADR 0026](adr/0026-wiretap-fw-in-the-command.md)); the pane's Firewall section ([ADR 0027](adr/0027-the-firewall-section-of-the-pane.md)); `b` in the Hosts tab blocks a host ([ADR 0028](adr/0028-block-a-host-from-the-hosts-tab.md)); the Firewall tab, and block or allow by program or host with protocol and port ([ADR 0029](adr/0029-block-and-allow-from-the-window.md)); a new-program note opens the window on it; asking before the first packet is declined ([ADR 0030](adr/0030-ask-after-not-before.md)); next: profiles, per-program history for the longer timescales. |
| **M3** | Alerts through the desktop's notifications, a usage report export, a per-host map where the terminal draws pixels. |

The design and its honest limits: [PLAN.md](PLAN.md).
