# wiretap on the desktop

Every face reads the node through the pane's reader (`control-panel/wiretap.hibr`, [ADR 0005](adr/0005-the-pane-owns-the-node-reader.md)).
With no node they say why (module not installed / not running / join the group `wiretap`).

| Face | File | What you see | Keys / clicks |
|---|---|---|---|
| Menu bar item | `menubar/wiretap.hibr` | the tap badge; with the pane's switches also `▂▇█▆▄` (last 8 s) and `↓136.7K` | left click opens the graph (the Tap); right click opens a menu: Open Wiretap…, Settings… ([ADR 0015](adr/0015-the-bar-is-the-tap-and-a-menu.md), [0017](adr/0017-left-click-the-graph-right-click-the-menu.md)) |
| The Tap | same file, `wtap_popdraw` | rates, a 60 s mirrored graph, the 5 busiest apps | live: redraws each second with no input ([ADR 0006](adr/0006-the-tap-draws-itself-and-asks-for-its-next-frame.md)) |
| Control Strip | `control-strip/wiretap.hibr` | one `◎`: dim = no node, info = quiet, good = bytes moving | click: Wiretap Settings ([ADR 0007](adr/0007-the-strip-module-is-one-glyph-and-reads-through-the-pane.md)) |
| Pane | `control-panel/wiretap.hibr` | engine state, capture state, unreadable processes, rates, top apps, the alerts and Menu Bar Item switches, and a Firewall section: the kept rules (first five) and a switch that loads or removes the table, asking an administrator ([ADR 0027](adr/0027-the-firewall-section-of-the-pane.md)) | |
| Window | `apps/wiretap.hibr` (`wtview`) | Graph, Usage, Hosts, Firewall and Map tabs, four timescales ([ADR 0008](adr/0008-the-window-reads-timescales-through-the-pane.md), [0018](adr/0018-the-hosts-tab-in-the-window.md)) | `1`-`4` timescale, `g`/`u`/`h`/tab view, `c` colour by program, `m` the Map (programs and the hosts they talk to, a line for each; [ADR 0039](adr/0039-the-map-tab-flow-layout.md)), `n` in Hosts shows names (off by default; asks your name server, [ADR 0036](adr/0036-names-on-the-hosts-tab-on-request.md)), up/down in Usage and Hosts, `f` the Firewall tab (on or off, the rules, `x` removes one, space turns it on or off), `b` in Usage or Hosts blocks or allows the selected program or host: block or allow, protocol, port; `✕` and `✓` mark them ([ADR 0028](adr/0028-block-a-host-from-the-hosts-tab.md), [0029](adr/0029-block-and-allow-from-the-window.md)) |

Colour: download is the desktop's good colour, upload its info colour, dim is idle. Where the glyph set is ASCII the
strip glyph is `o`; the graphs use block characters throughout.

## Alerts

Two notifications, from the same poll the bar makes ([ADR 0014](adr/0014-alerts-from-the-same-poll.md)): a program talking for the first time (the first run takes everything talking as known) and a program uploading 4 MB/s or more, averaged over 5 seconds (`WT_BIG` in bytes a second; once in ten minutes per program). Both are switches in the pane under Alerts, and clicking a note opens the window on Usage (a new host: on Hosts), where `b` blocks or allows it ([ADR 0030](adr/0030-ask-after-not-before.md)); they run while the menu bar item is shown. A third, off by default, tells of a program reaching a new public host, a note a minute at most ([ADR 0021](adr/0021-new-host-alerts.md)).

## Colour

Each program has its own colour across the Tap, the Usage tab and the Hosts tab (eight validated hues in a fixed order, a swatch before the name; the buckets in brackets are DIM). See [ADR 0019](adr/0019-one-colour-per-program.md).

The window's 1-minute graph is a stacked ribbon by program, with a legend (`c` switches it off): [ADR 0020](adr/0020-the-colour-ribbon-from-per-program-history.md). The hour, day and week are ribbons too, from a per-program history the node keeps and saves ([ADR 0032](adr/0032-a-programs-day-and-week.md)); the colours are the same on every scale.
