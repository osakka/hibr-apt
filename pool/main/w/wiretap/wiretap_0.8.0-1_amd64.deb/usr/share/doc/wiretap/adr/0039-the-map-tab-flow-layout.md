# 0039 — The Map tab: a flow layout of programs and the hosts they talk to

Status: accepted (0.8.0)

## Context

The Hosts tab is a table. It is exact, but you cannot see at a glance that one program fans out to forty hosts, which conversation is the heavy one, or which went quiet. The roadmap named a per-host map. The owner asked for two layouts (a flow and a world map) as a setting, free of charge, and without complication; the flow comes first.

## Decision

1. **A fifth tab, Map (`m`, and after Firewall in the tab cycle).** Its first layout is **Flow**: programs on the left, the remote hosts on the right, one line per conversation, grouped under the program as a tree (`┬ ├ └`) so no lines cross.
2. **A line is bytes.** Its length is the host's total bytes against the biggest shown (at least one cell); its weight is heavy (`━`) from a fifth of the biggest and thin (`─`) below; its colour is the program's (ADR 0019). A host not heard from for a minute is drawn faded. A blocked host carries `✕`, an allowed one `✓`, as in Hosts.
3. **Same data, same keys.** The rows come from the Hosts list (`wtp_hosts`), the biggest first, as many as fit. Up and down select, `b` blocks or allows the selected host through the same dialog, `n` turns names on (ADR 0036). The order drawn differs from the list's, so the window keeps it (`WV_ORD`) and `b` acts on the host at the selected row.
4. **Text cells only.** It runs in any terminal and is tested here. No new reads, no forks in a frame (ADR 0031), no new privilege.

## Not done

- **A layout setting and the World layout.** The world map needs a dataset mapping addresses to places. It would be a free database file the user supplies, read locally and never fetched; nothing is bundled and nothing is sent. Until one exists, Flow is the only layout, so there is nothing to choose.
- Pixel drawing of the lines on a terminal that supports it.
- Scrolling: only as many hosts as fit are shown.
