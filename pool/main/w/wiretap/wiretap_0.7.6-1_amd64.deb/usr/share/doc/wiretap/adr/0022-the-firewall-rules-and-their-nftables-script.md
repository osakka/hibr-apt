# 0022 — The firewall: rules as text, one script, a table of its own, open on failure

Status: accepted (the renderer is built; the helper that applies it is not). Starts M2 of [PLAN](../PLAN.md).

## Context

M2 is a firewall: block or allow by program, host and port. Three facts shape it. Applying rules needs root, and the monitor
(ADR 0002) deliberately is not root. A wrong rule can cut a machine off from the network. And `nft` is not installed on the build
machine, so nothing that talks to the kernel can be tested here; what can be tested is everything before it.

## Decision

- **Rules are lines of text**, `ACTION DIR PROTO WHO HOST PORT`, first match wins, nothing matching is allowed:
  `block out tcp uid:1000 93.184.216.34 443`. WHO is `any`, `uid:N` or `cgroup:/path`; HOST is `any`, an address or `ADDR/PREFIX`;
  PORT is `any`, `N` or `N-M`. A rule file is plain text a person can read, diff and keep in git.
- **`engine/fw.c` turns that text into an nftables script, and is pure**: no socket, no process, no `nft`. Every field is parsed
  and printed again from the parsed value (addresses through `inet_pton`/`inet_ntop` with host bits cleared, numbers as numbers, a
  cgroup path only from `[A-Za-z0-9_.@:-]` parts with no `..`), so nothing from the input reaches the script as typed. The privileged
  helper will run exactly this output through `nft -f -` and nothing else. At most 256 rules.
- **A table of its own**, `inet wiretap`, replaced in one transaction (`add table`, `delete table`, define). Wiretap never touches
  another table, so it cannot damage firewalld, ufw or hand-written rules; it only adds its own hook beside them.
- **Fail open.** Both chains have `policy accept`, loopback is accepted first, and deleting the table (service stop, helper failure,
  empty rule file) returns the machine to how it was. There is no default-deny mode in this step; "ask before a new app talks"
  needs the desktop to answer in time and comes later, as its own decision.
- **Per program means per cgroup, and that is a limit.** nftables cannot match a program name. It can match the owner uid
  (`meta skuid`) and the cgroup v2 path of the sending socket (`socket cgroupv2 level N "path"`, so N is the path's depth). A program
  launched as its own scope or service (flatpak, snap, `systemd-run`, most desktop launchers) has its own cgroup and can be told
  apart; two programs sharing a terminal's cgroup cannot. The window will offer a program's cgroup only when it is distinct.
- **Outgoing rules can name the owner; incoming cannot** (a packet has no socket yet), so `WHO` must be `any` for `in`.
- `wiretap`'s module gains `wt fwrender FILE` (or `-` for stdin): prints the script, changes nothing.

## Applying: the `nft` binary, in a separate root helper, not libnftables

The question is not "library or binary in the module". The module runs inside the monitor, which is unprivileged and whose unit
sets `RestrictAddressFamilies=AF_UNIX AF_PACKET`; changing rules needs AF_NETLINK and CAP_NET_ADMIN. So applying lives in a
separate root helper, and the choice is library or `execve` inside that helper. We choose `execve`:

1. **Licence, verified.** Debian's copyright file for `libnftables1` 1.0.6 lists `src/libnftables.c` and its header as `GPL-2`, not
   "or later". That cannot be combined with this project's GPL-3.0-or-later in one linked program, and `dlopen` does not clearly
   escape that.
2. **Dependencies.** libnftables needs libnftnl, libmnl and gmp; the project is TCC and libc only (Makefile, BUILD.md).
3. **No gain that matters.** What it would add is in-process structured errors. `nft -c -f -` already checks the script, and its
   stderr goes back to the pane verbatim. Rules change a few times a day; a fork costs nothing.

The helper `execve`s `/usr/sbin/nft` with a fixed argument list and no shell: `nft -c -f -` and then `nft -f -`, with the script from
`wt_fw_render` on stdin. Revisit only if the binary proves a problem on a target distro.

## Not yet decided

Package dependencies when the helper ships: `nftables` as a Recommends in the three packagings (ADR 0025 decided against a hard dependency). A missing `/usr/sbin/nft` must fail open with a clear error to the pane, never a silent no-op; confirm the path
once on Fedora and Arch (usr-merge). The apply helper and its polkit action (`org.wiretap.rules`), how the service and the helper share state, profiles, and the
prompt for new programs. Each is a later ADR. Per-(program, host) pairs in the engine are not needed for the rules above; they are
for a "block this host for this program" suggestion in the Hosts tab, which can use the existing one-row-per-address view meanwhile.

## Consequences

- `tests/fw.sh` checks the script text for each kind of rule, 17 refusals (including an injection attempt), line numbers in errors,
  the 256 limit, and that an empty rule file still gives an accepting table. It cannot show nft accepts the script: that is the
  first thing to check on a machine that has it (`nft -c -f`), recorded in docs/BUILD.md.
- Nothing is applied by this step, so it changes no behaviour of the installed package.
