# 0034 — One list of rules; profiles withdrawn

Status: accepted (0.7.1); supersedes [0033](0033-profiles-are-saved-rules.md)

## Context

0.7.0 added `wiretap profile`: named copies of the rules, kept per user. The owner objected: they want one way of doing things and one source of truth, with safety first.

## Decision

1. **`/etc/wiretap/rules` is the only list.** `wiretap profile` is removed in 0.7.1. Files already saved in `~/.config/wiretap/profiles` are the user's data and are not touched.
2. **Why.** Copies drift: nothing says which is in force, and after any edit the live rules match none. `use` replaced the whole list without showing what it dropped, so a rule added after the last `save` vanished silently. Profiles are per user while the rules are per machine, so whoever ran `use` last decided for everyone.
3. **Not a reason.** An empty rule list allows everything; that is the documented design and `fw rm` reaches it too.

## Consequences

- Possible later, each only on the owner's say-so: one step back (the root helper keeps the previous rules, `fw undo` restores them), and rules that carry an optional condition such as the network, still one list. Both wait for the firewall to have run on a real `nft` (`docs/BUILD.md`).
