# 0027 — The Firewall section of the pane: show the rules, one switch

Status: accepted, built. Follows [0026](0026-wiretap-fw-in-the-command.md).

## Decision

- The pane gets a **Firewall** section (after the Menu Bar rows, and also when the monitor is not running: the firewall does not need it).
  With no rules it says so and how to add one. With rules it shows a **Firewall** switch, then the first five rules numbered, and a count of the rest.
- **The switch means "the table is loaded"**: on is `wiretap-rules.service` active (the unit loads the kept rules and removes them on stop,
  ADR 0025). Flipping it asks the helper for `off` or `on`, through `pkexec`, in the background so the pane does not freeze behind the password
  prompt; the next poll shows the result. Without kept rules there is no switch to flip.
- **Rules are not edited in the pane.** A rule has six fields and a list that must be checked before it is applied; the command does that
  (ADR 0026), and a form in a settings list would be a worse copy. The pane says "wiretap fw block HOST PORT --tcp". A "block this host"
  action in the window's Hosts tab is the better place for a graphical edit and is a later step.
- `WT_RULES` (the file), `WT_FW_STATE` (a file that exists when "on"; test only) and `WT_RULES_HELPER` (run as the caller, grants nothing) make it testable.

## Consequences

- `tests/pane.sh` (35): the rows with no rules, with rules, comments left out, on and off, more than five, the helper asked for off then on, no helper.
- Needs a look by eye on a real desktop, like the colours: the harness reads text.
