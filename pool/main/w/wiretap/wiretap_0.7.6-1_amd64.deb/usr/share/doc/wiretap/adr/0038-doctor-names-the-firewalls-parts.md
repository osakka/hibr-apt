# 0038 — `wiretap doctor` says whether the firewall's parts are there

Status: accepted (0.7.5)

## Context

The firewall needs `nft` (the `nftables` package), the root helper and polkit's `pkexec`. A machine without them found out only when an apply failed. The build machine has no `nft`, so the firewall has never run for real; the owner will be the first to try it.

## Decision

`wiretap doctor` prints one `firewall` line: its parts are installed, or what is missing (`nft`, the helper, `pkexec`). It is information only: it never makes `doctor` fail and never changes the exit status, because a machine that only monitors is not out of step. The installed line does not claim the firewall works; it says it has not been tried until a rule is applied.

## Consequences

- It checks that the programs exist, not that polkit would authorise them or that `nft` accepts the rules; `docs/BUILD.md` still has the real checklist.
