# 0025 — The root helper: one verb, rules on stdin, a clean environment, polkit

Status: accepted, built, tested with a fake nft. Follows [0024](0024-applying-rules-check-then-apply-then-fail-open.md).

## Decision

- **`/usr/libexec/wiretap-rules VERB`** is the only thing that changes the firewall. Verbs: `apply` (rules on stdin: check, apply, keep
  them), `on` (apply the kept rules), `off` (delete the table, stop applying at boot), `show`. It takes nothing else from the caller:
  one argument, and a second one is a usage error.
- **POSIX sh, not a hibr script.** It runs `env -i /usr/bin/hibr -c 'mod load /usr/lib/hibr/wiretap.so; wt fwapply FILE'`: the packaged
  module, an empty environment, a path under the helper's own control. A caller's `HIBR_*`, `PATH`, `LD_*` or `HOME` cannot steer a
  process that runs as root. (pkexec scrubs most of the environment already; this does not rely on that.)
- **polkit action `org.wiretap.rules`**, annotated with the helper's path: `auth_admin_keep` for the active session,
  `auth_admin` otherwise. Changing the firewall asks for an administrator; a person who is in the group `wiretap` can *see* traffic
  but not change rules.
- **Rules are kept only when they applied.** The new rules are written to a temp file in `/etc/wiretap` (root-owned, 0755) and moved
  over `/etc/wiretap/rules` after `nft` accepted them. A failed `apply` leaves the previous rules in place and the table removed
  (ADR 0024), so a bad edit means "open", not "unknown".
- **At boot**, `wiretap-rules.service` (a oneshot, before `network-pre.target`) runs `on`; its `ExecStop` runs `off`, so stopping it opens
  the machine. It has `ConditionPathExists=/etc/wiretap/rules`. The helper enables it the first time rules are kept and disables it on
  `off`: the first `apply` is what turns the firewall on across reboots, not installing the package.
- **Test overrides** (`WT_RULES_DIR`, `WT_MODULE`, `WT_NFT`) are honoured only when the helper is not root.
- Input is limited to 64 KiB, as the module's is.

## Packaging

`nftables` is a **Recommends** (deb, rpm) / optdepends (arch), not a hard dependency: the monitor does not need it, and most people who
install wiretap to look at traffic should not be forced to carry a firewall package. Without it `apply` says so and changes nothing
(ADR 0024). This corrects the note in ADR 0022 that suggested a hard dependency.

## Consequences

- `tests/rules.sh` (21 checks): each verb, the keep-only-on-success rule, the environment not reaching nft, oversize input, the unit and
  the policy file. The polkit rule itself, `pkexec` and a real boot are not testable here; first checks on a real machine are listed in BUILD.md.
