# 0029 — Block and allow from the window: a Firewall tab, a dialog on b, per program by control group

Status: accepted, built. Extends [0028](0028-block-a-host-from-the-hosts-tab.md).

## Decision

- **A fourth tab, Firewall** (`f`, or click, or tab): whether the firewall is on (the boot unit is active), how many rules are kept, and the
  rules numbered in columns ACTION DIR PROTO WHO HOST PORT. `x` asks to remove the selected rule; `space` loads or removes the table.
- **`b` in Usage or Hosts opens a short dialog** for the selected row: block or allow (`b`/`a`), then the protocol (`a` any, `t` tcp, `u` udp), then,
  for tcp and udp, a port (digits and enter, enter alone for any). Escape cancels at every step. The rule it writes is
  `ACTION out PROTO WHO HOST PORT`; the engine checks the whole text, then the root helper applies it (ADR 0025).
- **The target is the row.** On a Hosts row it is the address (`WHO any`). On a Usage row it is the program's control group
  (`WHO cgroup:/path`), read from `/proc/PID/cgroup`.
- **A program is offered only when a rule can name it alone** (ADR 0022). Its cgroup must be its own scope or service: not a login session
  (`session-N.scope`), the user manager (`user@N.service`), `init.scope` or a slice, because those hold many programs and a rule would
  take them all; and every character must be in the rule's alphabet (systemd escapes such as `\x2d` in a unit name are not, so those programs
  are refused too). Otherwise the footer says "does not run in a control group of its own" and nothing is written.
- **Marks**: `✕` blocked and `✓` allowed, at the left of a Usage or Hosts row, only when the kept rules hold exactly the rule the dialog writes
  for that row with protocol and port `any`. A rule with a port or a protocol is in the Firewall tab but does not mark the row, because it covers
  only part of what the row stands for. `b` on a marked row asks to remove that one rule, never the others.
- The rule file is read for marks every second; changes show when the helper has applied them (it runs in the background behind the password
  prompt), and the footer says so.

## Consequences

- `tests/window.py` (34): the tab, tab order, the dialog end to end with a recording helper (escape, block, the mark, remove, allow tcp 443 typed
  in digits, remove from the Firewall tab). `tests/pane.sh` (45): marks, exact deletion, removal by number, appending, cgroup refusals.
- Programs that share a terminal's scope cannot be blocked one by one: that is the kernel's matching, not ours.
- Incoming rules are not offered in the window (a packet has no owner yet); `wiretap fw block HOST --in` still does them.
