# 0026 — `wiretap fw`: edit the rules from the command, check before asking for a password

Status: accepted, built. Follows [0025](0025-the-root-helper-and-the-polkit-action.md).

## Decision

- `wiretap fw [list | block|allow HOST [PORT] [--tcp|--udp] [--in] [--uid N] [--cgroup /PATH] [--first] | rm N | on | off | render]`.
- **Every change is a whole new rules text**, built from the kept file and the edit, **checked by the engine (`wt fwrender`) first**, and only then
  sent to the helper. A mistake therefore costs no password and no pkexec round trip; nft's own check still follows in the helper (ADR 0024).
- **Reading needs no privilege.** `/etc/wiretap/rules` is 0644, so `fw` and `fw render` work for anyone. Whether the table is *loaded* is not
  shown (that would need root); `fw on` is idempotent.
- **No port without a protocol.** `fw block HOST 443` is refused with "a port needs tcp or udp" rather than guessing tcp, because DNS (53) is
  udp and the wrong guess blocks nothing while looking done.
- **New rules go at the end**; `--first` puts one at the top, which is how an `allow` overrides a later `block`.
- `WT_RULES_HELPER` names another program in place of the helper and is run as the caller, so it grants nothing; it is how `tests/rules.sh`
  drives the command. `WT_RULES` moves the rules file the command reads.

## Consequences

- `tests/rules.sh` grew to 36 checks (the command section: adding, `--first`, `--uid`, `--in`, refusals before the helper, `rm`, `on`/`off`, no helper).
- The pane is next; it will call the same functions.
