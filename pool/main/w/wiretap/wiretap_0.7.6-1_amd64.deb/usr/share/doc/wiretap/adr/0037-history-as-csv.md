# 0037 — `wiretap history --csv`: the first slice of a usage export

Status: accepted (0.7.4)

## Context

M3 lists a usage report export. The numbers a person wants out of the node are who used the most over a window, which `wiretap history` already prints, in sizes meant for reading (`1.2M`), and `--json`, which is the node's raw reply.

## Decision

1. `wiretap history [1h|24h|7d] [N] --csv` prints `app,down_bytes,up_bytes,total_bytes,window`, one row per program, **exact bytes** (no rounding to K or M), so a spreadsheet can sum them.
2. **A program's name is not trusted.** It comes from a process's own name. Each name is quoted with its quotes doubled, and a name that begins with `=`, `+`, `-` or `@` gets a leading `'`, so a spreadsheet shows it as text and does not run it as a formula.
3. With no rows the output is the header alone; the "nothing yet" sentence is for people, not for files.
4. It writes to standard output only. Nothing is saved or sent anywhere; redirect it if you want a file.

## Consequences

- The same keeps for the window later (an export key) without a new format.
- Not done: `usage --csv` and `hosts --csv` (the same shape; add if wanted), a time column per slot, and a choice of delimiter.

## Addendum (0.7.6): `usage --csv` and `hosts --csv`

The same shape for the other two tables, with the same name quoting.
- `usage --csv`: `app,pid,attributed,down_bytes,up_bytes,total_bytes`, exact bytes since the node started.
- `hosts --csv`: `address,app,down_bytes,up_bytes,seconds_ago`. It is addresses only: an export never looks names up, so it never tells a name server what the machine talks to (ADR 0036). `--names` and `--csv` together give the CSV.
- `top --csv` is not offered; the rate view is for watching, not exporting.
