# Build, test, package

Needs `tcc`, hibr >= `HIBR_MIN` with its headers (`HIBR_SRC`, default `../hibr`), python3; for packages `dpkg-deb`, `fakeroot`,
`objdump`, `rpmbuild`, `makepkg`.

```
make              # build/wiretap.so (TCC only; `make CC=...` is ignored on purpose)
make check        # lint, then every suite: engine units (under TCC's bounds checker), the node, the control socket,
                  # real packet capture in an unprivileged namespace, the CLI, the pane reader, the Tap and the window on
                  # the real desktop through hibr's pty harness, the docs, the packages
make packages     # build/pkg: wiretap_<v>-1_<arch>.deb, then .rpm and .pkg.tar.zst from the deb's files
sh packaging/bump.sh X.Y.Z   # the one way to change the version
```

Building a package is local and publishes nothing ([ADR 0011](adr/0011-delivery-is-the-same-as-longwires.md)).
Publishing to the hibr apt/rpm/arch repositories and the catalogue is a deliberate separate step, and needs the owner. Catalogue: copy the scripts into a tree with the kind folders (`cli/`, `control-panel/`, `menubar/`, `control-strip/`, `apps/`, `bundles/`), run `./addapp` on each and `./mkindex` in hibr-apps, commit, push. Packages: `packaging/{deb,rpm,arch}/publish.sh` in hibr.

## First check on a machine with nft

The firewall renderer (ADR 0022) is tested for its text only. On a machine that has `nftables`, check the script is accepted before the apply helper is written: `hibr -c "mod load build/wiretap.so; wt fwrender rules.txt" | nft -c -f -`.

On a machine with nftables and polkit, also check: `pkexec /usr/libexec/wiretap-rules apply < rules.txt` asks for a password and then `nft list table inet wiretap` shows the rules; `systemctl stop wiretap-rules` removes the table; a reboot with kept rules brings it back before the network.
