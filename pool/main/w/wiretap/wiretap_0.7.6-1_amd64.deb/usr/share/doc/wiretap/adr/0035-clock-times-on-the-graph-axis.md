# 0035 — The graph's left edge is a clock time

Status: accepted (0.7.2)

## Context

The hour, day and week graphs labelled their left edge "1 h ago", "24 h ago", "7 d ago". To find when something happened you had to do the sum yourself.

## Decision

1. On the hour, day and week scales the left label is the local clock time at that edge: `HH:MM` for the hour, `Dow HH:MM` for the day, `Dow DD Mon` for the week. The right edge stays "now".
2. The 1-minute graph keeps "60 s ago": a clock time is no clearer for a minute.
3. The label comes from the shell's own `printf '%(FORMAT)T'`, so no process is forked in a frame (ADR 0031). The edge is computed from the time now minus the scale's length; the node's data is not involved.

## Consequences

- Times are the desktop's local time zone, which is what the user's clock shows.
- When the ribbon is on, its legend begins at column 12 and the longest label (`Sat 07 Nov`, 10 characters from column 2) still fits.
- Not done: ticks in the middle of the axis, which would collide with the ribbon's legend.
