# 0021 — New-host alerts: opt-in, public addresses, a note a minute

Status: accepted. Extends [0014](0014-alerts-from-the-same-poll.md).

## Context

The plan lists a "new host" alert beside "new app" and "big upload". Unlike a program name, an address is not stable: CDNs, mobile
networks and DNS round-robin mean a normal desktop meets new addresses all day. Done naively it is noise.

## Decision

- **Off by default** (`DT_WTHOST`), a switch in the pane under Alerts: *A program reaches a new public host*.
- The unit is the **pair of the program that last spoke to an address, and the address** (the engine keeps one row per address, ADR 0016, and names the last program; the exact per-program pairs of M2 are not needed for this).
- Only **public** addresses count: private (10/8, 172.16/12, 192.168/16), loopback, link-local, multicast and IPv6's local ranges are the local network's own business. `(unattributed)` traffic is not told.
- **The first run takes every pair as known**, silently. The pairs are kept in `hosts` beside the known-programs file (`$XDG_STATE_HOME/wiretap/hosts`), up to 5000; past that it stops learning and stops telling, rather than grow without bound.
- **At most one note a minute**, saying how many and giving the first: "New host: curl to 93.184.216.34", or "3 new hosts, the first ssh to 1.2.3.4". Clicking it opens the pane, as the other alerts do.
- Script-side, from the same poll (the hosts are fetched at most every two seconds), nothing in the engine.

## Consequences

- Alerts run while the bar item is shown (as ADR 0014).
- A name is not given with the address: no resolver in the service, and none in the bar.
- `tests/pane.sh` checks the first run, public against private, the count, the file, and the switch.
