# 0002 — The service may read every process and every packet, and keeps those privileges

Status: accepted for M1; amended 2026-11-06 to add `CAP_NET_RAW` (the owner chose packet capture over `tcp_info`). Departs from longwire's [ADR 0004](../../../my-vpn/docs/adr/0004-a-node-never-runs-as-root.md) on one point, stated below.

## Context

Showing *which program* is talking needs the socket-to-process join: netlink `sock_diag` gives a socket's inode and owner
uid, and only `/proc/PID/fd` links an inode to a pid and a command name. Another user's `/proc/PID/fd` is unreadable
without `CAP_SYS_PTRACE` (the ptrace access check) and `CAP_DAC_READ_SEARCH`. The owner chose whole-machine attribution.

## Amendment: packets are the byte source

`tcp_info` counts TCP only. Browsers send most traffic to the big providers over QUIC (UDP), which would show as
"unattributed". So the engine reads packets on an `AF_PACKET` socket, parses each to its 5-tuple (protocol, local and
remote address and port), counts the frame's wire length, and finds the owner by looking the tuple up in the kernel's
socket table (`/proc/net/{tcp,udp}{,6}`) and the inode in `/proc/PID/fd`. This needs `CAP_NET_RAW` in addition to the
two below, and `AF_PACKET` among the address families. It still needs no `AF_INET*` socket: the engine cannot send
anything to a network, and the capture socket is receive-only (it never calls `send`).

## Decision

- The engine runs as the service `wiretap.service`, `DynamicUser=yes`, never as root, with exactly
  `AmbientCapabilities=CAP_SYS_PTRACE CAP_DAC_READ_SEARCH CAP_NET_RAW` and the same three in `CapabilityBoundingSet`.
- **It does not drop them after start.** longwire drops its one capability once its socket is open; wiretap re-reads
  `/proc/*/fd` on every sample for the life of the process, so it cannot. What it does instead: `NoNewPrivileges=yes`;
  `ProcSubset` unset and **no** `ProtectProc=invisible` (that option would hide the very processes it must see); a
  `@system-service` call filter; read-only filesystem except its state directory; no `AF_INET*` sockets at all
  (`RestrictAddressFamilies=AF_UNIX AF_PACKET`), so a compromise cannot send what it read anywhere.
- The engine never writes to a process, never calls `ptrace(2)`, and only reads. Its code says so in one place
  (`engine/proc.c`) and the test suite greps for any other use of `/proc` paths.
- The control socket is `/run/wiretap/ctl`, mode 0660, group `wiretap`; a member of the group reads, and in M1 nothing over
  the socket can change anything.

## Consequences

This is the one real privilege in the product, so it is listed first in `SECURITY.md`. A bug in the reader is a
read-everything bug, not a write bug, and the no-network rule is what keeps that contained. M2's firewall does **not**
widen this service: rules are written by a separate polkit root helper (`org.wiretap.rules`), as longwire's jack helper is.
A user outside the group sees only their own processes through an unprivileged fallback.

## Verified (0.1.2)

Run for real under systemd on the build machine: as the dynamic user `wiretapd`, with exactly the three capabilities effective and ambient, the service captured packets and read the `/proc/PID/fd` of other users' processes (`wiretap doctor`: processes all readable; `wiretap top` names sshd, rsyslogd, nslcd, chromium). An unprivileged node on the same machine reads the same set only partly.
