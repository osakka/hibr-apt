# 0019 — One colour per program: a categorical palette

Status: accepted.

## Context

The Tap, the Usage tab and the Hosts tab list programs, and until now every row looked alike (one hue for the meters). The owner wants a
visual bonanza: a program should be recognisable by colour across all three.

## Decision

- **Eight hues in a fixed order**, the validated default of the dataviz method: blue, orange, aqua, yellow, magenta, green, violet,
  red. Validated with its `validate_palette.js` on the adjacent pairs, against its reference surfaces: light, worst adjacent colour-blind
  distance 9.1 and normal-vision 19.6; dark, 8.4 and 19.3 (targets: at least 8 and 15); lightness band and chroma floor pass in both. In light mode three hues (aqua,
  yellow, magenta) are under 3:1 contrast with the surface, which the method answers with visible labels: every colour mark here has the
  program's name beside it in ordinary ink, and the Usage table is the table view.
- **The two columns**: the desktop's face (`DT_FACE`, `#rrggbb`) decides: a luminance of 128 or more is a light face, anything else dark.
  The desktop's own surface may differ from the reference's, so the validation is of the palette, not of every theme.
- **The colour follows the program, not its rank**: the first program seen gets the first hue, the next the next, in order of first
  appearance for as long as the desktop runs; after eight they repeat (a ninth program is not given a ninth, invented hue). Across restarts the assignment can differ; it is not saved.
- **Buckets are never a hue**: `(unattributed)`, `(root)`, `(user N)`, `(other)` are DIM.
- Used as a mark, never as text: a `▌` swatch before the name (Usage, Tap) or the app column (Hosts), and the Tap's meter. The words stay in ink.
- `wtp_hue NAME` in the pane's reader (control-panel/wiretap.hibr), tested in `tests/pane.sh`.

## Consequences

- A ribbon of stacked per-program colour over time (the original idea) needs per-program history from the engine and is not done; this
  is the palette it would use.
- The harness reads text, not colour: the colours themselves are only checked by the function's tests, and by eye.
- Found on the way: the Tap divided `rx5` by five again, as the Usage tab did (ADR 0014, 0018); fixed.
