# 0031 — The desktop never waits on the node

Status: accepted (0.5.2)

## Context

The menu-bar item's ticker called `wtp_poll`, which ran `wt status`, `wt apps` and `wt series` in the desktop's frame loop. A slow node
made each call wait up to the module's 2 s read limit, and the desktop (one process, one frame loop) relays no program frames while a
callback runs: a game in a window froze for about 2 s, roughly once a minute (`held: wtb_tick held the desktop 2004 ms`, reported from a
real machine). The desktop's own rule (hibr's WRITING.md) is that a callback finishes in a few milliseconds and slow work is
a job.

The node could be slow for a real reason: a full rescan of `/proc` for sockets and owners, run every 5 s and again after any miss, takes
long on a machine with a game under Proton (many processes and descriptors), and a miss-driven rescan was allowed as often as every 100 ms.

## Decision

1. Every read of the node from the desktop is a job (`dt_jobvars`): the reading (`wtp_read`: status, apps, the last minute, and whether
   the firewall unit is active), the range for the graph (`wtp_rfetch`), the per-program ribbon (`wtp_asfetch`) and the hosts
   (`wtp_hfetch`). Each has a callback that sets the variables and asks for a frame. A job in flight is waited for, never started twice.
   Drawing and ticking use the last answer. Where there is no desktop (the tests, the command line) the same functions read directly, and
   `WTP_SYNC=1` forces that.
2. Until the first answer the window says nothing (`WTP_SEEN`), instead of "No wiretap node answers".
3. Nothing started in a frame: the cgroup lookup is remembered by pid, the kept rules are read without a program (`wtp_fw_read`), and
   `systemctl is-active` moved into the reading.
4. The module waits at most 700 ms for a reply (it was 2 s). The node answers a local request in microseconds, so a longer wait is only a
   node that is busy.
5. The node bounds its own rescans: a scan may use at most a tenth of the time (the next miss-driven rescan waits nine times the last
   one's cost), and `status` reports `refresh_ms` and `refresh_max_ms` so a slow machine can be diagnosed.

## Consequences

The picture lags the node by up to a job's latency (well under a second); a machine where the node is slow shows a stale picture and no
longer freezes. Tests that look at a window right after starting it must wait for the first reading (`TermR` in `tests/window.py`).

## Verified

On the owner's mini PC, a day with games after the 0.5.2 install (2026-11-14): no `held: wtb_tick` entry since the install (141 before it, the last on 2026-11-13), no freezes reported, and `wiretap status` shows `refresh_ms` 16 and `refresh_max_ms` 19. The synchronous poll was the cause; the `/proc` rescan was not.
