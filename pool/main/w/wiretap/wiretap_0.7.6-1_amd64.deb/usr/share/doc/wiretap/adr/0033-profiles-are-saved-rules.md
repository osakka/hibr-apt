# 0033 — Profiles: a name for a set of rules, kept per user

Status: superseded by [0034](0034-one-list-of-rules-no-profiles.md) (0.7.0 shipped it; 0.7.1 withdrew it)

## Context

Rules are one machine-wide list in `/etc/wiretap/rules`. People want a different set in different places: strict on public Wi-Fi, open at home. Re-typing rules, or editing the file, is what profiles replace.

## Decision

1. **A profile is only text.** `wiretap profile save NAME` copies the current rules to `~/.config/wiretap/profiles/NAME` (mode of the user's umask; `WT_PROFILES` overrides the directory). Nothing privileged is stored or changed by saving.
2. **`use` is an ordinary rule change.** `wiretap profile use NAME` reads the file and gives it to `wt_fw_set`: the engine checks the whole text first, then the root helper applies it under the polkit action `org.wiretap.rules`, as for `fw block`. A profile therefore grants nothing a user could not already do, and a bad or hand-edited profile is refused before any password is asked. The helper and the polkit action are unchanged.
3. **Names are slugs.** Letters, digits, `-` and `_`, at most 40, so a name can never be a path (`../x` is refused). "Public Wi-Fi" is `Public-WiFi`.
4. **Commands:** `profile [list]`, `save`, `use`, `show`, `rm`.

## Consequences

- No new attack surface: the only new code reads and writes files in the user's own directory.
- Profiles are per user, the rules are per machine: whoever runs `use` last decides the machine's rules. This is the same as `fw` today.
- Not yet: a profile picker in the window and the pane, and switching by network name. Both need a place to ask; the command is the base for them.
