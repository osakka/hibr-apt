# 0018 — The hosts tab in the window

Status: accepted. Extends [0008](0008-the-window-reads-timescales-through-the-pane.md).

## Context

The engine counts remote addresses (ADR 0016) and the CLI shows them; the window had a Graph and a Usage tab.

## Decision

- A third tab, **Hosts** (key `h`, a click on its label, View > Hosts; Tab cycles Graph, Usage, Hosts): one row per remote address, the
  biggest first: the address, the program that last spoke to it, bytes down and up since the node started, and seconds since it was last heard.
  Up and Down move the selection, as in Usage.
- The pane's reader asks for `hosts 200` at most every two seconds (`wtp_hosts`, `WTP_H`); the tab draws what it has.
- **Addresses, not names.** A lookup from the window would stall it (a name server can take seconds) and the service cannot do one; `wiretap hosts --names` names them in a terminal. A background resolver with a cache is a later slice.
- **A fix found on the way:** the Usage tab divided `rx5`/`tx5` by five again (they are already bytes a second), so it showed a fifth of the real rate; as with ADR 0014's correction, the value is used as it is.

## Consequences

- `tests/window.py` draws the tab on the real desktop from a fixed reply (so the populated table is checked on known rows) and checks the empty message from a real node that captures nothing.
