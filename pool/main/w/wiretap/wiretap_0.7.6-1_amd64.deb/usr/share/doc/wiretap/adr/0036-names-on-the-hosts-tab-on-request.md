# 0036 — Names on the Hosts tab, on request, looked up in a job

Status: accepted (0.7.3); finishes the slice ADR 0018 deferred

## Context

The Hosts tab shows addresses only (ADR 0018). The service cannot look names up (it has no IP sockets), and a lookup in a frame would stall the desktop for seconds (ADR 0031). `wiretap hosts --names` names them in a terminal.

## Decision

1. **Off by default; `n` in the Hosts tab turns it on and off.** A reverse lookup tells the name server which addresses this machine talks to. That is a disclosure, so it is the person's choice, and the footer note says so when it is turned on ("your name server is asked about the addresses shown").
2. **A job, never a frame.** The addresses on screen that are not yet known (at most 12 at a time, one job at a time) go to `getent hosts` with a two-second limit, in a desktop job (`dt_jobvars`). Nothing waits in a frame; the callback merges the answers and asks for a redraw.
3. **Kept for the session.** Each address is marked as soon as it is asked, so a slow or failed lookup is not repeated every frame; a miss stays as the address. The cache is in memory only and is not saved.
4. **Only plain addresses are asked.** Characters other than hex digits, `:` and `.`, and anything over 45 characters, are dropped before `getent` sees them, so a value from the node can never become an option or a command.

## Consequences

- With names on, a row shows the name in the address column (cut to 39); the address is still the key for block and allow, and `b` works on the selected row as before.
- Not done: a saved cache, a time limit on cached names, and resolving names of rows scrolled out of view until they scroll in.
