# 0030 — "A new program talks": ask after, open the window on it; no prompt before the first packet

Status: accepted, built (the note's action); the before-the-packet prompt is declined.

## Context

GlassWire-style firewalls ask "allow this program?" the first time it connects, holding the connection until you answer. Holding a packet
needs the kernel to queue it to a program (nfnetlink_queue, `libnetfilter_queue`), which is another library (ADR 0023, libc only), a
privileged process that must answer in milliseconds forever (a crash or a slow prompt stalls every new connection on the machine), and
a way to name the program at that moment (the socket is only just being created; ADR 0022 already limits naming to cgroup and uid).

## Decision

- **No queue, no hold.** wiretap does not delay any packet. Its firewall stays what ADR 0022 says: ordered rules, nothing matching is allowed,
  open on any failure.
- **Ask after.** The existing alerts (ADR 0014, 0021) already tell, within seconds, that a program is new, uploading a lot, or reaching a new
  host. Their notification now opens the **window on the Usage tab** (or Hosts for a host), where `b` blocks or allows it in two keys (ADR 0029).
  Before, it opened the pane.
- **A person who wants "nothing new gets out until I say" can already have it**, with the rules and no new code: allow what is wanted, then
  end the list with a catch-all, `wiretap fw block any`. Everything not allowed above it is blocked, a new program is blocked on arrival,
  and the alert says it appeared. The cost is theirs to weigh: DNS, DHCP and updates need allow rules first; `wiretap fw off` opens it again.
  It is not a switch in the pane, because a button that can cut off the network by itself is not one to put there.

## Consequences

- The first packets of a new program may leave before the note. That is stated here and in the docs rather than hidden.
- `tests/pane.sh` (48) checks the action and the view it sets; `tests/window.py` (35) that a window opened this way starts on Usage.
- If a hold is ever wanted, it is its own helper process and its own ADR, not part of the monitor or of this step.
