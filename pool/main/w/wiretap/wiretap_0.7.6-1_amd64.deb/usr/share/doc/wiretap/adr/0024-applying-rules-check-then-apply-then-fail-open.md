# 0024 — Applying rules: check, then apply, and any failure leaves the machine open

Status: accepted for the module commands (built, tested against a fake `nft`); the root entry point and the polkit action are the next step.
Follows [0022](0022-the-firewall-rules-and-their-nftables-script.md).

## Decision

- **`wt fwapply FILE|-`** renders the rules (ADR 0022), runs `nft -c -f -` on the script, and only if that passes runs `nft -f -`.
  A rejected check changes nothing and returns nft's own message. If the real apply fails, it **deletes the wiretap table** and says
  so: a half-applied or unknown state is never left in place. **`wt fwoff`** deletes the table.
- nft is run by `execve` with a fixed argument list, **no shell and an empty environment**; the script goes in as a memfd, so neither side
  can block on a pipe; stdout and stderr are captured for the error text. If `nft` is missing the command says the firewall needs the
  `nftables` package and changes nothing.
- **The path of nft is fixed for root.** `--nft PATH` exists so tests can use a fake, and is honoured only when the caller is *not*
  root (effective uid). A root helper therefore cannot be pointed at another program.
- Both commands need CAP_NET_ADMIN. The monitor service has none and its unit forbids AF_NETLINK, so the monitor can never apply rules.

## Next (built in ADR 0025)

The root entry point: a fixed-purpose program installed under `/usr/libexec`, run through `pkexec` under a polkit action
`org.wiretap.rules` (`auth_admin_keep`), taking **no arguments from the caller** beyond a verb (`apply`, `off`) and reading the rules
from standard input, so nothing in a command line or environment is under the user's control. It keeps the active rules in
`/etc/wiretap/rules` (root-owned, 0644) and a boot-time unit re-applies them. It is not a hibr script run by root with the caller's
environment; that shape would let the caller's `HIBR_*` settings steer a root process, so it is decided before it is written.

## Consequences

- `tests/fw.sh`: argument order (check then apply), the empty environment, the script on stdin, the three failure paths, bad rules never
  reaching nft, no nft installed. Skipped when run as root (the override is off there). Against a real nft: still to do (BUILD.md).
