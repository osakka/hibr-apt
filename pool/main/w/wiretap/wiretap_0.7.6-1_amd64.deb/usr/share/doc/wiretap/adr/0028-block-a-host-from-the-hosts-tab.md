# 0028 — Block a host from the Hosts tab: one key, one question, a mark

Status: accepted, built. Follows [0027](0027-the-firewall-section-of-the-pane.md).

## Decision

- In the window's **Hosts** tab, **`b`** on the selected row asks "Block ADDR for every program? y = block, any other key = cancel". `y` writes the
  rule `block out any any ADDR any` through the same path as the command (the engine checks the whole new text, then the root helper behind
  pkexec); any other key cancels and nothing is sent.
- **A blocked host is marked `✕`** at the left of its row, found by reading the kept rules for exactly that rule. `b` on a marked row asks
  "Stop blocking ADDR?" and, on `y`, takes out only that rule line, keeping every other rule and comment.
- The helper is run in the background (a password prompt must not freeze the window), so the mark appears when the rules file changes, not
  when `y` is pressed; the window says so ("the mark follows when it is applied"). If the helper is missing or the engine refuses the rule, a
  notification says why.
- **Per host, not per program**: the rows are the engine's one-row-per-address (ADR 0016), and the program shown is only the last one that spoke
  to it. A program-and-host rule needs a cgroup or uid (ADR 0022), which the Hosts row does not have; it stays a `wiretap fw` job.
- The rule logic lives in the pane's file (`wtp_fw_host`, `wtp_fw_blocked`), which the window already loads.

## Consequences

- `tests/window.py` (24): ask, cancel, apply through a recording helper, the mark, unblock, down-then-b picks the next row.
  `tests/pane.sh` (39): both addresses, only-that-rule removal, an injected address refused before the helper.
- Not seen on a real desktop with a real polkit agent; the mark depends on the rules file being readable (0644).
