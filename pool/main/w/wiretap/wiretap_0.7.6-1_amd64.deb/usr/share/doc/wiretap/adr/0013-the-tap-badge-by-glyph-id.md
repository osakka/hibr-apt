# 0013 — The tap badge, named by glyph id, with the bullseye as the fallback

Status: accepted.

## Context

The owner did not like the `◎` glyph and asked Blit for a logo that looks like a tap. Blit (hw-manager) draws two states as two-cell
colour badges, water blue `#2e8fe0`: ON, a tap with a drop (`wiretap-left`, `wiretap-right`), and OFF, the same tap without the drop
(`wiretap-off-left`, `wiretap-off-right`). Codepoints U+1002C7..U+1002CA are planned, and shipped in Blit 0.3.52 (confirmed: U+1002C7..U+1002CA). The SVG sources are in `brand/` (`wiretap.svg`, `wiretap-off.svg`, from Blit's `assets/fonts/icons/`), water blue `#2e8fe0`.

## Decision

- Wiretap names the badge by **id**, never by codepoint. `wtp_logo on|off` (control-panel/wiretap.hibr) calls the desktop's
  `dt_blitread` and `dt_bg` for those ids and returns the badge, or nothing.
- **Fallbacks** (Blit's suggestion): the unicode and nerd sets get 🚰 U+1F6B0 POTABLE WATER, a tap; ascii gets `T`. Where no id is in Blit's catalogue (an older Blit) nothing is added. The Tap's rates start after the title, whatever its width.
- The two-cell badge only exists under the **Blit glyph set** (`DT_GLYPHSET=blit`); `dt_bg` leaves a name alone where this Blit has no such id. Everywhere else
  and on an older Blit, `wtp_logo` prints nothing and the existing look stands, so nothing changes until the glyphs ship.
- Used where there are two cells to give: the **bar item** (ON while a node answers, OFF with none) and the **drop-down's title**. The **Control Strip
  module and the pane tile are one cell wide and wear the one-cell tap** (Blit 0.3.53 added a one-cell tap, `wiretap-1` on and `wiretap-1-off` off, U+1002CB and U+1002CC; they use it, with `T` as the fallback).
- The SVG sources are copied to `brand/` for the README.

## Consequences

- The scripts can be published before Blit 0.3.52: they behave as before until the ids exist.
- `tests/m0_tap.py` draws the real desktop with a fixture catalogue under the Blit set and checks the badge is on the bar.
