# 0014 — Alerts: two of them, read from the same poll, said through the desktop's notifications

Status: accepted.

## Context

The plan lists alerts (a new program talks, a big upload). Every fact they need is already in the `apps` reply the bar polls each second: names, and bytes sent and received in the last 5 s (`rx5`, `tx5`). Doing them in the engine would mean a second state to persist and a notification channel the engine does not have.

## Decision

- Alerts are **script-side**, in the pane (`wta_scan`, control-panel/wiretap.hibr), run by the bar's ticker after each poll; they are said with the desktop's `dt_notify`, and clicking one opens the Wiretap pane. The engine and the socket are unchanged.
- **New program:** a name not yet in the known file (`$XDG_STATE_HOME/wiretap/known`, `WT_KNOWN` overrides it) that has moved bytes. It is learned either way and announced once. **The first run (no file) takes everything talking as known**, silently. The buckets in brackets are never announced.
- **Big upload:** a program whose `tx5` (a rate: bytes a second, averaged over 5 s) reaches `WT_BIG` (4 MB/s) is announced with its rate, **at most once in ten minutes per program**.
- Two settings in the pane, both on by default: *A program talks for the first time* (`DT_WTNEW`) and *A program uploads a lot* (`DT_WTBIG`).

## Consequences

- Alerts fire while the bar item is shown (its ticker drives them); with the menu bar item off there are none. A later slice may give the pane its own ticker.
- A program is recognised by its name only, so a renamed binary is new. Known names accumulate in the file; it is a plain list to edit.
- No new-host alert yet: hosts are not in the engine (ROADMAP).
- `tests/pane.sh` checks the decisions with a stubbed `dt_notify`.

## Correction (0.1.6)

0.1.4 treated `rx5`/`tx5` as bytes in 5 s and divided the rate again. They are already bytes a second (averaged over 5 s), so 0.1.4 alerted at 20 MB/s and printed a fifth of the real rate. The threshold is now 4 MB/s and the rate printed is the value itself.
