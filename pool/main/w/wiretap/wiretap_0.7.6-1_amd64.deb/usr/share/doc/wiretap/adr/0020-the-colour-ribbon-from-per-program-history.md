# 0020 — The colour ribbon: per-program history, for the last minute

Status: accepted. Uses the palette of [0019](0019-one-colour-per-program.md).

## Context

The plan's "per-app ribbon (stacked, coloured by app)". The engine already keeps each program's last 60 seconds (a slot a second, for
the meters), and nothing asked for them as a series.

## Decision

- **`appseries [N]`** (N 1 to 32, default 8): the busiest N attributed programs, each with `rx` and `tx` as 60 values, oldest second
  first (the last is now), `{"now","count":60,"apps":[{"name","rx":[..],"tx":[..]}]}`. The buckets in brackets are not in it (the
  ribbon's remainder is whatever the total has beyond the programs). Digits only, checked by the module and again by the node.
- **The window's 1-minute graph is stacked by program**: a column a second, each program in its own hue (ADR 0019) from the axis
  outwards in rank order, and the rest in DIM on top; download above the axis, upload below. A cell is coloured by the program at its
  middle, the top cell by the top of the column, so a thin program can vanish at five rows of height; the legend (a swatch and a name
  per program, in the time-label row) says who is in it. `c` (or View > Colour by Program) turns it off.
- **Only for the last minute.** The longer rings (an hour, a day, a week) are totals, not per program, and keeping per-program history
  for them is a larger change (a ring per program, persisted); those timescales stay one colour.
- The reader is `wtp_appseries` in the pane (at most once a second, 960 reads, about 7 ms).

## Consequences

- Found on the way: the node's `apps` request matched on a prefix, so `appseries` was answered as `apps`; it now matches the whole word.
- `tests/attr.c` checks the series (order, buckets left out, limit, old seconds as zero, a small buffer), `tests/ctl.sh` the request and its input checking, `tests/capture.sh` real traffic, `tests/window.py` the legend and the switch.
- The colours are not checked by the harness (it reads text); by eye on the real display.
