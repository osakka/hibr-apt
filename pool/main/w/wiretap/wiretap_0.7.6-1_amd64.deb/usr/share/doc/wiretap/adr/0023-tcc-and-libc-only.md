# 0023 — The engine and module are built with TCC and need nothing but libc

Status: accepted (2026-11-06; recorded after the fact, it has been the rule since the first commit).

## Context

wiretap is a hibr module, and hibr's own native code is built with TCC (the Tiny C Compiler) alone, as longwire's is. The engine
runs as a service with three capabilities (ADR 0002), so what it links and what it parses matter more than usual.

## Decision

- The only compiler is `tcc` (`override CC = tcc` in the Makefile, so `make CC=...` cannot change it), with no optimisation flags.
  `make lint` turns TCC's warnings into errors; the tests that touch memory run under TCC's bounds checker (`tcc -b`).
- The engine and module include only libc and the kernel's headers. No other library is linked: not libpcap (the packet reader is
  `pkt.c`), not a JSON library (`json.c`), not libnftables (ADR 0022).
- The privileged parts are small enough to read: the engine is one translation unit (`engine/all.c`).

## Consequences

- Building needs `tcc` and hibr's headers and nothing else; the three packages are built from the same binary.
- Anything that wants a heavier library does it in a separate process (the `nft` binary for the firewall), never in the module.
- It costs us writing small parsers ourselves, which is why each has a test against real kernel output, not only fixtures.
