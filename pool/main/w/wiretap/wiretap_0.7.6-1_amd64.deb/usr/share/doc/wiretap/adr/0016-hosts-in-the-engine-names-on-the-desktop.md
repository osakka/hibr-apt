# 0016 — Hosts: the engine counts remote addresses, the desktop names them

Status: accepted. Extends [0004](0004-apps-are-keyed-by-command-name-and-unreadable-owners-get-buckets.md).

## Context

The window's hosts view, a "new host" alert and the M2 firewall (per host and port) all need to know who the machine talks to. The
packet capture already has both addresses of every frame and the join already says which program owns it.

## Decision

- `engine/hosts.c` keeps **one row per remote address**: bytes received and sent, first and last second seen, and the program that
  last spoke to it. The remote address is the packet's destination when it leaves and its source when it arrives. IPv4 is stored
  v4-mapped, so one table serves both families; the all-zero address is not a host.
- **Bounded**: 1024 rows in an open-addressing table. A full table does not grow or evict: it counts the bytes it could not keep in
  `folded`, and says so.
- **In memory only.** Hosts are not written to the history file (ADR 0009): they are more sensitive than volumes, and a restart starting empty is the safe default.
- The request is `hosts [ROWS]` (digits only, 1 to 1024, default 100): `{"now","total","folded","hosts":[{"addr","app","rx","tx","first","last"}]}`, biggest first.
- **The engine never resolves a name.** The unit allows only `AF_UNIX` and `AF_PACKET`, so the service cannot ask DNS (and should not). `wiretap hosts --names` looks each address up as the user, with a two-second limit; the window may do the same.
- Per-(program, host) pairs are not kept: a host row names the last program to speak to it. That is enough for the list and for a new-host alert; the firewall in M2 will need pairs and gets its own ADR.

## Consequences

- A group member now learns who every user talks to: SECURITY.md says so.
- Tests: unit (`tests/attr.c`: counting, v4/v6 printing, the limit, folding, a small buffer), real packets in a namespace (`tests/capture.sh`: the remote address of real traffic), and the CLI.
