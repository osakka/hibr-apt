# 0032 — A program's day and week: a minute a slot and an hour a slot, kept and saved

Status: accepted (0.6.0)

## Context

ADR 0020 made the 1-minute graph a ribbon by program, because the node kept a program's last 60 seconds. The hour, day and week graphs had
only the total, so they were one colour, and nothing said who used the most yesterday: the totals in `usage` are since the node started.

## Decision

1. **Rings per program.** Each program with a name (not the buckets in brackets) gets a ring of 1440 minute slots and 168 hour slots, made
   when it first sends a byte (about 38 KB each). They are addressed by absolute time, as the history's rings are (ADR 0009): a slot
   is valid when its tag is its own time, so there is no roll-up state and a gap is only old tags. The table still folds new names into
   "(other)" beyond 255, which bounds the memory (about 10 MB at the very worst).
2. **A request.** `apphist RES COUNT [N]`: RES 60 or 3600, COUNT up to 1440 or 168, N programs up to 32 (8 by default), numbers only, and the
   node checks them itself as it does for `series`. The reply lists the busiest N over the window (a program with no bytes in it is left out),
   oldest slot first. A day for eight busy programs is about 230 KB, under the 256 KB reply limit; a reply that does not fit is an error,
   never a cut one. The module's `wt apphist` forwards it.
3. **Saved.** `<state>.apps` beside the history: a header (magic, byte-order probe, the two capacities, a count) then per program its name,
   uid and two rings as they are in memory. Written to a temporary file and renamed, mode 0600, every ten minutes and on a clean stop (it is
   about 40 KB a program, so it is not written every minute as the history is). A file that is not this build's is ignored with a note in
   `status`, and slots from the future or older than their ring are dropped on load.
4. **Shown.** The window draws the hour, day and week as ribbons, the programs' columns grouped exactly as the total's are (the same groups of
   slots), read in a job (ADR 0031) every ten seconds. `wiretap history [1h|24h|7d] [N]` prints the same as a table.

## Consequences

The ribbon of a longer scale begins when the node first ran with this version, and a program that restarts under another name is a new row.
Unattributed, `(root)` and `(user N)` traffic are not kept per program: they are in the total only. A program's last-minute ring and its
day and week come from the same bump, so they cannot disagree.
