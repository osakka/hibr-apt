# wiretap: plan (approved; M0 done, M1 monitor published and in use, see the roadmap)

> **See every byte. Block the ones you don't like.** A GlassWire-style network monitor and firewall, native to hibr's desktop (hui).

Modelled one-for-one on longwire (`../my-vpn`): a C engine as a hibr module, built with TCC, libc only; every
thing you see and touch is a hibr script; delivered the same three ways: **packages** (deb/rpm/pacman, engine + launcher + service),
**catalogue** (scripts and desktop pieces, one bundle), **`catalogue install wiretap`**. Decisions already made: the name is
**wiretap**; it sees the **whole machine through a service**; **monitor first (M1), firewall second (M2)**.

## The five faces (all talk to one node)

| Piece | File (mirrors longwire) | What it is |
|---|---|---|
| **The Wiretap window** | `apps/wiretap.hibr` | the visual bonanza: full-screen mirrored in/out area graph, per-app ribbon (stacked, coloured by app), a time scrubber (1 min / 1 h / 24 h / 7 d), a Usage table, an Alerts list, a hosts list with reverse DNS. longwire's big view lives in an app (`switchboard.hibr`) for the same reason: a pane is too narrow |
| **The Tap** (drop-down) | `menubar/wiretap.hibr`, `dt_baripop` | click the bar item (the bar API has click, wheel and right-click, no hover) and a panel drops from it: live 60 s graph, top 5 talkers with per-app meters, an alert badge, and one-key **Open Wiretap…**. Drawn through `_popdraw`, which the desktop calls from its per-frame draw path, so it can hold a graph, not just menu rows. **Verified in M0** (`tests/m0_tap.py`, on the real desktop through hibr's pty harness): `_popdraw` asks for its own next frame with `dt_want 1000`, and the graph keeps moving with no input |
| **Control Panel pane** | `control-panel/wiretap.hibr` | settings: sampling, history length, alert rules (new app, big upload, new host), phone-home hosts, the service, and (M2) firewall profiles. The pane owns the node reader (`wtp_poll`/`wtp_get`); bar and strip call its functions (`# needs: control-panel/wiretap`) |
| **Control Strip** | `control-strip/wiretap.hibr` | one glyph, colour by load (dim / info / good / warn on an alert), click = the Tap's menu |
| **CLI** | `scripts/wiretap.hibr` (launcher `wiretap`) | `wiretap top`, `watch`, `usage --since 1h --by app`, `alerts`, `hosts`, `doctor`, `service`, and `--json` on all; (M2) `block`, `allow`, `rules` |

Menu-bar text mirrors longwire's: a mini sparkline plus the rate, e.g. `▂▃▅ 1.2M↓ 80K↑`, turning amber with an alert.
Every drawn thing degrades through `DT_GLYPHSET` (Blit pixels where the terminal draws them, braille / half-blocks on unicode, `# . -` on ascii).

## Engine (`module/wiretap.c`, `engine/*.c`, plain C99 under TCC)

A background worker, run as the service `wiretap.service` (DynamicUser). Its unit starts from longwire's `longwire@.service` but **deliberately differs in three places**, because that template fights this design: it drops `ProtectProc=invisible` (which hides every other user's `/proc/PID`, so no attribution), keeps `ProcSubset=` unset (so `/proc/net/dev` stays), and adds `AmbientCapabilities=CAP_SYS_PTRACE CAP_DAC_READ_SEARCH` with a matching `CapabilityBoundingSet`. This is the plan's one real privilege and gets its own ADR (`0002-the-service-may-read-every-process`) before any code:

1. **Interface totals**: `/proc/net/dev`, per interface, once a second. Exact.
2. **Packets**: an `AF_PACKET` receive-only socket (`CAP_NET_RAW`); each frame is parsed to a 5-tuple and its wire length counted (ADR 0002's amendment). Exact for TCP, UDP and QUIC, and for short-lived connections.
3. **Sockets to apps**: the kernel's socket table (`/proc/net/{tcp,udp}{,6}`: addresses, uid, inode) joined to `/proc/PID/fd` inodes gives pid and `comm`. Needs `CAP_SYS_PTRACE` + `CAP_DAC_READ_SEARCH`. A pid whose fds cannot be read, and a packet with no socket (kernel-owned: tunnels, forwarded, ICMP), land in "unattributed", so the totals still add up to the interface counters.
4. **Hosts**: remote address per socket, reverse DNS and a small local cache; first-seen tracking for the "new host / new app" alerts.
5. **History**: ring buffers (1 s x 1 h, 1 min x 24 h, 1 h x 30 d) in a state directory (mode 0700, DynamicUser); control socket `/run/wiretap/ctl`, mode 0660, group `wiretap`, JSON out, nothing writable from it in M1 (as longwire's).

**C handles bytes; hibr makes decisions** (alert rules, formatting, UI), and the engine's C never includes `hibr.h`, again as in longwire.

## Delivery (the same as longwire)

`VERSION`, `HIBR_MIN`, `Makefile` (`override CC = tcc`, `make check`), `packaging/{launcher.hibr,deb,rpm,arch,systemd,wiretap.sysusers,*.policy,bump.sh}`,
`bundles/wiretap.json` (members: `cli/wiretap`, `control-panel/wiretap`, `menubar/wiretap`, `control-strip/wiretap`, `apps/wiretap`),
docs (`README`, `ARCHITECTURE`, `DESKTOP`, `CLI`, `SECURITY`, `ROADMAP`, `adr/`), man pages, `tests/*.sh`, `tests/docs.py`.
User path: `please apt install wiretap` -> `catalogue install wiretap` -> Refresh Desktop. **Nothing is published to
`hibr-apps`, `hibr-apt`, `hibr-rpm` or `hibr-arch` without your say-so**: that is shared and outward-facing.

## Roadmap

| | Ships | Verifiable here? |
|---|---|---|
| **M0** | **Done.** `proto/graph.hibr` (stdout), `proto/tap.hibr` (the Tap on the real desktop: bar item, click-open drop-down, mirrored 1/8-row graph, live via `dt_want`), `tests/m0_tap.py` (5 checks pass) | yes |
| **M1** | *(in progress: ADRs 0001-0002, `engine/` history rings + `/proc/net/dev` sampler + bounded JSON, 22 unit checks; `module/wiretap.c` + `engine/node.c`: builtin `wt`, forked or foreground worker, control socket, 28 end-to-end checks through real hibr; attribution: packet parser, kernel socket table, `/proc/PID/fd` join, per-app totals (38 unit checks incl. real sockets), `AF_PACKET` capture proven end to end in an unprivileged namespace (UDP and TCP, bytes exact); CLI; pane reader and a first pane; the Tap on real node data, proven on the real desktop (ADRs 0005, 0006); the Control Strip module (ADR 0007); the window (ADR 0008); history persisted (ADR 0009); packages built locally (ADRs 0010, 0011); next: pane settings, the capability test in a real service, publishing)*  Engine (1-4), service, CLI, pane, bar + the Tap, strip, the Wiretap window, packages, docs. Read-only: it never changes a firewall | yes, except the service's capability grants (needs a throwaway unit) |
| **M2** | Firewall: a table of its own (`wiretap`), block/allow per app (cgroup v2) and per host/port, profiles, "ask before a new app talks" prompts, a root helper + polkit action (`org.wiretap.rules`), fail-open on stop; exact UDP counters | **no: `nft` is not installed on this machine** |
| **M3** | Alerts through the desktop's notifications, a Usage report export, per-host world-map view if the terminal draws pixels | yes |

## Honest limits to put in `SECURITY.md`

- Whole-machine attribution means a service holding `CAP_SYS_PTRACE`: the one real privilege here, so it gets its own ADR, a minimal seccomp filter and a group-gated socket.
- Process names are what the kernel reports (`comm`), which a process can change: the display is evidence, not proof.
- A firewall that is only the OS's (nftables) cannot stop what it can't see; and nothing here defends against root.
- Counters can miss a socket that opens and closes between two samples.

## Known M1 gaps (stated so the summary stays honest)

- **History is saved** (ADR 0009): every minute and on stop; a crash loses at most a minute, and the time down shows as a gap.
- **Apps are keyed by command name** (`comm`): three `python3` processes, or two users' `firefox`, merge into one row (pid and uid are the last seen). GlassWire groups by app too; this is by design, not a bug.
- **Programs that live under about 100 ms** can still be missed (the socket is gone before the table is read); their bytes land in the unattributed bucket.
- **A process whose descriptors cannot be read** is bucketed as `(root)` or `(user N)`, not attributed: what a user outside the service's reach sees.

## First run (the group-gated socket)

The service is the product here, so a fresh install must not show a desktop that reads nothing. Recommendation: the package's
`postinst` adds the installing user (`SUDO_USER`/`PKEXEC_UID`) to group `wiretap` and prints that a fresh login is needed; the pane's top row
says **Join the group `wiretap`, then log in again** for anyone else (longwire's wording and habit). Alternative to decide later: a polkit
action that hands a per-session grant. A user who is not in the group sees the unprivileged view of their own processes only, never nothing.

